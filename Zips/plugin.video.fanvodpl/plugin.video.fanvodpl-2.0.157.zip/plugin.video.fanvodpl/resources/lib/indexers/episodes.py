"""
    FanVodPL Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import datetime
import json
import os
import re
import sys
from urllib.parse import (parse_qsl, quote, unquote_plus, quote_plus, urlsplit, urlencode, urlparse, )

import requests
import six  # Do wywalenia - wkrótce
from ptw.libraries import apis
from ptw.libraries import cache
from ptw.libraries import cleantitle
from ptw.libraries import client
from ptw.libraries import control
from ptw.libraries import log_utils
from ptw.libraries import source_utils
from ptw.libraries.log_utils import log, fflog, _is_debugging
from ptw.debug import log_exception, fflog_exc
from ptw.libraries import playcount
from ptw.libraries import trakt
from ptw.libraries import utils
from ptw.libraries import views
from ptw.libraries import bookmarks
from xbmcplugin import addSortMethod, SORT_METHOD_UNSORTED
from resources.lib.indexers.super_info import SuperInfo

# import simplejson as json

params = dict(parse_qsl(sys.argv[2].replace("?", ""))) if len(sys.argv) > 1 else dict()


def _ff_no_poster_art():
    try:
        art_path = control.artPath()
        if art_path:
            return os.path.join(art_path, "no_poster.png")
    except Exception:
        pass
    return ""


def _ff_fast_poster_art(url):
    return re.sub(r'(/t/p/w)\d{3,4}/', r'\g<1>342/', url or "")


# --- ANDROID MOBILE SAFE MODE ---
# Problem runtime jest widoczny po STOP przy odbudowie list sezonów/odcinków
# na Android phone/tablet (m.in. Samsung / Pixel, nowe wersje Androida).
# Zostawiamy pełną ścieżkę dla PC / Android TV, a dla ryzykownych urządzeń
# włączamy tryb ochronny: mniej progress/cast/vtag oraz lżejsze infoLabels.
_FF_ANDROID_MOBILE_SAFE_MODE = None

def _ff_is_exynos():
    """Zwraca True dla urządzeń wymagających SAFE MODE.

    Nazwa historyczna zostaje, żeby nie ruszać wielu call-site'ów.
    Teraz łapiemy szerzej: każdy Android phone/tablet, nawet gdy
    ro.build.characteristics jest puste albo nie zawiera słowa 'phone'.
    PC i Android TV mają zostać poza SAFE MODE.
    """
    global _FF_ANDROID_MOBILE_SAFE_MODE
    if _FF_ANDROID_MOBILE_SAFE_MODE is not None:
        return _FF_ANDROID_MOBILE_SAFE_MODE

    _FF_ANDROID_MOBILE_SAFE_MODE = False
    try:
        import xbmc as _xbmc
        if not _xbmc.getCondVisibility("System.Platform.Android"):
            return False
    except Exception:
        return False

    def _vis(expr):
        try:
            return bool(_xbmc.getCondVisibility(expr))
        except Exception:
            return False

    def _getprop(name):
        try:
            import subprocess as _sp
            for cmd in (['/system/bin/getprop', name], ['getprop', name]):
                try:
                    return _sp.check_output(cmd, stderr=_sp.DEVNULL, timeout=1).decode('utf-8', errors='ignore').strip().lower()
                except Exception:
                    continue
        except Exception:
            pass
        return ''

    def _getprop_many(*names):
        for name in names:
            value = _getprop(name)
            if value:
                return value
        return ''

    blob = ''
    for _fp in ('/proc/cpuinfo', '/system/build.prop', '/vendor/build.prop', '/product/build.prop'):
        try:
            with open(_fp, 'r', errors='ignore') as _f:
                blob += '\n' + _f.read().lower()
        except Exception:
            pass

    board = _getprop_many('ro.board.platform', 'ro.hardware')
    characteristics = _getprop_many('ro.build.characteristics', 'ro.product.characteristics')
    sdk_raw = _getprop_many('ro.build.version.sdk', 'ro.vendor.build.version.sdk')
    manufacturer = _getprop_many('ro.product.manufacturer', 'ro.product.vendor.manufacturer')
    brand = _getprop_many('ro.product.brand', 'ro.product.vendor.brand')
    model = _getprop_many('ro.product.model', 'ro.product.vendor.model', 'ro.product.system.model')
    device = _getprop_many('ro.product.device', 'ro.product.vendor.device', 'ro.product.system.device')
    marketname = _getprop_many('ro.product.marketname', 'ro.product.vendor.marketname')
    density_raw = _getprop_many('ro.sf.lcd_density', 'qemu.sf.lcd_density', 'persist.sys.dpi')

    try:
        sdk = int(re.sub(r'[^0-9]', '', sdk_raw) or '0')
    except Exception:
        sdk = 0
    try:
        density = int(re.sub(r'[^0-9]', '', density_raw) or '0')
    except Exception:
        density = 0

    joined = ' '.join(x for x in (manufacturer, brand, model, device, marketname, characteristics, board, blob) if x)

    is_exynos = board.startswith('s5e') or 'exynos' in joined or 's5e' in joined

    tv_tokens = (
        ' tv', 'android tv', 'google tv', ' bravia', 'chromecast', 'shield', 'mibox',
        'stb', 'settop', 'set-top', 'smarttv', 'smart-tv', 'aft', 'operator_tier'
    )
    characteristics_tv = any(token in characteristics for token in ('tv', 'atv', 'stb', 'box'))
    is_touch = any(_vis(expr) for expr in ('System.HasTouchInput', 'System.HasTouchScreen'))
    is_probably_tv = characteristics_tv or any(token in joined for token in tv_tokens) or _vis('System.Platform.AndroidTV')

    mobile_vendor_tokens = (
        'pixel', 'google', 'samsung', 'sm-', 'galaxy', 'xiaomi', 'redmi', 'poco', 'oneplus',
        'oppo', 'realme', 'vivo', 'motorola', 'moto', 'sony', 'xperia', 'huawei', 'honor',
        'nokia', 'asus', 'zenfone', 'nothing', 'lenovo', 'tablet', 'phone'
    )
    is_mobile_by_characteristics = any(x in characteristics for x in ('phone', 'tablet', 'nosdcard')) and not characteristics_tv
    is_mobile_by_vendor = any(token in joined for token in mobile_vendor_tokens) and not is_probably_tv
    is_mobile_by_density = density >= 260 and not is_probably_tv

    is_android_mobile = not is_probably_tv and (is_touch or is_mobile_by_characteristics or is_mobile_by_vendor or is_mobile_by_density)

    # ZMIANA (2026-07) [BUGFIX]: fail-safe fallback - identyczny jak
    # tvshows.py (audyt PROMPT v21.67, dla agenta/bramki_log.txt, S5A/T0-T10) -
    # spojnosc miedzy tvshows.py i episodes.py.
    # NIE ZMIENIAC: warunek dziala TYLKO gdy Android potwierdzony i
    # is_probably_tv=False.
    if not is_probably_tv and not is_android_mobile and not is_exynos:
        is_android_mobile = True

    _FF_ANDROID_MOBILE_SAFE_MODE = bool(is_exynos or is_android_mobile)
    if _FF_ANDROID_MOBILE_SAFE_MODE:
        try:
            _xbmc.log(
                '[ANDROID SAFE MODE] board={0} sdk={1} density={2} characteristics={3} manufacturer={4} brand={5} model={6} touch={7} tv={8}'.format(
                    board or '?', sdk, density, characteristics or '?', manufacturer or '?', brand or '?', model or '?', is_touch, is_probably_tv
                ),
                _xbmc.LOGINFO
            )
        except Exception:
            pass
    return _FF_ANDROID_MOBILE_SAFE_MODE


def _ff_safe_info_labels(meta, label, mediatype):
    """Minimalny zestaw infoLabels dla trybu SAFE MODE."""
    data = {
        'title': meta.get('title') or label or '',
        'mediatype': mediatype,
    }
    if mediatype in ('season', 'episode'):
        tvshowtitle = meta.get('localtvshowtitle') or meta.get('tvshowtitle') or ''
        if tvshowtitle:
            data['tvshowtitle'] = tvshowtitle
    for key in ('year', 'season', 'episode', 'premiered', 'plot', 'duration', 'status'):
        val = meta.get(key)
        if val not in (None, '', '0'):
            data[key] = val
    return data

def _ff_apply_safe_video_metadata(item, meta, label, mediatype):
    """Mobile SAFE MODE: ustaw lekkie metadane przez InfoTagVideo, bez setInfo/setCast/resume."""
    try:
        vtag = item.getVideoInfoTag()
    except Exception:
        vtag = None
    if vtag is None:
        return False

    def _call(method_name, *args):
        func = getattr(vtag, method_name, None)
        if not callable(func):
            return False
        try:
            func(*args)
            return True
        except Exception:
            return False

    def _as_int(value):
        try:
            if value in (None, '', '0'):
                return None
            return int(float(value))
        except Exception:
            return None

    title = meta.get('title') or label or ''
    if title:
        _call('setTitle', title)

    _call('setMediaType', mediatype)

    tvshowtitle = meta.get('localtvshowtitle') or meta.get('tvshowtitle') or ''
    if tvshowtitle:
        _call('setTvShowTitle', tvshowtitle) or _call('setTVShowTitle', tvshowtitle)

    original_title = meta.get('originalname') or meta.get('originaltitle') or ''
    if original_title:
        _call('setOriginalTitle', original_title)

    year = _as_int(meta.get('year'))
    if year:
        _call('setYear', year)

    season = _as_int(meta.get('season'))
    if season is not None:
        _call('setSeason', season)

    episode = _as_int(meta.get('episode'))
    if episode is not None:
        _call('setEpisode', episode)

    duration = _as_int(meta.get('duration'))
    if duration:
        _call('setDuration', duration)

    plot = meta.get('plot') or ''
    if plot:
        _call('setPlot', plot)

    premiered = meta.get('premiered') or meta.get('aired') or ''
    if premiered:
        _call('setPremiered', premiered)

    status = meta.get('status') or ''
    if status:
        _call('setTvShowStatus', status) or _call('setTvshowStatus', status)

    return True
# --- END ANDROID MOBILE SAFE MODE ---

action = params.get("action")


class seasons:
    def __init__(self):
        # fflog("inicjalizacja klasy seasons")

        # fix for not always current value
        global params, action
        params = dict(parse_qsl(sys.argv[2].replace("?", ""))) if len(sys.argv) > 1 else dict()
        action = params.get("action")

        self.session = requests.Session()

        self.showunaired = "true"  # always show unaired episodes
        # fflog(f'{self.showunaired=}',1,1)
        # self.specials = "false"
        self.specials = control.setting('tv.specials')
        # self.trailer_source = "1"
        self.trailer_source = control.setting('trailer.source')
        #fflog(f'{self.trailer_source=}')

        self.datetime = datetime.datetime.utcnow()  # - datetime.timedelta(hours = 5)
        self.today_date = self.datetime.strftime("%Y-%m-%d")

        self.lang = control.apiLanguage()["tmdb"] or "en"
        self.tm_user = control.setting("tm.user") or apis.tmdb_API

        self.tmdb_show_link = "https://api.themoviedb.org/3/tv/%s?api_key=%s&language=%s&append_to_response=aggregate_credits,content_ratings,external_ids" % ("%s", self.tm_user, "%s")
        self.tmdb_show_lite_link = "https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en" % ("%s", self.tm_user)
        self.tmdb_by_imdb = "https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id" % ("%s", self.tm_user)
        self.search_link = "https://api.themoviedb.org/3/search/tv?api_key=%s&language=en-US&query=%s&page=1" % (self.tm_user, "%s")
        self.tm_img_link = "https://image.tmdb.org/t/p/w%s%s"

        self.list = []


    def __del__(self):
        self.session.close()


    def get(self, tvshowtitle, year, imdb, tmdb, tvdb=None, meta=None, localtvshowtitle="", originaltvshowtitle="", idx=True, create_directory=True):
        fflog(f'(seasons) {params=}', 1, 1)
        try:
            if idx:
                self.list = cache.get(self.tmdb_list, 12, tvshowtitle, year, imdb, tmdb, tvdb, meta, localtvshowtitle, originaltvshowtitle)
                #log_utils.log('idx_list_loaded ')
                #fflog(repr(self.list))
                if create_directory:
                    self.seasonDirectory(self.list)
                return self.list
            else:
                self.list = self.tmdb_list(tvshowtitle, year, imdb, tmdb, tvdb, localtvshowtitle=localtvshowtitle, originaltvshowtitle=originaltvshowtitle, lite=True)
                #log_utils.log('nonidx_list_loaded ')# + repr(self.list))
                return self.list
        except Exception:
            fflog_exc(1)
            log_utils.log("seasons_get", "indexer")


    def tmdb_list(self, tvshowtitle, year, imdb, tmdb, tvdb, meta=None, localtvshowtitle="", originaltvshowtitle="", lite=False):
        # fflog(f'{lite=}',1,1)
        try:

            if tmdb is None and not imdb == "0":
                try:
                    url = self.tmdb_by_imdb % imdb
                    # control.log(f'{url=}', 1)
                    result = self.session.get(url, timeout=10).json()
                    tmdb_result = result["tv_results"][0]
                    tmdb = tmdb_result["id"]
                    if not tmdb:
                        tmdb = "0"
                    else:
                        tmdb = str(tmdb)
                except Exception:
                    # fflog_exc(1)
                    pass

            if tmdb == "0" and tvshowtitle:
                try:
                    url = (self.search_link % (quote(tvshowtitle)) + "&first_air_date_year=" + year)
                    # control.log(f'{url=}', 1)
                    result = self.session.get(url, timeout=10).json()
                    results = result["results"]
                    show = [r for r in results if cleantitle.get(r.get("name")) == cleantitle.get(tvshowtitle)][
                        0]  # and re.findall('(\d{4})', r.get('first_air_date'))[0] == year][0]
                    tmdb = show["id"]
                    if not tmdb:
                        tmdb = "0"
                    else:
                        tmdb = str(tmdb)
                except Exception:
                    # fflog_exc(1)
                    pass

        except Exception as e:
            log_utils.log("tmdb-list0 Exception %s" % e, "indexer")
            fflog_exc(1)
            pass

        try:
            if tmdb == "0":
                raise Exception(f"{tmdb=}")

            seasons_url = self.tmdb_show_link % (tmdb, self.lang) + ",translations"
            seasons_en_url = self.tmdb_show_link % (tmdb, "en")
            seasons_lite_url = self.tmdb_show_lite_link % tmdb

            if self.lang == "en":
                url = seasons_en_url
            elif lite:
                url = seasons_lite_url
            else:
                url = seasons_url

            # control.log(f'{url=}', 1)
            r = self.session.get(url, timeout=10)
            r.raise_for_status()
            r.encoding = "utf-8"
            item = r.json()
            # log_utils.log('tmdb_item: ' + str(item))

            if imdb == "0":
                try:
                    imdb = item["external_ids"]["imdb_id"]
                    if not imdb:
                        imdb = "0"
                except Exception:
                    pass

            try:
                # if not tvdb:
                tvdb = item["external_ids"]["tvdb_id"]
                if not tvdb:
                    tvdb = "0"
                else:
                    tvdb = str(tvdb)
            except Exception:
                tvdb = "0"

            try:
                studio = item["networks"][0]["name"]
            except:
                studio = ""
            if not studio:
                studio = "0"

            try:
                genres = item["genres"]
                genre = [d["name"] for d in genres]
                genre = " / ".join(genre)
            except:
                genre = ""
            if not genre:
                genre = "0"

            try:
                duration = item["episode_run_time"][0]
                duration = str(duration)
            except:
                duration = ""
            if not duration:
                duration = "0"

            try:
                m = item["content_ratings"]["results"]
                #mpaa = [d["rating"] for d in m if d["iso_3166_1"] == "US"][0]
                mpaa = [d["rating"] for d in m if d["iso_3166_1"] in ["US","PL"]][0]
            except:
                mpaa = ""
            if not mpaa:
                mpaa = "0"
            #fflog(f'{mpaa=}')

            try:
                status = item["status"]
            except:
                status = ""
            if not status:
                status = "0"

            castwiththumb = []
            try:
                c = item["aggregate_credits"]["cast"][:30]
                for person in c:
                    _icon = person["profile_path"]
                    icon = self.tm_img_link % ("185", _icon) if _icon else ""
                    castwiththumb.append(
                        {"name": person["name"], "role": person["roles"][0]["character"], "thumbnail": icon, })
            except Exception:
                pass
            if not castwiththumb:
                castwiththumb = "0"

            # opis serialu (nie sezonu) - na wypadek, gdy nie będzie opisu sezonu
            try:
                show_plot = item["overview"]
            except:
                show_plot = ""
            if not show_plot:
                show_plot = "0"
            if not self.lang == "en" and show_plot == "0":
                try:
                    translations = item["translations"]["translations"]
                    trans_item = [x["data"] for x in translations if x.get("iso_639_1") == "en"][0]
                    show_plot = trans_item["overview"]
                except:
                    pass

            unaired = ""

            try:
                poster_path = item["poster_path"]
            except:
                poster_path = ""
            if poster_path:
                show_poster = self.tm_img_link % ("500", poster_path)
            else:
                show_poster = "0"

            try:
                fanart_path = item["backdrop_path"]
            except:
                fanart_path = ""
            if fanart_path:
                show_fanart = self.tm_img_link % ("1280", fanart_path)
            else:
                show_fanart = "0"

            meta_poster = meta_fanart = None
            banner = clearlogo = clearart = keyart = landscape = characterart = country = original_language = original_translation_lang = "0"

            if meta:
                _meta = json.loads(unquote_plus(meta))
                # fflog(f'{_meta=}',1,1)
                # fflog(f'_meta={json.dumps(_meta, indent=2)}',1,1)
                meta_poster, meta_fanart, banner, clearlogo, clearart, keyart, landscape, characterart, country = (
                    _meta.get("poster"),
                    _meta.get("fanart"),
                    _meta.get("banner"),
                    _meta.get("clearlogo"),
                    _meta.get("clearart"),
                    _meta.get("keyart"),
                    _meta.get("landscape"),
                    _meta.get("characterart"),
                    _meta.get("country"),
                )
                original_language, original_translation_lang = (
                    _meta.get("original_language"),
                    _meta.get("original_translation_lang"),
                )
            else:
                _meta = {}

        except Exception as e:
            log_utils.log("tmdb-list1 Exception: %s " % e, "indexer")
            fflog_exc(1)
            return

        seasons = item["seasons"]

        if self.specials == "false":
            seasons = [s for s in seasons if not s["season_number"] == 0]

        # check if en version needed
        seasons_en = {}
        for s_item in seasons:
            plot = s_item["overview"]
            if not plot:
                log_utils.fflog('potrzeba pobrania angielskich opisów do sezonów', 0,1)
                # control.log(f'{seasons_en_url=}', 1)
                # control.log(f'{seasons_lite_url=}', 1)
                # r_en = self.session.get(seasons_en_url, timeout=10)
                r_en = self.session.get(seasons_lite_url, timeout=10)
                r_en.raise_for_status()
                r_en.encoding = "utf-8"
                seasons_en = r_en.json()["seasons"]
                break

        # check if original version needed
        if  original_translation_lang and original_translation_lang != "0":
            for s_item in seasons_en:
                plot = s_item["overview"]
                if not plot:
                    log_utils.fflog('potrzeba pobrania originalnych opisów do sezonów', 0,1)
                    # seasons_en_url = self.tmdb_show_link % (tmdb, original_translation_lang)
                    seasons_lite_url = seasons_lite_url.replace("&language=en", "&language=%s" % original_translation_lang)
                    # control.log(f'{seasons_en_url=}', 1)
                    # control.log(f'{seasons_lite_url=}', 1)
                    # r_en = self.session.get(seasons_en_url, timeout=10)
                    r_en = self.session.get(seasons_lite_url, timeout=10)
                    r_en.raise_for_status()
                    r_en.encoding = "utf-8"
                    seasons_en = r_en.json()["seasons"]
                    break

        if self.specials == "false":
            seasons_en = [s for s in seasons_en if not s["season_number"] == 0]

        count = 0
        # fflog(f'{len(seasons)=}',1,1)
        for s_item in seasons:
            try:
                # fflog(f's_item={json.dumps(s_item, indent=2)}',1,1)

                name = str(s_item["name"])
                
                season = str(s_item["season_number"])

                premiered = s_item.get("air_date", "0") or "0"

                if status == "Ended":
                    pass
                elif not premiered or premiered == "0":
                    # raise Exception()
                    # continue
                    pass
                    # brak daty może oznaczać, że nie znana jest jeszcze premiera (ale i też, że nie została wprowadzona informacja o tym)
                    unaired = "true"
                    if self.showunaired != "true":
                        continue
                elif int(re.sub("[^0-9]", "", str(premiered))) > int(re.sub("[^0-9]", "", str(self.today_date))):
                    unaired = "true"
                    if self.showunaired != "true":
                        # raise Exception()
                        continue

                plot = s_item["overview"]
                if not plot:
                    plot = seasons_en[count]["overview"]
                    if not plot:
                        # plot = show_plot
                        pass

                count += 1

                episodes = s_item.get("episode_count")

                poster_path = s_item.get("poster_path")
                if poster_path:
                    season_poster = self.tm_img_link % ("500", poster_path)
                else:
                    season_poster = None
                # fflog(f'{_meta=} {_meta.get("seasons_posters")=} {season=}')
                poster = season_poster or meta_poster or show_poster
                poster = _meta.get("seasons_posters", {}).get(season) or poster

                banner = _meta.get("seasons_banners", {}).get(season) or _meta.get("banner") or ""
                landscape = _meta.get("seasons_landscapes", {}).get(season) or _meta.get("landscape") or ""
                # fflog(f'{season=}')
                # fflog(f'{_meta.get("seasons_banners")=}')
                # fflog(f'{_meta.get("seasons_banners").get(season)=}')
                # fflog(f'{banner=}')

                # fanart = meta_fanart or show_fanart
                fanart = _meta.get("seasons_fanarts", {}).get(season) or _meta.get("fanart") or show_fanart or ""

                self.list.append({
                    "title": name, "season": season, "tvshowtitle": tvshowtitle, "year": year, "premiered": premiered,
                    "status": status, "studio": studio, "genre": genre, "duration": duration, "mpaa": mpaa,
                    "castwiththumb": castwiththumb, "plot": plot, "imdb": imdb, "tmdb": tmdb, "tvdb": tvdb,
                    "poster": poster, "fanart": fanart, "banner": banner, "clearlogo": clearlogo, "clearart": clearart,
                    "landscape": landscape, "unaired": unaired, "keyart": keyart, "characterart": characterart, "country": country,
                    "original_language": original_language, "original_translation_lang": original_translation_lang,
                    "localtvshowtitle": localtvshowtitle, "originaltvshowtitle": originaltvshowtitle, "episodes": episodes,
                    })

            except Exception as e:
                log_utils.log("seasons_dir Exception: %s " % e, "indexer")
                fflog_exc(1)
                pass

        try:
            cache.cache_insert("seasons" + f"_{tmdb or imdb}", repr(self.list))  # to w sumie nie jest do niczego potrzebne
        except Exception:
            fflog_exc(1)
            pass
        # fflog(f'self.list={json.dumps(self.list, indent=2)}')
        return self.list


    def seasonDirectory(self, items, cacheToDisc=False):
        #fflog(f'[seasonDirectory]')
        if items is None or len(items) == 0:
            return  #  ; sys.exit()

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])

        noPoster = _ff_no_poster_art()
        if control.setting("zastepcze_grafiki") == "true":
            addonPoster = noPoster or control.addonPoster()
            addonFanart = control.addonFanart()
            addonBanner = control.addonBanner()
        else:
            addonPoster = noPoster
            addonFanart = addonBanner = ""

        settingFanart = control.setting("fanart")

        traktCredentials = trakt.getTraktCredentialsInfo()
        traktIndicators  = trakt.getTraktIndicatorsInfo()

        isOld = False
        try:
            control.item().getArt("type")
        except Exception:
            #fflog_exc(1)
            isOld = True

        try:
            indicators = playcount.getSeasonIndicators(items[0]["imdb"], ret_tuple=True)
            # fflog(f'{indicators=}',1,1)
        except Exception:
            # fflog_exc(1)
            indicators = []
            pass

        # trailerAction = "tmdb_trailer" if self.trailer_source == "0" else "yt_trailer"  # to nie jest zrobione
        trailerAction = "trailer"
        watchedMenu =   (control.lang(32068) if traktIndicators == True else control.lang(32066))
        unwatchedMenu = (control.lang(32069) if traktIndicators == True else control.lang(32067))
        queueMenu = control.lang(32065)
        traktManagerMenu = control.lang(32070)
        labelMenu = control.lang(32055)
        playRandom = control.lang(32535)
        addToLibrary = control.lang(32551)
        infoMenu = control.lang(32101)

        generate_short_path = control.setting("generate_short_path") == "true"

        addSortMethod(syshandle, sortMethod=SORT_METHOD_UNSORTED, labelMask="%L", label2Mask="%Y")

        cm_enable_addToLibrary = control.setting("cm.enable.addToLibrary") == "true"
        cm_enable_queueMenu = control.setting("cm.enable.queueMenu") == "true"  # to chyba Kodi dodaje od wersji 21.2
        cm_enable_watchedUnwatched = control.setting("cm.enable.watchedUnwatched") == "true"

        unpremiered_color = control.setting("unpremiered_color")
        if unpremiered_color == "inny":
            unpremiered_color = control.setting("unpremiered_custom_color")
        else:
            colors_map = {
                "szary": "gray",
                "czerwony": "red",
                "fioletowy": "magenta",
                "pomarańczowy": "orange",
                }
            unpremiered_color = colors_map[unpremiered_color]
        # fflog(f'{unpremiered_color=}')

        #counter = 1
        for i in items:
            try:
                # log_utils.fflog(f'{i=}')
                # fflog(f'i={json.dumps(i, indent=2)}',1,1)

                label = i.get("title")
                if not label:
                    label = "{} {}".format(labelMenu, i["season"])

                syslabel = quote_plus(label)

                systitle = quote_plus(i["tvshowtitle"])
                syslocaltitle = quote_plus(i.get("localtvshowtitle", ""))

                poster = (i["poster"] if "poster" in i and not i["poster"] == "0" else addonPoster)
                poster = _ff_fast_poster_art(poster) or poster

                fanart = (i["fanart"] if "fanart" in i and not i["fanart"] == "0" else addonFanart)

                banner1 = i.get("banner", "")
                # banner = banner1 or fanart or addonBanner
                banner = banner1 or addonBanner

                if "landscape" in i and not i["landscape"] == "0":
                    landscape = i["landscape"]
                else:
                    landscape = fanart

                imdb, tvdb, tmdb, year, season, duration, status = (
                    i["imdb"], i["tvdb"], i["tmdb"], i["year"], i["season"], i.get("duration", "45"), i.get("status", "0")
                )

                ep_meta = {
                    "poster": poster,
                    "fanart": fanart,
                    "banner": banner,
                    "clearlogo": i.get("clearlogo") or "0",
                    "clearart": i.get("clearart") or "0",
                    "keyart": i.get("keyart") or "0",
                    "characterart": i.get("characterart") or "0",
                    "landscape": landscape,
                    "duration": duration,
                    "status": status,
                    "mpaa": i.get("mpaa", ""),
                    "country": i.get("country") or "0",
                    'original_language': i.get('original_language') or '0',
                    'original_translation_lang': i.get('original_translation_lang') or '0',
                    "localtvshowtitle": i.get("localtvshowtitle") or "",
                    "originaltvshowtitle": i.get("originaltvshowtitle") or "",
                }
                # fflog(f'ep_meta={json.dumps(ep_meta, indent=2)}',1,1)

                sysmeta = quote_plus(json.dumps(ep_meta))
                # log_utils.log('sysmeta: ' + str(sysmeta))

                meta = {k: v for k, v in i.items() if not v == "0"}

                meta.update({"title": i.get("title") or label})

                meta.update({"mediatype": "season"})

                meta.update({"season": season})  # potrzebne dla sezonów o numerze 0

                meta.update({"imdbnumber": imdb, "code": tmdb})

                # meta.update({"trailer": "%s?action=%s&name=%s&tmdb=%s&season=%s" % (sysaddon, trailerAction, systitle, tmdb, season)})
                meta.update({"trailer": "%s?action=trailer&name=%s&url=%s" % (sysaddon, systitle + " " + syslabel, quote_plus(meta.get("trailer") or ""))})

                if not "duration" in meta:
                    # meta.update({"duration": "45"})
                    # meta.update({"duration": "1"})
                    pass
                elif meta["duration"] == "0":
                    # meta.update({"duration": "45"})
                    # meta.update({"duration": "1"})
                    pass
                try:
                    if meta.get("duration") and meta.get("duration") != "0":
                        meta.update({"duration": str(int(meta["duration"]) * 60)})
                except Exception:
                    pass

                # try: meta.update({"genre": cleangenre.lang(meta["genre"], self.lang)})
                # except: pass

                try:
                    seasonYear = i["premiered"]
                    seasonYear = re.findall(r"(\d{4})", seasonYear)[0]
                    # seasonYear = six.ensure_str(seasonYear)
                    meta.update({"tvshowyear": i["year"]})
                    meta.update({"year": seasonYear})
                except Exception:
                    pass

                meta.update({"originalname": i.get("originaltvshowtitle", "")})


                try:
                    if i["unaired"] == "true":
                        if self.showunaired != "true":
                            continue
                        label = f"[COLOR {unpremiered_color}][I]%s[/I][/COLOR]" % label
                except:
                    pass


                # create ListItem
                try:
                    item = control.item(label=label, offscreen=True)  # dlaczego tak? przecież to ma być wyświetlane! chyba tego nierozumiem
                except Exception:
                    item = control.item(label=label)



                episodes = i.get("episodes") or 0
                # fflog(f'{episodes=}',1,1)
                watched = 0
                try:
                    overlay = playcount.getSeasonOverlay(indicators, imdb, season, episodes, ret_tuple=True)
                    # fflog(f'{overlay=}  {imdb=}  {season=}  {label=} ')
                    if isinstance(overlay, tuple):
                        overlay, watched, episodes = overlay
                    overlay = int(overlay)
                    if overlay == 7:
                        meta.update({"playcount": 1, "overlay": 7})  # to zmienia ptaszki
                    else:
                        meta.update({"playcount": 0, "overlay": 6})  # to zmienia ptaszki
                except Exception:
                    fflog_exc(1)
                    overlay = 6

                if episodes:
                    item.setProperty("TotalEpisodes", str(episodes))
                    if not _ff_is_exynos():
                        item.setProperty("WatchedEpisodes", str(watched))
                        item.setProperty("UnWatchedEpisodes", str(episodes - watched))
                    started = 0
                    try:
                        if not traktIndicators:
                            started = bookmarks.get_inprogress_episode_count(imdb, season)
                    except Exception:
                        started = 0
                    started = max(0, min(int(started or 0), max(int(episodes) - int(watched), 0)))
                    progress_units = int(watched) + int(started)
                    progress = int((progress_units / episodes) * 100) if episodes else 0
                    if progress_units > 0 and progress <= 0:
                        progress = 1
                    if progress_units < int(episodes):
                        progress = min(progress, 99)
                    else:
                        progress = 100
                    if not _ff_is_exynos():
                        item.setProperty("WatchedEpisodePercent", str(progress))  # for tvshow and season
                        item.setProperty("InProgressEpisodes", str(started))
                    # === PROGRESS: etykieta sezonu: Kontynuuj / Zakończono (bez procentów) ===
                    try:
                        progress_value = int(progress)
                    except Exception:
                        progress_value = 0
                    if progress_value <= 0:
                        pass
                    elif progress_value < 100:
                        try:
                            current_label = item.getLabel()
                            if current_label and not current_label.lower().startswith("kontynuuj"):
                                item.setLabel("Kontynuuj: {0}".format(current_label))
                        except Exception:
                            pass
                    else:
                        try:
                            current_label = item.getLabel()
                            if current_label and "Zakończono" not in current_label:
                                item.setLabel("[COLOR grey][Zakończono][/COLOR] {0}".format(current_label))
                        except Exception:
                            pass



                meta.pop("next", None)


                cm = []  # bulding context menu

                if cm_enable_addToLibrary:
                    cm.append((addToLibrary,
                               "RunPlugin(%s?action=tvshowToLibrary&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&localtvshowtitle=%s)" % (
                                sysaddon, systitle, year, imdb, tmdb, syslocaltitle),))

                if not traktIndicators:
                    if overlay != 7:
                        if cm_enable_watchedUnwatched:
                            cm.append((watchedMenu,   "RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tmdb=%s&season=%s&query=7)" % (sysaddon, systitle, imdb, tmdb, season),))
                    if True:
                        if cm_enable_watchedUnwatched:
                            cm.append((unwatchedMenu, "RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tmdb=%s&season=%s&query=6)" % (sysaddon, systitle, imdb, tmdb, season),))

                if traktCredentials:
                    cm.append((traktManagerMenu, "RunPlugin(%s?action=traktManager&name=%s&imdb=%s&tmdb=%s&season=%s&content=tvshow&overlay=%s)" % (sysaddon, systitle, imdb, tmdb, season, overlay),))

                # Odtwarzaj losowo (? - trochę dziwne to, raczej do teledysków się nadaje, niż do seriali).
                if False:  # wyłączenie
                    cm.append((playRandom, "RunPlugin(%s?action=random&rtype=episode&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&season=%s)" % (
                                        sysaddon, quote_plus(systitle), quote_plus(year), quote_plus(imdb), quote_plus(tmdb), quote_plus(season),),))
 
                if cm_enable_queueMenu:
                    if not generate_short_path:  # zapis z tvshow.py - bo inaczej źle dodaje (dodaje te same odcinki kilka razy w zależności od ilości sezonów)
                        cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))

                if generate_short_path:
                    cm.append(("[I]przygotuj do ulubionych[/I]", "Container.Update(%s?action=prepareItemForAddToLibrary)" % (sysaddon),))

                if isOld:
                    cm.append((infoMenu, "Action(Info)"))

                if not _ff_is_exynos():
                    item.addContextMenuItems(cm)


                art = {}

                art.update({
                            "icon": poster, 
                            "thumb": poster, 
                            "poster": poster, 
                            "season.poster": poster,  # zależy od skórki (jak ma kod napisany
                            # "tvshow.poster": poster,  # niektóre mogą pewnie i tego wymagać
                            "banner": banner, 
                            "landscape": landscape, 
                          })

                if settingFanart == "true":
                    art.update({"fanart": fanart})
                elif not addonFanart is None:
                    art.update({"fanart": addonFanart})

                if "clearlogo" in i and not i["clearlogo"] == "0":
                    art.update({"clearlogo": i["clearlogo"]})
                    art.update({"tvshow.clearlogo": i["clearlogo"]})  # to jest ważniejsze dla skórki (tak są tam przeważnie zapisane warunki sprawdzające) - sprawdzane po kolei od góry i zatrzymanie się na którymś
                    pass

                if "clearart" in i and not i["clearart"] == "0":
                    art.update({"clearart": i["clearart"]})

                if "keyart" in i and not i["keyart"] == "0":
                    art.update({"keyart": i["keyart"]})

                """
                if "characterart" in i and not i["characterart"] == "0":
                    art.update({"characterart": i["characterart"]})
                """
                # if has("characterart"):
                if "characterart" in i and not i["characterart"] == "0":
                    characterart = i["characterart"]
                    if isinstance(characterart, list):
                        for an in range(0, len(characterart)):
                            # art[f"characterart{an+1}"] = characterart[an]
                            art.update({f"characterart{an+1}": characterart[an]})
                            # art.update({f"tvshow.characterart{an+1}": characterart[an]})
                    else:
                        # art["characterart"] = characterart
                        art.update({"characterart": characterart})
                        # art.update({"tvshow.characterart": characterart})


                item.setArt(art)

                # Android mobile SAFE MODE: nie ustawiamy ResumeTime/TotalTime
                # ani liczników watched/progress na liście sezonów.

                castwiththumb = i.get("castwiththumb")
                if castwiththumb and not castwiththumb == "0":
                    if not _ff_is_exynos():
                        try:
                            item.setCast(castwiththumb)
                        except Exception:
                            pass

                if _ff_is_exynos():
                    _ff_apply_safe_video_metadata(item, meta, label, 'season')
                else:
                    try:
                        item.setInfo(type="video", infoLabels=control.metadataClean(meta))
                    except Exception:
                        pass

                    # korekta pod standard ListItem (bo super_info.py inaczej generuje)
                    try:
                        item.setInfo(type="Video", infoLabels={'TvShowTitle': meta.get("localtvshowtitle") or meta.get("tvshowtitle", "")})
                    except Exception:
                        pass
                item.setProperty("englishTvShowTitle", meta.get("englishtvshowtitle") or meta.get("tvshowtitle", ""))
                #item.setProperty("OriginalTvShowTitle", meta.get("originaltvshowtitle") or meta.get("tvshowtitle", ""))
                item.setProperty("OriginalTvShowTitle", meta.get("originaltvshowtitle") or "")
                item.setProperty("TvShowYear", meta.get("tvshowyear") or meta.get("year", ""))

                if generate_short_path:
                    # fflog(f'{imdb=} {tmdb=} {tvdb=}')
                    try:
                        if not _ff_is_exynos():
                            vtag = item.getVideoInfoTag()
                            vtag.setUniqueIDs({
                                'imdb': imdb,
                                'tmdb' : tmdb,
                                'tvdb' : tvdb,
                            })
                        else:
                            raise Exception("Exynos: skip vtag")
                    except Exception:
                        fflog_exc(1)
                        item.setProperty("imdb_id", imdb)
                        item.setProperty("tmdb_id", tmdb)
                        item.setProperty("tmdb_id", tvdb)

                    item.setProperty("meta", json.dumps(ep_meta))


                url = "%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&meta=%s&season=%s" % (sysaddon, systitle, year, imdb, tmdb, tvdb, sysmeta, season)
                if generate_short_path:
                    item.setProperty("fullpath", url)
                    url = "{}?action=episodes&item={}".format(sysaddon, i["season"])


                # video_streaminfo = {"codec": "h264"}; item.addStreamInfo("video", video_streaminfo)  # czy to konieczne?


                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)

                #counter += 1
            except Exception:
                log_utils.log("season-dir Exception", "indexer")
                fflog_exc(1)
                pass

        try:
            # ciekawe do czego to służy
            # control.property(syshandle, "ShowPlot", items[0]["plot"])  # ale to powoduje, że każdy sezon ma ten sam opis
            # control.property(syshandle, "ShowTitle", items[0]["tvshowtitle"])  # j.w. choć nie testowałem - a może to nieprawidłowa implementacja w skórce?
            # https://kodi.wiki/view/InfoLabels  Container.ShowPlot i Container.ShowTitle  dyskusja https://forum.kodi.tv/showthread.php?tid=94282&pid=726187#pid726187
            # jakby górny tytuł katalogu w niektórych skórkach
            # if len(items):
            # cat_label = items[0]["tvshowtitle"]
            # cat_label = meta["tvshowtitle"]
            cat_label = meta.get("localtvshowtitle") or meta.get("tvshowtitle")
            if meta.get("tvshowyear") and cat_label:
                cat_label += f' ({meta.get("tvshowyear")})'
                pass
            if cat_label:
                control.pluginCategory(syshandle, cat_label)
                pass
        except Exception:
            fflog_exc(1)
            pass


        control.content(syshandle, "seasons")  # takiego typu oficjalnie chyba nie ma (albo brak takiej informacji w dokumentacji)

        params = dict(parse_qsl(sys.argv[2][1:]))
        updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie

        control.directory(syshandle, cacheToDisc=cacheToDisc, updateListing=updateListing)

        views.setView("seasons")



class episodes:
    def __init__(self):
        # fflog("inicjalizacja klasy episodes")

        # fix for not always current value
        global params, action
        params = dict(parse_qsl(sys.argv[2].replace("?", ""))) if len(sys.argv) > 1 else dict()
        action = params.get("action")

        self.session = requests.Session()

        self.list = []

        self.trakt_link = "https://api.trakt.tv"
        self.tvmaze_link = "https://api.tvmaze.com"

        self.datetime = datetime.datetime.utcnow()  # - datetime.timedelta(hours = 5)
        self.systime = self.datetime.strftime("%Y%m%d%H%M%S%f")
        self.today_date = self.datetime.strftime("%Y-%m-%d")

        self.tm_user = control.setting("tm.user") or apis.tmdb_API
        self.trakt_user = control.setting("trakt.user").strip()
        self.showunaired = "true"  # always show unaired episodes
        # self.specials = "false"
        self.specials =  control.setting('tv.specials')
        self.lang = control.apiLanguage()["tmdb"] or "en"
        self.language = f"{self.lang}-{self.lang.upper()}"
        # self.hq_artwork = "false"
        self.fanartTV_artwork = control.setting("fanartTV_artwork")
        self.items_per_page = str(control.setting("items.per.page")) or "20"
        # self.trailer_source = "1"
        self.trailer_source = control.setting('trailer.source')


        # tmdb
        self.tmdb_show_lite_link =   "https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en" % ("%s", self.tm_user)
        self.tmdb_season_link =     ("https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=%s&append_to_response=aggregate_credits" % (
                    "%s", "%s", self.tm_user, "%s"))
        self.tmdb_season_lite_link = "https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=en" % ("%s", "%s", self.tm_user)
        self.tmdb_episode_link =    ("https://api.themoviedb.org/3/tv/%s/season/%s/episode/%s?api_key=%s&language=%s&append_to_response=credits" % (
                    "%s", "%s", "%s", self.tm_user, self.lang))
        self.tmdb_episode_link_en = ("https://api.themoviedb.org/3/tv/%s/season/%s/episode/%s?api_key=%s&language=en" % (
                    "%s", "%s", "%s", self.tm_user))
        self.search_link =           "https://api.themoviedb.org/3/search/tv?api_key=%s&language=en-US&query=%s&page=1" % (self.tm_user, "%s")
        self.tmdb_by_imdb =          "https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id" % ("%s", self.tm_user)
        self.tm_img_link = "https://image.tmdb.org/t/p/w%s%s"


        self.tmdbuser = control.setting("tmdb.username") or "me"  # or control.setting("tmdb.account_id")
        self.tmdb_sessionid = control.setting("tmdb.sessionid") or ""
        self.tmdb_guest_session_id = control.setting("tmdb.guest_session_id") or ""


        self.tmdbuserrated_link = self.tmdbuserratedepisodes_link = (
            "https://api.themoviedb.org/3/account/%s/rated/tv/episodes?api_key=%s&language=%s&session_id=%s&sort_by=created_at.desc&page=1" % (
                self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid))

        self.tmdbguestrated_link = self.tmdbguestratedepisodes_link = (
            "https://api.themoviedb.org/3/guest_session/%s/rated/tv/episodes?api_key=%s&language=%s&sort_by=created_at.desc&page=1" % (
                self.tmdb_guest_session_id, self.tm_user, self.lang))


        # obrazki z fanartTV
        self.fanart_tv_art_link = "http://webservice.fanart.tv/v3/tv/%s"
        self.fanart_tv_user = control.setting("fanart.tv.user") or apis.fanarttv_client_key  # user musi swój podać (bo na domyślnym z FF nie działa)
        self.fanart_tv_API_key = control.setting("fanart.tv.dev") or apis.fanarttv_API_key
        self.fanart_tv_headers = {"api-key": self.fanart_tv_API_key, "client-key": self.fanart_tv_user, }

        # tv maze
        self.added_link = "https://api.tvmaze.com/schedule"
        self.calendar_link = "https://api.tvmaze.com/schedule?date=%s"

        # trakt
        # https://api.trakt.tv/calendars/all/shows/date[30]/31 #use this for new episodes?
        # self.mycalendar_link = "https://api.trakt.tv/calendars/my/shows/date[29]/60/"
        self.mycalendar_link = "https://api.trakt.tv/calendars/my/shows/date[30]/31/"  # go back 30 and show all shows aired until tomorrow
        self.trakthistory_link = "https://api.trakt.tv/users/me/history/shows?limit=%s" % self.items_per_page
        self.progress_link = "https://api.trakt.tv/users/me/watched/shows"
        self.hiddenprogress_link = "https://api.trakt.tv/users/hidden/progress_watched?limit=1000&type=show"
        self.onDeck_link = "https://api.trakt.tv/sync/playback/episodes?limit=%s" % self.items_per_page
        self.traktlists_link = "https://api.trakt.tv/users/me/lists"
        self.traktlikedlists_link = "https://api.trakt.tv/users/likes/lists?limit=1000000"
        self.traktlist_link = "https://api.trakt.tv/users/%s/lists/%s/items"



    def __del__(self):
        self.session.close()


    def _duration_to_minutes(self, value):
        try:
            if value in (None, "", "0", 0):
                return 0
            if isinstance(value, str):
                value = value.strip()
                if not value or value == "0":
                    return 0
                if ":" in value:
                    parts = [int(x) for x in value.split(":") if x != ""]
                    seconds = 0
                    for i, part in enumerate(reversed(parts)):
                        seconds += part * (60 ** i)
                    return int(round(seconds / 60.0)) if seconds else 0
            return int(float(value))
        except Exception:
            return 0


    def _get_episode_base_duration(self, meta=None, imdb=None, tmdb=None):
        try:
            _meta = meta
            if isinstance(_meta, str) and _meta:
                try:
                    _meta = json.loads(unquote_plus(_meta))
                except Exception:
                    _meta = json.loads(_meta)
            if isinstance(_meta, dict):
                base_duration = self._duration_to_minutes(_meta.get("duration"))
                if base_duration > 0:
                    return base_duration
        except Exception:
            pass

        try:
            meta1 = self.get_meta_for_tvshow(imdb=imdb, tmdb=tmdb)
            if isinstance(meta1, dict):
                return self._duration_to_minutes(meta1.get("duration"))
        except Exception:
            pass
        return 0


    def _normalize_episode_duration(self, duration_value, base_duration_value):
        runtime_minutes = self._duration_to_minutes(duration_value)
        base_minutes = self._duration_to_minutes(base_duration_value)
        if runtime_minutes <= 0:
            return "0"
        if base_minutes > 0 and runtime_minutes >= 80 and runtime_minutes >= int(base_minutes * 1.5):
            return str(base_minutes)
        return str(runtime_minutes)


    def _normalize_episode_list_durations(self, items, meta=None, imdb=None, tmdb=None):
        try:
            base_duration = self._get_episode_base_duration(meta=meta, imdb=imdb, tmdb=tmdb)
            if base_duration <= 0 or not items:
                return items
            for item in items:
                if not isinstance(item, dict):
                    continue
                current_duration = item.get("duration", "0")
                try:
                    progress_runtime = self._duration_to_minutes(current_duration)
                    if progress_runtime > 0:
                        item["_progress_runtime"] = str(int(progress_runtime) * 60)
                except Exception:
                    pass
                normalized_duration = self._normalize_episode_duration(current_duration, base_duration)
                if str(current_duration) != normalized_duration:
                    try:
                        fflog(f'[EPISODES DURATION] render override S{item.get("season", "?")}E{item.get("episode", "?")}: {current_duration} -> {normalized_duration} (base={base_duration})')
                    except Exception:
                        pass
                    item["duration"] = normalized_duration
        except Exception:
            fflog_exc(1)
        return items


    def get(self, tvshowtitle, year, imdb, tmdb, tvdb=None, season=None, episode=None, meta=None, localtvshowtitle="", originaltvshowtitle="", idx=True, create_directory=True, showunaired=None):
        fflog(f'(episodes) {params=}', 1, 1)
        # fflog(f'{season=} {episode=}')
        try:
            if idx:
                if season is None or episode is None:
                    # fflog(f'tu 1')
                    self.list = cache.get(self.tmdb_list, 1, tvshowtitle, year, imdb, tmdb, tvdb, season, meta, localtvshowtitle, originaltvshowtitle)
                    # fflog(f'{len(self.list)=}')
                # elif episode == None:
                # self.list = cache.get(self.tmdb_list, 1, tvshowtitle, year, imdb, tmdb, fanart, duration, status, season)
                # pass
                else:
                    # fflog(f'tu 2')  # kiedy to jest wykorzystywane ? - okazało się, że to przychodzi z calendar'a , np. postęp (pokazuje odcinki od któregoś dopiero)
                    self.list = cache.get(self.tmdb_list, 1, tvshowtitle, year, imdb, tmdb, tvdb, season, meta, localtvshowtitle, originaltvshowtitle)
                    # fflog(f'{len(self.list)=}')
                    num = [x for x, y in enumerate(self.list) if y["season"] == str(season) and y["episode"] == str(episode)][-1]
                    # fflog(f'{num=}')
                    self.list = [y for x, y in enumerate(self.list) if x >= num]
                    # fflog(f'{len(self.list)=}')
                self.list = self._normalize_episode_list_durations(self.list, meta=meta, imdb=imdb, tmdb=tmdb)
                if create_directory:
                    # fflog(f'tu 3')
                    self.episodeDirectory(self.list)
                return self.list
            else:
                # fflog(f'tu 4')
                self.list = self.tmdb_list(tvshowtitle, year, imdb, tmdb, tvdb, season, meta, localtvshowtitle=localtvshowtitle, originaltvshowtitle=originaltvshowtitle, lite=True, showunaired=showunaired)
                return self.list
        except Exception:
            log_utils.log("episodes_get Exception", "indexer")
            fflog_exc(1)
            pass


    def calendar(self, url, refresh=None):
        # debug
        if not "http" in url: 
            fflog(f'{params=}', fn=True)
            pass
        else:
            if not _is_debugging():
                fflog(f'params={({**params, "url": "*"})}', 1, 1)
                pass
            else:
                fflog(f'params={({**params, "url": url})}', 0)

        force_tvshow_title: bool = False
        #fflog(f'{url=} {refresh=}')
        try:
            #url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)  # tu nie występuje nic z tmdb
            try:
                url = getattr(self, url + "_link")
            except Exception:
                #fflog_exc(1)
                pass
            #fflog(f'{url=}')
            if self.trakt_link in url and url == self.onDeck_link:
                # self.blist = cache.get(self.trakt_episodes_list, 0, url, self.trakt_user, self.lang)
                self.list = []
                self.list = self.trakt_episodes_list(url, self.trakt_user, self.lang)
                if self.list:
                    self.list = sorted(self.list, key=lambda k: int(k["paused_at"]), reverse=True)

            elif self.trakt_link in url and url == self.progress_link:
                cache_timeout = 0 if refresh else 1
                # self.blist = cache.get(self.trakt_progress_list, 720, url, self.trakt_user, self.lang)
                self.list = cache.get(self.trakt_progress_list, cache_timeout, url, self.trakt_user, self.lang)
                force_tvshow_title = True

            elif self.trakt_link in url and url == self.mycalendar_link:
                # self.blist = cache.get(self.trakt_episodes_list, 720, url, self.trakt_user, self.lang)
                cache_timeout = 0 if refresh else 12
                self.list = []
                self.list = cache.get(self.trakt_episodes_list, cache_timeout, url, self.trakt_user, self.lang)
                if self.list:
                    self.list = sorted(self.list, key=lambda k: k["premiered"], reverse=True)

            elif self.trakt_link in url and url == self.trakthistory_link:
                cache_timeout = 0 if refresh else 1
                self.list = cache.get(self.trakt_episodes_list, cache_timeout, url, self.trakt_user, self.lang)
                if self.list:
                    self.list = sorted(self.list, key=lambda k: int(k["watched_at"]), reverse=True)

            elif self.trakt_link in url and "/users/" in url:
                cache_timeout = 0 if refresh else 1
                self.list = cache.get(self.trakt_list, cache_timeout, url, self.trakt_user)
                if self.list:
                    self.list = self.list[::-1]

            elif self.trakt_link in url:
                cache_timeout = 0 if refresh else 1
                self.list = cache.get(self.trakt_list, cache_timeout, url, self.trakt_user)

            elif self.tvmaze_link in url and url == self.added_link:
                urls = [i["url"] for i in self.calendars(idx=False)][:5]
                self.list = []
                for url in urls:
                    self.list += cache.get(self.tvmaze_list, 720, url, True)

            elif self.tvmaze_link in url:
                self.list = cache.get(self.tvmaze_list, 1, url, False)

            elif self.tmdbuserratedepisodes_link in url or self.tmdbguestratedepisodes_link in url:
                # fflog(f'{url=}',1,1)
                cache_timeout = 0 if refresh else 0.1  # 6 minut
                # cache_timeout = 0  # wyłączenie z cachowania
                self.list = cache.get(self.tmdb_list_by_url, cache_timeout, url)


            if self.list:
                self.episodeDirectory(self.list, force_tvshow_title=force_tvshow_title)
            else:
                control.infoDialog('Nic nie znaleziono', "Błąd", icon="ERROR")
                control.directory(int(sys.argv[1]), cacheToDisc=False)
                control.execute('Action(Back)')

            return self.list

        except Exception:
            fflog_exc(1)
            pass


    def widget(self):
        if trakt.getTraktIndicatorsInfo():
            setting = control.setting("tv.widget.alt")
        else:
            setting = control.setting("tv.widget")

        if setting == "2":
            self.calendar(self.progress_link)
        elif setting == "3":
            self.calendar(self.mycalendar_link)
        else:
            self.calendar(self.added_link)


    def calendars(self, idx=True):
        m = control.lang(32060).split("|")
        try:
            months = [(m[0], "January"), (m[1], "February"), (m[2], "March"), (m[3], "April"), (m[4], "May"),
                (m[5], "June"), (m[6], "July"), (m[7], "August"), (m[8], "September"), (m[9], "October"),
                (m[10], "November"), (m[11], "December"), ]
        except:
            months = []

        d = control.lang(32061).split("|")
        try:
            days = [(d[0], "Monday"), (d[1], "Tuesday"), (d[2], "Wednesday"), (d[3], "Thursday"), (d[4], "Friday"),
                (d[5], "Saturday"), (d[6], "Sunday"), ]
        except:
            days = []

        for i in range(0, 30):
            try:
                name = self.datetime - datetime.timedelta(days=i)
                name = control.lang(32062) % (name.strftime("%A"), six.ensure_str(name.strftime("%d %B")),)
                for m in months:
                    name = name.replace(m[1], m[0])
                for d in days:
                    name = name.replace(d[1], d[0])
                # try: name = six.ensure_str(name)
                # except: pass

                url = self.calendar_link % (self.datetime - datetime.timedelta(days=i)).strftime("%Y-%m-%d")

                self.list.append({"name": name, "url": url, "action": "calendar", "image": "calendar.png",})
            except:
                pass
        if idx:
            self.addDirectory(self.list)
        return self.list


    def userlists(self):
        """ tylko listy trakt """
        fflog(f'{params=}', 1, 1)
        try:
            userlists = []
            if not trakt.getTraktCredentialsInfo():
                raise Exception()
            activity = trakt.getActivity()
            #fflog(f'{activity=}')
        except Exception:
            fflog_exc(1)
            pass

        try:
            if not trakt.getTraktCredentialsInfo():
                raise Exception()
            try:
                if activity > cache.timeout(self.trakt_user_list, self.traktlists_link, self.trakt_user):
                    raise Exception()
                #fflog(f'z cache')
                userlists += cache.get(self.trakt_user_list, 720, self.traktlists_link, self.trakt_user)
            except:
                #fflog(f'odświeżam')
                userlists += cache.get(self.trakt_user_list, 0, self.traktlists_link, self.trakt_user)
        except Exception:
            #fflog_exc(1)
            pass

        try:
            self.list = []
            if not trakt.getTraktCredentialsInfo():
                raise Exception()
            try:
                if activity > cache.timeout(self.trakt_user_list, self.traktlikedlists_link, self.trakt_user):
                    raise Exception()
                #fflog(f'z cache')
                userlists += cache.get(self.trakt_user_list, 720, self.traktlikedlists_link, self.trakt_user, )
            except:
                #fflog(f'odświeżam')
                userlists += cache.get(self.trakt_user_list, 0, self.traktlikedlists_link, self.trakt_user)
        except Exception:
            #fflog_exc(1)
            pass

        self.list = userlists
        for i in range(0, len(self.list)):
            self.list[i].update({
                "action": "calendar",
                # "image": "userlists.png",
                "image": "trakt.png",
                })
        self.addDirectory(self.list, queue=True, add_refresh=True)
        return self.list


    def trakt_list(self, url, user):
        try:
            #fflog(f'{url=}')
            for i in re.findall(r"date\[(\d+)]", url):
                url = url.replace("date[%s]" % i, (self.datetime - datetime.timedelta(days=int(i))).strftime("%Y-%m-%d"), )

            q = dict(parse_qsl(urlsplit(url).query))
            q.update({"extended": "full"})
            q = (urlencode(q)).replace("%2C", ",")
            u = url.replace("?" + urlparse(url).query, "") + "?" + q
            # fflog(f'{u=}')
            itemlist = []
            items = trakt.getTraktAsJson(u)
        except Exception:
            fflog_exc(1)
            # print("Unexpected error in info builder script:", sys.exc_info()[0])
            # exc_type, exc_obj, exc_tb = sys.exc_info()
            # print(exc_type, exc_tb.tb_lineno)
            log_utils.log("trakt_list0", "indexer")
            return

        localtvshowtitles = {}

        fflog(f'{len(items)=}',1,1)
        for item in items:
            try:
                # fflog(f'{item=}')
                if not item.get("episode"):
                    #raise Exception()
                    continue              

                title = item["episode"]["title"]
                if title is None or title == "":
                    #raise Exception()
                    continue
                title = client.replaceHTMLCodes(title)

                season = item["episode"]["season"]
                season = re.sub("[^0-9]", "", "%01d" % int(season))
                if season == "0" and self.specials != "true":
                    #raise Exception()
                    continue

                episode = item["episode"]["number"]
                episode = re.sub("[^0-9]", "", "%01d" % int(episode))
                if episode == "0":
                    #raise Exception()
                    continue

                tvshowtitle = item["show"]["title"]
                if not tvshowtitle:
                    #raise Exception()
                    continue
                else:
                    tvshowtitle = client.replaceHTMLCodes(six.ensure_str(tvshowtitle))

                year = item["show"]["year"]
                year = re.sub("[^0-9]", "", str(year))

                imdb = item["show"]["ids"].get("imdb")
                if imdb is None or imdb == "":
                    imdb = "0"
                else:
                    imdb = "tt" + re.sub("[^0-9]", "", str(imdb))

                tvdb = item["show"]["ids"].get("tvdb")
                if not tvdb:
                    tvdb == "0"
                tvdb = re.sub("[^0-9]", "", str(tvdb))

                tmdb = item["show"]["ids"]["tmdb"]
                if not tmdb:
                    #raise Exception()
                    continue
                tmdb = str(tmdb)

                premiered = item["episode"].get("first_aired")
                try:
                    premiered = re.compile(r"(\d{4}-\d{2}-\d{2})").findall(premiered)[0]
                except:
                    premiered = "0"

                studio = item["show"].get("network")
                if not studio:
                    studio = "0"

                genre = item["show"].get("genres")
                genre = [i.title() for i in genre] if genre else []
                if not genre:
                    genre = "0"
                else:
                    genre = " / ".join(genre)

                try:
                    duration = str(item["show"]["runtime"])
                except:
                    duration = ""
                if not duration:
                    duration = "0"

                try:
                    rating = str(item["episode"]["rating"])
                except:
                    rating = "0"
                if rating is None or rating == "0.0":
                    rating = "0"

                try:
                    votes = str(item["episode"]["votes"])
                except:
                    votes = "0"
                try:
                    votes = str(format(int(votes), ",d"))
                except:
                    pass
                if not votes:
                    votes = "0"

                mpaa = item["show"].get("certification")
                if not mpaa:
                    mpaa = "0"

                try:
                    plot = item["episode"]["overview"]
                except:
                    plot = ""
                if not plot:
                    plot = item["show"]["overview"]
                if not plot:
                    plot = "0"
                else:
                    plot = client.replaceHTMLCodes(six.ensure_str(plot, errors="replace"))

                try:
                    paused_at = item.get("paused_at", "0") or "0"
                    paused_at = re.sub("[^0-9]+", "", paused_at)
                except:
                    paused_at = "0"

                try:
                    watched_at = item.get("watched_at", "0") or "0"
                    watched_at = re.sub("[^0-9]+", "", watched_at)
                except:
                    watched_at = "0"

                try:
                    if self.lang != "en":
                        # fflog(f'tłumaczenia {imdb=} {season=} {episode=}')
                        trans_item = trakt.getTVShowTranslation(imdb, lang=self.lang, season=season, episode=episode, full=True)
                        # fflog(f'{trans_item=}')
                        if trans_item:
                            title = client.replaceHTMLCodes(six.ensure_str(trans_item.get("title") or "")) or title
                            plot = client.replaceHTMLCodes(six.ensure_str(trans_item.get("overview"), errors="replace")) or plot

                        # fflog(f'ustalenie polskiego tytułu serialu {imdb=}')
                        localtvshowtitle = localtvshowtitles.get(imdb)
                        if not localtvshowtitle:
                            # fflog(f'pobranie polskiego tytułu serialu z internetu {imdb=}')
                            localtvshowtitle = trakt.getTVShowTranslation(imdb, lang=self.lang) or tvshowtitle
                            localtvshowtitles[imdb] = localtvshowtitle
                        # fflog(f'{localtvshowtitle=}')
                except Exception:
                    fflog_exc(0)
                    localtvshowtitle = ""  # ważne
                    pass

                originaltvshowtitle = ""  # szkoda, że trakt nie daje takiej informacji

                itemlist.append(
                    {"title": title, "season": season, "episode": episode, "tvshowtitle": tvshowtitle, "year": year,
                        "premiered": premiered, "status": "Continuing", "studio": studio, "genre": genre,
                        "duration": duration, "rating": rating, "votes": votes, "mpaa": mpaa, "plot": plot,
                        "imdb": imdb, "tvdb": tvdb, "tmdb": tmdb, "poster": "0", "thumb": "0", "paused_at": paused_at,
                        "watched_at": watched_at, "localtvshowtitle": localtvshowtitle,
                        #"originaltvshowtitle": originaltvshowtitle,
                        })
            except Exception:
                fflog_exc(1)
                # log_utils.log("trakt_list1", "indexer")
                pass

        itemlist = itemlist[::-1]
        return itemlist


    def trakt_progress_list(self, url, user, lang):
        try:
            url += "?extended=full"
            result = trakt.getTraktAsJson(url)
            # log_utils.log('prog_res: ' + str(result))
            items = []
        except:
            return

        sortorder = control.setting("prgr.sortorder")
        for item in result:
            try:
                num_1 = 0
                for i in range(0, len(item["seasons"])):
                    if item["seasons"][i]["number"] > 0:
                        num_1 += len(item["seasons"][i]["episodes"])
                num_2 = int(item["show"]["aired_episodes"])
                if num_1 >= num_2:
                    # raise Exception()
                    continue

                season = str(item["seasons"][-1]["number"])

                episode = [x for x in item["seasons"][-1]["episodes"] if "number" in x]
                episode = sorted(episode, key=lambda x: x["number"])
                episode = str(episode[-1]["number"])

                tvshowtitle = item["show"]["title"]
                if not tvshowtitle:
                    raise Exception()
                    # continue
                else:
                    tvshowtitle = client.replaceHTMLCodes(six.ensure_str(tvshowtitle))

                year = item["show"]["year"]
                year = re.sub("[^0-9]", "", str(year))
                if int(year) > int(self.datetime.strftime("%Y")):  # co to za warunek ?
                    # raise Exception()
                    continue

                imdb = item["show"]["ids"].get("imdb")
                if not imdb:
                    imdb = "0"

                tvdb = item["show"]["ids"].get("tvdb")
                if not tvdb:
                    tvdb = "0"
                else:
                    tvdb = re.sub("[^0-9]", "", str(tvdb))

                tmdb = item["show"]["ids"].get("tmdb")
                if not tmdb:
                    tmdb = "0"
                else:
                    tmdb = str(tmdb)

                studio = item.get("show").get("network", "0")
                if not studio:
                    studio = "0"

                duration = item["show"].get("runtime")
                if not duration:
                    duration = "0"

                mpaa = item["show"].get("certification")
                if not mpaa:
                    mpaa = "0"

                status = item["show"].get("status")
                if not status:
                    status = "0"

                genre = item["show"].get("genres")
                if not genre:
                    genre = "0"
                else:
                    genre = " / ".join(genre)

                last_watched = item.get("last_watched_at")
                if last_watched is None or last_watched == "":
                    last_watched = "0"

                if self.lang != "en":
                    localtvshowtitle = trakt.getTVShowTranslation(imdb, lang=self.lang) or tvshowtitle

                items.append({"imdb": imdb, "tvdb": tvdb, "tmdb": tmdb, "tvshowtitle": tvshowtitle, "year": year,
                    "studio": studio, "duration": duration, "mpaa": mpaa, "status": status, "genre": genre,
                    "snum": season, "enum": episode, "_last_watched": last_watched, "localtvshowtitle": localtvshowtitle, })
            except Exception:
                fflog_exc(1)
                pass

        try:
            result = trakt.getTraktAsJson(self.hiddenprogress_link)
            # log_utils.log('hid_prog_res: ' + str(result))
            result = [str(i["show"]["ids"]["tmdb"]) for i in result]

            items = [i for i in items if not i["tmdb"] in result]
        except Exception:
            log_utils.log("Trakt Progress List 1", "indexer")
            fflog_exc(1)
            pass


        def items_list(i, arts_from_fanarttv=None, meta_from_tmdb=None):

            tmdb, imdb, tvdb = i.get("tmdb"), i.get("imdb"), i.get("tvdb")
            if (not tmdb or tmdb == "0") and not imdb == "0":
                try:
                    url = self.tmdb_by_imdb % imdb
                    result = self.session.get(url, timeout=16).json()
                    tmdb_result = result["tv_results"][0]
                    tmdb = tmdb_result.get("id")
                    if not tmdb:
                        tmdb = "0"
                    else:
                        tmdb = str(tmdb)
                except Exception:
                    tmdb = "0"  # dać czy nie ?
                    pass

            # try:
            # item = [x for x in self.blist if x['tmdb'] == tmdb and x['snum'] == i['snum'] and x['enum'] == i['enum']][0]
            # item['action'] = 'episodes'
            # self.list.append(item)
            # return
            # except:
            # pass

            try:
                if tmdb == "0":
                    raise Exception()

                _episode = str(int(i["enum"]) + 1)
                _season = str(int(i["snum"]) + 1)

                url = self.tmdb_episode_link % (tmdb, i["snum"], _episode)
                r = self.session.get(url, timeout=10)
                if r.json().get("status_code") == 34:
                    url2 = self.tmdb_episode_link % (tmdb, _season, "1")
                    r = self.session.get(url2, timeout=10)
                r.raise_for_status()
                r.encoding = "utf-8"
                item = r.json()  # if six.PY3 else utils.json_loads_as_str(r.text)

                try:
                    premiered = item["air_date"]
                except:
                    premiered = ""
                if not premiered:
                    premiered = "0"

                unaired = ""
                if i.get("status") == "Ended":
                    pass
                elif premiered == "0":
                    raise Exception()
                elif int(re.sub(r"[^0-9]", "", str(premiered))) > int(re.sub(r"[^0-9]", "", str(self.today_date))):
                    unaired = "true"
                    if self.showunaired != "true":
                        raise Exception()

                title = item["name"]
                if not title:
                    title = "0"

                season = str(item["season_number"])
                # season = '%01d' % season
                if int(season) == 0 and self.specials != 'true':
                    raise Exception()

                episode = item["episode_number"]
                episode = "%01d" % episode

                tvshowtitle = i["tvshowtitle"]
                localtvshowtitle = i.get("localtvshowtitle", "")

                year = i["year"]

                try:
                    still_path = item["still_path"]
                except:
                    still_path = ""
                if not still_path:
                    thumb = "0"
                else:
                    thumb = self.tm_img_link % ("1280", still_path)

                try:
                    rating = str(item["vote_average"])
                except:
                    rating = ""
                if not rating:
                    rating = "0"

                try:
                    votes = str(item["vote_count"])
                except:
                    votes = ""
                if not votes:
                    votes = "0"

                try:
                    plot = item["overview"]
                except:
                    plot = ""
                if not plot:
                    url_en = self.tmdb_episode_link_en % (tmdb, i["snum"], _episode)
                    r_en = self.session.get(url_en, timeout=10)
                    if r_en.json().get("status_code") == 34:
                        url2_en = self.tmdb_episode_link_en % (tmdb, _season, "1")
                        r_en = self.session.get(url2_en, timeout=10)
                    r_en.raise_for_status()
                    r_en.encoding = "utf-8"
                    item_en = r_en.json()
                    try:
                        plot = item_en["overview"]
                    except:
                        plot = ""
                    if not plot:
                        plot = "0"

                try:
                    r_crew = item["crew"]
                    director = [d for d in r_crew if d["job"] == "Director"]
                    director = ", ".join([d["name"] for d in director])
                    writer = [w for w in r_crew if w["job"] == "Writer"]
                    writer = ", ".join([w["name"] for w in writer])
                except:
                    director = writer = ""
                if not director:
                    director = "0"
                if not writer:
                    writer = "0"

                castwiththumb = []
                try:
                    r_cast = item["credits"]["cast"][:30]
                    for person in r_cast:
                        _icon = person["profile_path"]
                        icon = self.tm_img_link % ("185", _icon) if _icon else ""
                        castwiththumb.append({"name": person["name"], "role": person["character"], "thumbnail": icon, })
                except:
                    pass
                if not castwiththumb:
                    castwiththumb = "0"

                poster = poster2 = fanart = fanart2 = landscape = landscape2 = clearlogo = clearart = keyart = banner = banner2 = characterart= "0"

                if meta_from_tmdb:
                    poster = meta_from_tmdb.get( (imdb, tmdb) ).get("poster") or "0"
                    poster2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_posters") or "0"
                    fanart = meta_from_tmdb.get( (imdb, tmdb) ).get("fanart") or "0"
                    fanart2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_fanarts") or "0"
                    landscape = meta_from_tmdb.get( (imdb, tmdb) ).get("landscape") or "0"
                    landscape2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_landscapes") or "0"
                    clearlogo = meta_from_tmdb.get( (imdb, tmdb) ).get("clearlogo") or "0"
                    clearart = meta_from_tmdb.get( (imdb, tmdb) ).get("clearart") or "0"
                    keyart = meta_from_tmdb.get( (imdb, tmdb) ).get("keyart") or "0"
                    banner = meta_from_tmdb.get( (imdb, tmdb) ).get("banner") or "0"
                    banner2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_banners") or "0"
                    characterart = meta_from_tmdb.get( (imdb, tmdb) ).get("characterart") or "0"

                    if isinstance(poster2, dict):
                        poster2 = poster2.get(season)
                    if isinstance(fanart2, dict):
                        fanart2 = fanart2.get(season)
                    if isinstance(landscape2, dict):
                        landscape2 = landscape2.get(season)
                    if isinstance(banner2, dict):
                        banner2 = banner2.get(season)

                """
                # fflog(f'{tvdb=}')
                if not tvdb == "0":
                    if self.fanartTV_artwork == "true":
                        # fflog('pobranie grafik z fanart_tv_art')
                        # (poster, poster2, fanart, banner, landscape, clearlogo, clearart,) = self.fanart_tv_art(tvdb)  # wyniosłem poza pętlę
                        try:
                            # fflog(f'próba pozyskania grafiki z FanartTV {tvdb=} {season=} {episode=}')
                            poster, poster2, fanart, banner, landscape, clearlogo, clearart, banner2, landscape2 = arts_from_fanarttv.get(tvdb)
                            if isinstance(poster2, dict):
                                poster2 = poster2.get(season)
                            if isinstance(banner2, dict):
                                banner2 = banner2.get(season)
                            if isinstance(landscape2, dict):
                                landscape2 = landscape2.get(season)
                            # fflog(f'Fanart TV zwrócił, co mógł')
                        except Exception:
                            fflog_exc(1)
                            pass
                else:
                    pass
                """
                """
                if (not poster or poster == "0") and arts_from_tmdb:
                    poster = arts_from_tmdb.get( (tmdb, season) )
                    poster = self.tm_img_link % ("500", poster) if poster else "0"
                    # fflog(f'{poster=} {tmdb=} {season=}')
                """
                if (not poster or poster == "0") and meta_from_tmdb:
                    seasons_posters = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_posters") or {}
                    poster = seasons_posters.get(season) or "0"
                    # fflog(f'{poster=} {tmdb=} {season=}')

                #if (not poster or poster == "0") and meta_from_tmdb:
                if meta_from_tmdb:
                    tvshow_poster = meta_from_tmdb.get( (imdb, tmdb) ).get("poster")
                    # fflog(f'{tvshow_poster=} {imdb=} {tmdb=}')
                    if (not poster or poster == "0"):
                        poster = tvshow_poster if tvshow_poster and tvshow_poster != "0" else "0"
                    # fflog(f'{poster=} {imdb=} {tmdb=}')
                else:
                    tvshow_poster = "0"

                if poster2 and poster2 != "0":
                    poster = poster2

                if banner2 and banner2 != "0":
                    banner = banner2
                if landscape2 and landscape2 != "0":
                    landscape = landscape2

                if fanart2 and fanart2 != "0":
                    fanart = fanart2

                if (not fanart or fanart == "0") and meta_from_tmdb:
                    fanart = meta_from_tmdb.get( (imdb, tmdb) ).get("fanart") or "0"
                    # fanart = self.tm_img_link % ("1280", fanart) if fanart else "0"
                    # fanart = fanart if fanart else "0"
                    # fflog(f'{fanart=} {imdb=} {tmdb=}')

                if (not landscape or landscape == "0") and meta_from_tmdb:
                    landscape = meta_from_tmdb.get( (imdb, tmdb) ).get("landscape") or "0"
                    # landscape = self.tm_img_link % ("1280", landscape) if landscape else "0"
                    # landscape = landscape if landscape else "0"
                    # fflog(f'{landscape=} {imdb=} {tmdb=}')

                if (not clearlogo or clearlogo == "0") and meta_from_tmdb:
                    clearlogo = meta_from_tmdb.get( (imdb, tmdb) ).get("clearlogo") or "0"
                    # fflog(f'{clearlogo=} {imdb=} {tmdb=}')

                # fflog(f'{poster=} {fanart=} {banner=} {landscape=} {clearlogo=} {clearart=}')

                self.list.append(
                    {"title": title, "season": season, "episode": episode, "tvshowtitle": tvshowtitle, "year": year,
                        "premiered": premiered, "studio": i.get("studio", ""), "genre": i.get("genre", ""),
                        "status": i.get("status"), "duration": i.get("duration", ""), "rating": rating, "votes": votes,
                        "mpaa": i.get("mpaa", ""), "director": director, "writer": writer, "castwiththumb": castwiththumb,
                        "plot": plot, "poster": poster, "banner": banner, "fanart": fanart, "thumb": thumb,
                        "clearlogo": clearlogo, "clearart": clearart, "landscape": landscape, "snum": i["snum"],
                        "enum": i["enum"], "action": "episodes", "unaired": unaired,
                        "_last_watched": i["_last_watched"], "imdb": imdb, "tvdb": tvdb, "tmdb": tmdb,
                        "_sort_key": max(i["_last_watched"], premiered), "localtvshowtitle": localtvshowtitle,
                        "tvshow.poster": tvshow_poster,
                        "keyart": keyart, "characterart": characterart,
                    })
            except:
                log_utils.log("trakt_progress_list", "indexer")
                pass

        items = items[:50]

        arts_from_fanarttv = {}
        """
        tvdb_list = list(set((i["tvdb"]) for i in items if i["tvdb"]!="0"))
        if self.fanartTV_artwork == "true":
            for tvdb in tvdb_list:
                arts = self.fanart_tv_art(tvdb)
                arts_from_fanarttv.update({tvdb: arts})
        # fflog(f'{len(arts_from_fanarttv)=}  {arts_from_fanarttv=}')
        """

        meta_from_tmdb = {}
        tmdb_list = list(set((i["imdb"], i["tmdb"]) for i in items))
        # fflog(f'{tmdb_list=}')
        for imdb, tmdb in tmdb_list:
            meta = self.get_meta_for_tvshow(imdb, tmdb)
            meta_from_tmdb[imdb, tmdb] = {k:v for k,v in meta.items() 
                                          # if k in ["poster", "landscape", "fanart", "seasons_posters", "clearlogo"]
                                          if k in [ "poster",
                                                    "seasons_posters",
                                                    "fanart",
                                                    "seasons_fanarts",
                                                    "landscape",
                                                    "seasons_landscapes",
                                                    "clearlogo",
                                                    "clearart",
                                                    "keyart",
                                                    "banner",
                                                    "seasons_banners",
                                                    "characterart",
                                                  ]
                                         }
        # fflog(f'{len(meta_from_tmdb)=}  {meta_from_tmdb=}')
        meta = None

        threads = []
        import threading

        for i in items:
            threads.append(threading.Thread(target=items_list, args=(i, arts_from_fanarttv, meta_from_tmdb,)))  # asynchronicznie
        [i.start() for i in threads]
        [i.join() for i in threads]

        try:
            if sortorder == "0":
                self.list = sorted(self.list, key=lambda k: k["premiered"], reverse=True)
            else:
                self.list = sorted(self.list, key=lambda k: k["_sort_key"], reverse=True)
        except Exception:
            fflog_exc(1)
            pass

        return self.list


    def trakt_episodes_list(self, url, user, lang):
        # fflog(f'{url=}')
        items = self.trakt_list(url, user)
        # fflog(f'{len(items)=}  {items=}')

        def items_list(i, arts_from_fanarttv=None, arts_from_tmdb=None, meta_from_tmdb=None):

            tmdb, imdb, tvdb = i.get("tmdb"), i.get("imdb"), i.get("tvdb")
            if (not tmdb or tmdb == "0") and not imdb == "0":
                try:
                    url = self.tmdb_by_imdb % imdb
                    # control.log(f'[trakt_episodes_list] {url=}', 1)
                    result = self.session.get(url, timeout=16).json()
                    tmdb_result = result["tv_results"][0]
                    tmdb = tmdb_result.get("id")
                    if not tmdb:
                        tmdb = "0"
                    else:
                        tmdb = str(tmdb)
                except Exception:
                    tmdb = "0"
                    fflog_exc(1)
                    pass

            # try:
                # item = [x for x in self.blist if x['tmdb'] == tmdb and x['season'] == i['season'] and x['episode'] == i['episode']][0]
                # if item['poster'] == '0': raise Exception()
                # self.list.append(item)
                # return
            # except Exception:
                # pass

            try:
                if tmdb == "0":
                    raise Exception()

                # if i['season'] == '0': raise Exception()
                if True:
                    url = self.tmdb_episode_link % (tmdb, i["season"], i["episode"])
                    # control.log(f'[trakt_episodes_list] {url=}', 1)
                    r = self.session.get(url, timeout=16)
                    r.encoding = "utf-8"
                    item = r.json()  # if six.PY3 else utils.json_loads_as_str(r.text)
                else:
                    item = i

                title = item.get("name", "")
                if not title:
                    title = "0"

                season = str(item["season_number"])
                # season = '%01d' % season
                if int(season) == 0 and self.specials != 'true':
                    raise Exception()

                episode = str(item["episode_number"])
                # episode = '%01d' % episode

                tvshowtitle = i["tvshowtitle"]
                localtvshowtitle = i.get("localtvshowtitle", "")

                premiered = i.get("premiered")

                status, duration, mpaa, studio, genre, year = (
                    i.get("status"), i.get("duration"), i.get("mpaa"), i.get("studio"), i.get("genre"), i.get("year"),)

                rating, votes = i.get("rating"), i.get("votes")

                try:
                    still_path = item["still_path"]  # stopklatka (miniatura) odcinka
                except:
                    still_path = ""
                if not still_path:
                    thumb = "0"
                else:
                    thumb = self.tm_img_link % ("1280", still_path)

                try:
                    plot = item["overview"]  # z tmdb
                except:
                    plot = ""
                if not plot:
                    plot = i["plot"]  # z trakt

                try:
                    r_crew = item["crew"]
                    director = [d for d in r_crew if d["job"] == "Director"]
                    director = ", ".join([d["name"] for d in director])
                    writer = [w for w in r_crew if w["job"] == "Writer"]
                    writer = ", ".join([w["name"] for w in writer])
                except:
                    director = writer = ""
                if not director:
                    director = "0"
                if not writer:
                    writer = "0"

                castwiththumb = []
                try:
                    r_cast = item["credits"]["cast"][:30]
                    for person in r_cast:
                        _icon = person["profile_path"]
                        icon = self.tm_img_link % ("185", _icon) if _icon else ""
                        castwiththumb.append({"name": person["name"], "role": person["character"], "thumbnail": icon, })
                except:
                    pass
                if not castwiththumb:
                    castwiththumb = "0"

                paused_at = i.get("paused_at", "0") or "0"

                watched_at = i.get("watched_at", "0") or "0"

                poster = poster2 = fanart = fanart2 = landscape = landscape2 = clearlogo = clearart = keyart = banner = banner2 = characterart= "0"

                if meta_from_tmdb:
                    poster = meta_from_tmdb.get( (imdb, tmdb) ).get("poster") or "0"
                    poster2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_posters") or "0"
                    fanart = meta_from_tmdb.get( (imdb, tmdb) ).get("fanart") or "0"
                    fanart2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_fanarts") or "0"
                    landscape = meta_from_tmdb.get( (imdb, tmdb) ).get("landscape") or "0"
                    landscape2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_landscapes") or "0"
                    clearlogo = meta_from_tmdb.get( (imdb, tmdb) ).get("clearlogo") or "0"
                    clearart = meta_from_tmdb.get( (imdb, tmdb) ).get("clearart") or "0"
                    keyart = meta_from_tmdb.get( (imdb, tmdb) ).get("keyart") or "0"
                    banner = meta_from_tmdb.get( (imdb, tmdb) ).get("banner") or "0"
                    banner2 = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_banners") or "0"
                    characterart = meta_from_tmdb.get( (imdb, tmdb) ).get("characterart") or "0"

                    if isinstance(poster2, dict):
                        poster2 = poster2.get(season)
                    if isinstance(fanart2, dict):
                        fanart2 = fanart2.get(season)
                    if isinstance(landscape2, dict):
                        landscape2 = landscape2.get(season)
                    if isinstance(banner2, dict):
                        banner2 = banner2.get(season)

                """
                # fflog(f'{tvdb=}')
                if not tvdb == "0":
                    if self.fanartTV_artwork == "true":
                        # fflog('pobranie grafik z fanart_tv_art')
                        # (poster, poster2, fanart, banner, landscape, clearlogo, clearart, banner2, landscape2) = self.fanart_tv_art(tvdb)  # wyniosłem poza pętlę
                        try:
                            # fflog(f'próba pozyskania grafiki z FanartTV {tvdb=} {season=} {episode=}')
                            poster, poster2, fanart, banner, landscape, clearlogo, clearart, banner2, landscape2 = arts_from_fanarttv.get(tvdb)
                            if isinstance(poster2, dict):
                                poster2 = poster2.get(season)
                            if isinstance(banner2, dict):
                                banner2 = banner2.get(season)
                            if isinstance(landscape2, dict):
                                landscape2 = landscape2.get(season)
                            # fflog(f'Fanart TV zwrócił, co mógł')
                        except Exception:
                            fflog_exc(1)
                            pass
                else:
                    pass
                """
                if (not poster or poster == "0") and arts_from_tmdb:
                    poster = arts_from_tmdb.get( (tmdb, season) )
                    poster = self.tm_img_link % ("500", poster) if poster else "0"
                    # fflog(f'{poster=} {tmdb=} {season=}')

                if (not poster or poster == "0") and meta_from_tmdb:
                    seasons_posters = meta_from_tmdb.get( (imdb, tmdb) ).get("seasons_posters") or {}
                    poster = seasons_posters.get(season) or "0"
                    # fflog(f'{poster=} {tmdb=} {season=}')

                #if (not poster or poster == "0") and meta_from_tmdb:
                if meta_from_tmdb:
                    tvshow_poster = meta_from_tmdb.get( (imdb, tmdb) ).get("poster")
                    # fflog(f'{tvshow_poster=} {imdb=} {tmdb=}')
                    if (not poster or poster == "0"):
                        poster = tvshow_poster if tvshow_poster and tvshow_poster != "0" else "0"
                    # fflog(f'{poster=} {imdb=} {tmdb=}')
                else:
                    tvshow_poster = "0"

                if poster2 and poster2 != "0":
                    poster = poster2

                if banner2 and banner2 != "0":
                    banner = banner2
                if landscape2 and landscape2 != "0":
                    landscape = landscape2

                if fanart2 and fanart2 != "0":
                    fanart = fanart2

                if (not fanart or fanart == "0") and meta_from_tmdb:
                    fanart = meta_from_tmdb.get( (imdb, tmdb) ).get("fanart") or "0"
                    # fanart = self.tm_img_link % ("1280", fanart) if fanart else "0"
                    # fanart = fanart if fanart else "0"
                    # fflog(f'{fanart=} {imdb=} {tmdb=}')

                if (not landscape or landscape == "0") and meta_from_tmdb:
                    landscape = meta_from_tmdb.get( (imdb, tmdb) ).get("landscape") or "0"
                    # landscape = self.tm_img_link % ("1280", landscape) if landscape else "0"
                    # landscape = landscape if landscape else "0"
                    # fflog(f'{landscape=} {imdb=} {tmdb=}')

                if (not clearlogo or clearlogo == "0") and meta_from_tmdb:
                    clearlogo = meta_from_tmdb.get( (imdb, tmdb) ).get("clearlogo") or "0"
                    # fflog(f'{clearlogo=} {imdb=} {tmdb=}')

                # fflog(f'{poster=} {fanart=} {banner=} {landscape=} {clearlogo=} {clearart=}')

                self.list.append(
                    {"title": title, "season": season, "episode": episode, "tvshowtitle": tvshowtitle, "year": year,
                        "premiered": premiered, "status": status, "studio": studio, "genre": genre,
                        "duration": duration, "rating": rating, "votes": votes, "mpaa": mpaa, "director": director,
                        "writer": writer, "castwiththumb": castwiththumb, "plot": plot, "imdb": imdb, "tvdb": tvdb,
                        "tmdb": tmdb, "poster": poster, "banner": banner, "fanart": fanart, "thumb": thumb, "keyart": keyart,
                        "clearlogo": clearlogo, "clearart": clearart, "landscape": landscape, "paused_at": paused_at,
                        "watched_at": watched_at, "localtvshowtitle": localtvshowtitle, "tvshow.poster": tvshow_poster,
                        "characterart": characterart,
                        })

            except Exception:
                log_utils.log("trakt_episodes_list", "indexer")
                fflog_exc(1)
                pass

        items = items[:100]
        # fflog(f'{len(items)=}  {items=}')

        arts_from_fanarttv = {}
        """
        tvdb_list = list(set((i["tvdb"]) for i in items if i["tvdb"]!="0"))
        if self.fanartTV_artwork == "true":
            for tvdb in tvdb_list:
                arts = self.fanart_tv_art(tvdb)
                arts_from_fanarttv.update({tvdb: arts})
        # fflog(f'{len(arts_from_fanarttv)=}  {arts_from_fanarttv=}')
        """

        arts_from_tmdb = {}  # do wywalenia (bo to daje tylko postery sezonu, a niżej mam więcej)
        """
        tmdb_list = list(set((i["tmdb"], i["season"]) for i in items))
        # fflog(f'{tmdb_list=}')
        for tmdb, season in tmdb_list:
            url = self.tmdb_season_lite_link % (tmdb, season)
            # control.log(f'{url=}', 1)
            try:
                r = self.session.get(url, timeout=16)
                r.encoding = "utf-8"
                item = r.json()
                arts = item.get("poster_path", "")  # tylko poster sezonu
                arts_from_tmdb[tmdb, season] = arts
            except Exception:
                # fflog_exc(1)
                pass
        # fflog(f'{len(arts_from_tmdb)=}  {arts_from_tmdb=}')
        """

        tmdb_list = list(set((i["imdb"], i["tmdb"]) for i in items))
        # fflog(f'{tmdb_list=}')
        meta_from_tmdb = {}
        for imdb, tmdb in tmdb_list:
            meta = self.get_meta_for_tvshow(imdb, tmdb)
            meta_from_tmdb[imdb, tmdb] = {k:v for k,v in meta.items() 
                                          #if k in ["poster", "landscape", "fanart", "seasons_posters", "clearlogo"]
                                          if k in [ "poster",
                                                    "seasons_posters",
                                                    "fanart",
                                                    "seasons_fanarts",
                                                    "landscape",
                                                    "seasons_landscapes",
                                                    "clearlogo",
                                                    "clearart",
                                                    "keyart",
                                                    "banner",
                                                    "seasons_banners",
                                                    "characterart",
                                                  ]
                                         }
        # fflog(f'{len(meta_from_tmdb)=}  {meta_from_tmdb=}')
        meta = None

        asynchronicznie = False
        threads = []
        if asynchronicznie:
            import threading
        # fflog('start')
        for i in items:
            if asynchronicznie:
                threads.append(threading.Thread(target=items_list, args=(i, arts_from_fanarttv, arts_from_tmdb, meta_from_tmdb,)))  # asynchronicznie
            else:
                items_list(i,arts_from_fanarttv,arts_from_tmdb, meta_from_tmdb)  # sychronicznie
        if threads:
            [i.start() for i in threads]
            [i.join() for i in threads]
        # fflog('koniec')

        return self.list


    def trakt_user_list(self, url, user):
        try:
            items = trakt.getTraktAsJson(url)
        except Exception:
            fflog_exc(1)
            pass

        for item in items:
            try:
                try:
                    name = item["list"]["name"]
                    # name += " *"
                    name += f'  [LIGHT][I][{item["list"]["user"]["username"]}][/I][/LIGHT]'
                except:
                    name = item["name"]
                name = client.replaceHTMLCodes(name)

                try:
                    url = (trakt.slug(item["list"]["user"]["username"]), item["list"]["ids"]["slug"])
                except:
                    url = ("me", item["ids"]["slug"])
                url = self.traktlist_link % url
                # url = six.ensure_str(url)

                self.list.append({"name": name, "url": url, "context": url})
            except Exception:
                fflog_exc(1)
                pass

        self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
        return self.list


    def tvmaze_list(self, url, limit):  # ciekawe kiedy ta funkcja jest w użyciu
        fflog(f'[tvmaze_list] {url=} {limit=}')
        try:
            # result = client.request(url)
            items = self.session.get(url).json()
            itemlist = []
        # items = json.loads(result)
        except Exception:
            fflog_exc(1)
            return

        for item in items:
            try:
                if not "english" in item["show"]["language"].lower():
                    raise Exception()

                if limit == True and not "scripted" in item["show"]["type"].lower():
                    raise Exception()

                title = item["name"]
                if title is None or title == "":
                    raise Exception()
                title = client.replaceHTMLCodes(title)
                # title = six.ensure_str(title)

                season = item["season"]
                season = re.sub("[^0-9]", "", "%01d" % int(season))
                if season == "0":
                    raise Exception()
                # season = six.ensure_str(season)

                episode = item["number"]
                episode = re.sub("[^0-9]", "", "%01d" % int(episode))
                if episode == "0":
                    raise Exception()
                # episode = six.ensure_str(episode)

                tvshowtitle = item["show"]["name"]
                if tvshowtitle is None or tvshowtitle == "":
                    raise Exception()
                tvshowtitle = client.replaceHTMLCodes(tvshowtitle)
                # tvshowtitle = six.ensure_str(tvshowtitle)

                year = item["show"]["premiered"]
                year = re.findall(r"(\d{4})", year)[0]
                # year = six.ensure_str(year)

                imdb = item["show"]["externals"].get("imdb")
                if imdb is None or imdb == "":
                    imdb = "0"
                else:
                    imdb = "tt" + re.sub("[^0-9]", "", str(imdb))
                # imdb = six.ensure_str(imdb)

                tvdb = item["show"]["externals"].get("thetvdb")
                if tvdb is None or tvdb == "":
                    tvdb = "0"  # raise Exception()
                tvdb = re.sub("[^0-9]", "", str(tvdb))
                # tvdb = six.ensure_str(tvdb)

                poster1 = "0"
                try:
                    poster1 = item["show"]["image"]["original"]
                except:
                    poster1 = "0"
                if poster1 is None or poster1 == "":
                    poster1 = "0"
                else:
                    poster1 = six.ensure_str(poster1)

                try:
                    thumb1 = item["show"]["image"]["original"]
                except:
                    thumb1 = "0"
                try:
                    thumb2 = item["image"]["original"]
                except:
                    thumb2 = "0"
                if thumb2 is None or thumb2 == "0":
                    thumb = thumb1
                else:
                    thumb = thumb2
                if thumb is None or thumb == "":
                    thumb = "0"
                thumb = six.ensure_str(thumb)

                premiered = item.get("airdate")
                try:
                    premiered = re.findall(r"(\d{4}-\d{2}-\d{2})", premiered)[0]
                except:
                    premiered = "0"
                premiered = six.ensure_str(premiered)

                try:
                    studio = item["show"]["network"]["name"]
                except:
                    studio = "0"
                if studio is None:
                    studio = "0"
                studio = six.ensure_str(studio)

                try:
                    genre = item["show"]["genres"]
                except:
                    genre = "0"
                genre = [i.title() for i in genre]
                if not genre:
                    genre = "0"
                genre = " / ".join(genre)
                genre = six.ensure_str(genre)

                try:
                    duration = item["show"]["runtime"]
                except:
                    duration = "0"
                if duration is None:
                    duration = "0"
                duration = str(duration)
                # duration = six.ensure_str(duration)

                try:
                    rating = item["show"]["rating"]["average"]
                except:
                    rating = "0"
                if rating is None or rating == "0.0":
                    rating = "0"
                rating = str(rating)
                # rating = six.ensure_str(rating)

                votes = "0"

                try:
                    plot = item["show"]["summary"]
                except:
                    plot = "0"
                if plot is None:
                    plot = "0"
                plot = re.sub("<.+?>|</.+?>|\n", "", plot)
                plot = client.replaceHTMLCodes(plot)
                # plot = six.ensure_str(plot)

                poster2 = fanart = banner = landscape = clearlogo = clearart = banner2 = landscape2 = "0"

                if not tvdb == "0":
                    if self.fanartTV_artwork == "true":
                        poster1, poster2, fanart, banner, landscape, clearlogo, clearart, banner2, landscape2 = self.fanart_tv_art(tvdb)
                        if isinstance(poster2, dict):
                            poster2 = poster2.get(season)
                        if isinstance(banner2, dict):
                            banner2 = banner2.get(season)
                        if isinstance(landscape2, dict):
                            landscape2 = landscape2.get(season)

                poster = poster2 if poster2 and not poster2 == "0" else poster1
                banner = banner2 if banner2 and not banner2 == "0" else banner
                landscape = landscape2 if landscape2 and not landscape2 == "0" else landscape

                itemlist.append(
                    {"title": title, "season": season, "episode": episode, "tvshowtitle": tvshowtitle, "year": year,
                        "premiered": premiered, "status": "Continuing", "studio": studio, "genre": genre,
                        "duration": duration, "rating": rating, "votes": votes, "plot": plot, "imdb": imdb,
                        "tvdb": tvdb, "tmdb": "0", "thumb": thumb, "poster": poster, "banner": banner, "fanart": fanart,
                        "clearlogo": clearlogo, "clearart": clearart, "landscape": landscape, })

            except:
                pass

        itemlist = itemlist[::-1]
        return itemlist


    def fanart_tv_art(self, tvdb, season=None):  # "season" do usunięcia
        # chyba już tylko dla tvmaze_list list jest to uruchamiane
        poster = poster2 = fanart = banner = landscape = clearlogo = clearart = banner2 = landscape2 = "0"
        # props  = ["seasonposter", "tvposter", "showbackground", "tvbanner", "hdtvlogo", "hdclearart", "tvthumb", "seasonbanner", "seasonthumb"]
        # props += ["characterart"]  # to do
        order = 1  # -1 to odwrócenie (kiedyś tak było, ale dlaczego?)
        # control.log(f'{self.fanart_tv_user=}', 1)
        # control.log(f'{self.fanart_tv_headers=}', 1)
        if self.fanart_tv_user != '':

            try:
                # control.log(f'url: {self.fanart_tv_art_link % tvdb}  {self.fanart_tv_headers=}', 1)
                r = self.session.get(self.fanart_tv_art_link % tvdb, headers=self.fanart_tv_headers, timeout=10, )
                # fflog(f'from FanartTV: {r=}')
                if r.status_code >= 400:
                    # fflog(f'{r.text=}')
                    pass
                r.raise_for_status()

                r.encoding = "utf-8"
                art = r.json()  # if six.PY3 else utils.json_loads_as_str(r.text)
                # fflog(f'{art=}')
            except Exception:
                art = {}
                pass

            if art:
                try:

                    try:
                        _poster = art["tvposter"]
                        _poster = ([x for x in _poster if x.get("lang") == self.lang][::order] 
                                 + [x for x in _poster if x.get("lang") == "en"][::order] 
                                 + [x for x in _poster if x.get("lang") in ["00", ""]][::order]
                                )
                        _poster = _poster[0]["url"]
                        if _poster:
                            poster = _poster
                    except Exception:
                        # fflog_exc(1)
                        pass

                    #if season:
                    if True:
                        try:
                            _poster = art["seasonposter"]
                            _poster = ([x for x in _poster if x.get("lang") == self.lang][::order] 
                                     + [x for x in _poster if x.get("lang") == "en"][::order] 
                                     + [x for x in _poster if x.get("lang") in ["00", ""]][::order]
                                    )
                            # if season:
                                # _poster = [x for x in _poster if x.get("season") == season]
                                # _poster = _poster[0]["url"]
                            # _poster = [{x["season"]:x["url"]} for x in _poster]  # lista
                            _poster = {x["season"]:x["url"] for x in _poster}  # słownik
                            if _poster:
                                poster2 = _poster
                        except Exception:
                            # fflog_exc(1)
                            pass

                        try:
                            _banner = art["seasonbanner"]
                            _banner = ([x for x in _banner if x.get("lang") == self.lang][::order] 
                                     + [x for x in _banner if x.get("lang") == "en"][::order] 
                                     + [x for x in _banner if x.get("lang") in ["00", ""]][::order]
                                    )
                            # if season:
                                # _banner = [x for x in _banner if x.get("season") == season]
                                # _banner = _banner[0]["url"]
                            # _banner = [{x["season"]:x["url"]} for x in _banner]
                            _banner = {x["season"]:x["url"] for x in _banner}
                            if _banner:
                                banner2 = _banner
                        except Exception:
                            # fflog_exc(1)
                            pass

                        try:
                            _landscape = art["seasonthumb"]
                            _landscape = ([x for x in _landscape if x.get("lang") == self.lang][::order] 
                                     + [x for x in _landscape if x.get("lang") == "en"][::order] 
                                     + [x for x in _landscape if x.get("lang") in ["00", ""]][::order]
                                    )
                            # if season:
                                # _landscape = [x for x in _landscape if x.get("season") == season]
                                # _landscape = _landscape[0]["url"]
                            # _landscape = [{x["season"]:x["url"]} for x in _landscape]
                            _landscape = {x["season"]:x["url"] for x in _landscape}
                            if _landscape:
                                landscape2 = _landscape
                        except Exception:
                            # fflog_exc(1)
                            pass

                    try:
                        _fanart = art["showbackground"]
                        _fanart = ( [x for x in _fanart if x.get("lang") == self.lang][::order] + 
                                    [x for x in _fanart if x.get("lang") == "en"][::order] + 
                                    [x for x in _fanart if x.get("lang") in ["00", ""]][::order]
                                  )
                        _fanart = _fanart[0]["url"]
                        if _fanart:
                            fanart = _fanart
                    except Exception:
                        # fflog_exc(1)
                        pass


                    #if self.hq_artwork == "true":  # wywalić trzeba będzie
                    if True:
                        # fflog(f'{self.hq_artwork=}')
                        try:
                            _banner = art["tvbanner"]
                            _banner = ( [x for x in _banner if x.get("lang") == self.lang][::order] + 
                                        [x for x in _banner if x.get("lang") == "en"][::order] + 
                                        [x for x in _banner if x.get("lang") in ["00", ""]][::order]
                                      )
                            _banner = _banner[0]["url"]
                            if _banner:
                                banner = _banner
                        except Exception:
                            # fflog_exc(1)
                            pass

                        try:
                            if "hdtvlogo" in art:
                                _clearlogo = art["hdtvlogo"]
                            else:
                                _clearlogo = art["clearlogo"]
                            _clearlogo = (
                                    [x for x in _clearlogo if x.get("lang") == self.lang][::order] + 
                                    [x for x in _clearlogo if x.get("lang") == "en"][::order] + 
                                    [x for x in _clearlogo if x.get("lang") in ["00", ""]][::order]
                                    )
                            _clearlogo = _clearlogo[0]["url"]
                            if _clearlogo:
                                clearlogo = _clearlogo
                        except Exception:
                            # fflog_exc(1)
                            pass

                        try:
                            if "hdclearart" in art:
                                _clearart = art["hdclearart"]
                            else:
                                _clearart = art["clearart"]
                            _clearart = ([x for x in _clearart if x.get("lang") == self.lang][::order] + 
                                         [x for x in _clearart if x.get("lang") == "en"][::order] + 
                                         [x for x in _clearart if x.get("lang") in ["00", ""]][::order]
                                        )
                            _clearart = _clearart[0]["url"]
                            if _clearart:
                                clearart = _clearart
                        except Exception:
                            # fflog_exc(1)
                            pass

                        try:
                            if "tvthumb" in art:
                                _landscape = art["tvthumb"]
                            else:
                                _landscape = art["showbackground"]  # fallback
                            _landscape = (
                                    [x for x in _landscape if x.get("lang") == self.lang][::order] +
                                    [x for x in _landscape if x.get("lang") == "en"][::order] + 
                                    [x for x in _landscape if x.get("lang") in ["00", ""]][::order]
                                    )
                            _landscape = _landscape[0]["url"]
                            if _landscape:
                                landscape = _landscape
                        except Exception:
                            # fflog_exc(1)
                            pass

                except Exception:
                    log_utils.log("fanart.tv art fail", "indexer")
                    fflog_exc(1)
                    pass

        else:
            # brak danych do zalogowania do fanart
            fflog('brak danych do zalogowania do fanart')
            pass
        if r.status_code == 200:
            # fflog(f'\n{poster=} \n{poster2=} \n{fanart=} \n{banner=} \n{landscape=} \n{clearlogo=} \n{clearart=} \n{banner2=} \n{landscape2=}')
            pass
        # return poster, poster2, fanart, banner, landscape, clearlogo, clearart
        # return poster, poster2, fanart, banner, landscape, clearlogo, clearart, banner2
        return poster, poster2, fanart, banner, landscape, clearlogo, clearart, banner2, landscape2


    def tmdb_list_by_url(self, url):  # na razie na szybko przekopiowane z tvshow.py
        # fflog(f'{params=}', 1, 1)
        # fflog(f'{url=}', 1, 1)

        if "/4/" in url:  # v4 API
            fflog(f'wersja v4 API',1,1)
            headers = {
                "accept": "application/json",
                # "Authorization": f"Bearer {self.tm_bearer}"  # nie wiem, który powinien być
                "Authorization": f"Bearer {self.tmdb_access_token}"  # nie wiem, który powinien być
            }
            tmdb_results = requests.get(url, headers=headers)  # zapytanie do serwera
        else:
            url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
            url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)
            # fflog(f'{url=}', 1, 1)
            # control.log(f'{url=}', 1)
            tmdb_results = requests.get(url, timeout=30)

        if not tmdb_results:
            fflog(f'wystąpił jakiś problem  {tmdb_results=}  {url=}',1,1)
            pass

        tmdb_results = tmdb_results.json()  # format json, czyli słownik będzie w Pythonie
        # fflog(f'{tmdb_results=}',1,1)
        # fflog(f'tmdb_results={json.dumps(tmdb_results, indent=2)}',1,1)


        next_page = None

        page = tmdb_results.get("page", 0)
        total = tmdb_results.get("total_pages", 0)
        if page < total and "page=" in url:
            next_page = re.sub(r"page=\d+", f"page={page + 1}", url)
        else:
            next_page = ""
        # next_page = re.sub("(?<=api_key=)[^&]*", "", next_page)
        # next_page = re.sub("(?<=session_id=)[^&]*", "", next_page)
        # fflog(f'{next_page=}')
        # next = next_page


        if "results" in tmdb_results:
            items = tmdb_results["results"]
        elif "items" in tmdb_results:
            items = tmdb_results["items"]
        elif "parts" in tmdb_results:
            items = tmdb_results["parts"]
        elif "cast" in tmdb_results and (items := tmdb_results["cast"]):
            # items = tmdb_results["cast"]
            pass
        elif "crew" in tmdb_results and (items := tmdb_results["crew"]):
            # items = tmdb_results["crew"]
            pass
        else:
            fflog(f'[tmdb_list] błąd: brak poprawnych danych do stworzenia listy  |  {tmdb_results=}')
            items = []

        media_id_list = []  # pomocniczo
        fflog(f'{len(items)=}',1,1)
        for item in items:
            try:
                # fflog(f'item={json.dumps(item, indent=2)}')

                if 'media_type' in item and not item['media_type'] == 'tv':
                    #raise Exception()
                    continue

                tmdb = str(item.get('id'))

                if tmdb not in media_id_list:
                    if tmdb:
                        media_id_list.append(tmdb)
                else:
                    continue
                    
                if item.get("show_id"):
                    ep_id = tmdb
                    tmdb = str(item.get("show_id"))

                try:
                    title = item['name']
                except:
                    title = ''
                title = six.ensure_str(title)

                try:
                    originaltitle = item['original_name']
                except:
                    originaltitle = ''
                originaltitle = six.ensure_str(originaltitle)
                if not originaltitle:
                    originaltitle = title

                try:
                    premiered = item['first_air_date']
                except:
                    try:
                        premiered = item['air_date']
                    except:
                        premiered = ''
                if not premiered:
                    premiered = '0'

                try:
                    plot = item['overview']
                except:
                    plot = ''
                if not plot:
                    plot = ''

                try:
                    year = re.findall(r'(\d{4})', premiered)[0]
                except:
                    year = ''
                if not year:
                    year = '0'

                season = str(item.get("season_number") or "") or None
                episode = str(item.get("episode_number") or "") or None
                if episode:
                    tvshowtitle = item.get("tvshowtitle") or ""
                else:
                    continue
                    tvshowtitle = ""
                
                vote_average = item.get("vote_average") or 0
                vote_count = item.get("vote_count") or 0
                rating = item.get("rating") or 0
                duration = item.get("runtime") or 0
                thumb = item.get("still_path")  # choć dla odcinka to jest thumb
                thumb = self.tm_img_link % ("500", thumb)
                poster = '0'
                # poster = thumb if thumb else poster

                meta1 = {}
                if not tvshowtitle or not tvdb:
                    # log_utils.fflog('trzeba pobrać dane serialu')
                    # meta1 = self.get_meta_for_tvshow('', tmdb)
                    # fflog(f'meta1={json.dumps(meta1, indent=2)}',1,1)
                    if meta1:
                        tvshowtitle = meta1.get("originaltitle")
                        year = meta1.get("year")
                        localtvshowtitle = meta1.get("title")
                        originaltvshowtitle = meta1.get("originalname")
                        tvdb = meta1.get("tvdb")
                        mpaa = meta1.get("mpaa")
                        country = meta1.get("country")
                        original_language = meta1.get("original_language")
                        original_translation_lang = meta1.get("original_translation_lang")
                        #meta = ep_meta # ?
                        #meta1 = None  # nie, przydaje się później

                self.list.append({'title': title,
                                  'originaltitle': originaltitle,
                                  'premiered': premiered,
                                  'year': year,
                                  'imdb': '0',
                                  'tmdb': tmdb,
                                  'tvdb': '0',
                                  'plot': plot,
                                  'poster': poster,
                                  'next': next_page,
                                  "curr_page": page,  # number
                                  "total_pages": total,
                                  "season": season,
                                  "episode": episode,
                                  "vote_average": vote_average,
                                  "vote_count": vote_count,
                                  "rating": rating,
                                  "duration": duration,
                                  "thumb": thumb,
                                  "tvshowtitle": tvshowtitle,
                                })
            except Exception:
                fflog_exc(1)
                pass
        # fflog(f'self.list={json.dumps(self.list, indent=2)}',1,1)
        return self.list



    #def tmdb_list(self, tvshowtitle, year, imdb, tmdb, season, meta=None, localtvshowtitle="", originaltvshowtitle="", lite=False):
    def tmdb_list(self, tvshowtitle="", year="", imdb=None, tmdb=None, tvdb=None, season=None, meta=None, localtvshowtitle="", originaltvshowtitle="", lite=False, showunaired=None):
        fflog(f'{tvshowtitle=} {year=} {imdb=} {tmdb=} {tvdb=} {season=} {localtvshowtitle=} {lite=} {showunaired=} {meta=}', 0)
        # tvdb = None
        tmdb = None if tmdb == "" else tmdb
        showunaired = self.showunaired == "true" if showunaired is None else showunaired
        if (tmdb is None or tmdb == "0") and not imdb == "0" and imdb:
            try:
                url = self.tmdb_by_imdb % imdb
                result = self.session.get(url, timeout=16).json()
                # fflog(f'result={json.dumps(result, indent=2)}')
                tmdb_result = result["tv_results"][0]
                tmdb = tmdb_result["id"]
                if not tmdb:
                    tmdb = "0"
                else:
                    tmdb = str(tmdb)
                    fflog(f'{tmdb=} {tvshowtitle=}', 0)
            except Exception:
                fflog_exc(1)
                pass

        if tmdb is None and tvshowtitle:
            try:
                url = (self.search_link % (quote(tvshowtitle)) + "&first_air_date_year=" + year)
                result = self.session.get(url, timeout=16).json()
                # fflog(f'result={json.dumps(result, indent=2)}')
                results = result["results"]
                show = [r for r in results if cleantitle.get(r.get("name")) == cleantitle.get(tvshowtitle)][0]  # and re.findall('(\d{4})', r.get('first_air_date'))[0] == self.list[i]['year']][0]
                tmdb = show["id"]
                if not tmdb:
                    tmdb = "0"
                else:
                    tmdb = str(tmdb)
                    fflog(f'{tmdb=} {tvshowtitle=}', 0)
            except Exception:
                fflog_exc(1)
                tmdb = None
                fflog(f'{tmdb=}')
                pass

        try:
            if tmdb == "0" or tmdb is None or not tmdb:
                # fflog(f'{tmdb=}  {imdb=}',1,1)
                raise Exception( f'{tmdb=}  |  {imdb=}' )

            mpaa = ""
            country = ""
            original_language = ""
            original_translation_lang = ""

            meta1 = {}
            if not tvshowtitle or not tvdb:
                # log_utils.fflog('trzeba pobrać dane serialu',1,1)
                meta1 = self.get_meta_for_tvshow(imdb, tmdb)
                # fflog(f'meta1={json.dumps(meta1, indent=2)}',1,1)
                tvshowtitle = meta1.get("originaltitle")
                year = meta1.get("year")
                localtvshowtitle = meta1.get("title")
                originaltvshowtitle = meta1.get("originalname")
                tvdb = meta1.get("tvdb")
                mpaa = meta1.get("mpaa")
                country = meta1.get("country")
                original_language = meta1.get("original_language")
                original_translation_lang = meta1.get("original_translation_lang")
                #meta = ep_meta # ?
                #meta1 = None  # nie, przydaje się później

            if not tvdb:
                tvdb = "0"

            # fflog(f'{season=}')

            # można jeszcze dodać pobieranie z fanart_tv
            # poster1 = poster2 = fanart1 = fanart2 = banner1 = landscape1 = clearlogo1 = clearart1 = banner2 = landscape2 = keyart1 = "0"
            """
            if not tvdb == "0":
                if self.fanartTV_artwork == "true":
                    poster1, poster2, fanart1, banner1, landscape1, clearlogo1, clearart1, banner2, landscape2 = self.fanart_tv_art(tvdb)
                    # czy tu jest znany season ? czyli numer sezonu ?
                    if isinstance(poster2, dict):
                        poster2 = poster2.get(season)
                    if isinstance(banner2, dict):
                        banner2 = banner2.get(season)
                    if isinstance(landscape2, dict):
                        landscape2 = landscape2.get(season)
            """
            poster1 = poster2 = fanart1 = fanart2 = landscape1 = landscape2 = clearlogo1 = clearart1 = keyart1 = banner1 = banner2 = characterart1 = "0"
            country1 = original_language1 = original_translation_lang1 = "0"

            if meta1:
                poster = meta1.get("poster") or "0"
                poster2 = meta1.get("seasons_posters") or "0"
                fanart = meta1.get("fanart") or "0"
                fanart2 = meta1.get("seasons_fanarts") or "0"
                landscape = meta1.get("landscape") or "0"
                landscape2 = meta1.get("seasons_landscapes") or "0"
                clearlogo = meta1.get("clearlogo") or "0"
                clearart = meta1.get("clearart") or "0"
                keyart = meta1.get("keyart") or "0"
                banner = meta1.get("banner") or "0"
                banner2 = meta1.get("seasons_banners") or "0"
                characterart = meta1.get("characterart") or "0"
                country = meta1.get("country") or "0"
                original_language = meta1.get("original_language") or "0"
                original_translation_lang = meta1.get("original_translation_lang") or "0"

                if isinstance(poster2, dict):
                    poster2 = poster2.get(season)
                if isinstance(fanart2, dict):
                    fanart2 = fanart2.get(season)
                if isinstance(landscape2, dict):
                    landscape2 = landscape2.get(season)
                if isinstance(banner2, dict):
                    banner2 = banner2.get(season)

            seasons = self.tmdb_show_lite_link % tmdb
            # control.log(f"{seasons=}", 1)
            r = self.session.get(seasons, timeout=10)
            r.raise_for_status()
            r.encoding = "utf-8"
            result = r.json()  # if six.PY3 else utils.json_loads_as_str(r.text)
            # fflog(f'{result["number_of_seasons"]=}')
            #for season_tmp in range(1, result["number_of_seasons"] + 1, 1):
            for season_tmp in range(0, result["number_of_seasons"] + 1, 1):
                # fflog(f'{season=}')
                if season or season == 0:
                    season_tmp = season
                # fflog(f'{season_tmp=}')

                if self.specials == "false":
                    if season_tmp == 0 or season_tmp == '0':
                        # fflog(f'pomijam')
                        continue

                episodes_url = self.tmdb_season_link % (tmdb, season_tmp, self.lang)
                episodes_lite_url = self.tmdb_season_lite_link % (tmdb, season_tmp)
                if not lite:
                    url = episodes_url
                else:
                    url = episodes_lite_url

                # control.log('tmdb url: ' + repr(url), 1)
                r = self.session.get(url, timeout=10)
                if r.status_code == 404:
                    fflog(f'brak sesonu o numerze {season_tmp=}')
                    continue
                r.raise_for_status()
                r.encoding = "utf-8"
                result = r.json()  # if six.PY3 else utils.json_loads_as_str(r.text)

                episodes = result["episodes"]

                if self.specials == "false":
                    episodes = [e for e in episodes if not e["season_number"] == 0]

                if not episodes:
                    fflog(f'brak odcinków dla {tvshowtitle=} {year=} {season_tmp=}')
                    continue
                    # raise Exception()

                r_cast = result.get("aggregate_credits", {}).get("cast", [])

                poster_path = result.get("poster_path")
                if poster_path:
                    poster = self.tm_img_link % ("500", poster_path)
                else:
                    poster = "0"

                fanart = banner = clearlogo = clearart = landscape = duration = status = tvshow_poster = tvshow_banner = tvshow_landscape = keyart = tvshow_fanart = characterart = "0"
                country = original_language = original_translation_lang = "0"
                season_banner = season_landscape = season_poster = "0"  # (na razie) nieużywane

                clearlogo = meta1.get("clearlogo") or "0"

                if meta:
                    try:
                        _meta = json.loads(unquote_plus(meta))
                    except Exception:
                        fflog_exc(1)
                        _meta = None
                        pass
                elif meta1:
                    _meta = meta1
                else:
                    _meta = None
                if _meta:
                    try:
                        if "poster" in _meta.keys():
                            poster = _meta["poster"]

                        if "tvshow.poster" in _meta.keys():
                            tvshow_poster = _meta["tvshow.poster"]

                        if "season.poster" in _meta.keys():
                            # season_poster = _meta["season.poster"]
                            poster = _meta["season.poster"]

                        if "fanart" in _meta.keys():
                            fanart = _meta["fanart"]

                        if "clearlogo" in _meta.keys():
                            clearlogo = _meta["clearlogo"]

                        if "clearart" in _meta.keys():
                            clearart = _meta["clearart"]

                        if "keyart" in _meta.keys():
                            keyart = _meta["keyart"]  # or "0"  # jak nie chcemy, aby było None

                        if "characterart" in _meta.keys():
                            characterart = _meta["characterart"]

                        if "banner" in _meta.keys():
                            banner = _meta["banner"]

                        if "landscape" in _meta.keys():
                            landscape = _meta["landscape"]

                        if "duration" in _meta.keys():
                            duration = _meta["duration"]

                        if "status" in _meta.keys():
                            status = _meta["status"]

                        if "mpaa" in _meta.keys() and _meta["mpaa"]:
                            mpaa = _meta["mpaa"]

                        if "tvshow.banner" in _meta.keys():
                            tvshow_banner = _meta["tvshow.banner"]

                        if "tvshow.landscape" in _meta.keys():
                            tvshow_landscape = _meta["tvshow.landscape"]

                        if "tvshow.fanart" in _meta.keys():
                            tvshow_fanart = _meta["tvshow.fanart"]

                        if "season.banner" in _meta.keys():
                            # season_banner = _meta["season.banner"]
                            banner = _meta["season.banner"]

                        if "season.landscape" in _meta.keys():
                            # season_landscape = _meta["season.landscape"]
                            landscape = _meta["season.landscape"]

                        if "country" in _meta.keys():
                            country = _meta["country"]

                        if "original_language" in _meta.keys():
                            original_language = _meta["original_language"]

                        if "original_translation_lang" in _meta.keys():
                            original_translation_lang = _meta["original_translation_lang"]

                        if "localtvshowtitle" in _meta.keys() and not localtvshowtitle:
                            localtvshowtitle = _meta["localtvshowtitle"]

                        if "originaltvshowtitle" in _meta.keys() and not originaltvshowtitle:
                            originaltvshowtitle = _meta["originaltvshowtitle"]

                    except Exception:
                        # fflog_exc(1)
                        pass


                tvshow_poster = poster1 if poster1 and poster1 != "0" else tvshow_poster
                poster = poster2 if poster2 and poster2 != "0" else poster  # season.poster
                poster = poster1 if (not poster2 or poster2 == "0") and poster1 and poster1 != "0" else poster

                fanart = fanart1 if fanart1 and fanart1 != "0" else fanart

                clearart = clearart1 if clearart1 and clearart1 != "0" else clearart

                clearlogo = clearlogo1 if clearlogo1 and clearlogo1 != "0" else clearlogo
                
                keyart = keyart1 if keyart1 and keyart1 != "0" else keyart if keyart else "0"  # jak nie chcemy, aby było None

                characterart = characterart1 if characterart1 and characterart1 != "0" else characterart

                tvshow_banner = banner1 if banner1 and banner1 != "0" else tvshow_banner
                banner = banner2 if banner2 and banner2 != "0" else banner  # season.banner
                banner = banner1 if (not banner2 or banner2 == "0") and banner1 and banner1 != "0" else banner

                tvshow_landscape = landscape1 if landscape1 and landscape1 != "0" else tvshow_landscape
                landscape = landscape2 if landscape2 and landscape2 != "0" else landscape  # season.landscape
                landscape = landscape1 if (not landscape2 or landscape2 == "0") and landscape1 and landscape1 != "0" else landscape

                tvshow_fanart = fanart1 if fanart1 and fanart1 != "0" else tvshow_fanart
                fanart = fanart2 if fanart2 and fanart2 != "0" else fanart  # season.fanart
                fanart = fanart1 if (not fanart2 or fanart2 == "0") and fanart1 and fanart1 != "0" else fanart
                
                country = country1 if country1 and country1 != "0" else country
                original_language = original_language1 if original_language1 and original_language1 != "0" else original_language
                original_translation_lang = original_translation_lang1 if original_translation_lang1 and original_translation_lang1 != "0" else original_translation_lang

                fflog(f'{country=}',0,1)
                fflog(f'{original_language=}',0,1)
                fflog(f'{original_translation_lang=}',0,1)

                base_duration = duration
                result_en = {}
                # if country.lower() not in ["poland", "pl", "polska"]:  # a jak do polskiego filmu żaden Polak nie wprowadzi opisu, a zagraniczny user tak?
                for item in episodes:
                    episodeplot = item["overview"]
                    title = item.get("name") or ""
                    if not episodeplot or re.search(r'^[Oo]dcinek \d+$', title):
                        log_utils.fflog(f'potrzeba pobrania angielskich opisów dla odcinków', 0,1)
                        ##### En plot fetch - set up
                        episodes_url_en = self.tmdb_season_lite_link % (tmdb, season_tmp)
                        # control.log(f'{episodes_url_en=}', 1)
                        r_en = self.session.get(episodes_url_en, timeout=10)
                        r_en.raise_for_status()
                        r_en.encoding = "utf-8"
                        result_en = r_en.json()
                        ##########
                        break

                if original_translation_lang and original_translation_lang != "0" and original_translation_lang != "pl-PL":
                    for item in result_en.get("episodes", []):
                        episodeplot = item["overview"]
                        title = item.get("name") or ""
                        if not episodeplot or re.search(r'^[Ee]pisode \d+$', title):
                            log_utils.fflog(f'potrzeba pobrania originalnych opisów dla odcinków', 0,1)
                            ##### Original plot fetch - set up
                            episodes_url_en = self.tmdb_season_lite_link % (tmdb, season_tmp)
                            episodes_url_en = episodes_url_en.replace("&language=en", "&language=%s" % original_translation_lang)
                            # control.log(f'{episodes_url_en=}', 1)
                            r_en = self.session.get(episodes_url_en, timeout=10)
                            r_en.raise_for_status()
                            r_en.encoding = "utf-8"
                            result_en = r_en.json()
                            ##########
                            break

                count = 0
                # fflog(f'{len(episodes)=}',1,1)
                # fflog(f'episodes={json.dumps(episodes, indent=2)}',1,1)
                for item in episodes:
                    # fflog(f'{count=}')
                    try:
                        season_tmp = str(item["season_number"])
                        episode = str(item["episode_number"])

                        title = item.get("name")
                        # fflog(f'{title=}')
                        # if not title or 'dcinek ' in title:
                        if not title or result_en and re.search(r'^[Oo]dcinek \d+$', title):
                            try:
                                title = result_en["episodes"][count]["name"]
                            except Exception:
                                # fflog_exc(1)
                                pass
                        # fflog(f'{title=}')
                        if not title or result_en and re.search(r'^[Ee]pisode \d+$', title):
                            # title = "Episode %s" % episode
                            title = "Odcinek %s" % episode
                            if country.lower() not in ["poland", "pl", "polska"]:
                                title = f"({title})"
                                pass
                            # fflog(f'2 {title=}')

                        label = title

                        premiered = item.get("air_date")
                        if not premiered:
                            premiered = "0"

                        raw_duration = item.get("runtime", "0")
                        duration = self._normalize_episode_duration(raw_duration, base_duration)
                        if str(raw_duration) != duration:
                            fflog(f'[EPISODES DURATION] tmdb override S{season_tmp}E{episode}: {raw_duration} -> {duration} (base={base_duration})')

                        unaired = ""
                        # fflog(f'{premiered=} {title=}')
                        if not premiered or premiered == "0":
                            pass
                            # brak daty może oznaczać, że nie znana jest jeszcze premiera (ale i też, że nie została wprowadzona informacja o tym)
                            unaired = "true"
                            # if self.showunaired != "true" and not showunaired:
                            if not showunaired:
                                continue
                        elif int(re.sub("[^0-9]", "", str(premiered))) > int(re.sub("[^0-9]", "", str(self.today_date))):
                            unaired = "true"
                            # if self.showunaired != "true" and not showunaired:
                            if not showunaired:
                                continue
                                # raise Exception()

                        still_path = item.get("still_path")
                        if still_path:
                            thumb = self.tm_img_link % ("1280", still_path)
                        else:
                            thumb = "0"

                        mpaa1 = mpaa
                        try:
                            mpaa = str(item["mpaa"])
                        except:
                           # mpaa = ""
                            mpaa = mpaa1
                        if not mpaa:
                            mpaa = "0"
                            pass


                        try:
                            rating = str(item["vote_average"])
                        except:
                            rating = ""
                        if not rating:
                            rating = "0"

                        try:
                            votes = str(item["vote_count"])
                        except:
                            votes = ""
                        if not votes:
                            votes = "0"

                        try:
                            episodeplot = item["overview"]
                        except:
                            episodeplot = ""
                        if not episodeplot:
                            try:
                                episodeplot = result_en["episodes"][count]["overview"]
                            except:
                                pass
                            if not episodeplot:
                                episodeplot = "0"

                        count += 1

                        # if not self.lang == 'en' and episodeplot == '0':
                        # try:
                        # en_item = en_result.get('episodes', [])
                        # episodeplot = en_item['overview']
                        # episodeplot = six.ensure_str(episodeplot)
                        # except:
                        # episodeplot = ''
                        # if not episodeplot: episodeplot = '0'

                        try:
                            r_crew = item["crew"]
                            director = [d for d in r_crew if d["job"] == "Director"]
                            director = ", ".join([d["name"] for d in director])
                            writer = [w for w in r_crew if w["job"] == "Writer"]
                            writer = ", ".join([w["name"] for w in writer])
                        except:
                            director = writer = ""
                        if not director:
                            director = "0"
                        if not writer:
                            writer = "0"

                        castwiththumb = []
                        try:
                            for person in r_cast[:30]:
                                _icon = person["profile_path"]
                                icon = (self.tm_img_link % ("185", _icon) if _icon else "")
                                castwiththumb.append({
                                    "name": person["name"],
                                    "role": person["roles"][0]["character"],
                                    "thumbnail": icon,
                                    })
                        except:
                            pass
                        if not castwiththumb:
                            castwiththumb = "0"

                        self.list.append({"title": title, "label": label, "season": season_tmp, "episode": episode,
                            "tvshowtitle": tvshowtitle, "year": year, "premiered": premiered, "rating": rating, "mpaa": mpaa,
                            "votes": votes, "director": director, "writer": writer, "castwiththumb": castwiththumb,
                            "duration": duration, "status": status, "plot": episodeplot, "imdb": imdb, "tmdb": tmdb,
                            "tvdb": tvdb, "unaired": unaired, "thumb": thumb, "poster": poster, "fanart": fanart,
                            "banner": banner, "clearlogo": clearlogo, "clearart": clearart, "landscape": landscape,
                            "localtvshowtitle": localtvshowtitle, "originaltvshowtitle": originaltvshowtitle, "keyart": keyart,
                            "tvshow.poster": tvshow_poster, "tvshow.banner": tvshow_banner, "tvshow.landscape": tvshow_landscape,
                            # "season.poster": season_poster, "season.banner": season_banner, "season.landscape": season_landscape,
                            "characterart": characterart, "country": country, "original_language": original_language, "original_translation_lang": original_translation_lang,
                            })

                    except Exception:
                        log_utils.log("tmdb_list2 Exception", "indexer")
                        fflog_exc(1)
                        pass

                try:
                    if season or season == 0:
                        # fflog(f'wyskoczenie z pętli {season=} {season_tmp=}')  # musi wyskoczyć, gdy nie jest włączone spłaszczanie seriali
                        break
                except Exception as e:
                    fflog_exc(1)
                    pass

            # fflog(f'{self.list=}')
            # self.list = sorted(self.list, key=lambda k: k["premiered"], reverse=False)
            self.list = sorted(self.list, key=lambda k: (int(k["season"]), int(k["episode"])), reverse=False)

            try:
                # fflog(f'zapisywanie do cache')
                if season or season == 0:
                    cache.cache_insert("episodes" + f"_{tmdb or imdb}_s{season}", repr(self.list))
                else:
                    cache.cache_insert("episodes" + f"_{tmdb or imdb}", repr(self.list))
            except Exception:
                fflog_exc(1)
                pass

            return self.list

        except Exception as e:
            log_utils.log(f"tmdb_list1 Exception {e!r}", "indexer")
            fflog_exc(1)
            return self.list


    def get_meta_for_tvshow(self, imdb=None, tmdb=None):
        try:
            meta = cache.cache_get("superinfo" + f"_{tmdb or imdb}")  # sprawdzenie, czy nie ma już w cache
            if not meta:
                # log_utils.fflog('próba pobrania informacji o serialu przez super_info.py')
                # from resources.lib.indexers.super_info import SuperInfo
                media_list = [{'tmdb': tmdb, 'imdb': imdb}]
                # import requests
                # session = requests.Session()
                lang = control.apiLanguage()["tmdb"]
                super_info_obj = SuperInfo(media_list, self.session, lang, "tvshow")
                super_info_obj.get_info(0)

                meta = cache.cache_get("superinfo" + f"_{tmdb or imdb}")
            if meta:
                from ast import literal_eval
                meta = meta["value"]
                meta = literal_eval(meta)
            else:
                meta = {}
        except Exception:
            meta = {}
            fflog_exc(1)
        return meta


    def episodeDirectory(self, items, force_tvshow_title=False, cacheToDisc=False):
        # fflog(f'[episodeDirectory]')
        if items is None or len(items) == 0:
            fflog(f'{items=}')
            # sys.exit()
            return

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])
        currentPath = dict(parse_qsl(sys.argv[2][1:]))

        noPoster = _ff_no_poster_art()
        if control.setting("zastepcze_grafiki") == "true":
            addonPoster = noPoster or control.addonPoster()
            addonFanart = control.addonFanart()
            addonBanner = control.addonBanner()
        else:
            addonPoster = noPoster
            addonFanart = addonBanner = ""

        settingFanart = control.setting("fanart")

        traktCredentials = trakt.getTraktCredentialsInfo()

        try:
            isOld = False
            control.item().getArt("type")
        except:
            isOld = True

        # nie pamiętam co tu to multi oznacza (to chyba jak trakt podaje listę odcinków, to mogą one być od różnych seriali i dlatego nazwa multi)
        try:
            multi = [i["tvshowtitle"] for i in items]
        except:
            multi = []
        multi = force_tvshow_title or len(set(multi)) > 1

        try:
            sysaction = items[0]["action"]
        except:
            sysaction = ""

        isFolder = False if not sysaction == "episodes" else True
        disp_dir = False if control.setting("hosts.mode") != "1" else True
        isPlayable = "true" if "plugin" not in control.infoLabel("Container.PluginName") else "false"  # dziwny warunek - niżej go modyfikuje jeszcze
        yatse = control.setting("yatse") == "true"
        yatse = False if not disp_dir else yatse  # zastanowić się
        playbackMenu = (control.lang(32063) if control.setting("hosts.mode") == "2" else control.lang(32064))
        dont_use_setResolvedUrl = control.setting("player.dont_use_setResolvedUrl") == "true"
        indicators = playcount.getTVShowIndicators(refresh=True)
        traktIndicators  = trakt.getTraktIndicatorsInfo()
        watchedMenu =   (control.lang(32068) if traktIndicators == True else control.lang(32066))
        unwatchedMenu = (control.lang(32069) if traktIndicators == True else control.lang(32067))
        indicator_kodi = control.setting("indicator.kodi") == "true"
        queueMenu = control.lang(32065)
        traktManagerMenu = control.lang(32070)
        tvshowBrowserMenu = control.lang(32071)  # Przeglądaj sezony
        addToLibrary = control.lang(32551)
        generate_short_path = control.setting("generate_short_path") == "true"
        # add_rating_for_tmdb = control.setting("add_rating_for_tmdb.episodes") == "true" and control.setting("add_rating_for_tmdb") == "true"
        add_rating_for_tmdb = True
        kodiver = source_utils.get_kodi_version()
        meta = {}

        # Spis odcinków w sezonie.
        addSortMethod(syshandle, sortMethod=SORT_METHOD_UNSORTED, labelMask="%L")

        cm_enable_autoplay = control.setting("cm.enable.autoplay") == "true"
        cm_enable_similar_trakt = control.setting("cm.enable.similar_trakt") == "true"
        cm_enabl_similar_tmdb = control.setting("cm.enable.similar_tmdb") == "true"
        cm_enable_recommendations_tmdb = control.setting("cm.enable.recommendations_tmdb") == "true"
        cm_enable_removeFromBookmarks = control.setting("cm.enable.removeFromBookmarks") == "true"
        cm_enable_addToLibrary = control.setting("cm.enable.addToLibrary") == "true"
        cm_enable_addMultiToLibrary = control.setting("cm.enable.addMultiToLibrary") == "true"
        cm_enable_editForSearch = control.setting("cm.enable.editForSearch") == "true"
        cm_enable_queueMenu = control.setting("cm.enable.queueMenu") == "true"  # to chyba Kodi dodaje od wersji 21.2
        cm_enable_watchedUnwatched = control.setting("cm.enable.watchedUnwatched") == "true"

        downloads = (
            control.setting("downloads") == "true"
            and not (
                control.setting("movie.download.path") == ""
                or control.setting("tv.download.path") == ""
            )
        )
        downloadMenu = control.lang(32403)

        unpremiered_color = control.setting("unpremiered_color")
        if unpremiered_color == "inny":
            unpremiered_color = control.setting("unpremiered_custom_color")
        else:
            colors_map = {
                "szary": "gray",
                "czerwony": "red",
                "fioletowy": "magenta",
                "pomarańczowy": "orange",
                }
            unpremiered_color = colors_map[unpremiered_color]
        # fflog(f'{unpremiered_color=}')

        counter = 1
        # fflog(f'{len(items)=}')
        for i in items:
            try:
                #fflog(f'{i=}',1,1)
                # fflog(f'i={json.dumps(i, indent=2)}',1,1)

                if "label" not in i:
                    i["label"] = i["title"]
                if i["label"] == "0":
                    label = "%sx%02d  %s %s" % (i["season"], int(i["episode"]), "Episode", i["episode"],)
                else:
                    label = "%sx%02d  %s" % (i["season"], int(i["episode"]), i["label"],)
                syslabel = quote_plus(label)
                if multi:
                    label = "{} – {}".format(i.get("localtvshowtitle") or i["tvshowtitle"], label)

                imdb, tvdb, tmdb, year, season, episode = i["imdb"], i["tvdb"], i["tmdb"], i["year"], i["season"], i["episode"]

                systitle = quote_plus(i["title"])
                systvshowtitle = quote_plus(i["tvshowtitle"])
                syslocaltvshowtitle = quote_plus( i.get("localtvshowtitle") or "")
                syspremiered = quote_plus(i["premiered"])

                meta = {k: v for k, v in i.items() if not v == "0"}

                meta.update({"mediatype": "episode"})

                meta.update({"season": season})  # potrzebne dla sezonów o numerze 0
                meta.update({"episode": episode})  # potrzebne dla epizodów o numerze 0

                # meta.update({"trailer": "%s?action=trailer&name=%s" % (sysaddon, systvshowtitle)})
                # meta.update({"trailer": "%s?action=trailer&name=%s&url=%s" % (sysaddon, systvshowtitle, quote_plus(meta.get("trailer") or ""))})
                meta.update({"trailer": "%s?action=trailer&name=%s&url=%s" % (sysaddon, systvshowtitle + " " + syslabel, quote_plus(meta.get("trailer") or ""))})

                # fflog(f'{("duration" in i)=} {i.get("duration")=} {meta.get("duration")=} {i["label"]=}')
                if not "duration" in i:
                    # meta.update({"duration": "60"})
                    # meta.update({"duration": "1"})
                    pass
                elif i["duration"] == "0":
                    # meta.update({"duration": "60"})
                    # meta.update({"duration": "1"})
                    pass
                try:
                    if meta.get("duration") and meta.get("duration") != "0":
                        meta.update({"duration": str(int(meta["duration"]) * 60)})
                except:
                    pass
                # fflog(f'{("duration" in i)=} {i.get("duration")=} {meta.get("duration")=} {i["label"]=}')

                # try:
                #    meta.update({"genre": cleangenre.lang(meta["genre"], self.lang)})
                # except:
                #    pass

                try:
                    meta.update({"tvshowyear": i["year"]})
                    meta.update({"year": re.findall(r"(\d{4})", i["premiered"])[0]})
                except:
                    pass

                try:
                    meta.update({"title": i["label"]})
                except:
                    pass

                meta.update({"originalname": i.get("originaltvshowtitle", "")})

                meta.pop("next", None)

                sysmeta = quote_plus(json.dumps(meta))

                # url = "%s?action=play&title=%s&year=%s&imdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&t=%s" % (sysaddon, systitle, year, imdb, tvdb, season, episode, systvshowtitle, syspremiered, sysmeta, self.systime,)
                url = "%s?action=play&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s" % (sysaddon, systitle, year, imdb, tmdb, tvdb, season, episode, systvshowtitle, syspremiered, sysmeta)
                sysurl = quote_plus(url)  # potrzebne dla context menu
                fullpath = ""
                if generate_short_path and disp_dir:
                    fullpath = url
                    url = "{}?action=play&item={}".format(sysaddon, counter)
                    #sysurl = quote_plus(url)  # ale czy to potrzebne? bo może bardziej zaszkodzi

                # ta zmienna chyba nie jest wykorzystywana
                # path = "%s?action=play&title=%s&year=%s&imdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s" % (sysaddon, systitle, year, imdb, tvdb, season, episode, systvshowtitle, syspremiered,)

                if isFolder:
                    url = "%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s" % (sysaddon, systvshowtitle, year, imdb, tmdb, tvdb, season, episode)  # czy tu nie trzeba dać jeszcze meta ?
                    if generate_short_path:
                        fullpath = url
                        url = "{}?action=episodes&item={}".format(sysaddon, counter)

                if "?action=play&" in url:
                    # disp = False if control.setting("hosts.mode") == "0" else True
                    # disp = False if control.setting("hosts.mode") != "1" else True  # disp_dir
                    disp = disp_dir
                else:
                    disp = isFolder

                isPlayable = "true" if not disp else "false"
                isPlayable = "false" if dont_use_setResolvedUrl else isPlayable


                cm = []

                # autoodtwarzanie, albo zatrzymanie autoodtwarzania
                if cm_enable_autoplay:
                    if not isFolder:
                        #cm.append((playbackMenu, "RunPlugin(%s?action=alterSources&url=%s&meta=%s)" % (sysaddon, sysurl, sysmeta),))  # w url jest już meta, więc bez sensu
                        cm.append((playbackMenu, "RunPlugin(%s?action=alterSources&url=%s)" % (sysaddon, sysurl),))

                if cm_enable_editForSearch:
                    if not isFolder:
                        # if isPlayable == "true":
                        if not disp:
                            cm.append(("EDYTUJ dane do wyszukiwarki", "RunPlugin(%s?action=alterSources&url=%s)" % (sysaddon, sysurl + quote_plus("&customTitles=3")),))
                        else:
                            if not generate_short_path:
                                cm.append(("EDYTUJ dane do wyszukiwarki", "Container.Update(%s?action=alterSources&url=%s)" % (sysaddon, sysurl + quote_plus("&customTitles=3")),))
                            else:
                                cm.append(("EDYTUJ dane do wyszukiwarki", "Container.Update(%s)" % (url + "&customTitles=1"),))

                if cm_enable_queueMenu:
                    if not disp:
                        if kodiver.major < 21 or kodiver.major >= 21 and kodiver.minor < 2:
                            cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))

                # if multi:
                if True:  # bo to przydatne raczej zawsze
                    # Przeglądaj sezony
                    if not generate_short_path:
                        cm.append((tvshowBrowserMenu,
                                   #"Container.Update(%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s,return)" % (
                                   "Container.Update(%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s)" % (
                                    sysaddon, systvshowtitle, year, imdb, tmdb, tvdb),))
                    else:
                        cm.append((tvshowBrowserMenu, "Container.Update(%s?action=seasons)" % (sysaddon, ), ))

                if cm_enable_addToLibrary:
                    cm.append((addToLibrary,
                               "RunPlugin(%s?action=tvshowToLibrary&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&localtvshowtitle=%s)" % (
                               sysaddon, systvshowtitle, year, imdb, tmdb, syslocaltvshowtitle),))

                overlay = None
                if not isPlayable or traktIndicators or not indicator_kodi:
                    try:
                        overlay = int(playcount.getEpisodeOverlay(indicators, imdb, tmdb, season, episode))
                        # fflog(f'{overlay=}  {imdb=}  {title=}  {label=}  {season=}  {episode=}  {indicators=}')
                        if overlay == 7:
                            meta.update({"playcount": 1, "overlay": 7})  # to zmienia ptaszki
                            if not traktIndicators:
                                if cm_enable_watchedUnwatched:
                                    cm.append((unwatchedMenu, "RunPlugin(%s?action=episodePlaycount&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s&query=6)" % (sysaddon, imdb, tmdb, tvdb, season, episode),))
                        else:
                            meta.update({"playcount": 0, "overlay": 6})  # to zmienia ptaszki
                            if not traktIndicators:
                                if cm_enable_watchedUnwatched:
                                    cm.append((watchedMenu,   "RunPlugin(%s?action=episodePlaycount&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s&query=7)" % (sysaddon, imdb, tmdb, tvdb, season, episode),))
                    except Exception:
                        fflog_exc(1)
                        pass

                if traktCredentials:
                    overlay = "" if overlay is None else overlay
                    cm.append((traktManagerMenu, "RunPlugin(%s?action=traktManager&name=%s&imdb=%s&tmdb=%s&content=episode&season=%s&episode=%s&overlay=%s)" % (sysaddon, systvshowtitle, imdb, tmdb, season, episode, overlay),))

                # na ten moment raczej nie ma to sensu, bo w lastWatched pojawiają się seriale, a nie odcinki
                if cm_enable_removeFromBookmarks:
                    if currentPath.get("action") == "lastWatched":
                    # if True:  # zawsze (a może jakiś warunek sprawdzający, czy w ogóle jest potrzeba, tzn. czy jest w bazie bookmarks)
                        cm.append(("Usuń z lokalnej historii", "RunPlugin(%s?action=removeFromBookmarks&content=episode&imdb=%s&season=%s&episode=%s)" % (sysaddon, imdb, season, episode),))
                        pass

                if fullpath:
                    cm.append(("[I]przygotuj do ulubionych[/I]", "Container.Update(%s?action=prepareItemForAddToLibrary)" % (sysaddon),))

                if downloads and not isFolder and not disp:
                    cm.append((downloadMenu, "RunPlugin(%s)" % (url + "&download=1"),))

                if isOld:
                    cm.append((control.lang2(19033), "Action(Info)"))


                try:
                    if i["unaired"] == "true":
                        if self.showunaired != "true":
                            continue
                        label = f"[COLOR {unpremiered_color}][I]%s[/I][/COLOR]" % label
                except:
                    pass


                item = control.item(label=label, offscreen=True)  # create ListItem



                offset = 0
                runtime = 0
                offsetSource = None
                if overlay != 7:
                    # if True:
                    if not isPlayable or traktIndicators or not indicator_kodi:
                        percent = 0
                        # if trakt.getTraktIndicatorsInfo() and trakt.getTraktCredentialsInfo() == True:
                        if traktIndicators is True:
                            offsetSource = "trakt"
                            percent = bookmarks.get_scrobble("episode", imdb, season, episode)
                            # fflog(f'{percent=}  trakt  {imdb=}  {season=}  {episode=}  {label=}',1,1)
                            runtime = offset = 0  # bo nie ma takiej informacji z powyższej funkcji
                            if not percent:
                                offset, runtime, _localOffsetSource = bookmarks.get("episode", imdb, season, episode, local=True)
                                runtime = runtime or int(meta.get("_progress_runtime") or 0) or int(meta.get("duration") or 0)
                                if runtime and offset > 1:
                                    percent = int((offset / runtime) * 100)
                                    if percent and percent < 100:
                                        percent = max(1, min(percent, 99))
                                    elif percent >= 100:
                                        saved_runtime = bookmarks.get_saved_total_time("episode", imdb, season, episode)
                                        percent = 1 if not saved_runtime else 99
                                    offsetSource = _localOffsetSource or "local"
                                else:
                                    percent = None
                        else:
                            offset, runtime, offsetSource = bookmarks.get("episode", imdb, season, episode)
                            # fflog(f'{offset=}  {runtime=}  {offsetSource=}  {imdb=}  {season=}  {episode=}  {label=}',1,1)
                            runtime = runtime or int(meta.get("_progress_runtime") or 0) or int(meta.get("duration") or 0)
                            # fflog(f'{offset=}  {runtime=}  {offsetSource=}  {imdb=}  {season=}  {episode=}  {label=}',1,1)
                            if runtime and offset > 1:
                                percent = int((offset / runtime) * 100)
                                if percent >= 100 and str(meta.get("_progress_runtime") or "0") not in ("", "0"):
                                    try:
                                        runtime = int(meta.get("_progress_runtime") or 0)
                                        percent = int((offset / runtime) * 100) if runtime else percent
                                    except Exception:
                                        pass
                                if percent and percent < 100:
                                    percent = max(1, min(percent, 99))
                                elif percent >= 100:
                                    saved_runtime = bookmarks.get_saved_total_time("episode", imdb, season, episode)
                                    percent = 1 if not saved_runtime else 99
                                # fflog(f'{percent=}  {offsetSource}  {imdb=}  {season=}  {episode=}  {label=}',1,1)
                            else:
                                percent = None
                        # fflog(f'{percent=}  {offsetSource}  {imdb=}  {season=}  {episode=}  {label=}',1,1)
                        if percent and percent < 92 and not _ff_is_exynos():
                            item.setProperty("WatchedProgress", str(percent) )  # a może jest lepszy sposób?
                            pass

                            totalTime = runtime or float(meta.get("duration") or 0)
                            time = offset or float(percent / 100) * totalTime
                            if totalTime and totalTime > 10:
                                if not _ff_is_exynos():  # Exynos: resume dialog = crash, nie ustawiamy
                                    if kodiver.major < 20:
                                        try:
                                            item.setProperty("resumetime", str(time))
                                            item.setProperty("totaltime", str(totalTime))
                                            pass
                                        except Exception:
                                            # fflog_exc(1)
                                            pass
                                    else:
                                        try:
                                            # bo vtag i setResumePoint dopiero od Kodi v20
                                            # BUGFIX: nie używaj globalnego vtag (należy do poprzedniej iteracji pętli)
                                            # zamiast tego pobierz vtag bezpośrednio z aktualnego item
                                            item.getVideoInfoTag().setResumePoint(time, totalTime)
                                        except Exception:
                                            # fflog_exc(1)
                                            # fflog(f'{time=}, {totalTime=}',1,1)
                                            pass
                    else:
                        percent = None

                        try:
                            meta_duration_dbg = int(meta.get("duration") or 0)
                        except Exception:
                            meta_duration_dbg = 0
                        try:
                            progress_runtime_dbg = int(meta.get("_progress_runtime") or 0)
                        except Exception:
                            progress_runtime_dbg = 0
                        try:
                            saved_total_dbg = bookmarks.get_saved_total_time("episode", imdb, season, episode)
                        except Exception:
                            saved_total_dbg = 0
                        try:
                            label_dbg = control.tagdataClean(label)
                        except Exception:
                            label_dbg = label
                        fflog(
                            f"[episodes.py][progress_debug] imdb={imdb} season={season} episode={episode} label={label_dbg!r} overlay={overlay} offset={offset!r} runtime={runtime!r} meta_duration={meta_duration_dbg!r} meta_progress_runtime={progress_runtime_dbg!r} saved_total={saved_total_dbg!r} percent={percent!r} offsetSource={offsetSource!r} traktIndicators={traktIndicators!r} indicator_kodi={indicator_kodi!r} isPlayable={isPlayable!r}",
                            1,
                            1,
                        )


                # === PATCH: procent postępu w tytule odcinka (widoczny od razu na liście) ===
                if overlay != 7 and isinstance(percent, int) and percent > 0:
                    try:
                        item.setLabel(item.getLabel() + '  [COLOR FF00AAFF][B](%d%%)[/B][/COLOR]' % percent)
                    except Exception:
                        pass

                # === PROGRESS: kolorowy pasek postępu w opisie odcinka ===
                try:
                    progress_value = None
                    # overlay 7 = obejrzany w całości, inaczej bierzemy percent jeśli dostępny
                    if overlay == 7:
                        progress_value = 100
                    elif isinstance(percent, int):
                        progress_value = max(0, min(percent, 100))
                    if progress_value is not None and progress_value > 0:
                        total_seconds = 0.0
                        watched_seconds = 0.0
                        try:
                            total_seconds = float(runtime or meta.get("duration") or 0)
                        except Exception:
                            total_seconds = 0.0
                        if total_seconds and progress_value and progress_value <= 100:
                            watched_seconds = total_seconds * (float(progress_value) / 100.0)
                        else:
                            watched_seconds = 0.0
                        remaining_minutes = None
                        if total_seconds:
                            try:
                                remaining_minutes = int(round(max(total_seconds - watched_seconds, 0) / 60.0))
                            except Exception:
                                remaining_minutes = None
                        # dobierz kolor wg progresu
                        if progress_value <= 10:
                            color = "red"
                        elif progress_value <= 25:
                            color = "yellow"
                        elif progress_value <= 50:
                            color = "orange"
                        elif progress_value <= 70:
                            color = "gold"
                        elif progress_value <= 90:
                            color = "lightgreen"
                        else:
                            color = "darkgreen"
                        # zbuduj pasek z kwadratów
                        bar_len = 20
                        try:
                            filled = int(round(bar_len * min(progress_value, 100) / 100.0))
                        except Exception:
                            filled = 0
                        filled = max(0, min(bar_len, filled))
                        empty = bar_len - filled
                        bar = "■" * filled + "□" * empty
                        # status tekstowy dla odcinka
                        if progress_value < 15:
                            status = "Nowy odcinek – dopiero zaczynasz"
                        elif progress_value < 35:
                            status = "Odcinek rozpoczęty – w trakcie"
                        elif progress_value < 65:
                            status = "Jesteś za połową odcinka"
                        elif progress_value < 90:
                            status = "Prawie koniec odcinka – do dokończenia"
                        elif progress_value < 100:
                            status = "Końcówka odcinka – możesz domknąć"
                        else:
                            status = "Odcinek obejrzany w całości"
                        header_lines = []
                        header_lines.append("[COLOR {0}]{1} {2}%[/COLOR]".format(color, bar, progress_value))
                        header_lines.append("[COLOR grey]{0}[/COLOR]".format(status))
                        if remaining_minutes is not None:
                            header_lines.append("Pozostało około {0} min odcinka".format(remaining_minutes))
                        plot = meta.get("plot") or ""
                        meta["plot"] = "[CR]".join(header_lines) + ("[CR][CR]" + plot if plot else "")
                except Exception:
                    pass


                # fflog(f'{overlay=}  {percent=}',1,1)
                if add_rating_for_tmdb:
                    if overlay == 7 or percent and int(percent) > 40:
                    # if True:
                        cm.append(("Oceń odcinek", "RunPlugin(%s?action=add_rating&content=episode&tmdb=%s&season=%s&episode=%s)" % (sysaddon, tmdb, season, episode),))


                art = {}
                # na liście odcinków skórki szukają w kolejności: postera sezonu, a potem postera serialu. Na końcu (jak nie znajdą poprzednich), to wyświetlają poster przypisany do zmiennej poster
                if "poster" in i and not i["poster"] == "0" or "tvshow.poster" in i or "season.poster" in i:
                    art.update({
                        "season.poster": _ff_fast_poster_art(i.get("season.poster") or i.get("poster") or ""),  # ustawiamy poster sezonu (u mnie zmienna poster2)
                        "tvshow.poster": _ff_fast_poster_art(i.get("tvshow.poster") or i.get("poster") or ""),  # ustawiamy poster serialu (u mnie zmienna poster1)
                        "poster": _ff_fast_poster_art(i.get("poster") or ""),  # taki fallback, bo nie ma posteru odcinka raczej (u mnie zmienna poster)
                        })
                else:
                    # art.update({"poster": addonPoster})  # plakatu chyba nie
                    # art.update({"poster": ""})
                    # art.pop("poster", None)
                    if addonPoster:
                        art.update({
                            "season.poster": addonPoster,
                            "tvshow.poster": addonPoster,
                            "poster": addonPoster,
                        })
                    pass
                # takie porządki
                if art.get("poster") == "0":
                    art.pop("poster", None)
                if art.get("tvshow.poster") == "0":
                    art.pop("tvshow.poster", None)
                if art.get("season.poster") == "0":
                    art.pop("season.poster", None)

                if "thumb" in i and not i["thumb"] == "0":
                    art.update({
                        "icon": i["thumb"],
                        "thumb": i["thumb"]
                        })
                # elif "fanart" in i and not i["fanart"] == "0":
                    # art.update({
                        # "icon": i["fanart"],
                        # "thumb": i["fanart"]
                        # })
                # elif "poster" in i and not i["poster"] == "0":
                    # art.update({
                        # "icon": i["poster"],
                        # "thumb": i["poster"]
                        # })
                else:
                    art.update({"icon": addonFanart, "thumb": addonFanart})
                    # art.update({"icon": "", "thumb": ""})
                    # art.pop("icon", None)
                    # art.pop("thumb", None)
                    pass
                art["icon"] = re.sub(r'(/t/p/w)\d{3,4}/', r'\g<1>200/', art.get("icon") or "")
                art["thumb"] = re.sub(r'(/t/p/w)\d{3,4}/', r'\g<1>200/', art.get("thumb") or "")
                if not art["thumb"]:
                    art.pop("thumb", None)
                    pass
                if not art["icon"]:
                    art.pop("icon", None)
                    pass

                if "fanart" in i and not i["fanart"] == "0":
                    art.update({"fanart": i["fanart"]})

                if "banner" in i and not i["banner"] == "0":
                    art.update({"banner": i["banner"]})
                elif "fanart" in i and not i["fanart"] == "0":
                    # art.update({"banner": i["fanart"]})
                    pass
                else:
                    art.update({"banner": addonBanner})
                    # art.update({"banner": ""})
                    # art.pop("banner", None)
                    pass

                if "tvshow.banner" in i and not i["tvshow.banner"] == "0":
                    art.update({"tvshow.banner": i["tvshow.banner"]})

                if "season.banner" in i and not i["season.banner"] == "0":
                    art.update({"season.banner": i["season.banner"]})

                if "landscape" in i and not i["landscape"] == "0":
                    art.update({"landscape": i["landscape"]})

                if "tvshow.landscape" in i and not i["tvshow.landscape"] == "0":
                    art.update({"tvshow.landscape": i["tvshow.landscape"]})

                if "season.landscape" in i and not i["season.landscape"] == "0":
                    art.update({"season.landscape": i["season.landscape"]})

                if "clearlogo" in i and not i["clearlogo"] == "0":
                    art.update({"clearlogo": i["clearlogo"]})
                    art.update({"tvshow.clearlogo": i["clearlogo"]})  # to jest ważniejsze dla skórki (tak są napisane warunki sprawdzające)

                if "clearart" in i and not i["clearart"] == "0":
                    art.update({"clearart": i["clearart"]})

                if "keyart" in i and not i["keyart"] == "0":
                    art.update({"keyart": i["keyart"]})

                """
                if "characterart" in i and not i["characterart"] == "0":
                    art.update({"characterart": i["characterart"]})
                """
                if "characterart" in i and not i["characterart"] == "0":
                    characterart = i["characterart"]
                    if isinstance(characterart, list):
                        for an in range(0, len(characterart)):
                            # art[f"characterart{an+1}"] = characterart[an]
                            art.update({f"characterart{an+1}": characterart[an]})
                            # art.update({f"tvshow.characterart{an+1}": characterart[an]})
                    else:
                        # art["characterart"] = characterart
                        art.update({"characterart": characterart})
                        # art.update({"tvshow.characterart": characterart})


                # fflog(f'{art=}',1,1)
                item.setArt(art)

                if settingFanart == "true" and "fanart" in i and not i["fanart"] == "0":
                    item.setProperty("Fanart_Image", i["fanart"])  # czy to nie dla jakiejś starszej wersji Kodi ?
                elif not addonFanart is None:
                    # item.setProperty("Fanart_Image", addonFanart)  # j.w.
                    pass

                item.setProperty("IsPlayable", isPlayable)

                # Android mobile SAFE MODE: nie ustawiamy ResumeTime/TotalTime
                # ani WatchedProgress na liście odcinków.

                # fflog(f'{addonFanart=}')
                # fflog(f'{addonPoster=}')

                # obsada — tylko na nie-Exynos (bezpieczne ograniczenie)
                if not _ff_is_exynos():
                    castwiththumb = i.get("castwiththumb")
                    if castwiththumb and not castwiththumb == "0":
                        try:
                            item.setCast(castwiththumb)
                        except Exception:
                            pass


                    # meta.pop("imdb", None)
                    # meta.pop("tmdb_id", None)
                    # meta.pop("imdb_id", None)
                    # meta.pop("poster", None)
                    # meta.pop("clearlogo", None)
                    # meta.pop("clearart", None)
                    # meta.pop("fanart", None)
                    # meta.pop("fanart2", None)
                    # meta.pop("imdb", None)
                    # meta.pop("tmdb", None)
                    # meta.pop("metacache", None)
                    # meta.pop("poster2", None)
                    # meta.pop("poster3", None)
                    # meta.pop("banner", None)
                    # meta.pop("next", None)
                    # meta.pop("tvdb", None)
                    # meta.pop("tvdb_id", None)
                    # meta.pop("banner2", None)
                    # meta.pop("label", None)
                    # meta.pop("thumb", None)


                if not _ff_is_exynos():
                    try:
                        vtag = item.getVideoInfoTag()
                    except Exception:
                        vtag = None
                else:
                    vtag = None

                if _ff_is_exynos():
                    _ff_apply_safe_video_metadata(item, meta, label, 'episode')
                else:
                    try:
                        item.setInfo(type="Video", infoLabels=control.metadataClean(meta))
                    except Exception:
                        pass
                # fflog(f'metadataClean={json.dumps(control.metadataClean(meta), indent=2)}',1,1)

                    # vtag.setTitle( meta.get("title") )
                    # if meta.get("year"):  vtag.setYear( int( meta.get("year") ) )
                    # vtag.setPlot( meta.get("plot") or "" )
                    # if meta.get("season"): vtag.setSeason( int(meta.get("season")) )
                    # if meta.get("episode"): vtag.setEpisode( int(meta.get("episode")) )
                    # vtag.setPremiered(  )
                    # vtag.setDuration(  )
                    # pewnie trzeba jeszcze więcej dorobić

                # korekta pod standard ListItem (bo super_info.py inaczej generuje)
                if not _ff_is_exynos():
                    try:
                        item.setInfo(type="Video", infoLabels={'TvShowTitle': meta.get("localtvshowtitle") or meta.get("tvshowtitle", "")})
                    except Exception:
                        pass
                    # vtag.setTvShowTitle( meta.get("localtvshowtitle") or meta.get("tvshowtitle", "") )  # nie wiem, czy to dopiero nie od Kodi 20
                item.setProperty("englishTvShowTitle", meta.get("englishtvshowtitle") or meta.get("tvshowtitle", ""))
                    #item.setProperty("OriginalTvShowTitle", meta.get("originaltvshowtitle") or meta.get("tvshowtitle", ""))
                item.setProperty("OriginalTvShowTitle", meta.get("originaltvshowtitle") or "")
                item.setProperty("TvShowYear", meta.get("tvshowyear") or meta.get("year", ""))

                if generate_short_path:
                    # fflog(f'{imdb=} {tmdb=} {tvdb=} {i["label"]=}')
                    try:
                        if vtag is not None:
                            vtag.setUniqueIDs({
                                'imdb' : imdb, 
                                'tmdb' : tmdb, 
                                'tvdb' : tvdb,
                            })
                        else:
                            raise Exception("vtag is None")
                    except Exception:
                        item.setProperty("imdb_id", imdb)
                        item.setProperty("tmdb_id", tmdb)
                        item.setProperty("tvdb_id", tvdb)

                    item.setProperty("meta", json.dumps(meta))
                    item.setProperty("fullpath", fullpath)

                    # video_streaminfo = {"codec": "h264"};
                    # item.addStreamInfo("video", video_streaminfo)  # czy to w czymś pomaga?

                    if yatse and vtag is not None:
                        vtag.setMediaType('video')  # yatse źle interpretuje element, gdy jest podany jako typ Movie, tzn. nie chce wyświetlać źródeł, jeśli mają być wyświetlone w katalogu (na fonie)


                if not _ff_is_exynos():
                    item.addContextMenuItems(cm)  # dodanie menu kontekstowego


                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=disp)  # dodanie całej pozycji do listy katalogu Kodi

                counter += 1
            except Exception:
                fflog_exc(1)
                pass

        params = dict(parse_qsl(sys.argv[2][1:]))
        updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie
        try:
            # cat_label = items[0]["tvshowtitle"]
            # fflog(f'{items[0]=}',1,1)
            # fflog(f'{meta=}',1,1)
            cat_label = meta.get("localtvshowtitle") or meta.get("tvshowtitle")
            if meta.get("tvshowyear") and cat_label:
                cat_label += f' ({meta.get("tvshowyear")})'
                pass
            # if sa_sezony:  # nie wiem, skąd wziąść informacje o ilości wszystkich sezonów
            cat_label += f' / Sezon {items[0]["season"]}'
            if cat_label:
                control.pluginCategory(syshandle, cat_label)
                pass
        except Exception:
            fflog_exc(1)
            pass
        control.content(syshandle, "episodes")
        control.directory(syshandle, cacheToDisc=cacheToDisc, updateListing=updateListing)
        views.setView("episodes")



    def addDirectory(self, items, queue=False, add_refresh=False, category=""):
        fflog(f'[addDirectory]')

        if items is None or len(items) == 0:
            return  #  ; sys.exit()

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])

        addonFanart, addonThumb, artPath = (control.addonFanart(), control.addonThumb(), control.artPath(),)
        queueMenu = control.lang(32065)
        generate_short_path = control.setting("generate_short_path") == "true"

        # Spis... czego właściwie? do kalendarza ?
        # addSortMethod(syshandle, sortMethod=SORT_METHOD_UNSORTED)
        for i in items:
            try:
                name = i["name"]

                if i["image"].startswith("http"):
                    thumb = i["image"]
                elif not artPath is None:
                    thumb = os.path.join(artPath, i["image"])
                else:
                    thumb = addonThumb

                # create ListItem
                try:
                    item = control.item(label=name, offscreen=True)
                except:
                    item = control.item(label=name)

                item.setArt({"icon": thumb, "thumb": thumb, "fanart": addonFanart})

                i["url"] = re.sub("(?<=api_key=)[^&]*", "", i["url"])

                log_utils.fflog(f'{i["action"]=}', 0)  # nie wiem jakie mogą być
                url = "{}?action={}".format(sysaddon, i["action"])
                try:
                    if not generate_short_path or i["action"] not in ["calendar"]:
                        url += "&url=%s" % quote_plus(i["url"])
                    else:
                        item.setProperty("url", i["url"])
                        item.setProperty("urlD", i["url"])
                except Exception:
                    pass

                cm = []
                if queue:
                    cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))
                if add_refresh:
                    cm.append(("Odśwież teraz", "Container.Update(%s&refresh=1)" % url))
                item.addContextMenuItems(cm)

                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
            except Exception:
                fflog_exc(1)
                pass

        # czy potrzebna także następna strona ?

        params = dict(parse_qsl(sys.argv[2][1:]))
        updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie
        if category:
            control.pluginCategory(syshandle, category)
        # control.content(syshandle, "addons")
        control.directory(syshandle, cacheToDisc=True, updateListing=updateListing)
        views.setView("addons")  # dodatkowa funkcja FanVodPL
