# -*- coding: utf-8 -*-
import time, threading
import xbmc, xbmcgui
import xbmcaddon, urllib.parse
# === FF dyn plugin root ===
ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
PLUGIN_ROOT = f"plugin://{ADDON_ID}/"
# === /FF dyn plugin root ===

from ptw.libraries import control
try:
    control.run_android_mobile_bookmarks_migration_once()
except Exception:
    pass

try:
    from ptw.libraries import trace_log as _tlog
    _tlog.section('service.py start')
except Exception:
    _tlog = None

def _tr(*a, **kw):
    try:
        if _tlog: _tlog.trace(*a, **kw)
    except Exception:
        pass

LOG = xbmc.LOGINFO

def log(msg):
    try:
        xbmc.log(f"[FFRF] {msg}", LOG)
    except Exception:
        pass

MON = xbmc.Monitor()
PLAYER = xbmc.Player()
WIN = xbmcgui.Window(10000)

PROP_LAST_PATH = "ffrf.last_ff_path"
PROP_LAST_TS   = "ffrf.last_ff_path_ts"
PROP_LAST_END  = "ffrf.last_playback_end_ts"


PLUGIN_ROOT = "plugin://plugin.video.fanvodpl/"  # awaryjny powrót

def _now():
    try:
        return int(time.time())
    except Exception:
        return 0

def _setp(k, v):
    try:
        WIN.setProperty(k, str(v))
    except Exception:
        pass

def _getp(k, default=""):
    try:
        v = WIN.getProperty(k)
        return v if v not in (None, "") else default
    except Exception:
        return default

def _is_ff(path: str) -> bool:
    return isinstance(path, str) and path.lower().startswith("plugin://") and "fanvodpl" in path.lower()

def _remember_folder():
    """Zapamiętaj ostatni katalog FanVodPL — tylko gdy nic nie jest odtwarzane."""
    try:
        if PLAYER.isPlaying():
            return  # nie nadpisuj ścieżki podczas odtwarzania
        cur = xbmc.getInfoLabel("Container.FolderPath")
        if _is_ff(cur):
            _setp(PROP_LAST_PATH, cur)
            _setp(PROP_LAST_TS, _now())
            _tr('service.py', 'remember_folder', folder=cur)
    except Exception:
        pass

def _best_target(max_age=1800) -> str:
    """Zwraca ścieżkę do powrotu (zapamiętaną) lub root pluginu jako fallback."""
    path = _getp(PROP_LAST_PATH, "")
    try:
        ts = int(_getp(PROP_LAST_TS, "0"))
    except Exception:
        ts = 0
    if path and _is_ff(path) and (_now() - ts) <= max_age:
        return path
    return PLUGIN_ROOT

def _activate_to(path: str):
    """Wejście do okna Wideo (10025) z podaną ścieżką pluginu oraz dopięcie focusu na liście (id=50)."""
    try:
        xbmc.executebuiltin("Dialog.Close(all,true)")  # pozamykaj zbędne okna po playerze
        xbmc.executebuiltin(f"ActivateWindow(10025,{path},return)")
        # Focus na główny kontener (większość skinów: 50)
        xbmc.executebuiltin("Control.SetFocus(50,0,true)")
        log(f"ActivateWindow -> {path}")
        _tr('service.py', 'ActivateWindow', target=path)
    except Exception as e:
        log(f"ActivateWindow error: {e}")
        _tr('service.py', 'ActivateWindow ERROR', error=str(e))

def _is_fanfilm(path: str) -> bool:
    """Sprawdza czy ścieżka należy do FanFilm (nie FanVodPL)."""
    return isinstance(path, str) and 'fanfilm' in path.lower() and 'fanvodpl' not in path.lower()

def _guard_return(duration=7.0, interval=0.25, delay=0.7):
    if delay>0:
        time.sleep(delay)
    """
    Pętla anty-bounce:
    - zamyka dialogi, wymusza powrót do listy FanVodPL (również gdy free -> handle=-1),
    - pilnuje focusu przez kilka sekund (część skinów gubi fokus po odtwarzaniu).
    """
    t_end = time.time() + duration
    target = _best_target()
    fired_once = False
    _last_activate = 0.0  # cooldown: nie odpala _activate_to częściej niż raz na 2.5s

    while time.time() < t_end and not MON.abortRequested():
        cur_folder = xbmc.getInfoLabel("Container.FolderPath")
        cur_win = xbmcgui.getCurrentWindowId()

        if _is_ff(cur_folder):
            if fired_once:
                log("Powrót potwierdzony, koniec strażnika")
            break

        # Cooldown 2.5s: ActivateWindow wyzwala załadowanie pluginu — bez cooldown 28 wywołań w 7s = crash na wolnych telefonach.
        now = time.time()
        # Sprawdź czy FanFilm nie wygrał wyścigu i nie wylądowaliśmy w starym pluginie
        if _is_fanfilm(cur_folder):
            log(f"FanFilm guard wygrał wyścig — wymuszam powrót do FanVodPL")
            _tr('service.py', 'GUARD fanfilm_override', cur_folder=cur_folder, target=target)
            _activate_to(target)
            _last_activate = now
            fired_once = True
        elif (cur_win in (10000, 10025) or not _is_ff(cur_folder)) and (now - _last_activate >= 2.5):
            _activate_to(target)
            _last_activate = now
            fired_once = True

        time.sleep(interval)

class FFGuardPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._started = False
        self._handled = False
        self._file = ''
        self._title = ''
        self._thumb = ''
        self._from_ff = False
        self._pos_cached = 0.0    # cache pozycji – bezpieczne dla Exynos
        self._total_cached = 0.0  # cache długości – bezpieczne dla Exynos
        self._poll_stop = threading.Event()

    def onPlayBackStarted(self):
        try:
            self._started = True
            self._handled = False
            self._pos_cached = 0.0
            self._total_cached = 0.0
            self._poll_stop.clear()
            self._file  = self.getPlayingFile() or ''
            self._title = xbmc.getInfoLabel('VideoPlayer.Title') or xbmc.getInfoLabel('Player.Title') or self._file
            self._thumb = xbmc.getInfoLabel('VideoPlayer.Cover') or xbmc.getInfoLabel('VideoPlayer.Art(thumb)') or ''
            cur = xbmc.getInfoLabel('Container.FolderPath')
            self._from_ff = _is_ff(cur)
            log(f"onPlayBackStarted from_ff={self._from_ff}, folder={cur}")
            log(f"Started: {self._title}")
            _tr('service.py', 'onPlayBackStarted', from_ff=self._from_ff, title=self._title, folder=cur)
            threading.Thread(target=self._poll_position, daemon=True).start()
        except Exception:
            pass

    def _poll_position(self):
        """Cachuje pos/total co 5s podczas odtwarzania. Bezpieczne dla Exynos – nie wywołuje getTime() w callbackach stop/end."""
        while not self._poll_stop.is_set() and not MON.abortRequested():
            try:
                if self.isPlaying():
                    t = self.getTotalTime()
                    p = self.getTime()
                    if t and t > 0:
                        self._total_cached = float(t)
                    if p and p >= 0:
                        self._pos_cached = float(p)
            except Exception:
                pass
            self._poll_stop.wait(5.0)

    def _send_mark_watched(self, ended: bool):
        try:
            # Używamy wartości z cache (zebranych podczas odtwarzania) – NIE wywołujemy
            # getTime()/getTotalTime() tu, bo na Exynos (Samsung) powoduje crash OS.
            total = self._total_cached
            pos   = self._pos_cached
            pct   = (pos/total*100.0) if total>0 else 0.0
            long_enough = (pct>=65.0) or (pos>=420.0 and total>=900.0)
            params = {
                'action':'ff_mark_watched',
                'file':  self._file or '',
                'title': self._title or '',
                'thumb': self._thumb or '',
                'pos':   str(int(pos)),
                'total': str(int(total)),
                'ended': '1' if ended else '0',
                'watched':'1' if long_enough else '0'
            }
            url = f"plugin://{ADDON_ID}/?{urllib.parse.urlencode(params)}"
            xbmc.executebuiltin(f"RunPlugin({url})")
            log(f"Mark-watched sent (ended={ended}, pct={pct:.1f}%, w={long_enough})")
        except Exception as e:
            log(f"Mark-watched error: {e}")

    def _finalize(self, ended: bool):
        if self._handled:
            return
        self._handled = True
        self._poll_stop.set()  # zatrzymaj polling pozycji
        if self._started and self._file:
            self._send_mark_watched(ended=ended)
        if self._from_ff:
            try:
                WIN.setProperty(PROP_LAST_END, str(int(time.time())))
            except Exception:
                pass
            # ZMIANA (2026-04) [PATCH]: sprawdzenie flagi FanVodPL.res_check_stop — NO-OP po revercie
            # POWOD: Flaga byla czescia proby stop-before-dialog w player.py (RES_CHECK). Ta proba
            #   zostala ZREVERROWANA 2026-04-19 (log 13:45 pokazal ze powodowala auto-zatrzymywanie
            #   filmu: DialogConfirm.xml nie ladowal sie, yesno() zwracal False jako default bez
            #   kliknięcia usera). Flaga nie jest juz ustawiana w player.py — sprawdzenie zostaje
            #   jako no-op zeby nie psuc service.py.
            # NIE ZMIENIAC: nie usuwac sprawdzenia. Gdyby w przyszlosci zaszla potrzeba ponownego
            #   wprowadzenia stop-before-dialog (z lepsza implementacja), ta flaga jest gotowym
            #   mechanizmem komunikacji z _finalize().
            if WIN.getProperty('FanVodPL.res_check_stop') == '1':
                log("Skip guard_return — RES_CHECK stop w toku")
                WIN.clearProperty('FanVodPL.res_check_stop')
            else:
                threading.Thread(target=_guard_return, kwargs={'delay':0.35}, daemon=True).start()
        else:
            log("Skip guard_return (playback not from FanVodPL)")
        self._started = False
        self._file = self._title = self._thumb = ''
        self._from_ff = False

    def onPlayBackEnded(self):
        log("onPlayBackEnded")
        _tr('service.py', 'onPlayBackEnded', title=self._title, pos=self._pos_cached, total=self._total_cached)
        self._finalize(ended=True)

    def onPlayBackStopped(self):
        log("onPlayBackStopped")
        _tr('service.py', 'onPlayBackStopped', title=self._title, pos=self._pos_cached, total=self._total_cached)
        self._finalize(ended=False)

if __name__ == "__main__":
    player = FFGuardPlayer()
    while not MON.abortRequested():
        try:
            _remember_folder()
        except Exception:
            pass
        try:
            ts = int(WIN.getProperty(PROP_LAST_END) or "0")
        except Exception:
            ts = 0
        if ts and (time.time() - ts) <= 12.0:
            try:
                if xbmc.getCondVisibility('Window.IsActive(yesnodialog)') or xbmc.getCondVisibility('Window.IsActive(dialogconfirm)') or xbmc.getCondVisibility('Window.IsActive(okdialog)'):
                    xbmc.executebuiltin('Dialog.Close(yesnodialog)')
                    xbmc.executebuiltin('Dialog.Close(dialogconfirm)')
                    xbmc.executebuiltin('Dialog.Close(okdialog)')
                    xbmc.executebuiltin('Dialog.Close(all,true)')
                    try:
                        WIN.setProperty(PROP_LAST_END, "0")
                    except Exception:
                        pass
            except Exception:
                pass
        MON.waitForAbort(0.5)