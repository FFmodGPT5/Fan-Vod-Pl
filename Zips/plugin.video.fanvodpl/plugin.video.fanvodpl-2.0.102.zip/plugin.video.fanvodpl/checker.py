"""
    FanVodPL Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import os
import re
import shutil
import zipfile

import requests

import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


def _safe_remove_tree(path):
    if path and os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=True)


def _safe_remove_file(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except Exception as e:
        xbmc.log(f"[checker] Can't remove file {path}: {e}", xbmc.LOGERROR)


def _extract_addon_to_stage(path_to_zip_file, addons_root, addon_name):
    stage_root = os.path.join(addons_root, f".ff_stage_{addon_name}")
    _safe_remove_tree(stage_root)
    try:
        os.makedirs(stage_root, exist_ok=True)
        with zipfile.ZipFile(path_to_zip_file, "r") as zip_ref:
            zip_ref.extractall(stage_root)
        staged_addon_path = os.path.join(stage_root, addon_name)
        addon_xml_path = os.path.join(staged_addon_path, "addon.xml")
        if not os.path.isdir(staged_addon_path) or not os.path.isfile(addon_xml_path):
            xbmc.log(f"[checker] Invalid addon package for {addon_name}", xbmc.LOGERROR)
            _safe_remove_tree(stage_root)
            return False
        return staged_addon_path
    except Exception as e:
        xbmc.log(f"[checker] {e}", xbmc.LOGERROR)
        xbmc.log("[checker] Unpacking addon fails", 1)
        _safe_remove_tree(stage_root)
        return False


def _install_staged_addon(addon_name, addons_root, staged_addon_path, set_enabled_callback):
    addon_path = os.path.join(addons_root, addon_name)
    backup_path = os.path.join(addons_root, f".ff_backup_{addon_name}")
    stage_root = os.path.dirname(staged_addon_path)
    try:
        _safe_remove_tree(backup_path)
        set_enabled_callback(enabled=False)
        if os.path.isdir(addon_path):
            shutil.move(addon_path, backup_path)
        shutil.move(staged_addon_path, addon_path)
        _safe_remove_tree(backup_path)
        return True
    except Exception as e:
        xbmc.log(f"[checker] Safe install failed for {addon_name}: {e}", xbmc.LOGERROR)
        try:
            _safe_remove_tree(addon_path)
            if os.path.isdir(backup_path):
                shutil.move(backup_path, addon_path)
        except Exception as restore_error:
            xbmc.log(f"[checker] Restore failed for {addon_name}: {restore_error}", xbmc.LOGERROR)
        try:
            set_enabled_callback(enabled=True)
        except Exception:
            pass
        return False
    finally:
        _safe_remove_tree(stage_root)


class PtwModuleChecker:
    def __init__(self):
        self.addonName = "script.module.ptwfanvod"
        self.LocalVersion = self.getInstalledPtwModuleVersion()
        self.ptwModuleLink = "https://ffmodgpt5.github.io/Fan-Vod-Pl/FanVodRepo/addons.xml"
        self.OfficialVersion = self.getOfficialPtwModuleVersion()
        self.ptwModuleLinkZip = (
            f"https://ffmodgpt5.github.io/Fan-Vod-Pl/FanVodRepo/zips/{self.addonName}/"
            f"{self.addonName}-{self.OfficialVersion}.zip"
        )

    def getOfficialPtwModuleVersion(self):
        try:
            content = requests.get(self.ptwModuleLink, verify=False, timeout=10).text
            ptwModuleUrlVersion = re.findall(r'PTW Module" version="(.*?)"', content)[0]
            xbmc.log(f"[checker]   {ptwModuleUrlVersion=}")
            return ptwModuleUrlVersion
        except Exception as e:
            xbmc.log(f"[checker] {e}", 0)
            xbmc.log("[checker] Can't get PTW version from official repo", xbmc.LOGERROR)
            return

    def getInstalledPtwModuleVersion(self):
        try:
            self.setPtwModule(enabled=True)
            ptwModuleAddon = xbmcaddon.Addon(self.addonName)
            ptwModuleAddonVersion = ptwModuleAddon.getAddonInfo("version")
            xbmc.log(f"[checker] {ptwModuleAddonVersion=}")
            return ptwModuleAddonVersion
        except Exception as e:
            xbmc.log(f"[checker] {e}", 0)
            xbmc.log("[checker] Can't get PTW version from kodi installation", xbmc.LOGERROR)
            return "0.0.0"

    def checkVersion(self):
        if self.OfficialVersion and tuple(self.LocalVersion.split(".")) < tuple(self.OfficialVersion.split(".")):
            dialog = xbmcgui.Dialog()
            ret = dialog.yesno(
                "Niekompatybilna wersja zaleznosci",
                (
                    "Czy chcesz zaktualizowac zaleznosc PTW Module do najnowszej wersji? "
                    "Aktualna wersja jest niezbedna do prawidlowego dzialania FanVodPL. "
                    "Bedzie to wymagac ponownego uruchomienia Kodi"
                ),
            )
            if ret:
                self.installPtwModule()

    def removePtwModule(self):
        addonPath = xbmcvfs.translatePath("special://home/addons/script.module.ptwfanvod")
        if os.path.isdir(addonPath):
            self.setPtwModule(enabled=False)
            xbmc.log("[checker] Usuniecie obecnego dodatku script.module.ptwfanvod z dysku")
            shutil.rmtree(addonPath, ignore_errors=True)

    def installPtwModule(self):
        xbmc.log("[checker] Przygotowanie do instalacji nowego dodatku script.module.ptwfanvod")
        addonsRoot = xbmcvfs.translatePath("special://home/addons/")
        zipPath = self.download_file(self.ptwModuleLinkZip)
        if zipPath:
            stagedAddonPath = self.unzip_addon(zipPath, addonsRoot)
            installed = False
            if stagedAddonPath:
                installed = self.install_staged_addon(stagedAddonPath, addonsRoot)
            self.removeZipFile(zipPath)
            if installed:
                self.closeKodi()
            else:
                self.showInstallFailure()

    def download_file(self, url):
        xbmc.log("[checker] Pobieranie pliku instalacyjnego dodatku script.module.ptwfanvod")
        try:
            localFileName = url.split("/")[-1]
            addonsDirectory = xbmcvfs.translatePath("special://home/addons/")
            with requests.get(url, stream=True) as r:
                r.raise_for_status()
                with open(os.path.join(addonsDirectory, localFileName), "wb") as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
            return os.path.join(addonsDirectory, localFileName)
        except Exception as e:
            xbmc.log(f"[checker] {e}", xbmc.LOGERROR)
            xbmc.log("[checker] Downloading addon fails", 1)
            return False

    def unzip_addon(self, path_to_zip_file, directory_to_extract_to):
        xbmc.log("[checker] Rozpakowanie pobranego pliku zip dodatku script.module.ptwfanvod")
        return _extract_addon_to_stage(path_to_zip_file, directory_to_extract_to, self.addonName)

    def install_staged_addon(self, staged_addon_path, addons_root):
        return _install_staged_addon(self.addonName, addons_root, staged_addon_path, self.setPtwModule)

    def removeZipFile(self, zipFilePath=None):
        xbmc.log("[checker] Usuniecie pobranego pliku instalacyjnego dodatku script.module.ptwfanvod", 1)
        if zipFilePath is None:
            zipFilePath = xbmcvfs.translatePath(
                f"special://home/addons/script.module.ptwfanvod-{self.OfficialVersion}.zip"
            )
        _safe_remove_file(zipFilePath)

    def showInstallFailure(self):
        xbmc.log("[checker] Preserved current PTW Module version after failed update", xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().ok(
                "Aktualizacja nieudana",
                "Nie udalo sie bezpiecznie zainstalowac PTW Module. Zachowano obecna wersje dodatku.",
            )
        except Exception:
            pass

    def closeKodi(self):
        xbmc.sleep(200)
        try:
            self.setPtwModule(enabled=True)
        except Exception:
            pass
        choice = xbmcgui.Dialog().ok("Zamkniecie", "Teraz Kodi zostanie zamkniete, aby zatwierdzic zmiany")
        if choice == 1:
            xbmc.log("[checker] Kodi zostanie zamkniete (PtwModuleChecker)")
            os._exit(1)
        else:
            xbmc.executebuiltin("Action(Close)")

    def setPtwModule(self, enabled=True):
        if enabled:
            xbmc.log("[checker] Wlaczenie (jesli nie wlaczony) dodatku script.module.ptwfanvod")
            xbmc.executeJSONRPC(
                f'{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{{"addonid": "{self.addonName}","enabled":true}}}}'
            )
        else:
            xbmc.log("[checker] Wylaczenie dodatku script.module.ptwfanvod")
            xbmc.executeJSONRPC(
                f'{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{{"addonid": "{self.addonName}","enabled":false}}}}'
            )


class ResolveUrlChecker:
    def __init__(self):
        self.addonName = "script.module.resolveurl"
        self.LocalVersion = self.getInstalledResolveUrlVersion()
        self.resolveUrlLink = "https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml"
        self.OfficialVersion = self.getOfficialResolveUrlVersion()
        self.resolveUrlLinkZip = (
            f"https://raw.githubusercontent.com/Gujal00/smrzips/master/zips/{self.addonName}/"
            f"{self.addonName}-{self.OfficialVersion}.zip"
        )

    def getOfficialResolveUrlVersion(self):
        try:
            content = requests.get(self.resolveUrlLink, verify=False, timeout=10).text
            resolveUrlVersion = re.findall(r'ResolveURL" version="(.*?)"', content)[0]
            xbmc.log(f"[checker]      {resolveUrlVersion=}")
            return resolveUrlVersion
        except Exception as e:
            xbmc.log(f"[checker] {e}", 0)
            xbmc.log("[checker] Can't get resolveUrl version from official repo", xbmc.LOGERROR)
            return

    def getInstalledResolveUrlVersion(self):
        try:
            self.setResolveUrl(enabled=True)
            resolveUrlAddon = xbmcaddon.Addon(self.addonName)
            resolveUrlAddonVersion = resolveUrlAddon.getAddonInfo("version")
            xbmc.log(f"[checker] {resolveUrlAddonVersion=}")
            return resolveUrlAddonVersion
        except Exception as e:
            xbmc.log(f"[checker] {e}", 0)
            xbmc.log("[checker] Can't get resolveUrl version from kodi installation", xbmc.LOGERROR)
            return "0.0.0"

    def checkVersion(self):
        if self.OfficialVersion and self.LocalVersion != self.OfficialVersion:
            dialog = xbmcgui.Dialog()
            ret = dialog.yesno(
                "Niekompatybilna wersja zaleznosci",
                "Chcesz zaktulizowac zaleznosc ResolveURL do najnowszej wersji? Bedzie to wymagac ponownego uruchomienia Kodi",
            )
            if ret:
                self.installResolveUrl()

    def removeResolveUrl(self):
        addonPath = xbmcvfs.translatePath("special://home/addons/script.module.resolveurl")
        if os.path.isdir(addonPath):
            self.setResolveUrl(enabled=False)
            xbmc.log("[checker] Usuniecie obecnego dodatku script.module.resolveurl z dysku")
            shutil.rmtree(addonPath, ignore_errors=True)

    def installResolveUrl(self):
        xbmc.log("[checker] Przygotowanie do instalacji nowego dodatku script.module.resolveurl")
        addonsRoot = xbmcvfs.translatePath("special://home/addons/")
        zipPath = self.download_file(self.resolveUrlLinkZip)
        if zipPath:
            stagedAddonPath = self.unzip_addon(zipPath, addonsRoot)
            installed = False
            if stagedAddonPath:
                installed = self.install_staged_addon(stagedAddonPath, addonsRoot)
            self.removeZipFile(zipPath)
            if installed:
                self.closeKodi()
            else:
                self.showInstallFailure()

    def download_file(self, url):
        xbmc.log("[checker] Pobieranie pliku instalacyjnego dodatku script.module.resolveurl")
        try:
            localFileName = url.split("/")[-1]
            addonsDirectory = xbmcvfs.translatePath("special://home/addons/")
            with requests.get(url, stream=True) as r:
                r.raise_for_status()
                with open(os.path.join(addonsDirectory, localFileName), "wb") as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
            return os.path.join(addonsDirectory, localFileName)
        except Exception as e:
            xbmc.log(f"[checker] {e}", xbmc.LOGERROR)
            xbmc.log("[checker] Downloading addon fails", 1)
            return False

    def unzip_addon(self, path_to_zip_file, directory_to_extract_to):
        xbmc.log("[checker] Rozpakowanie pobranego pliku zip dodatku script.module.resolveurl")
        return _extract_addon_to_stage(path_to_zip_file, directory_to_extract_to, self.addonName)

    def install_staged_addon(self, staged_addon_path, addons_root):
        return _install_staged_addon(self.addonName, addons_root, staged_addon_path, self.setResolveUrl)

    def removeZipFile(self, zipFilePath=None):
        xbmc.log("[checker] Usuniecie pobranego pliku instalacyjnego dodatku script.module.resolveurl", 1)
        if zipFilePath is None:
            zipFilePath = xbmcvfs.translatePath(
                f"special://home/addons/script.module.resolveurl-{self.OfficialVersion}.zip"
            )
        _safe_remove_file(zipFilePath)

    def showInstallFailure(self):
        xbmc.log("[checker] Preserved current ResolveURL version after failed update", xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().ok(
                "Aktualizacja nieudana",
                "Nie udalo sie bezpiecznie zainstalowac ResolveURL. Zachowano obecna wersje dodatku.",
            )
        except Exception:
            pass

    def closeKodi(self):
        xbmc.sleep(200)
        try:
            self.setResolveUrl(enabled=True)
        except Exception:
            pass
        choice = xbmcgui.Dialog().ok("Zamkniecie", "Teraz Kodi zostanie zamkniete, aby zatwierdzic zmiany")
        if choice == 1:
            xbmc.log("[checker] Kodi zostanie zamkniete (ResolveUrlChecker)")
            os._exit(1)
        else:
            xbmc.executebuiltin("Action(Close)")

    def setResolveUrl(self, enabled=True):
        if enabled:
            xbmc.log("[checker] Wlaczenie (jesli nie wlaczony) dodatku script.module.resolveurl")
            xbmc.executeJSONRPC(
                f'{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{{"addonid": "{self.addonName}","enabled":true}}}}'
            )
        else:
            xbmc.log("[checker] Wylaczenie dodatku script.module.resolveurl")
            xbmc.executeJSONRPC(
                f'{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{{"addonid": "{self.addonName}","enabled":false}}}}'
            )
