"""
DownloadConfirmDialog – duże okno potwierdzenia pobrania z serwisu premium.

Wyświetla statyczne (bez przewijania) informacje o pliku:
  - Nazwa pliku
  - Rozdzielczość
  - Ścieżka dźwiękowa
  - Format
  - Wielkość

Zwraca True (Pobierz) lub False (Anuluj / zamknięcie).
"""
from __future__ import annotations

import os
import re

import xbmcgui

# ── IDs kontrolek XML ────────────────────────────────────────────────────────
_ID_FILENAME   = 101
_ID_RESOLUTION = 102
_ID_AUDIO      = 103
_ID_FORMAT     = 104
_ID_SIZE       = 105
_ID_REMAINING  = 106

_BTN_DOWNLOAD  = 200
_BTN_CANCEL    = 201

_ACTION_BACK   = 92
_ACTION_PREV   = 10   # PreviousMenu


# ── Parser metadanych z nazwy pliku ─────────────────────────────────────────
def parse_media_info(filename: str) -> dict[str, str]:
    """
    Wyciąga z nazwy pliku (torrent-like) następujące pola:
      resolution, audio, video_codec, container

    Przykład:
      A.Knight.of.the.Seven.Kingdoms.S01E02.MULTi.720p.AMZN.WEB-DL.DDP5.1.Atmos.H.264-KPFR.mp4
      → {'resolution': '720p', 'audio': 'DDP5.1 Atmos', 'video_codec': 'H.264', 'container': 'mp4'}
    """
    name = filename.upper()

    # Rozdzielczość
    res_match = re.search(
        r'\b(4K|2160P|1080P|1080I|720P|576P|480P|360P|SD|HD|FHD|UHD)\b', name
    )
    resolution = res_match.group(1).lower().replace('p', 'p').replace('i', 'i') if res_match else "—"
    # ładniejszy zapis
    resolution = {'4k': '4K / 2160p', '2160p': '4K / 2160p', '1080p': '1080p (Full HD)',
                  '1080i': '1080i', '720p': '720p (HD)', '576p': '576p', '480p': '480p (SD)',
                  '360p': '360p', 'fhd': '1080p (Full HD)', 'uhd': '4K / 2160p'}.get(resolution, resolution)

    # Ścieżka dźwiękowa – kolejność: bardziej szczegółowe wzorce najpierw
    audio_patterns = [
        (r'DOLBY\s*VISION', 'Dolby Vision'),
        (r'ATMOS', 'Atmos'),
        (r'DDP\s*5[\.\s]1', 'DDP 5.1'),
        (r'DDP\s*7[\.\s]1', 'DDP 7.1'),
        (r'DDP\s*2[\.\s]0', 'DDP 2.0'),
        (r'\bDDP\b', 'Dolby Digital Plus'),
        (r'DD\s*5[\.\s]1', 'DD 5.1'),
        (r'DD\s*7[\.\s]1', 'DD 7.1'),
        (r'\bDTS[-\s]?HD', 'DTS-HD'),
        (r'\bDTS[-\s]?MA', 'DTS-MA'),
        (r'\bDTS[-\s]?X\b', 'DTS:X'),
        (r'\bDTS\b', 'DTS'),
        (r'\bTRUEHD\b', 'Dolby TrueHD'),
        (r'\bAAC', 'AAC'),
        (r'\bAC3\b', 'Dolby Digital'),
        (r'\bFLAC\b', 'FLAC'),
        (r'\bMP3\b', 'MP3'),
        (r'\bOPUS\b', 'Opus'),
        (r'\bVORBIS\b', 'Vorbis'),
        (r'5[\.\s]1', '5.1'),
        (r'7[\.\s]1', '7.1'),
        (r'2[\.\s]0', '2.0'),
    ]
    # Zbieramy wszystkie trafienia (unikamy duplikatów i subsetów)
    audio_found: list[str] = []
    for pattern, label in audio_patterns:
        if re.search(pattern, name):
            # Pomijamy 'DTS' jeśli już mamy 'DTS-HD', 'DTS-MA' lub 'DTS:X'
            if label == 'DTS' and any(x in audio_found for x in ('DTS-HD', 'DTS-MA', 'DTS:X')):
                continue
            # Pomijamy '5.1'/'7.1' jeśli już mamy 'DDP 5.1', 'DD 5.1', itp. z tym kanałem
            if label in ('5.1', '7.1', '2.0'):
                channels = label.replace('.', r'[\.\s]')
                if any(re.search(channels, a) for a in audio_found):
                    continue
            if label not in audio_found:
                audio_found.append(label)
            if len(audio_found) >= 3:
                break
    # Scalamy w czytelny ciąg (np. "DDP 5.1 + Atmos")
    if audio_found:
        # Atmos łączymy z poprzednim kodekiem
        if 'Atmos' in audio_found and len(audio_found) > 1:
            idx = audio_found.index('Atmos')
            audio_found[idx - 1] = audio_found[idx - 1] + ' + Atmos'
            audio_found.remove('Atmos')
        audio = ' / '.join(audio_found)
    else:
        audio = '—'

    # Jezyk audio (MULTi, POL, ENG…)
    lang_match = re.search(r'\b(MULTI|PL|POL|ENG|DUAL|ORG|LEKTOR|NAPISY)\b', name)
    if lang_match:
        lang_map = {'PL': 'PL', 'POL': 'PL', 'ENG': 'EN', 'MULTI': 'Multi',
                    'DUAL': 'Dual', 'ORG': 'ORG', 'LEKTOR': 'PL (Lektor)',
                    'NAPISY': 'Napisy PL'}
        lang_label = lang_map.get(lang_match.group(1), lang_match.group(1))
        audio = f'{audio}  [{lang_label}]'

    # Kodek wideo
    codec_match = re.search(
        r'\b(H[\.\s]?265|HEVC|X265|H[\.\s]?264|AVC|X264|XVID|DIVX|VP9|AV1|MPEG2)\b', name
    )
    if codec_match:
        codec_raw = codec_match.group(1).replace(' ', '.')
        codec_map = {
            'H.265': 'H.265 (HEVC)', 'HEVC': 'H.265 (HEVC)', 'X265': 'H.265 (x265)',
            'H.264': 'H.264 (AVC)',  'AVC':  'H.264 (AVC)',   'X264': 'H.264 (x264)',
            'XVID': 'XviD', 'DIVX': 'DivX', 'VP9': 'VP9', 'AV1': 'AV1', 'MPEG2': 'MPEG-2',
        }
        video_codec = codec_map.get(codec_raw, codec_raw)
    else:
        video_codec = '—'

    # Kontener (rozszerzenie)
    ext_match = re.search(r'\.(MKV|MP4|AVI|TS|M2TS|VOB|WMV|MOV|FLV|WEBM)$', name)
    container = ext_match.group(1).lower() if ext_match else '—'

    return {
        'resolution':  resolution,
        'audio':       audio,
        'video_codec': video_codec,
        'container':   container,
    }


# ── Klasa dialogu ─────────────────────────────────────────────────────────────
class DownloadConfirmDialog(xbmcgui.WindowXMLDialog):
    """
    Duże okno potwierdzenia pobierania z danymi statystycznymi pliku.

    WIRE: wywoływane przez show_download_confirm() → twojlimit.py / nopremium.py / rapideo.py
    """

    def __init__(
        self,
        xml_filename: str,
        script_path: str,
        filename_full: str = '',
        charge: str = '',
        remaining: str = '',
        default_skin: str = 'Default',
        default_res: str = '720p',
    ) -> None:
        super().__init__(xml_filename, script_path, default_skin, default_res)
        self._filename_full = filename_full
        self._charge        = charge
        self._remaining     = remaining
        self.confirmed      = False

    def onInit(self) -> None:  # noqa: N802
        info = parse_media_info(self._filename_full)

        # Ustalenie nazwy pliku do wyświetlenia (bez ścieżki)
        display_name = os.path.basename(self._filename_full)

        # Format = kodek + kontener
        fmt_parts = []
        if info['video_codec'] != '—':
            fmt_parts.append(info['video_codec'])
        if info['container'] != '—':
            fmt_parts.append(f'.{info["container"].lower()}')
        fmt_label = '  •  '.join(fmt_parts) if fmt_parts else '—'

        self.getControl(_ID_FILENAME).setLabel(display_name)
        self.getControl(_ID_RESOLUTION).setLabel(info['resolution'])
        self.getControl(_ID_AUDIO).setLabel(info['audio'])
        self.getControl(_ID_FORMAT).setLabel(fmt_label)
        self.getControl(_ID_SIZE).setLabel(f'[B]{self._charge}[/B]')
        self.getControl(_ID_REMAINING).setLabel(self._remaining)

        try:
            self.setFocus(self.getControl(_BTN_DOWNLOAD))
        except Exception:
            pass

    def onAction(self, action: xbmcgui.Action) -> None:  # noqa: N802
        action_id = action.getId()
        if action_id in (_ACTION_BACK, _ACTION_PREV):
            self.confirmed = False
            self.close()

    def onClick(self, control_id: int) -> None:  # noqa: N802
        if control_id == _BTN_DOWNLOAD:
            self.confirmed = True
            self.close()
        elif control_id == _BTN_CANCEL:
            self.confirmed = False
            self.close()

    def onFocus(self, control_id: int) -> None:  # noqa: N802
        pass


# ── Funkcja pomocnicza (call site) ───────────────────────────────────────────
def show_download_confirm(
    addon_path: str,
    filename_full: str,
    charge: str,
    remaining: str,
) -> bool:
    """
    Wyświetla duże okno potwierdzenia pobierania.

    Args:
        addon_path:    ścieżka do katalogu wtyczki (control.addonPath)
        filename_full: pełna nazwa pliku z API
        charge:        koszt transferu (np. "1.04 GB")
        remaining:     pozostały transfer (np. "15.2 GB")

    Returns:
        True  → użytkownik kliknął "Pobierz"
        False → użytkownik kliknął "Anuluj" lub zamknął okno
    """
    dialog = DownloadConfirmDialog(
        xml_filename='DownloadConfirmDialog.xml',
        script_path=addon_path,
        filename_full=filename_full,
        charge=charge,
        remaining=remaining,
    )
    dialog.doModal()
    result = dialog.confirmed
    del dialog
    return result
