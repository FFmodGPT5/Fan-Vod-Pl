# -*- coding: utf-8 -*-
import os
import re
from urllib.parse import urlparse

import xbmcgui


class ConfirmDownloadMetaDialog(xbmcgui.WindowXMLDialog):
    """
    Duże okno potwierdzenia pobrania/wypożyczenia z metadanymi pliku.

    Cel: użytkownik widzi parametry (wideo/audio/język/rozmiar/hosting) ZANIM
    nastąpi jakakolwiek akcja, która nalicza transfer.
    """
    def __init__(self, *args, **kwargs):
        self.heading = kwargs.pop("heading", "Wymagane potwierdzenie")
        self.file_label = kwargs.pop("file_label", "")
        self.size_line = kwargs.pop("size_line", "")
        self.meta_text = kwargs.pop("meta_text", "")
        self.result = False
        super().__init__(*args)

    def onInit(self):
        self._set_label(110, self.heading)
        self._set_label(120, self.file_label)
        self._set_label(130, self.size_line)
        self._set_text(140, self.meta_text)
        self.setFocusId(201)

    def _set_label(self, cid, txt):
        try:
            self.getControl(cid).setLabel(txt or "")
        except Exception:
            pass

    def _set_text(self, cid, txt):
        try:
            self.getControl(cid).setText(txt or "")
        except Exception:
            pass

    def onClick(self, controlId):
        if controlId == 201:  # Pobierz
            self.result = True
            self.close()
        elif controlId == 202:  # Anuluj
            self.result = False
            self.close()

    def onAction(self, action):
        if action in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self.result = False
            self.close()
        else:
            super().onAction(action)


def _safe_ptn_parse(name: str) -> dict:
    try:
        from ptw.libraries import PTN
        return PTN.parse(name) or {}
    except Exception:
        return {}


def _detect_resolution(name: str, ptn: dict) -> str:
    res = (ptn.get("resolution") or "").lower()
    up = name.upper()
    if res:
        if "2160" in res or "4k" in res:
            return "UHD (2160p)"
        if "1080" in res:
            return "FULLHD (1080p)"
        if "720" in res:
            return "HD (720p)"
        if "576" in res:
            return "SD (576p)"
        if "480" in res:
            return "SD (480p)"
    if "2160" in up or "UHD" in up or "4K" in up:
        return "UHD (2160p)"
    if "1080" in up:
        return "FULLHD (1080p)"
    if "720" in up:
        return "HD (720p)"
    if "576" in up:
        return "SD (576p)"
    if "480" in up:
        return "SD (480p)"
    return "-"


def _detect_audio(name: str, ptn: dict) -> str:
    up = name.upper()
    atmos = "ATMOS" in up
    codec = None

    if "DDP" in up or "DD+" in up or "EAC3" in up:
        codec = "DDP"
    elif "AC3" in up:
        codec = "DD"
    elif "DTS" in up:
        codec = "DTS"
    elif "AAC" in up:
        codec = "AAC"

    # channels like 5.1 / 7.1
    m = re.search(r"(?<!\d)(\d\.\d)(?!\d)", up)
    ch = m.group(1) if m else None

    parts = []
    if atmos:
        parts.append("ATMOS")
    if codec:
        parts.append(codec)
    if ch:
        parts.append(ch)

    # fallback from PTN audio field if nothing detected
    if not parts:
        a = (ptn.get("audio") or "").strip()
        if a:
            return a
    return " ".join(parts) if parts else "-"


def _detect_lang(name: str) -> str:
    up = name.upper()
    if "MULTI" in up:
        return "MULTI"
    # wykrycie PL jako tokenu (unika AMZN/WEB itp.)
    if re.search(r"(?<![A-Z])PL(?![A-Z])", up) or "POLISH" in up or ".POL." in up:
        return "PL"
    return "-"


def _detect_host(url: str) -> str:
    if not url:
        return "-"
    try:
        host = urlparse(url).netloc or ""
        host = host.replace("www.", "")
        if host:
            # najczęściej wystarczy domena główna
            parts = host.split(".")
            if len(parts) >= 2:
                return ".".join(parts[-2:])
            return host
    except Exception:
        pass
    return "-"


def meta_from_filename(filename_full: str, url: str = "") -> dict:
    """
    Buduje metadane pliku na podstawie nazwy pliku + opcjonalnie hosta z URL.
    Nie wykonuje żadnych requestów sieciowych.
    """
    ptn = _safe_ptn_parse(filename_full)
    title = (ptn.get("title") or "").strip() or "-"
    return {
        "title": title,
        "video": _detect_resolution(filename_full, ptn),
        "audio": _detect_audio(filename_full, ptn),
        "lang": _detect_lang(filename_full),
        "size": "-",
        "host": _detect_host(url),
    }


def build_meta_text(meta: dict) -> str:
    def g(k, default="-"):
        v = meta.get(k)
        return v if v not in (None, "", "N/A") else default

    return "\n".join([
        f"TYTUŁ: {g('title')}",
        "",
        "=== WIDEO ===",
        f"Rozdzielczość: {g('video')}",
        "",
        "=== AUDIO ===",
        f"Ścieżka: {g('audio')}",
        f"Język: {g('lang')}",
        "",
        "=== PLIK ===",
        f"Rozmiar: {g('size')}",
        "",
        "=== ŹRÓDŁO ===",
        f"Hosting: {g('host')}",
    ])


def confirm_download(addon_path: str, file_name: str, meta: dict, size_line_override: str = "", heading: str = "Wymagane potwierdzenie") -> bool:
    """
    Otwiera dialog potwierdzenia + metadane.
    Zwraca True jeśli user kliknie "Pobierz", wpp False.

    WAŻNE: wywołuj to PRZED start_download_or_play / resolve,
    żeby nie naliczać transferu przed pokazaniem metadanych.
    """
    xml = "DialogFanVodConfirm.xml"
    skin = "Default"

    # preferuj 1080i jeśli istnieje, w przeciwnym razie 720p
    xml_1080 = os.path.join(addon_path, "resources", "skins", skin, "1080i", xml)
    res = "1080i" if os.path.exists(xml_1080) else "720p"

    meta_text = build_meta_text(meta)
    size_line = size_line_override or ""

    dlg = ConfirmDownloadMetaDialog(
        xml, addon_path, skin, res,
        heading=heading,
        file_label=file_name,
        size_line=size_line,
        meta_text=meta_text,
    )
    dlg.doModal()
    return bool(dlg.result)
