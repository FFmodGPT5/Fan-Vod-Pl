"""
    FanVodPL — Wyszukiwanie przez Google Custom Search API
    Działa jak przeglądarka: wpisujesz opis, Google szuka, TMDB pokazuje wyniki.

    Jak uzyskać klucz i CX:
    1. Klucz API:  console.developers.google.com → Credentials → Create API Key
       (włącz "Custom Search API" w bibliotece)
    2. CX (Search Engine ID):  programmablesearch.google.com → Add
       → w "Sites to search" wpisz: themoviedb.org
       → skopiuj "Search engine ID"
"""

import re
import unicodedata

import requests
import xbmcgui

from ptw.libraries import control
from ptw.libraries.log_utils import log

_GOOGLE_CSE_URL = 'https://www.googleapis.com/customsearch/v1'

# ZMIANA (2026-05) [PATCH]: lokalne maskowanie sekretów Google CSE w logach i błędach.
# POWÓD: wyjątki requests mogą zawierać pełny URL z parametrami key/cx.
# NIE ZMIENIAĆ: funkcja ma usuwać sekrety tylko z tekstu logu, bez wpływu na realny request.
def _redact_google_secrets(value):
    text = u'{}'.format(value or '')
    text = re.sub(r'([?&](?:key|api_key|access_token)=)[^&\s]+', r'\1[REDACTED]', text, flags=re.IGNORECASE)
    text = re.sub(r'([?&]cx=)[^&\s]+', r'\1[REDACTED_CX]', text, flags=re.IGNORECASE)
    text = re.sub(r'(Authorization\s*:\s*Bearer\s+)[^\s,;]+', r'\1[REDACTED]', text, flags=re.IGNORECASE)
    return text



# ---------------------------------------------------------------------------
# Parsowanie wyników Google → tytuł
# ---------------------------------------------------------------------------
def _clean_title_from_result(title_raw):
    t = title_raw or ''
    t = re.sub(r'\s*[—\-–|]\s*The Movie Database.*$', '', t, flags=re.IGNORECASE)
    t = re.sub(r'\s*[—\-–|]\s*TMDB.*$',              '', t, flags=re.IGNORECASE)
    t = re.sub(r'\s*[—\-–|]\s*Seriale.*$',            '', t, flags=re.IGNORECASE)
    t = re.sub(r'\s*\(\d{4}\)\s*$',                   '', t)
    return t.strip()


def _fold_text(value):
    text = unicodedata.normalize('NFKD', value or '')
    text = ''.join([c for c in text if not unicodedata.combining(c)])
    return text.lower().replace(u'ł', u'l').replace(u'Ł', u'l')


def _query_terms(query):
    folded = _fold_text(query)
    stop = set([
        'film', 'serial', 'movie', 'series', 'stary', 'bardzo', 'chyba',
        'jaki', 'jaka', 'tytul', 'tytulu', 'szukam', 'byla', 'byl',
        'tam', 'aktor', 'aktora', 'znany', 'lata', 'moze',
    ])
    out = []
    for token in re.split(r'[^a-z0-9]+', folded):
        token = token.strip()
        if len(token) >= 4 and token not in stop and token not in out:
            out.append(token)
    return out[:10]


def _build_google_queries(query):
    q = u' '.join((query or '').split()).strip()
    queries = [
        u'{} film'.format(q),
        u'{} movie plot'.format(q),
        u'{} filmweb imdb'.format(q),
        u'{} site:themoviedb.org'.format(q),
    ]
    terms = _query_terms(q)
    if terms:
        short = u' '.join(terms[:6])
        queries.insert(0, u'{} film'.format(short))
        queries.insert(1, u'{} movie'.format(short))
    seen, out = set(), []
    for item in queries:
        key = _fold_text(item)
        if item and key not in seen:
            seen.add(key)
            out.append(item[:160])
    return out[:6]


def _score_google_item(item, query):
    title = item.get('title') or ''
    snippet = item.get('snippet') or ''
    link = item.get('link') or ''
    hay = _fold_text(u'{} {} {}'.format(title, snippet, link))
    score = 0
    for term in _query_terms(query):
        if term in hay:
            score += 8
    link_low = link.lower()
    if 'themoviedb.org' in link_low:
        score += 16
    if 'imdb.com' in link_low:
        score += 12
    if 'wikipedia.org' in link_low:
        score += 8
    if 'filmweb.pl' in link_low:
        score += 8
    if any(word in hay for word in ('film', 'movie', 'serial', 'series')):
        score += 4
    return score


# ---------------------------------------------------------------------------
# Główna funkcja — wywoływana z default.py dla action=googleSearch
# ---------------------------------------------------------------------------
def google_search_action():
    api_key = (control.setting('google_search.api_key') or '').strip()
    cx      = (control.setting('google_search.cx')      or '').strip()

    # --- Brak konfiguracji ---
    if not api_key or not cx:
        xbmcgui.Dialog().ok(
            'FanVodPL — Wyszukiwanie Google',
            'Brak klucza API lub ID wyszukiwarki (CX).\n\n'
            'Skonfiguruj w:\n'
            '[I]Ustawienia → Wyszukiwanie AI → sekcja Google[/I]\n\n'
            'Klucz: console.developers.google.com\n'
            'CX:    programmablesearch.google.com'
        )
        return

    # --- Zapytanie użytkownika ---
    kb = control.keyboard('', u'Opisz film lub serial (po polsku)\u2026')
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = (kb.getText() or '').strip()
    if not query:
        return

    # --- Powiadomienie ---
    xbmcgui.Dialog().notification(
        'FanVodPL',
        u'Google szuka\u2026',
        xbmcgui.NOTIFICATION_INFO,
        2000,
    )

    # --- Wywołanie Google Custom Search ---
    search_queries = _build_google_queries(query)
    found_title  = query  # fallback

    try:
        items = []
        seen = set()
        for search_query in search_queries:
            r = requests.get(
                _GOOGLE_CSE_URL,
                params={
                    'key': api_key,
                    'cx':  cx,
                    'q':   search_query,
                    'num': 5,
                    'hl':  'pl',
                    'safe': 'active',
                },
                timeout=10,
            )
            r.raise_for_status()
            data = r.json()
            for item in data.get('items', []):
                link = (item.get('link') or '').split('#')[0].lower()
                if link and link not in seen:
                    seen.add(link)
                    items.append(item)
        if not items:
            xbmcgui.Dialog().notification(
                'FanVodPL Google',
                u'Brak wynik\u00f3w — spr\u00f3buj inaczej opisa\u0107',
                xbmcgui.NOTIFICATION_WARNING,
                4000,
            )
            return

        best      = sorted(items, key=lambda item: _score_google_item(item, query), reverse=True)[0]
        raw_title = best.get('title', '')
        best_url  = best.get('link',  '')

        found_title = _clean_title_from_result(raw_title) or query

        log(
            '[GOOGLE_SEARCH] query={!r} → raw={!r} title={!r} url={}'.format(
                search_queries, raw_title, found_title, best_url
            ), 1
        )

    except Exception as exc:
        log('[GOOGLE_SEARCH] ERROR: {}'.format(_redact_google_secrets(exc)), 1)
        xbmcgui.Dialog().notification(
            'FanVodPL Google',
            u'B\u0142\u0105d Google: {}'.format(_redact_google_secrets(str(exc))[:60]),
            xbmcgui.NOTIFICATION_ERROR,
            5000,
        )

    # --- Wyszukiwanie w TMDB ---
    from resources.lib.indexers.movies import movies as MoviesClass
    MoviesClass().search_term(found_title, s_type='multi')
