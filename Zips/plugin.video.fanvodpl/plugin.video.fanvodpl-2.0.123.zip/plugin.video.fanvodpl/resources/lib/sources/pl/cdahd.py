"""
    FanFilm Add-on
    Copyright (C) 2025

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

try:
    import urllib.parse as urlparse
except:
    import urllib.parse as urlparse  # ??

import json
import re
import requests

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from html import unescape

from ptw.libraries import cleantitle, source_utils, control
from ptw.libraries import client, cache
from ptw.debug import fflog_exc, fflog



class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["cda-hd.cc"]
        self.base_link = "https://cda-hd.cc"
        self.search_link = "/?s=%s"
        self.headers = {}


    def init(self, get_cookies_from_file=None):
        """ zrobiłem dodatkową funkcję, bo jak źródła są brane z cache, to __init__ i tak się wykoknuje, choć nie będzie potrzebny """
        self.cdahd_files = control.setting("cdahd.files") == "true"
        self.headers = {
            # "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/142.0",
            # ":authority": self.domains,  # requests.exceptions.InvalidHeader: Invalid leading whitespace, reserved character(s), or returncharacter(s) in header name: ':authority'
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            # "Accept-Encoding": "gzip, deflate, br, zstd",  # to powoduje dziwne krzaczki w odpowiedzi
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "Referer": "https://cda-hd.cc/",
            # "Origin": "https://cda-hd.cc",
            # "Host": "cda-hd.cc",
            # "Priority": "u=0, i",
            # "Connection": "keep-alive",
            # "Upgrade-Insecure-Requests": "1",
            # "Sec-Fetch-Dest": "document",
            # "Sec-Fetch-Mode": "navigate",
            # "Sec-Fetch-Site": "same-origin",
            # "Sec-Fetch-User": "?1",
            # "Sec-GPC": "1",
            # "TE": "trailers",
            # "DNT": "1",
            }
        if UA := control.setting("cdahd.ua").strip().strip('"\''):
            # fflog(f'{UA=}',1,1)
            self.headers.update({"User-Agent": UA})
            pass
        if not get_cookies_from_file:
            # cache.cache_insert("cdahd_headers", repr(self.headers) )
            pass
        """
        self.search_headers = {  # to do API (już raczej nie będzie potrzebne)
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
            "Connection": "keep-alive",
            "Origin": "https://cda-hd.cc",
            "Referer": "https://cda-hd.cc/",
            }
        """

        cookies = ""
        # cookies += "; cf_clearance=BaAQ4qlo1spWJmSDGjwTPENL4GhbQXEDmlZx_B2s2M4-1755042950-1.2.1.1-zAH5ySmzeLcjc2udyqbOKUowamC9Nz.Swta2O48MrmXXYCvFWLBXnKiM42qam6AHafhtUuBmwoSpbSWKf6MWeTdE2pEqjVoZDX5ET7JBlq6LCm475Nbw2w0GMUwbCsLqgflbIXd.NDGd_wmFvVClV.4uLI0kEcAYGGSi6Hp8CD_6.LJwqs5gxcLaWQVvddeXVgMThM13iBWCpXe.xOK34rZZWXohZQArcMY6fmE9cnY"
        # ciasteczko od Cloudflare
        cf = ""

        if get_cookies_from_file:
            fflog(f'{get_cookies_from_file=}',1,1)

            if dest := control.setting("cdahd.ua.file"):  # dla UserAgenta
                # dest = "smb://SERWER/UDOSTEPNIONY/useragent"  # test
                # fflog(f'{dest=}',1,1)
                if control.existsPath(dest):
                    with control.openFile(dest) as f:
                        content = f.read()
                    # fflog(f'{content=}',1,1)
                    content = content.replace('\ufeff', '')  # BOM
                    ua = content.strip().strip('"\'')
                    fflog(f'{ua=}',1,1)
                    if ua:
                        # fflog('zapisuje ua',1,1)
                        control.setSetting("cdahd.ua", ua)
                        self.headers.update({"User-Agent": ua})
                        # cache.cache_insert("cdahd_headers", repr(self.headers) )
                else:
                    fflog(f'nie można połączyć się z plikiem z zawartością UserAgenta {dest=}',1,1)
                    pass
            else:
                fflog(f'brak podanej ścieżki do pliku z zawartością UserAgenta {dest=}',1,1)
                pass

            if dest := control.setting("cdahd.cf.file"):
                # dest = "smb://SERWER/UDOSTEPNIONY/ciast.json"  # test
                # fflog(f'{dest=}',1,1)
                if control.existsPath(dest):
                    with control.openFile(dest) as f:
                        content = f.read()
                    # fflog(f'odczytane dane {content=}',1,1)
                    content = content.replace('\ufeff', '')  # BOM
                    content = content.strip().strip('"\'')
                    # fflog(f'odczytane dane {content=}',1,1)
                    if ( content.startswith("[")  # lista json
                        or content.startswith("{")  # pojedyncze ciasteczko json
                        ):
                        cookies = json.loads(content)
                        # cookies = {c["name"] : c["value"] for c in cookies}  # na słownik
                        # a może lepiej na string
                        if isinstance(cookies, list):
                            cookies = "; ".join(f'{c["name"]}={c["value"]}' for c in cookies)
                        elif isinstance(cookies, dict):  # nie testowałem tego wariantu
                            cookies = "; ".join(f'{c["name"]}={c["value"]}' for c in [cookies])
                            pass
                    else:
                        cookies = content
                    # fflog(f'{cookies=}',1,1)
                    if cookies:
                        if "=" in cookies:
                            cookiesD = {x[0].strip() : x[1].strip() for x in [c.split("=") for c in cookies.strip("; ").split(";")]}  # string to dict
                            # fflog(f'{cookiesD=}',1,1)
                            cf = cookiesD.get('cf_clearance')
                            cookies = ""  # nie potrzebuje pozostałych
                        else:
                            cf = cookies
                            cookies = ""  # ważne (póki nie potrzebuje innych)
                        fflog(f'{cf=}',1,1)
                        if cf:
                            # fflog(f'{cf=}',1,1)
                            # fflog('zapisuje cf',1,1)
                            control.setSetting("cdahd.cf", cf)
                            pass
                else:
                    fflog(f'nie można połączyć się z plikiem ciasteczka {dest=}',1,1)
                    pass
            else:
                fflog(f'brak podanej ścieżki do pliku ciasteczka {dest=}',1,1)
                pass

            control.setting = control.addon().getSetting  # odświeżenie cachu

        # fflog(f'{cf=}',1,1)
        if not cf:
            # fflog(f'{cf=}',1,1)
            cf = control.setting("cdahd.cf").strip().strip('"\'')
            # fflog(f'odczytany z Ustawień {cf=}',1,1)
        # fflog(f'{cf=}',1,1)
        # fflog(f'{cookies=}',1,1)
        cookies += ("; cf_clearance=" + cf) if cf else ""
        cookies = cookies.strip("; ")
        # fflog(f'{cookies=}',1,1)

        if cookies:
            # fflog('wstawiam ciasteczka do nagłówka',1,1)
            # cache.cache_insert("cdahd_cookies", cookies)
            self.headers.update({'Cookie': cookies})


    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        # fflog(f'szukanie filmu {title=} {localtitle=} {year=} {aliases=}',1,1)
        # self.init()
        year_alt = kwargs.get("year_alt")
        year = (year, year_alt) if year_alt else year
        return self.do_search(title, localtitle, year, aliases)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        # fflog(f'szukanie serialu {tvshowtitle=} {localtvshowtitle=} {year=} {aliases=}',1,1)
        # self.init()
        year_alt = kwargs.get("year_alt")
        year = (year, year_alt) if year_alt else year
        return self.do_search(tvshowtitle, localtvshowtitle, year, aliases)


    def do_search(self, title, localtitle, year, aliases=None, recurency=None):

        # to trzeba tylko, jak dostajemy 403
        # from resources.lib.temp import refresh_cdahd_cookies  # cloudscraper
        # from resources.lib.temp import get_cookies_for_cdahd  # na selenium

        if isinstance(year, tuple):
            year, year_alt = year
        else:
            year_alt = ""

        try:
            if aliases:
                originalname = [a for a in aliases if "originalname" in a]
                originalname = originalname[0]["originalname"] if originalname else ""
                # fflog(f'{originalname=}',1,1)
                originalname = "" if source_utils.czy_litery_krzaczki(originalname) else originalname

                aliases1 = [
                    (a.get("title") or a.get("originalname") or "")
                    + " ("
                    + a.get("country", "")
                    + ")"
                    for a in aliases
                ]
                aliases2 = [a.rpartition(" (")[0] for a in aliases1]  # country out
                aliases2 = [a.replace(year, "").replace("()", "").rstrip() for a in aliases2]  # year out
                aliases2 = [a for a in aliases2 if not source_utils.czy_litery_krzaczki(a)]  # krzaczki out
                aliases2 = [alias for i, alias in enumerate(aliases2) if alias.lower() not in [x.lower() for x in aliases2[:i]]]  # kolejne duplikaty są usuwane niezależnie od wielkości liter
            else:
                originalname = ""
                aliases2 = []

            titles = [localtitle, originalname, title]
            # titles = [cleantitle.normalize(cleantitle.getsearch(t)) for t in titles]  # niepotrzebne, bo zaczął szukać uwzgledniając wszystskie znaki i nie znajduje "wydzialu", ale znajduje "wydziału"
            # fflog(f'{titles=}',1,1)

            titles = list(filter(None, titles))  # usunięcie pustych
            titles = list(dict.fromkeys(titles))  # pozbycie się duplikatów
            # fflog(f'{titles=}',1,1)

            titles += aliases2

            # get_simple() już usuwa spacje, dwukropki, myślniki - idealny do deduplikacji
            def normalize_for_dedup(title):
                if not title:
                    return ""
                return cleantitle.get_simple(title)

            seen = set()
            unique_titles = []
            for t in titles:
                if t:
                    normalized = normalize_for_dedup(t)
                    if normalized not in seen:
                        unique_titles.append(t)
                        seen.add(normalized)
            titles = unique_titles[:4]
            # fflog(f"aliases={aliases2}")
            # fflog(f'{titles=}')

            # Używamy cleantitle.get_simple do porównań
            titles_for_compare = [cleantitle.get_simple(t) for t in titles]
            titles_for_compare = [t.replace("⁄", "").replace(" ", "") for t in titles]  # ułamki
            # fflog(f'{titles_for_compare=}',1,1)

            if not recurency:
                self.init()
                pass

            headers = self.headers
            cookies = headers.get('Cookie')
            cookiesD = {x[0].strip() : x[1].strip() for x in [c.split("=") for c in cookies.strip("; ").split(";")]} if cookies else {}

            for title in titles:
                try:
                    if not title:
                        continue

                    url = self.base_link

                    # albo szukamy poprzez url albo poprzez post - a poza tym, to jakoś musi być zgodne, bo serwer sprawdza
                    url = urlparse.urljoin(self.base_link, self.search_link)
                    url = url % urlparse.quote_plus(cleantitle.query(title))
                    # url = url % urlparse.quote_plus(title)
                    fflog(f'{url=}',1,1)

                    data = {"s": title}
                    # fflog(f'{data=}',1,1)

                    """
                    headers = {  # jeszcze inny header ??
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0",
                        "Accept": "*/*",
                        "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
                        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                        "X-Requested-With": "XMLHttpRequest",
                        "Origin": self.base_link,
                        "DNT": "1",
                        "Alt-Used": "vizjer.eu",
                        "Connection": "keep-alive",
                        "Referer": "https://cda-hd.cc/?s=" + title,
                        "Sec-Fetch-Dest": "empty",
                        "Sec-Fetch-Mode": "cors",
                        "Sec-Fetch-Site": "same-origin",
                        "Pragma": "no-cache",
                        "Cache-Control": "no-cache",
                        "TE": "trailers",
                        }
                    """
                    #result = client.request("https://api.searchiq.co/api/search/results?q=%s&engineKey=59344ef44ca3ca07a4bbbeb7b6ee6b38&page=0&itemsPerPage=8&group=0&autocomplete=1" % url.replace("+", "%20"), headers=self.search_headers, )

                    headers = self.headers
                    # fflog(f'headers={json.dumps(headers, indent=2)}',1,1)

                    #result = client.request(url, headers=headers, post=data)  # to coś chyba resolvera psuło
                    # result = requests.post(url, headers=headers, data=data)
                    # result = requests.post(url, cookies=cookiesD, headers=headers, data=data)
                    result = requests.get(url, cookies=cookiesD, headers=headers)
                    # fflog(f'{result=}',1,1)
                    if not result:
                        fflog(f'{result=}',1,1)
                        if not control.window.getProperty("blocked_sources_extend") == 'break':
                            if recurency:
                                control.infoDialog("nieprawidłowa odpowiedź serwera: " + str(result.status_code), 'CDA-HD.cc', "WARNING")
                            is_cf = self.check_if_cf(result, recurency or not self.cdahd_files)
                            if not recurency and is_cf and self.cdahd_files:
                                fflog(f'spróbuję pobrać ciasteczko z pliku i powtórzyć szukanie',1,1)
                                # wziąść ciasteczko z pliku
                                self.init(get_cookies_from_file=True)
                                # ponowić procedurę
                                return self.do_search(title, localtitle, (year, year_alt), aliases, recurency=True)
                            return
                        continue  # ?
                        return

                    result = result.text  # to daje html'a

                    if "rak wynik" in result:
                        fflog(f"Brak wyników dla {title=} ({data=})",1,1)
                        continue

                    elif "ykryto niezgodność wartości" in result:
                        fflog(f"Wykryto niezgodność wartości {title=} ({data=}) {url=}",1,1)
                        continue

                    try:
                        result = client.parseDOM(result, "div", attrs={"class": "peliculas"})[0]
                        res = client.parseDOM(result, "div", attrs={"class": "item_1 items"})[0]
                        rows = client.parseDOM(res, "div", attrs={"class": "item"})
                    except Exception:
                        if "<title>Just a moment...</title>" in result:
                            fflog(f'strona schowana obecnie za Cloudflare',1,1)
                            if not control.window.getProperty("blocked_sources_extend") == 'break':
                                control.infoDialog("strona schowana obecnie za Cloudflare", 'CDA-HD.cc', "WARNING")
                            fflog(f'brak implementacji ponownego uruchomienia procedury szukania',1,1)
                            return
                        fflog(f'wystąpił jakiś błąd',1,1)
                        fflog(f'{result=}',1,1)
                        fflog_exc(0)
                        continue
                        
                    # fflog(f'{len(rows)=}',1,1)
                    """
                    for row in result["main"]["records"]:  # to dla jsona
                        tytul = row["title"]
                        rok = row["ct_release-year"][0]
                    """
                    for row in rows:
                        # fflog(f'{row=}',1,1)
                        rok = client.parseDOM(row, "span", attrs={"class": "year"})[0]
                        tytul = client.parseDOM(row, "h2")[0].replace(f" ({rok})", "").rstrip()
                        tytul = unescape(tytul)
                        tytuly = tytul.split(" / ")
                        title1 = tytuly[0]
                        title2 = tytuly[-1]
                        # title1 = cleantitle.normalize(cleantitle.getsearch(title1))
                        # title2 = cleantitle.normalize(cleantitle.getsearch(title2))
                        # tak jak titles_for_compare
                        title1 = title1.replace("⁄", "").replace(" ", "")
                        title2 = title2.replace("⁄", "").replace(" ", "")
                        #words = title.split(" ")
                        #fflog(f'\n{title=} {words=} \n {cleantitle.normalize(cleantitle.getsearch(tytul))=} \n{rok=} {year=}',1,1)
                        # fflog(f'\n {rok=}  {title1=}  {title2!r}   ({tytul=})\n{year=} {titles=} \n{titles_for_compare=}',1,1)
                        if (
                            (str(year) in str(rok) or year_alt and str(year_alt) in str(rok))
                            # and self.contains_all_words(cleantitle.normalize(cleantitle.getsearch(tytul)), words)
                            # and (title1 in titles_for_compare or title2 in titles_for_compare)
                            and any(t in titles_for_compare for t in (title1, title2))
                           ):
                            #url = row["url"]
                            url = client.parseDOM(row, "a", ret="href")[0]
                            fflog(f'pasuje {url=}',1,1)
                            return url
                        else:
                            # fflog(f'nie pasuje, bo \n{title1=} \n{title2=}',1,1)
                            pass
                except Exception:
                    fflog_exc(1)
                    continue
            fflog("nic nie znaleziono")
        except Exception:
            fflog_exc(1)
            return


    def check_if_cf(self, result, recurency=None):
        if not isinstance(result, str):
            result = result.text
        if "<title>Just a moment...</title>" in result:
            fflog(f'strona schowana obecnie za Cloudflare',1,1)
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                if recurency:
                    control.infoDialog("strona schowana obecnie za Cloudflare", 'CDA-HD.cc', "WARNING")
            return True


    def episode(self, url, imdb, tvdb, title, premiered, season, episode, recurency=None):
        # fflog(f'szukanie odcinka {url=} {season=} {episode=}  ({title=} {premiered=} {imdb=} {tvdb=})',1,1)
        if not url:
            fflog(f'{url=}',1,1)
            return

        if not recurency:
            self.init()

        headers = self.headers
        cookies = headers.get('Cookie')
        cookiesD = {x[0].strip() : x[1].strip() for x in [c.split("=") for c in cookies.strip("; ").split(";")]} if cookies else {}

        #result = client.request(url, cookie=cookies, headers=self.headers)
        # result = requests.get(url, headers=headers)
        result = requests.get(url, cookies=cookiesD, headers=headers)
        if not result:
            fflog(f'{result=}',1,1)
            is_cf = self.check_if_cf(result, recurency or not self.cdahd_files)
            if is_cf and not recurency and self.cdahd_files:
                fflog(f'spróbuję pobrać ciasteczko z pliku i powtórzyć szukanie',1,1)
                self.init(get_cookies_from_file=True)
                return self.episode(url, imdb, tvdb, title, premiered, season, episode, recurency=True)
            return
        result = result.text
        #fflog(f'{result=}',1,1)
        """  nie wiem czy warto takimi krokami dotrzeć do celu
        try:
            seasons = client.parseDOM(result, "div", attrs={"id": "seasons"})[0]
            #fflog(f'{seasons=}',1,1)
        except:
            return
        """
        """
        # episodes = client.parseDOM(result, "div", attrs={"class": "episodiotitle"})
        # fflog(f'{len(episodes)=}',1,1)
        #episodes = client.parseDOM(episodes, "a", ret="href")  # z powodu błędu w kodzie html strony cda-hd.cc klonuje niebotycznie (z 48 zrobił 2018 linków)
        # <div>\n</li> taki jest błąd w kodzie strony
        # episodes = [e[0] for ep in episodes if (e:=client.parseDOM(ep, "a", ret="href"))]  # a to działa, ale dlatego, że interesujący link jest pierwszy w analizowanym bloku
        """
        # dlatego z powodu tego błędu trochę inaczej wyszukuje
        seasons = client.parseDOM(result, "ul", attrs={"class": "episodios"})
        # fflog(f'{len(seasons)=}',1,1)
        episodes = client.parseDOM(seasons, "a", ret="href")
        # fflog(f'{len(episodes)=} {episodes=}',1,1)
        for episode_url in episodes:
            if f"sezon-{season}-odcinek-{episode}-" in episode_url:
                fflog(f'pasujący odcinek to {episode_url=}',1,1)
                return episode_url
        fflog("brak pasującego odcinka",1,1)


    def sources(self, url, hostDict, hostprDict, recurency=None):
        # fflog(f'szukanie źródeł dla {url=}',1,1)
        sources = []
        if url is None:
            fflog(f'{url=}',1,1)
            return sources

        # self.init()

        url0 = url
        # control.sleep(1000)
        try:

            if not recurency:
                self.init()
            headers = self.headers
            # fflog(f'{headers=}',1,1)
            cookies = headers.get('Cookie')
            # fflog(f'{cookies=}',1,1)
            cookiesD = {x[0].strip() : x[1].strip() for x in [c.split("=") for c in cookies.strip("; ").split(";")]} if cookies else {}

            """
            headers = self.headers
            # fflog(f'{headers=}',1,1)
            if not headers:
                try:
                    headers = cache.cache_get("cdahd_headers")["value"]
                    headers = eval(headers)
                except Exception:
                    headers = {}
                    pass
            # fflog(f'{headers=}',1,1)

            try:
                cookies = cache.cache_get("cdahd_cookies")["value"]
            except Exception:
                cookies = ""

            if cookies:
                headers["Cookie"] = cookies
                # fflog(f'{cookies=}',1,1)
                cookiesD = {x[0].strip() : x[1].strip() for x in [c.split("=") for c in cookies.strip("; ").split(";")]}
            """

            # fflog(f'{url=}',1,1)
            # result = client.request(url, cookie=cookies, headers=headers)
            result = requests.get(url, cookies=cookiesD, headers=headers)
            # fflog(f'{type(result)=}',1,1)
            if not result:
                fflog(f'problem, bo {result=}',1,1)
                is_cf = self.check_if_cf(result, recurency or not self.cdahd_files)
                if is_cf and not recurency and self.cdahd_files:
                    fflog(f'spróbuję pobrać ciasteczko z pliku i powtórzyć szukanie',1,1)
                    self.init(get_cookies_from_file=True)
                    return self.sources(url, hostDict, hostprDict, recurency=True)
                return
            try:
                result = result.text
            except:
                pass
            # fflog(f'{result=}',1,1)

            if "/episode/" in url:
                serial = True
                result = client.parseDOM(result, "div", attrs={"class": "player2"})

                results_player = client.parseDOM(result, "div", attrs={"class": "embed2"})
                results_player = client.parseDOM(results_player, "div")
                results_player = list(filter(None, results_player))
                # fflog(f'{len(results_player)=}  {results_player=}',1,1)

                results_navi = client.parseDOM(result, "div", attrs={"class": "navplayer2"})
                results_navi = client.parseDOM(results_navi, "a", attrs={"href": ""})  # tylko, co mają href
                results_navi = list(filter(None, results_navi))
                # fflog(f'{len(results_navi)=}  {results_navi=}',1,1)
            else:
                serial = False
                results_player = client.parseDOM(result, "div", attrs={"id": "player2"})  # może to i opcjonalne
                results_player = client.parseDOM(results_player, "div", attrs={"class": "movieplay"})
                results_player = list(filter(None, results_player))

                results_navi = client.parseDOM(result, "div", attrs={"class": "player_nav"})
                results_navi = client.parseDOM(results_navi, "a")
                results_navi = list(filter(None, results_navi))

            if len(results_navi) != len(results_player):
                fflog(f'nie można kontynuować, bo {len(results_navi)=} != {len(results_player)=}',1,1)
                return sources
            else:
                # fflog(f'{len(results_navi)=} {len(results_player)=}',1,1)
                pass

            try:
                quality = client.parseDOM(result, "span", attrs={"class": "calidad2"})[0]
            except:
                quality = ""
            # fflog(f'{quality=}',1,1)
            # brak znacznika HD dla filmu może świadczyć o dubbing kino, albo 720p (np. film Istoty fantastyczne)

            i = -1
            # fflog(f'{len(results_navi)=}',1,1)
            for item in results_navi:
                try:
                    i += 1
                    #fflog(f'{item=}',1,1)
                    jezyk = item
                    jezyk = re.sub("<[^>]+>", "", jezyk)  # uzyskanie samego tekstu (w środku jest tag obrazka)
                    # fflog(f'{jezyk=}')
                    jezyk, info = self.get_lang_by_type(jezyk)
                    # fflog(f'{jezyk=} {info=}',1,1)

                    url = results_player[i]
                    # fflog(f'{url=}',1,1)
                    try:
                        url = client.parseDOM(url, "a", ret="href")[0]
                    except:
                        try:
                            domain = client.parseDOM(url, "div", ret="domain")[0]
                            # fflog(f'{domain=}',1,1)
                            encoded_vid = client.parseDOM(url, "div", ret="id")[0]
                            # fflog(f'{encoded_vid=}',1,1)
                            decoded_vid = self.decode_id(encoded_vid)
                            # fflog(f'{decoded_vid=}',1,1)
                            url = f"https://{domain}/e/{decoded_vid}"
                        except Exception:
                            # fflog_exc(1)
                            try:
                                url = client.parseDOM(url, "iframe", ret="src")[0]
                                url = url.replace("player.cda-hd.co/", "hqq.to/")
                            except Exception:
                                # fflog_exc(1)
                                """ do analizy działania było potrzebne
                                url = "https://hqq.to/e/226260277253228276221235209264264223194271217271255"
                                url = "https://hqq.to/player/embed_player.php?vid=226260277253228276221235209264264223194271217271255&autoplay=none&hash_from=9577577afd53ec77bbeda5ff4d30054a"
                                url = "https://hqq.to/f/FhyaHxAO5llC"
                                """
                                try:
                                    if not 'src="https://player.cda-hd.co/player/hash.php?hash=' in url:
                                        raise Exception()
                                    # hash = re.search("(?<=hash=)\d+", url)[0]  # mniej czytelne
                                    hash = re.search(r"hash=(\d+)", url)[1]
                                    # url = f"https://hqq.to/player/embed_player.php?vid={hash}&hash_from=9577577afd53ec77bbeda5ff4d30054a"
                                    url = f"https://hqq.to/e/{hash}"  # krótsza forma
                                except Exception:
                                    # fflog_exc(1)
                                    fflog(f"can't find proper url for this source  |  {url=}",1,1)
                                    continue

                    valid, host = source_utils.is_host_valid(url, hostDict)
                    # fflog(f'{valid=} {host=}',1,1)

                    host = host.rsplit(".", 1)[0]

                    unsure = None
                    # strzelanie
                    if "wysoka" in quality.lower() or quality == "HD":
                        jakosc = "HD"
                        jakosc = "1080p"
                        unsure = ["quality"]
                    elif "rednia" in quality.lower():
                        jakosc = "SD"
                    elif "niska" in quality.lower() or quality == "CAM":
                        jakosc = "CAM"
                    else:
                        jakosc = "SD"  # tylko ryzyko, że filtry mogą odrzucać, jak ktoś ustawił min 720p
                        jakosc = "HD" if serial else jakosc

                    info2 = url0.rstrip("/").rsplit("/")
                    info2 = info2[-1]

                    sources.append({"source": host,
                                    "quality": jakosc,
                                    "language": jezyk,
                                    "url": url,
                                    "info": info,
                                    "info2": info2,
                                    "direct": False,
                                    "debridonly": False})
                    if unsure:
                        sources[-1].update({"unsure": unsure})
                        pass
                except:
                    fflog_exc(1)
                    continue

            fflog(f'przekazano źródeł: {len(sources)}')
            return sources

        except Exception:
            fflog_exc(1)
            return sources


    def get_lang_by_type(self, lang_type):
        if "dubbing" in lang_type.lower():
            if "kino" in lang_type.lower():
                return "pl", "Dubbing Kino"
            return "pl", "Dubbing"
        elif "lektor pl" in lang_type.lower():
            return "pl", "Lektor"
        elif "lektor" in lang_type.lower():
            return "pl", "Lektor"
        elif "napisy pl" in lang_type.lower():
            return "pl", "Napisy"
        elif "napisy" in lang_type.lower():
            return "pl", "Napisy"
        elif "POLSKI" in lang_type.lower():
            return "pl", None
        elif "pl" in lang_type.lower():
            return "pl", None
        return "en", None


    def decode_id(self, id_hex):
        s1 = ''.join(chr(int(id_hex[i:i+2], 16) ^ 0x02) for i in range(0, len(id_hex), 2))
        return ''.join(format(ord(ch) ^ 0x04, 'x') for ch in s1)

    # print( decode_id("636d3b707a6d654933456f7a7b4567") )
    # 656b3d767c6b634f3543697c7d4361


    """
    def contains_word(self, str_to_check, word):
        str_to_check = cleantitle.get_title(str_to_check).split()
        if word.lower() in str_to_check:
            return True
        return False


    def contains_all_words(self, str_to_check, words):
        words = list(filter(None, words))
        for word in words:
            word = cleantitle.get_title(word)
            if not word:
                continue
            if not self.contains_word(str_to_check, word):
                return False
        return True
    """


    """
    def find_url_for_source(self, url):  # to już chyba nie działa (albo było potrzebne gdy dane były z api)
        url = url.split(";")
        fflog(f'{url=}',1,1)
        data = {"action": "doo_player_ajax", "post": url[0], "nume": url[1], "type": "movie", }
        response = requests.post("https://cda-hd.cc/wp-admin/admin-ajax.php", data=data)
        fflog(f'{response=}',1,1)
        response = response.text
        fflog(f'{response=}',1,1)
        try:
            url = client.parseDOM(response, "iframe", ret="src")[0]
        except:
            fflog(f"iframe tag not found")
        fflog(f'{url=}',1,1)
        return url
    """

    def resolve(self, url):
        # fflog(f'zwrócenie adresu źródła {url=}',1,1)
        return url
