"""
FanVodPL - osobny tryb „Nie pamiętam tytułu”.
Darmowy lokalno-internetowy agent: lokalne podpowiedzi + DuckDuckGo IA + Wikipedia + 1x TMDB.
Hosty są odpytywane dopiero po wyborze konkretnej propozycji.
"""
import json
import os
import re
import sys
import time
import unicodedata
from sqlite3 import dbapi2 as database

try:
    import urllib.parse as urllib
except Exception:
    import urllib

import requests

from resources.lib.indexers import navigator
from ptw.libraries import control
from ptw.libraries.log_utils import fflog

_LOCAL_HINTS = [
    (
        ('neo', 'morpheus', 'trinity', 'matrix', 'czerwona pigulka', 'niebieska pigulka', 'wybraniec'),
        'Matrix', '1999', 'movie',
        'Lokalna podpowiedź: Neo / Morfeusz / pigułki / Wybraniec kojarzone z Matrix.'
    ),
    (
        ('baba jaga', 'baba yaga', 'john wick', 'hotel dla zabojcow', 'hotel dla zabójców', 'zloty monet', 'złoty monet'),
        'John Wick', '2014', 'movie',
        'Lokalna podpowiedź: Baba Jaga / hotel dla zabójców / złote monety kojarzone z John Wick.'
    ),
    (
        ('continental', 'hotel continental'),
        'The Continental: From the World of John Wick', '2023', 'tv',
        'Lokalna podpowiedź: hotel Continental z uniwersum John Wick.'
    ),
    (
        ('czerwony balonik', 'klaun', 'pennywise', 'zolty plaszcz', 'żółty płaszcz', 'dzieci i klaun'),
        'It', '2017', 'movie',
        'Lokalna podpowiedź: czerwony balonik / Pennywise / klaun kojarzone z filmem To.'
    ),
    (
        ('maska hokejowa', 'hokejowa maska', 'jason', 'crystal lake', 'oboz nad jeziorem', 'obóz nad jeziorem'),
        'Friday the 13th', '1980', 'movie',
        'Lokalna podpowiedź: maska hokejowa / Jason / Crystal Lake kojarzone z Piątkiem trzynastego.'
    ),
    (
        ('freddy', 'freddy krueger', 'pazury', 'ulica wiazow', 'ulica wiązów', 'koszmar'),
        'A Nightmare on Elm Street', '1984', 'movie',
        'Lokalna podpowiedź: Freddy Krueger / pazury / Ulica Wiązów kojarzone z Koszmarem z ulicy Wiązów.'
    ),
    (
        ('walter white', 'jesse pinkman', 'chemik', 'metamfetamina', 'narkotyki w kamperze', 'kamper narkotyki'),
        'Breaking Bad', '2008', 'tv',
        'Lokalna podpowiedź: Walter White / Jesse / chemik / kamper kojarzone z Breaking Bad.'
    ),
    (
        ('widze martwych ludzi', 'widzę martwych ludzi', 'i see dead people', 'dziecko widzi martwych'),
        'The Sixth Sense', '1999', 'movie',
        'Lokalna podpowiedź: dziecko widzące martwych ludzi kojarzone z Szóstym zmysłem.'
    ),
    (
        ('swiecaca walizka', 'świecąca walizka', 'walizka swieci', 'walizka świeci', 'pulp fiction'),
        'Pulp Fiction', '1994', 'movie',
        'Lokalna podpowiedź: świecąca walizka kojarzona z Pulp Fiction.'
    ),
    (
        ('gollum', 'sauron', 'frodo', 'jedyny pierscien', 'jedyny pierścień', 'hobbit pierscien'),
        'The Lord of the Rings: The Fellowship of the Ring', '2001', 'movie',
        'Lokalna podpowiedź: Gollum / Sauron / Jedyny Pierścień kojarzone z Władcą Pierścieni.'
    ),
]

_STOP_TITLES = set([
    'wikipedia', 'film', 'serial', 'movie', 'tv series', 'lista', 'list of',
    'imdb', 'fandom', 'wiki', 'cast', 'obsada', 'soundtrack'
])


class forgotTitle:
    def __init__(self):
        self.db_file = control.searchFile
        self.cache_ttl = 60 * 60 * 24 * 30
        self.agent_ttl = 60 * 60 * 24 * 14

    def _params(self):
        try:
            return dict(urllib.parse_qsl(sys.argv[2].replace('?', '')))
        except Exception:
            return {}

    def _fold(self, value):
        value = value or ''
        try:
            value = unicodedata.normalize('NFKD', value)
            value = ''.join(ch for ch in value if not unicodedata.combining(ch))
        except Exception:
            pass
        return value

    def _normalize(self, value):
        value = self._fold(value).strip().lower()
        value = re.sub(r'<[^>]+>', ' ', value)
        value = re.sub(r'[^a-z0-9ąćęłńóśżź \-:]', ' ', value, flags=re.IGNORECASE)
        return re.sub(r'\s+', ' ', value).strip()

    def _notify(self, message, error=False):
        try:
            control.infoDialog(message, icon='ERROR' if error else 'INFO', time=2500, sound=True)
        except Exception:
            pass

    def _connect(self):
        db_dir = os.path.dirname(self.db_file)
        if db_dir and not os.path.exists(db_dir):
            try:
                os.makedirs(db_dir, exist_ok=True)
            except Exception:
                pass
        con = database.connect(self.db_file)
        cur = con.cursor()
        cur.execute('CREATE TABLE IF NOT EXISTS forgot_title_history (ID Integer PRIMARY KEY AUTOINCREMENT, term TEXT)')
        cur.execute('CREATE TABLE IF NOT EXISTS forgot_title_cache (key TEXT PRIMARY KEY, query TEXT, language TEXT, created_at INTEGER, payload TEXT)')
        cur.execute('CREATE TABLE IF NOT EXISTS forgot_title_agent_cache (key TEXT PRIMARY KEY, query TEXT, created_at INTEGER, payload TEXT)')
        con.commit()
        return con, cur

    def _cache_key(self, query, language=''):
        import hashlib
        raw = '%s|%s' % (self._normalize(query), language or '')
        return hashlib.sha1(raw.encode('utf-8', 'ignore')).hexdigest()

    def _history_save(self, query):
        query = (query or '').strip()
        if not query:
            return
        con = cur = None
        try:
            con, cur = self._connect()
            cur.execute('DELETE FROM forgot_title_history WHERE term=?', (query,))
            cur.execute('INSERT INTO forgot_title_history VALUES (?,?)', (None, query))
            con.commit()
        except Exception as e:
            try:
                fflog('[forgot_title] historia save error: %s' % e, 1)
            except Exception:
                pass
        finally:
            try: cur.close()
            except Exception: pass
            try: con.close()
            except Exception: pass

    def _history_list(self, limit=25):
        con = cur = None
        rows = []
        try:
            con, cur = self._connect()
            cur.execute('SELECT term FROM forgot_title_history ORDER BY ID DESC LIMIT ?', (limit,))
            seen = set()
            for (term,) in cur.fetchall():
                if term not in seen:
                    seen.add(term)
                    rows.append(term)
        except Exception:
            pass
        finally:
            try: cur.close()
            except Exception: pass
            try: con.close()
            except Exception: pass
        return rows

    def _cache_get(self, query, language):
        con = cur = None
        try:
            con, cur = self._connect()
            cur.execute('SELECT created_at, payload FROM forgot_title_cache WHERE key=?', (self._cache_key(query, language),))
            row = cur.fetchone()
            if not row:
                return None
            created_at, payload = row
            if self.cache_ttl and int(time.time()) - int(created_at or 0) > self.cache_ttl:
                return None
            return json.loads(payload or '{}')
        except Exception:
            return None
        finally:
            try: cur.close()
            except Exception: pass
            try: con.close()
            except Exception: pass

    def _cache_set(self, query, language, payload):
        con = cur = None
        try:
            con, cur = self._connect()
            cur.execute(
                'INSERT OR REPLACE INTO forgot_title_cache (key, query, language, created_at, payload) VALUES (?,?,?,?,?)',
                (self._cache_key(query, language), query, language or '', int(time.time()), json.dumps(payload or {}, ensure_ascii=False)),
            )
            con.commit()
        except Exception as e:
            try:
                fflog('[forgot_title] cache save error: %s' % e, 1)
            except Exception:
                pass
        finally:
            try: cur.close()
            except Exception: pass
            try: con.close()
            except Exception: pass

    def _agent_cache_get(self, query):
        con = cur = None
        try:
            con, cur = self._connect()
            cur.execute('SELECT created_at, payload FROM forgot_title_agent_cache WHERE key=?', (self._cache_key(query, 'free-agent'),))
            row = cur.fetchone()
            if not row:
                return None
            created_at, payload = row
            if self.agent_ttl and int(time.time()) - int(created_at or 0) > self.agent_ttl:
                return None
            return json.loads(payload or '{}')
        except Exception:
            return None
        finally:
            try: cur.close()
            except Exception: pass
            try: con.close()
            except Exception: pass

    def _agent_cache_set(self, query, payload):
        con = cur = None
        try:
            con, cur = self._connect()
            cur.execute(
                'INSERT OR REPLACE INTO forgot_title_agent_cache (key, query, created_at, payload) VALUES (?,?,?,?)',
                (self._cache_key(query, 'free-agent'), query, int(time.time()), json.dumps(payload or {}, ensure_ascii=False)),
            )
            con.commit()
        except Exception as e:
            try:
                fflog('[forgot_title] agent cache save error: %s' % e, 1)
            except Exception:
                pass
        finally:
            try: cur.close()
            except Exception: pass
            try: con.close()
            except Exception: pass

    def _http_json(self, url, params, timeout=12):
        headers = {'User-Agent': 'FanVodPL-FreeTitleAgent/1.0'}
        try:
            response = requests.get(url, params=params, timeout=timeout, headers=headers)
            if response is None:
                return {}
            return response.json()
        except Exception as e:
            try:
                fflog('[forgot_title] free agent http error: %s' % e, 1)
            except Exception:
                pass
            return {}

    def _free_agent_search_once(self, query):
        # PROMPT_GUARD: darmowy agent może wykonać tylko mały pakiet zapytań pomocniczych i musi cache'ować wynik.
        cached = self._agent_cache_get(query)
        if cached is not None:
            return cached, True

        payload = {'query': query, 'ddg': {}, 'wiki_pl': [], 'wiki_en': []}
        agent_query = '%s film serial movie tv title' % query

        payload['ddg'] = self._http_json(
            'https://api.duckduckgo.com/',
            {'q': agent_query, 'format': 'json', 'no_redirect': '1', 'no_html': '1', 'skip_disambig': '0'}
        )

        payload['wiki_pl'] = self._http_json(
            'https://pl.wikipedia.org/w/api.php',
            {'action': 'opensearch', 'search': query, 'limit': '8', 'namespace': '0', 'format': 'json'}
        )

        payload['wiki_en'] = self._http_json(
            'https://en.wikipedia.org/w/api.php',
            {'action': 'opensearch', 'search': query, 'limit': '8', 'namespace': '0', 'format': 'json'}
        )

        self._agent_cache_set(query, payload)
        return payload, False

    def _tmdb_search_once(self, query):
        # PROMPT_GUARD: tutaj wolno wykonać maksymalnie 1 request TMDB na jedno wpisanie użytkownika.
        from resources.lib.indexers import movies
        movie_indexer = movies.movies()
        language = getattr(movie_indexer, 'lang', '') or 'pl'
        cached = self._cache_get(query, language)
        if cached is not None:
            return cached, True
        url = movie_indexer.tmdb_multi_search % urllib.quote_plus(query)
        try:
            response = requests.get(url, timeout=20)
            payload = response.json() if response is not None else {}
        except Exception as e:
            try:
                fflog('[forgot_title] TMDB error: %s' % e, 1)
            except Exception:
                pass
            payload = {}
        self._cache_set(query, language, payload)
        return payload, False

    def _title(self, item):
        return item.get('title') or item.get('name') or item.get('original_title') or item.get('original_name') or ''

    def _year(self, item):
        raw = item.get('release_date') or item.get('first_air_date') or ''
        m = re.search(r'\d{4}', raw)
        return m.group(0) if m else ''

    def _clean_term(self, value):
        value = (value or '').strip()
        value = re.sub(r'<[^>]+>', ' ', value)
        value = re.sub(r'\s+', ' ', value).strip()
        value = re.sub(r'\s+-\s+.*$', '', value).strip()
        value = re.sub(r'\s+\|\s+.*$', '', value).strip()
        value = re.sub(r'\s+–\s+.*$', '', value).strip()
        value = re.sub(r'\s*\((film|serial|movie|tv series|franchise|character|postać|seria)[^)]*\)\s*', ' ', value, flags=re.IGNORECASE).strip()
        value = re.sub(r'^(the movie|film|serial)\s+', '', value, flags=re.IGNORECASE).strip()
        return value[:90]

    def _term_from_text(self, text):
        text = self._clean_term(text)
        if not text:
            return ''
        pieces = re.split(r'\s+(?:is|was|to|jest|byl|była|było|są|are)\s+', text, maxsplit=1, flags=re.IGNORECASE)
        candidate = pieces[0] if pieces else text
        candidate = self._clean_term(candidate)
        words = candidate.split()
        if len(words) > 8:
            candidate = ' '.join(words[:8])
        return candidate

    def _add_term(self, terms, seen, value, source='agent'):
        term = self._clean_term(value)
        if not term:
            return
        key = self._normalize(term)
        if not key or key in seen or key in _STOP_TITLES:
            return
        if len(key) < 2 or len(term) > 90:
            return
        seen.add(key)
        terms.append({'term': term, 'source': source})

    def _walk_related_topics(self, node, out):
        if isinstance(node, list):
            for item in node:
                self._walk_related_topics(item, out)
        elif isinstance(node, dict):
            if node.get('Text'):
                out.append(node.get('Text') or '')
            if node.get('Name'):
                out.append(node.get('Name') or '')
            if node.get('Topics'):
                self._walk_related_topics(node.get('Topics') or [], out)

    def _agent_terms(self, query, payload):
        terms = []
        seen = set()

        for hint in self._local_hints(query):
            self._add_term(terms, seen, hint.get('title'), 'local')

        ddg = (payload or {}).get('ddg') or {}
        for key in ('Heading', 'AbstractSource', 'Answer', 'Definition'):
            self._add_term(terms, seen, self._term_from_text(ddg.get(key) or ''), 'duckduckgo')
        self._add_term(terms, seen, self._term_from_text(ddg.get('AbstractText') or ''), 'duckduckgo')
        related_texts = []
        self._walk_related_topics(ddg.get('RelatedTopics') or [], related_texts)
        for text in related_texts[:12]:
            self._add_term(terms, seen, self._term_from_text(text), 'duckduckgo')

        for wiki_key in ('wiki_pl', 'wiki_en'):
            wiki = (payload or {}).get(wiki_key) or []
            if isinstance(wiki, list) and len(wiki) > 1 and isinstance(wiki[1], list):
                for title in wiki[1][:8]:
                    self._add_term(terms, seen, title, wiki_key)

        if not terms:
            self._add_term(terms, seen, query, 'query')
        return terms[:15]

    def _choose_tmdb_query(self, query, payload):
        terms = self._agent_terms(query, payload)
        if terms:
            return terms[0].get('term') or query, terms[0].get('source') or 'agent', terms
        return query, 'query', []

    def _score(self, query, item, base=0):
        q = self._normalize(query)
        title = self._normalize(item.get('title'))
        overview = self._normalize(item.get('overview'))
        score = base
        if q and title == q:
            score += 120
        elif q and q in title:
            score += 85
        elif title and title in q:
            score += 55
        tokens = [t for t in re.split(r'\W+', q) if len(t) >= 3]
        score += min(30, sum(7 for t in tokens if t in title))
        score += min(25, sum(4 for t in tokens if t in overview))
        if q and q in overview:
            score += 45
        try:
            score += min(20, float(item.get('popularity') or 0) / 10.0)
        except Exception:
            pass
        if item.get('year'):
            score += 5
        return score

    def _local_hints(self, query):
        q = self._normalize(query)
        out = []
        for keys, title, year, media_type, overview in _LOCAL_HINTS:
            if any(self._normalize(k) in q for k in keys):
                out.append({
                    'id': 'local:%s:%s' % (media_type, title),
                    'media_type': media_type,
                    'title': title,
                    'year': year,
                    'overview': overview,
                    'popularity': 999,
                    'score': 300,
                    'agent_source': 'local'
                })
        return out

    def _add_candidate(self, out, seen, query, item, base=0):
        media_type = item.get('media_type')
        if media_type not in ('movie', 'tv'):
            return
        title = self._title(item)
        if not title:
            return
        year = item.get('year') or self._year(item)
        key = (media_type, str(item.get('id') or ''), title.lower(), year)
        if key in seen:
            return
        seen.add(key)
        cand = {
            'id': item.get('id') or '',
            'media_type': media_type,
            'title': title,
            'year': year,
            'overview': item.get('overview') or '',
            'popularity': item.get('popularity') or 0,
            'agent_source': item.get('agent_source') or 'tmdb'
        }
        cand['score'] = self._score(query, cand, base)
        out.append(cand)

    def _build_candidates(self, query, payload):
        out = []
        seen = set()
        for hint in self._local_hints(query):
            seen.add((hint.get('media_type'), hint.get('id'), hint.get('title', '').lower(), hint.get('year')))
            out.append(hint)
        for item in (payload or {}).get('results', []) or []:
            if item.get('media_type') in ('movie', 'tv'):
                self._add_candidate(out, seen, query, item, 25)
            elif item.get('media_type') == 'person':
                person = self._normalize(item.get('name') or '')
                q = self._normalize(query)
                bonus = 80 if q and (q in person or person in q) else 45
                for known in item.get('known_for', []) or []:
                    self._add_candidate(out, seen, query, known, bonus)
        out.sort(key=lambda x: (x.get('score') or 0, x.get('popularity') or 0), reverse=True)
        return out[:30]

    def search(self):
        nav = navigator.navigator()
        nav.addDirectoryItem('[LIGHT][B][Wpisz, co pamiętasz z filmu][/B][/LIGHT]', 'forgotTitleSearchnew', 'search.png', 'DefaultAddonsSearch.png')
        nav.addDirectoryItem('[LIGHT]Agent: lokalne podpowiedzi + DuckDuckGo + Wikipedia + TMDB[/LIGHT]', 'forgotTitleSearch', 'search.png', 'DefaultAddonsSearch.png')
        for term in self._history_list():
            nav.addDirectoryItem(term, 'forgotTitleSearchnew&query=%s' % urllib.quote_plus(term), 'search.png', 'DefaultAddonsSearch.png')
        nav.endDirectory(cacheToDisc=False, category=['', 'Szukaj / Nie pamiętam tytułu'])

    def search_new(self):
        params = self._params()
        query = (params.get('query') or '').strip()
        if not query:
            keyboard = control.keyboard('', 'Wpisz opis, postać, przedmiot, cytat albo znak szczególny')
            keyboard.doModal()
            query = keyboard.getText() if keyboard.isConfirmed() else ''
            query = query.strip() if query is not None else ''
            if not query or query == '..':
                try:
                    navigator.navigator().endDirectory()
                except Exception:
                    pass
                control.execute('Action(Back)')
                return
            self._history_save(query)
            nav = navigator.navigator()
            nav.addDirectoryItem('... agent szuka najbliższych tytułów ...', 'forgotTitleSearch', 'search.png')
            control.directory(int(sys.argv[1]), cacheToDisc=False)
            control.execute('Container.Update("%s?action=forgotTitleSearchnew&query=%s")' % (sys.argv[0], urllib.quote_plus(query)))
            return

        self._history_save(query)
        agent_payload, agent_from_cache = self._free_agent_search_once(query)
        tmdb_query, agent_source, agent_terms = self._choose_tmdb_query(query, agent_payload)
        payload, tmdb_from_cache = self._tmdb_search_once(tmdb_query)
        candidates = self._build_candidates(query, payload)

        nav = navigator.navigator()
        if not candidates:
            nav.addDirectoryItem('Brak propozycji dla: %s' % query, 'forgotTitleSearch', 'search.png', 'DefaultAddonsSearch.png')
            nav.addDirectoryItem('[LIGHT]Spróbuj dopisać: aktor, postać, miejsce, przedmiot albo cytat[/LIGHT]', 'forgotTitleSearchnew', 'search.png', 'DefaultAddonsSearch.png')
            nav.endDirectory(cacheToDisc=False, category=['', 'Nie pamiętam tytułu', query])
            return

        cache_note = []
        cache_note.append('agent-cache' if agent_from_cache else 'agent')
        cache_note.append('tmdb-cache' if tmdb_from_cache else 'tmdb')
        if tmdb_query != query:
            nav.addDirectoryItem('[LIGHT]Agent sprawdzał w TMDB: %s (%s)[/LIGHT]' % (tmdb_query, agent_source), 'forgotTitleSearch', 'search.png', 'DefaultAddonsSearch.png')

        for cand in candidates:
            media_type = cand.get('media_type') or ''
            title = cand.get('title') or ''
            year = cand.get('year') or ''
            typ = 'film' if media_type == 'movie' else 'serial'
            overview = (cand.get('overview') or '').strip().replace('\n', ' ')
            if len(overview) > 160:
                overview = overview[:157].rstrip() + '...'
            label = '%s%s — %s' % (title, ' (%s)' % year if year else '', typ)
            if overview:
                label += '[CR][LIGHT]%s[/LIGHT]' % overview
            query_url = 'forgotTitleSelect&media_type=%s&title=%s' % (urllib.quote_plus(media_type), urllib.quote_plus(title))
            if year:
                query_url += '&year=%s' % urllib.quote_plus(year)
            nav.addDirectoryItem(label, query_url, 'search.png', 'DefaultAddonsSearch.png')

        if agent_terms:
            hint = ', '.join([t.get('term') for t in agent_terms[:5] if t.get('term')])
            if hint:
                nav.addDirectoryItem('[LIGHT]Podpowiedzi agenta: %s[/LIGHT]' % hint, 'forgotTitleSearch', 'search.png', 'DefaultAddonsSearch.png')
        nav.endDirectory(cacheToDisc=False, category=['', 'Nie pamiętam tytułu', '%s (%s)' % (query, '+'.join(cache_note))])

    def select(self, params=None):
        params = params or self._params()
        media_type = (params.get('media_type') or '').strip()
        title = (params.get('title') or '').strip()
        year = (params.get('year') or '').strip()
        if not title or media_type not in ('movie', 'tv'):
            self._notify('Nie można uruchomić wyszukiwania: błędna propozycja', error=True)
            try:
                navigator.navigator().endDirectory()
            except Exception:
                pass
            control.execute('Action(Back)')
            return
        if media_type == 'movie':
            from resources.lib.indexers import movies
            return movies.movies().search_term(title, s_type='movie', year=year)
        from resources.lib.indexers import tvshows
        return tvshows.tvshows().search_term(title, year=year)
