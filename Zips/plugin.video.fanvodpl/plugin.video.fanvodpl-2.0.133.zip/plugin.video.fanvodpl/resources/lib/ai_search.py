"""
    FanVodPL — Wyszukiwanie AI (Wersja Refaktoryzowana - Asystent Google)
    Obsługiwane providery z natywnym web search: Gemini, OpenAI, Claude
"""

import json
import re
import xbmc
import xbmcgui
import xbmcplugin

from ptw.libraries import control
from ptw.libraries.log_utils import log as _unsafe_log

_AI_LAST_TOKEN_USAGE = None

_AI_SECRET_SETTING_IDS = (
    'ai_search.key.gemini',
    'ai_search.key.gemini2',
    'ai_search.key.gemini3',
    'ai_search.key.gemini4',
    'ai_search.key.gemini5',
    'ai_search.key.openai',
    'ai_search.key.claude',
    'ai_voice.gemini_key',
    'ai_voice.openai_key',
    'google_search.api_key',
    'tm.user',
    'tm.user_bearer',
    'fanart.tv.user',
    'fanart.tv.dev',
)

_LEGAL_RESEARCH_USER_AGENT = 'FanVodPL-Kodi/2.0 legal metadata search'
_AI_WEB_SEARCH_PROVIDERS = ('Gemini', 'OpenAI', 'Claude')
_AI_DEFAULT_PROVIDER = 'Gemini'
_AI_CANDIDATE_POSTER_CACHE = {}
_AI_CANDIDATE_PREVIEW_CACHE = {}
_AI_CANDIDATE_MEDIA_TYPE_CACHE = {}
_AI_REQUESTED_MEDIA_VERIFY_CACHE = {}
_AI_TOUCH_SCROLL_DEVICE = None
_AI_VOICE_REQUEST_SEQ = 0
_AI_VOICE_LAST_LIMIT_NOTICE = {}

# ---------------------------------------------------------------------------
# Prompt systemowy dla AI - Wbudowany (zastępuje pliki .txt)
# ---------------------------------------------------------------------------
_SYSTEM_PROMPT = (
    "Jesteś inteligentnym asystentem wyszukiwania filmów i seriali, działającym jak wyszukiwarka Google.\n"
    "Twoim głównym celem jest ustalić tytuł przez web search, ale zachowywać się logicznie: "
    "kandydaci są najpierw WEWNĘTRZNYMI hipotezami, a nie listą do pokazania użytkownikowi.\n\n"
    "ZASADY DZIAŁANIA (JAK GOOGLE):\n"
    "1. ANALIZA: Zrozum intencję. Oddziel faktyczne cechy filmu od domysłów użytkownika.\n"
    "2. KANDYDACI WEWNĘTRZNI: Użyj web search i zwróć 3-6 hipotez w polu 'candidates', ale jeśli są z różnych krajów, epok, dekad albo gatunków, ustaw 'hide_candidates': true.\n"
    "3. WYSZUKIWANIE: Zawsze korzystaj z dostępnych narzędzi (Google Search Grounding), by weryfikować nietypowe tropy z opisu użytkownika.\n"
    "4. PEWNOŚĆ: Zwróć `ready_to_confirm: true` TYLKO, gdy na 95%+ jesteś pewien tytułu dzięki wynikom z wyszukiwarki lub gdy użytkownik "
    "podał wystarczająco dużo precyzyjnych szczegółów.\n"
    "4B. KONKRETNY TROP: Jeśli użytkownik podał konkretny szczegół, nie potwierdzaj tytułu tylko po kraju/gatunku/dekadzie. "
    "Najpierw musi pasować ten szczegół albo bardzo podobny trop.\n"
    "4C. SAMA SCENA TO ZA MAŁO: jeśli opis ma tylko scenę, dopytaj o typ, lata produkcji/premiery, kraj/język, czas lub miejsce akcji, aktora albo postać. "
    "Jeśli użytkownik nie pamięta aktora, szukaj po kraju i dekadzie: znani aktorzy/filmy z tej epoki + opis sceny.\n"
    "5. PYTANIE: Jeśli pewność jest niższa niż 95% albo kandydaci są rozstrzeleni, 'next_question' ma pytać o NAJBARDZIEJ różnicujący brak, ale krótko: maks. 90 znaków.\n"
    "6. NIE ZAŚMIECAJ: Gdy 'hide_candidates': true, nie wypisuj tytułów kandydatów w assistant_message. Powiedz krótko, że masz kilka tropów i zapytaj o kraj, lata/dekadę, gatunek albo inny kluczowy szczegół.\n"
    "7. KOLEJNOŚĆ: W JSON najpierw wpisz candidates jako wewnętrzne hipotezy, potem assistant_message. assistant_message ma mieć maks. 110 znaków.\n"
    "8. GŁOS: Pole voice_text ma być naturalnym, mówionym zdaniem po polsku, maks. 80 znaków. Nie czytaj całej listy kandydatów.\n"
    "9. Odpowiadasz WYŁĄCZNIE w czystym formacie JSON bez tekstu wokół.\n"
    "10. KANDYDACI — ENGLISH_TITLE: dla każdego kandydata zagranicznego ZAWSZE podaj 'english_title' "
    "z oryginalnym lub angielskim tytułem (np. 'The Saint', 'The Persuaders!'). "
    "Bez tego pole plakat/opis TMDB może trafić na zły tytuł przez zbieżność polskich nazw.\n\n"
    "Dla filmu/serialu zagranicznego confirmation_title i search_query muszą być oryginalnym albo angielskim tytułem TMDB; polski tytuł wpisuj w pl_title.\n"
    "SCHEMAT JSON (BARDZO WAŻNE):\n"
    "{\n"
    "  \"candidates\": [{\"title\":\"...\",\"year\":\"...\",\"country\":\"... lub null\",\"genre\":\"... lub null\",\"english_title\":\"oryg./ang. tytuł lub null\",\"confidence\":0,\"reason\":\"jaki trop pasuje, maks. 90 znaków\"}],\n"
    "  \"hide_candidates\": true albo false,\n"
    "  \"assistant_message\": \"Krótka informacja lub wniosek dla użytkownika (po polsku)\",\n"
    "  \"voice_text\": \"Naturalna krótka wypowiedź do odczytania głosem albo null\",\n"
    "  \"next_question\": \"Jedno logiczne pytanie doprecyzowujące (lub null, jeśli masz pewny wynik)\",\n"
    "  \"ready_to_confirm\": true albo false,\n"
    "  \"confirmation_title\": \"Tytuł do potwierdzenia albo null\",\n"
    "  \"search_query\": \"Tytuł dla bazy TMDB albo null\",\n"
    "  \"english_title\": \"Angielski tytuł lub null\",\n"
    "  \"pl_title\": \"Polski tytuł lub null\",\n"
    "  \"original_title\": \"Oryginalny tytuł lub null\",\n"
    "  \"is_polish\": true albo false,\n"
    "  \"year\": \"Rok premiery lub null\",\n"
    "  \"type\": \"movie lub tv lub null\",\n"
    "  \"confidence\": 0-100,\n"
    "  \"matched_rare_clues\": [\"potwierdzone fakty z sieci\"],\n"
    "  \"missing_rare_clues\": [\"czego brakuje by mieć pewność\"],\n"
    "  \"evidence_score\": 0-100,\n"
    "  \"fallback_queries\": [\"fraza1\", \"fraza2\"]\n"
    "}\n"
)


def _legal_research_headers(accept='application/json'):
    return {
        'User-Agent': _LEGAL_RESEARCH_USER_AGENT,
        'Accept': accept,
    }


def _ai_secret_values():
    values = []
    try:
        for setting_id in _AI_SECRET_SETTING_IDS:
            value = (control.setting(setting_id) or '').strip()
            if value and value.lower() != 'true' and len(value) >= 8:
                values.append(value)
    except Exception:
        pass
    return values


def _redact_ai_secrets(value):
    text = str(value or '')
    try:
        for secret in _ai_secret_values():
            if secret:
                text = text.replace(secret, '[REDACTED_KEY]')
        patterns = [
            (r'([?&])(?:key|api_key|apiKey|access_token)=[^&\s\'")]+', r'\1[REDACTED_QUERY_SECRET]'),
            (r'((?:Authorization|authorization)[\'"]?\s*:\s*[\'"]?Bearer\s+)[A-Za-z0-9._\-]+', r'\1[REDACTED_KEY]'),
            (r'((?:x-api-key|X-API-Key|x-goog-api-key|X-Goog-Api-Key|api-key)[\'"]?\s*:\s*[\'"]?)[A-Za-z0-9._\-]+', r'\1[REDACTED_KEY]'),
            (r'([\'"](?:key|api_key|apiKey|access_token)[\'"]\s*:\s*[\'"])[^\'"]+', r'\1[REDACTED_KEY]'),
            (r'\bAIza[0-9A-Za-z_\-]{20,}\b', '[REDACTED_GEMINI_KEY]'),
            (r'\bsk-proj-[0-9A-Za-z_\-]{20,}\b', '[REDACTED_OPENAI_KEY]'),
            (r'\bsk-ant-[0-9A-Za-z_\-]{20,}\b', '[REDACTED_CLAUDE_KEY]'),
        ]
        for pattern, repl in patterns:
            text = re.sub(pattern, repl, text)
    except Exception:
        return '[REDACTED_LOG_ERROR]'
    return text


def _safe_exception_text(exc, limit=140):
    text = _redact_ai_secrets(str(exc))
    status = ''
    try:
        response = getattr(exc, 'response', None)
        status_code = getattr(response, 'status_code', None)
        if status_code:
            status = 'HTTP {}'.format(status_code)
    except Exception:
        status = ''
    if status and status not in text:
        text = '{} {}'.format(status, text)
    return text[:limit]


def log(message, level=0):
    try:
        return _unsafe_log(_redact_ai_secrets(message), level)
    except TypeError:
        return _unsafe_log(_redact_ai_secrets(message))


def _ai_is_android_phone_touch_device():
    global _AI_TOUCH_SCROLL_DEVICE
    if _AI_TOUCH_SCROLL_DEVICE is not None:
        return _AI_TOUCH_SCROLL_DEVICE

    _AI_TOUCH_SCROLL_DEVICE = False
    try:
        if not xbmc.getCondVisibility('System.Platform.Android'):
            return False
    except Exception:
        return False

    def _vis(expr):
        try:
            return bool(xbmc.getCondVisibility(expr))
        except Exception:
            return False

    def _getprop(name):
        try:
            import subprocess as _sp
            for cmd in (('/system/bin/getprop', name), ('getprop', name)):
                try:
                    return _sp.check_output(list(cmd), stderr=_sp.DEVNULL, timeout=1).decode('utf-8', errors='ignore').strip().lower()
                except Exception:
                    continue
        except Exception:
            pass
        return ''

    def _getprop_many(*names):
        for name in names:
            value = _getprop(name)
            if value:
                return value
        return ''

    blob = ''
    for path in ('/proc/cpuinfo', '/system/build.prop', '/vendor/build.prop', '/product/build.prop'):
        try:
            with open(path, 'r', errors='ignore') as handle:
                blob += '\n' + handle.read().lower()
        except Exception:
            pass

    board = _getprop_many('ro.board.platform', 'ro.hardware')
    characteristics = _getprop_many('ro.build.characteristics', 'ro.product.characteristics')
    manufacturer = _getprop_many('ro.product.manufacturer', 'ro.product.vendor.manufacturer')
    brand = _getprop_many('ro.product.brand', 'ro.product.vendor.brand')
    model = _getprop_many('ro.product.model', 'ro.product.vendor.model', 'ro.product.system.model')
    device = _getprop_many('ro.product.device', 'ro.product.vendor.device', 'ro.product.system.device')
    marketname = _getprop_many('ro.product.marketname', 'ro.product.vendor.marketname')
    density_raw = _getprop_many('ro.sf.lcd_density', 'qemu.sf.lcd_density', 'persist.sys.dpi')

    try:
        density = int(re.sub(r'[^0-9]', '', density_raw) or '0')
    except Exception:
        density = 0

    joined = ' '.join(x for x in (manufacturer, brand, model, device, marketname, characteristics, board, blob) if x)
    tv_tokens = (
        ' tv', 'android tv', 'google tv', ' bravia', 'chromecast', 'shield', 'mibox',
        'stb', 'settop', 'set-top', 'smarttv', 'smart-tv', 'aft', 'operator_tier'
    )
    characteristics_tv = any(token in characteristics for token in ('tv', 'atv', 'stb', 'box'))
    is_touch = any(_vis(expr) for expr in ('System.HasTouchInput', 'System.HasTouchScreen'))
    is_probably_tv = characteristics_tv or any(token in joined for token in tv_tokens) or _vis('System.Platform.AndroidTV')
    mobile_vendor_tokens = (
        'pixel', 'google', 'samsung', 'sm-', 'galaxy', 'xiaomi', 'redmi', 'poco', 'oneplus',
        'oppo', 'realme', 'vivo', 'motorola', 'moto', 'sony', 'xperia', 'huawei', 'honor',
        'nokia', 'asus', 'zenfone', 'nothing', 'lenovo', 'tablet', 'phone'
    )
    is_mobile_by_characteristics = any(x in characteristics for x in ('phone', 'tablet', 'nosdcard')) and not characteristics_tv
    is_mobile_by_vendor = any(token in joined for token in mobile_vendor_tokens) and not is_probably_tv
    is_mobile_by_density = density >= 260 and not is_probably_tv

    _AI_TOUCH_SCROLL_DEVICE = bool(not is_probably_tv and (is_touch or is_mobile_by_characteristics or is_mobile_by_vendor or is_mobile_by_density))
    try:
        log('[AI_SEARCH] touch scroll device={} touch={} tv={} density={} model={}'.format(
            _AI_TOUCH_SCROLL_DEVICE, is_touch, is_probably_tv, density, (model or '?')[:80]), 1)
    except Exception:
        pass
    return _AI_TOUCH_SCROLL_DEVICE


def _ai_android_platform():
    try:
        return bool(xbmc.getCondVisibility('System.Platform.Android'))
    except Exception:
        return False


def _ai_android_tv_platform():
    try:
        return bool(_ai_android_platform() and not _ai_is_android_phone_touch_device())
    except Exception:
        return bool(_ai_android_platform())


def _ai_candidate_view_mode_setting():
    # ZMIANA (2026-05) [PATCH]: czytaj nowe opisowe ustawienie _v2, z fallbackiem do starego id.
    # POWOD: Kodi potrafil cache'owac stary select KAFELKI/MOBILNA, wiec nowe id wymusza popup z pelnym opisem opcji.
    # NIE ZMIENIAC: fallback do ai_search.candidate_view_mode zachowuje kompatybilnosc ze starsza konfiguracja uzytkownika.
    raw = ''
    for setting_id in ('ai_search.candidate_view_mode_v2', 'ai_search.candidate_view_mode'):
        try:
            raw = (control.setting(setting_id) or '').strip().lower()
        except Exception:
            raw = ''
        if raw:
            break
    if raw in ('1', 'mobile') or raw.startswith('mobilna') or 'telefon' in raw or 'tablet' in raw:
        return 'mobile'
    return 'cards'


def _ai_candidate_mobile_forced():
    # ZMIANA (2026-05) [PATCH]: tryb MOBILNA dziala tylko na Androidzie; poza Androidem zawsze wraca do KAFELEK.
    # POWOD: zabezpiecza PC/Windows/Linux/Mac przed przypadkowym wlaczeniem mobilnej listy w ustawieniach dodatku.
    # NIE ZMIENIAC: PC i Android TV maja pozostac na starych kafelkach, chyba ze uzytkownik celowo testuje Android phone/tablet.
    return bool(_ai_candidate_view_mode_setting() == 'mobile' and _ai_android_platform())


def _ai_voice_setting(setting_id, default=''):
    try:
        value = (control.setting(setting_id) or '').strip()
    except Exception:
        value = ''
    return value if value else default


def _ai_voice_bool_setting(setting_id, default=False):
    try:
        value = (control.setting(setting_id) or '').strip().lower()
    except Exception:
        value = ''
    if not value:
        return bool(default)
    return value in ('true', '1', 'yes', 'tak', 'on', 'enabled')


def _ai_voice_enabled():
    return _ai_voice_bool_setting('ai_voice.enabled', False)


def _ai_voice_engine():
    # ZMIANA (2026-05) [PATCH]: nowe id _v2 dodaje GEMINI TTS i omija cache starego wyboru OPENAI/SYSTEM.
    # POWOD: użytkownik korzysta z Gemini; głos ma działać z tym samym kluczem Gemini, bez obowiązkowego OpenAI.
    # NIE ZMIENIAC: fallback do ai_voice.engine zachowuje kompatybilnosc ze starszym ZIP-em testowym.
    raw = ''
    for setting_id in ('ai_voice.engine_v2', 'ai_voice.engine'):
        try:
            raw = (control.setting(setting_id) or '').strip().lower()
        except Exception:
            raw = ''
        if raw:
            break
    if not raw:
        raw = 'gemini'
    if 'gemini' in raw:
        return 'gemini'
    if 'system' in raw or 'lokal' in raw:
        return 'system'
    return 'openai'


def _ai_voice_mode():
    raw = _ai_voice_setting('ai_voice.mode', 'KRÓTKO').lower()
    return 'full' if 'peł' in raw or 'pytanie' in raw else 'short'


def _ai_voice_fast_start_enabled():
    # ZMIANA (2026-05) [UX]: hardcoded True — zawsze szybki start; usunięte z ustawień.
    # POWOD: użytkownik nie powinien tego zmieniać; fast_start jest zawsze optymalny.
    # NIE ZMIENIAC: brak odczytu ustawienia — setting ai_voice.fast_start usunięty z settings.xml.
    return True


def _ai_voice_preview_enabled():
    # ZMIANA (2026-05) [FEATURE]: osobny przełącznik głosu dla przycisku Podgląd.
    # POWOD: użytkownik chce, żeby po kliknięciu Podgląd narrator przeczytał krótki opis filmu/serialu.
    # NIE ZMIENIAC: działa tylko gdy główny TTS jest włączony; nie zmienia wyszukiwania, TMDB ani kart kandydatów.
    return _ai_voice_bool_setting('ai_voice.preview_enabled', True)


def _ai_voice_preview_max_chars():
    # ZMIANA (2026-05) [BUGFIX]: zwiększono limit z 600 do 1200 — pokrywa długie opisy TMDB (np. Matrix).
    # POWOD: 600 znaków + ~40 znaków prefiksu "Podgląd. To film X z roku Y." = głos urywał się
    #        w połowie opisu dla filmów z długim opisem TMDB. 1200 pokrywa praktycznie wszystkie opisy.
    # NIE ZMIENIAC: ta funkcja jest używana przez _ai_voice_build_preview_text i _ai_voice_speak_async.
    return 1200


def _ai_voice_media_label(media_type):
    media_type = _ai_normalize_media_type(media_type)
    return u'serial' if media_type == 'tv' else u'film'


def _ai_voice_build_preview_intro_text(title, year='', media_type=''):
    title = u'{}'.format(title or '').strip()
    year = u'{}'.format(year or '').strip()
    if not title:
        return ''
    kind = _ai_voice_media_label(media_type)
    display_title = title + (u' z roku {}'.format(year) if re.match(r'^\d{4}$', year or '') else '')
    return _ai_voice_clean_text(
        u'Podglad. To {} {}. Wczytuje opis.'.format(kind, display_title),
        limit=140
    )


def _ai_voice_build_preview_text(title, year='', media_type='', overview=''):
    if not _ai_voice_enabled():
        return ''
    preview_full = _ai_voice_preview_enabled()
    if not preview_full and not _ai_android_tv_platform():
        return ''
    limit = _ai_voice_preview_max_chars()
    title = u'{}'.format(title or '').strip()
    year = u'{}'.format(year or '').strip()
    kind = _ai_voice_media_label(media_type)
    if not title:
        return ''
    display_title = title + (u' z roku {}'.format(year) if re.match(r'^\d{4}$', year or '') else '')
    if _ai_android_tv_platform() and not preview_full:
        return _ai_voice_clean_text(
            u'Podglad. To {} {}. Opis i zwiastun sa juz na ekranie.'.format(kind, display_title),
            limit=140
        )
    overview = _ai_voice_clean_text(overview or '', limit=max(60, limit - len(display_title) - 28))
    if overview:
        text = u'Podgląd. To {} {}. {}'.format(kind, display_title, overview)
    else:
        text = u'Podgląd. To {} {}. Nie mam opisu z TMDB, ale możesz sprawdzić kartę i zwiastun.'.format(kind, display_title)
    return _ai_voice_clean_text(text, limit=limit)


def _ai_voice_clean_text(text, limit=260):
    text = str(text or '')
    text = re.sub(r'\[(?:/?[A-Z]+|COLOR[^\]]*|/?LIGHT|/?B)\]', ' ', text, flags=re.I)
    text = re.sub(r'\bAI\s*:\s*', ' ', text, flags=re.I)
    text = re.sub(r'https?://\S+', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    if len(text) > limit:
        cut = text[:limit].rsplit(' ', 1)[0].strip()
        text = (cut or text[:limit]).rstrip(',. ;:') + '...'
    return text


def _ai_voice_build_text(ai_data, display_msg='', candidate_count=0):
    ai_data = ai_data or {}
    fast_start = _ai_voice_fast_start_enabled()
    voice_text = (ai_data.get('voice_text') or '').strip()
    if not voice_text:
        voice_text = display_msg or ai_data.get('assistant_message') or ai_data.get('next_question') or ''
        if candidate_count and not fast_start:
            voice_text = (voice_text + u' Pokazałem {} kandydatów w kartach.'.format(candidate_count)).strip()
        if _ai_voice_mode() == 'full' and ai_data.get('next_question') and not fast_start:
            question = str(ai_data.get('next_question') or '').strip()
            if question and question not in voice_text:
                voice_text = (voice_text + u' ' + question).strip()
    limit = 110 if fast_start else 260
    return _ai_voice_clean_text(voice_text, limit=limit)


def _ai_voice_temp_path(filename='fanvodpl_ai_voice.mp3'):
    try:
        import xbmcvfs
        base = xbmcvfs.translatePath('special://temp/')
    except Exception:
        try:
            base = xbmc.translatePath('special://temp/')
        except Exception:
            base = ''
    if not base:
        import tempfile as _tempfile
        base = _tempfile.gettempdir()
    try:
        import os as _os
        if not _os.path.isdir(base):
            _os.makedirs(base)
        return _os.path.join(base, filename)
    except Exception:
        return filename


def _ai_voice_cache_enabled():
    # ZMIANA (2026-05) [UX]: hardcoded True — cache zawsze włączony; setting usunięty z XML.
    # POWOD: cache nie powinien być wyłączany przez użytkownika; zawsze przyspiesza TTS.
    # NIE ZMIENIAC: brak odczytu ustawienia — ai_voice.cache_enabled usunięty z settings.xml.
    return True


def _ai_voice_cache_path(engine, text, model='', voice='', ext='wav'):
    if not _ai_voice_cache_enabled():
        return ''
    try:
        import hashlib as _hashlib
        safe_ext = re.sub(r'[^a-zA-Z0-9]', '', ext or 'wav') or 'wav'
        safe_engine = re.sub(r'[^a-zA-Z0-9_\-]', '_', engine or 'tts')[:24] or 'tts'
        raw = u'{}|{}|{}|{}'.format(engine or '', model or '', voice or '', _ai_voice_clean_text(text))
        digest = _hashlib.sha1(raw.encode('utf-8')).hexdigest()[:24]
        return _ai_voice_temp_path('fanvodpl_ai_voice_{}_{}.{}'.format(safe_engine, digest, safe_ext))
    except Exception as exc:
        log('[AI_VOICE] cache path error: {}'.format(_safe_exception_text(exc, 120)), 1)
        return ''


def _ai_voice_wait_file_ready(path, min_bytes=128, attempts=10, delay=0.08):
    try:
        import os as _os
        import time as _time
        last_size = -1
        for _idx in range(int(attempts or 1)):
            try:
                if _os.path.isfile(path):
                    size = _os.path.getsize(path)
                    if size > int(min_bytes or 0) and size == last_size:
                        return True
                    last_size = size
            except Exception:
                pass
            _time.sleep(float(delay or 0))
        try:
            return bool(_os.path.isfile(path) and _os.path.getsize(path) > int(min_bytes or 0))
        except Exception:
            return False
    except Exception:
        return True


def _ai_voice_mime_for_path(path):
    try:
        lower = (path or '').lower()
        if lower.endswith('.wav'):
            return 'audio/wav'
        if lower.endswith('.mp3'):
            return 'audio/mpeg'
        if lower.endswith('.m4a'):
            return 'audio/mp4'
    except Exception:
        pass
    return 'audio/*'


def _ai_voice_queue_file(path, label='TTS'):
    try:
        import json as _json
        payload = {
            'jsonrpc': '2.0',
            'id': 1,
            'method': 'Player.Open',
            'params': {'item': {'file': path}},
        }
        result = xbmc.executeJSONRPC(_json.dumps(payload))
        if result and '"error"' not in result.lower():
            log('[AI_VOICE] {} play queued via JSON-RPC file={}'.format(
                label, _redact_ai_secrets(path)), 1)
            return True
        log('[AI_VOICE] {} JSON-RPC play fallback result={}'.format(
            label, _redact_ai_secrets((result or '')[:180])), 1)
    except Exception as exc:
        log('[AI_VOICE] {} JSON-RPC play fallback: {}'.format(
            label, _safe_exception_text(exc, 120)), 1)
    try:
        media_path = (path or '').replace('\\', '/').replace('"', '\\"')
        xbmc.executebuiltin('PlayMedia("{}")'.format(media_path))
        log('[AI_VOICE] {} play queued via PlayMedia file={}'.format(
            label, _redact_ai_secrets(path)), 1)
        return True
    except Exception as exc:
        log('[AI_VOICE] {} PlayMedia failed: {}'.format(
            label, _safe_exception_text(exc, 120)), 1)
    return False


def _ai_voice_play_file(path, label='TTS'):
    if not path:
        return False
    if not _ai_voice_wait_file_ready(path):
        log('[AI_VOICE] {} play skipped: file not ready {}'.format(
            label, _redact_ai_secrets(path)), 1)
        return False
    # Android/Kodi can fail direct xbmc.Player().play() from a worker thread
    # for freshly generated WAV files; queue playback through Kodi instead.
    if _ai_android_platform():
        if _ai_voice_queue_file(path, label):
            return True
    try:
        item = None
        try:
            item = xbmcgui.ListItem(path=path)
            try:
                item.setMimeType(_ai_voice_mime_for_path(path))
            except Exception:
                pass
            try:
                item.setProperty('IsPlayable', 'true')
            except Exception:
                pass
        except Exception:
            item = None
        if item is not None:
            xbmc.Player().play(path, item)
        else:
            xbmc.Player().play(path)
        log('[AI_VOICE] {} play started direct file={}'.format(
            label, _redact_ai_secrets(path)), 1)
        return True
    except Exception as exc:
        log('[AI_VOICE] {} direct play failed: {}'.format(
            label, _safe_exception_text(exc, 120)), 1)
    return _ai_voice_queue_file(path, label)


def _ai_voice_play_cached(path, label='TTS', request_id=None, source='chat'):
    if not path:
        return False
    try:
        import os as _os
        if _os.path.isfile(path) and _os.path.getsize(path) > 128:
            if not _ai_voice_request_is_current(request_id):
                log('[AI_VOICE] {} cache hit skipped: outdated request'.format(label), 1)
                return True
            if _ai_voice_play_file(path, label):
                _ai_voice_notify_preview_full_start(source)
                log('[AI_VOICE] {} cache hit play queued file={}'.format(label, _redact_ai_secrets(path)), 1)
                return True
    except Exception as exc:
        log('[AI_VOICE] cache play skipped: {}'.format(_safe_exception_text(exc, 120)), 1)
    return False


def _ai_voice_notify_preview_full_start(source='chat'):
    if source != 'preview':
        return
    try:
        control.infoDialog(
            'Pelny opis glosowy jest gotowy. Uruchamiam czytanie.',
            heading='Glos AI',
            icon='INFO',
            time=2500,
            sound=False,
        )
        log('[AI_VOICE] preview full voice start notice shown', 1)
    except Exception as exc:
        log('[AI_VOICE] preview full voice start notice skipped: {}'.format(_safe_exception_text(exc, 120)), 1)


def _ai_voice_cleanup_cache(keep=30):
    if not _ai_voice_cache_enabled():
        return
    try:
        import glob as _glob
        import os as _os
        sample = _ai_voice_temp_path('fanvodpl_ai_voice_cache_probe.tmp')
        base = _os.path.dirname(sample) or '.'
        files = _glob.glob(_os.path.join(base, 'fanvodpl_ai_voice_*.*'))
        files = [f for f in files if _os.path.basename(f).startswith('fanvodpl_ai_voice_')]
        files.sort(key=lambda f: _os.path.getmtime(f), reverse=True)
        for old_path in files[int(keep or 30):]:
            try:
                _os.remove(old_path)
            except Exception:
                pass
    except Exception as exc:
        log('[AI_VOICE] cache cleanup skipped: {}'.format(_safe_exception_text(exc, 120)), 1)


def _ai_voice_fast_candidate_count(ai_data, limit=10):
    try:
        candidates = (ai_data or {}).get('candidates') or []
        return min(len(candidates), limit) if isinstance(candidates, list) else 0
    except Exception:
        return 0


def _ai_voice_gemini_model():
    # ZMIANA (2026-05) [UX]: hardcoded Flash — zawsze najszybszy darmowy model; setting usunięty z XML.
    # POWOD: Flash jest jedynym modelem bezpiecznym dla darmowych kluczy; Pro wymaga płatnego konta.
    # NIE ZMIENIAC: brak odczytu ustawienia — ai_voice.gemini_model usunięty z settings.xml.
    return 'gemini-2.5-flash-preview-tts'


def _ai_voice_gemini_voice():
    voice = _ai_voice_setting('ai_voice.gemini_voice', 'Kore').strip()
    allowed = (
        'Zephyr', 'Puck', 'Charon', 'Kore', 'Fenrir', 'Leda', 'Orus', 'Aoede',
        'Callirrhoe', 'Autonoe', 'Enceladus', 'Iapetus', 'Umbriel', 'Algieba',
        'Despina', 'Erinome', 'Algenib', 'Rasalgethi', 'Laomedeia', 'Achernar',
        'Alnilam', 'Schedar', 'Gacrux', 'Pulcherrima', 'Achird', 'Zubenelgenubi',
        'Vindemiatrix', 'Sadachbia', 'Sadaltager', 'Sulafat',
    )
    return voice if voice in allowed else 'Kore'


def _ai_voice_write_wav(path, pcm_bytes, channels=1, rate=24000, sample_width=2):
    import wave as _wave
    with _wave.open(path, 'wb') as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sample_width)
        wf.setframerate(rate)
        wf.writeframes(pcm_bytes)


def _ai_voice_extract_inline_audio(data):
    try:
        parts = (((data.get('candidates') or [{}])[0].get('content') or {}).get('parts') or [])
        for part in parts:
            if not isinstance(part, dict):
                continue
            inline = part.get('inlineData') or part.get('inline_data') or {}
            audio_b64 = inline.get('data') or ''
            if audio_b64:
                return audio_b64, (inline.get('mimeType') or inline.get('mime_type') or '')
    except Exception:
        pass
    return '', ''


def _ai_voice_gemini_all_keys():
    # ZMIANA (2026-05) [FEATURE]: osobna lista kluczy TTS Gemini (ai_voice.gemini_key1..8).
    # POWOD: klucze TTS maja osobne limity niz AI Search — uzytkownik moze wpisac dedykowane
    #        klucze tylko dla glosu zeby nie wyczerpywac kluczy wyszukiwania.
    # LOGIKA: najpierw klucze TTS (ai_voice.gemini_key1..8), potem fallback na klucze AI Search.
    #         Jesli uzytkownik nie wpisal zadnego klucza TTS — uzywa kluczy AI Search (stare zachowanie).
    # NIE ZMIENIAC: kolejnosc — TTS najpierw, AI Search jako fallback.
    tts_keys = []
    for setting_id in (
        'ai_voice.gemini_key',
        'ai_voice.gemini_key2',
        'ai_voice.gemini_key3',
        'ai_voice.gemini_key4',
        'ai_voice.gemini_key5',
        'ai_voice.gemini_key6',
        'ai_voice.gemini_key7',
        'ai_voice.gemini_key8',
    ):
        try:
            key = (control.setting(setting_id) or '').strip()
        except Exception:
            key = ''
        if key:
            tts_keys.append(key)
    if tts_keys:
        return tts_keys
    # Fallback — brak osobnych kluczy TTS → używamy kluczy AI Search
    return _gemini_all_keys()


def _ai_voice_gemini_call_with_rotation(payload, model, timeout=60, api_key=''):
    import requests as _req
    import time as _t
    # ZMIANA (2026-05) [FEATURE]: uzywamy _ai_voice_gemini_all_keys() zamiast _gemini_all_keys()
    # POWOD: TTS ma teraz osobne klucze (ai_voice.gemini_key1..8) z fallback na klucze AI Search.
    # ZMIANA (2026-05) [BUGFIX]: przy 500/502/503 rotuj klucz po 1 retry zamiast zawsze tego samego.
    # POWOD: log potwierdzal ze przy seryjnych 500 kod wieczyscie probowal tego samego klucza.
    keys = _ai_voice_gemini_all_keys()
    extra_key = (api_key or '').strip()
    if extra_key and extra_key not in keys:
        keys.insert(0, extra_key)
    if not keys:
        raise RuntimeError('Brak klucza Gemini do TTS')
    key = extra_key or keys[0]
    if key not in keys:
        key = keys[0]
    used = set()
    retried_transient = set()
    safe_model = re.sub(r'[^A-Za-z0-9._\-]', '', model or 'gemini-3.1-flash-tts-preview')
    url = 'https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent'.format(safe_model)
    while True:
        used.add(key)
        r = _req.post(
            url,
            headers={'Content-Type': 'application/json', 'x-goog-api-key': key},
            json=payload,
            timeout=timeout,
        )
        if _gemini_should_rotate_response(r):
            new_key = _gemini_rotate_key(key, used)
            if not new_key:
                status = getattr(r, 'status_code', '-')
                raise RuntimeError('Gemini TTS odrzucil zapytanie na wszystkich kluczach. Status HTTP: {}'.format(status))
            log('[AI_VOICE] Gemini TTS key rotation: status={} - probuje nastepny klucz'.format(
                getattr(r, 'status_code', '-')), 1)
            key = new_key
            _t.sleep(2)
            continue
        transient_status = int(getattr(r, 'status_code', 0) or 0)
        if transient_status in (500, 502, 503):
            if key not in retried_transient:
                # Pierwsza próba — retry tego samego klucza po 2s
                retried_transient.add(key)
                log('[AI_VOICE] Gemini TTS transient error status={} - retry klucza po 2s'.format(
                    transient_status), 1)
                _t.sleep(2)
                continue
            else:
                # Drugi błąd 500 na tym samym kluczu — rotuj na następny
                new_key = _gemini_rotate_key(key, used)
                if not new_key:
                    log('[AI_VOICE] Gemini TTS status={} na wszystkich kluczach'.format(
                        transient_status), 1)
                    r.raise_for_status()
                log('[AI_VOICE] Gemini TTS status={} - rotacja klucza po 2x retry'.format(
                    transient_status), 1)
                key = new_key
                _t.sleep(2)
                continue
        r.raise_for_status()
        return r


def _ai_voice_next_request_id():
    global _AI_VOICE_REQUEST_SEQ
    try:
        _AI_VOICE_REQUEST_SEQ += 1
        return _AI_VOICE_REQUEST_SEQ
    except Exception:
        _AI_VOICE_REQUEST_SEQ = 1
        return 1


def _ai_voice_request_is_current(request_id):
    if request_id is None:
        return True
    try:
        return int(request_id) == int(_AI_VOICE_REQUEST_SEQ)
    except Exception:
        return True


def _ai_voice_notify_limit_429(request_id=None, source='chat'):
    # Pokazuj komunikat tylko dla aktualnego glosu; prefetch/cache w tle nie moze spamowac UI.
    if not _ai_voice_request_is_current(request_id):
        return
    global _AI_VOICE_LAST_LIMIT_NOTICE
    source_key = 'preview' if source == 'preview' else 'chat'
    try:
        import time as _time
        now = _time.time()
        if not isinstance(_AI_VOICE_LAST_LIMIT_NOTICE, dict):
            _AI_VOICE_LAST_LIMIT_NOTICE = {}
        last = float(_AI_VOICE_LAST_LIMIT_NOTICE.get(source_key, 0) or 0)
        throttle_seconds = 15 if source_key == 'preview' else 45
        if now - last < throttle_seconds:
            log('[AI_VOICE] limit notice throttled source={} age={:.1f}s'.format(
                source_key, now - last), 1)
            return
        _AI_VOICE_LAST_LIMIT_NOTICE[source_key] = now
    except Exception:
        pass
    try:
        control.infoDialog(
            'Gemini TTS zwrocil limit 429 po sprawdzeniu wszystkich kluczy. Tekst AI dziala.',
            heading='Glos AI niedostepny',
            icon='WARNING',
            time=7000,
            sound=False,
        )
        log('[AI_VOICE] limit notice shown source={} status=429'.format(source_key), 1)
    except Exception as exc:
        log('[AI_VOICE] limit notice skipped: {}'.format(_safe_exception_text(exc, 120)), 1)


def _ai_voice_speak_gemini(text, request_id=None, source='chat'):
    # ZMIANA (2026-05) [FEATURE]: Gemini TTS jako natywny silnik głosu dla użytkowników Gemini.
    # POWOD: na Androidzie SYSTEM TTS jest pomijany, a OpenAI TTS wymaga osobnego klucza; Gemini TTS uzywa klucza Gemini.
    # NIE ZMIENIAC: wynik audio zapisujemy jako WAV w special://temp, bez dodatkowych bibliotek i bez ffmpeg.
    api_key = _ai_voice_setting('ai_voice.gemini_key')
    if not api_key and not _gemini_all_keys():
        log('[AI_VOICE] Gemini TTS skipped: missing ai_search.key.gemini / ai_voice.gemini_key', 1)
        return False
    model = _ai_voice_gemini_model()
    voice = _ai_voice_gemini_voice()
    cache_path = _ai_voice_cache_path('gemini', text, model, voice, 'wav')
    if _ai_voice_play_cached(cache_path, 'Gemini TTS', request_id, source):
        return True
    if _ai_voice_fast_start_enabled():
        # ZMIANA (2026-05) [BUGFIX]: usunięto "krótko" z promptu — powodowało że Gemini
        # przerywał czytanie długich opisów (np. Matrix: 849 znaków, czytało tylko ~743).
        # POWOD: słowo "krótko" instruuje Gemini do skracania tekstu; usunięcie powoduje
        #        że model czyta pełny tekst słowo po słowie. Potwierdzone logiem: pct=87.6%
        #        (Matrix) i pct=67.7% (chat) — oba poniżej 100% bo Gemini urywał wcześniej.
        # NIE ZMIENIAC: "naturalnie" zachowane — Gemini nadal czyta płynnie bez skakania.
        prompt = u'Przeczytaj po polsku naturalnie, słowo po słowie: {}'.format(text)
    else:
        prompt = (
            u'Mów po polsku naturalnie i spokojnie jak asystent. '
            u'Przeczytaj dokładnie ten tekst, słowo po słowie, bez pomijania i bez skracania:\n"{}"'
        ).format(text)
    payload = {
        'contents': [{'parts': [{'text': prompt}]}],
        'generationConfig': {
            'responseModalities': ['AUDIO'],
            'speechConfig': {
                'voiceConfig': {
                    'prebuiltVoiceConfig': {'voiceName': voice}
                }
            },
        },
        'model': model,
    }
    try:
        import base64 as _base64
        r = _ai_voice_gemini_call_with_rotation(payload, model, timeout=75, api_key=api_key)
        data = r.json()
        audio_b64, mime_type = _ai_voice_extract_inline_audio(data)
        if not audio_b64:
            raise RuntimeError('Gemini TTS nie zwrocil inlineData audio')
        audio_bytes = _base64.b64decode(audio_b64)
        out_path = cache_path or _ai_voice_temp_path('fanvodpl_ai_voice_gemini.wav')
        if 'wav' in (mime_type or '').lower():
            with open(out_path, 'wb') as handle:
                handle.write(audio_bytes)
        else:
            _ai_voice_write_wav(out_path, audio_bytes, channels=1, rate=24000, sample_width=2)
        if not _ai_voice_request_is_current(request_id):
            log('[AI_VOICE] Gemini TTS ready but skipped: outdated request', 1)
            return True
        if not _ai_voice_play_file(out_path, 'Gemini TTS'):
            return False
        _ai_voice_notify_preview_full_start(source)
        _ai_voice_cleanup_cache()
        log('[AI_VOICE] Gemini TTS played model={} voice={} chars={} mime={} cache={}'.format(
            model, voice, len(text), mime_type or 'pcm', 'yes' if cache_path else 'no'), 1)
        return True
    except Exception as exc:
        safe_exc = _safe_exception_text(exc, 180)
        log('[AI_VOICE] Gemini TTS error: {}'.format(safe_exc), 1)
        if '429' in safe_exc:
            _ai_voice_notify_limit_429(request_id, source)
        return False


def _ai_voice_speak_openai(text, request_id=None, source='chat'):
    api_key = _ai_voice_setting('ai_voice.openai_key') or _ai_voice_setting('ai_search.key.openai')
    if not api_key:
        log('[AI_VOICE] OpenAI TTS skipped: missing ai_search.key.openai / ai_voice.openai_key', 1)
        return False
    model = _ai_voice_setting('ai_voice.openai_model', 'gpt-4o-mini-tts')
    voice = _ai_voice_setting('ai_voice.openai_voice', 'coral')
    cache_path = _ai_voice_cache_path('openai', text, model, voice, 'mp3')
    if _ai_voice_play_cached(cache_path, 'OpenAI TTS', request_id, source):
        return True
    payload = {
        'model': model,
        'voice': voice,
        'input': text,
        'response_format': 'mp3',
    }
    if str(model).startswith('gpt-4o'):
        # ZMIANA (2026-05) [BUGFIX]: usunięto "krótko" — ta sama przyczyna co w Gemini TTS.
        # POWOD: "krótko" powoduje że OpenAI skraca długie opisy zamiast czytać w całości.
        # NIE ZMIENIAC: "naturalnie i spokojnie" zachowane — styl głosu bez zmian.
        payload['instructions'] = 'Mów po polsku naturalnie i spokojnie jak asystent. Czytaj dokładnie, słowo po słowie.'
    try:
        import requests as _req
        r = _req.post(
            'https://api.openai.com/v1/audio/speech',
            headers={'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'},
            json=payload,
            timeout=45,
        )
        r.raise_for_status()
        out_path = cache_path or _ai_voice_temp_path('fanvodpl_ai_voice.mp3')
        with open(out_path, 'wb') as handle:
            handle.write(r.content)
        if not _ai_voice_request_is_current(request_id):
            log('[AI_VOICE] OpenAI TTS ready but skipped: outdated request', 1)
            return True
        if not _ai_voice_play_file(out_path, 'OpenAI TTS'):
            return False
        _ai_voice_notify_preview_full_start(source)
        _ai_voice_cleanup_cache()
        log('[AI_VOICE] OpenAI TTS played model={} voice={} chars={} cache={}'.format(
            model, voice, len(text), 'yes' if cache_path else 'no'), 1)
        return True
    except Exception as exc:
        log('[AI_VOICE] OpenAI TTS error: {}'.format(_safe_exception_text(exc, 180)), 1)
        return False


def _ai_voice_speak_system(text, request_id=None):
    # ZMIANA (2026-05) [FEATURE]: lokalny TTS jest trybem awaryjnym PC; Android zwykle nie udostepnia prostego CLI TTS dla Kodi.
    # POWOD: wariant uniwersalny dla Android TV/telefon/PC to OPENAI TTS MP3; tryb SYSTEM nie moze powodowac crasha.
    if _ai_android_platform():
        log('[AI_VOICE] SYSTEM TTS skipped on Android; use OPENAI engine for Kodi Android/TV', 1)
        return False
    try:
        import subprocess as _sp
        import shutil as _shutil
        import sys as _sys
        kwargs = {}
        if hasattr(_sp, 'DEVNULL'):
            kwargs = {'stdout': _sp.DEVNULL, 'stderr': _sp.DEVNULL}
        if _sys.platform.startswith('win'):
            safe = text.replace("'", "''")
            script = "Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak('{}')".format(safe)
            _sp.Popen(['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', script], **kwargs)
            return True
        if _sys.platform == 'darwin' and _shutil.which('say'):
            _sp.Popen(['say', text], **kwargs)
            return True
        for cmd in ('spd-say', 'espeak', 'festival'):
            exe = _shutil.which(cmd)
            if not exe:
                continue
            if cmd == 'festival':
                _sp.Popen(['sh', '-c', 'printf %s "$1" | festival --tts', 'festival', text], **kwargs)
            else:
                _sp.Popen([exe, text], **kwargs)
            return True
    except Exception as exc:
        log('[AI_VOICE] SYSTEM TTS error: {}'.format(_safe_exception_text(exc, 160)), 1)
    return False


def _ai_voice_speak(text, request_id=None, limit=260, source='chat'):
    if not _ai_voice_enabled():
        return False
    # ZMIANA (2026-05) [BUGFIX]: limit przekazywany z _ai_voice_speak_async — nie hardcode 260.
    # POWOD: poprzednio _ai_voice_speak_async ustawiał limit=600 dla preview, ale wątek wywoływał
    #        _ai_voice_clean_text(text) z domyślnym limit=260, ucinając tekst po raz drugi.
    #        Log potwierdzał: queued chars=542 → played chars=255 (ucinanie w tym miejscu).
    # NIE ZMIENIAC: dla czatu limit=260 pozostaje; dla preview limit=600 przekazywany z async.
    text = _ai_voice_clean_text(text, limit=limit)
    if not text:
        return False
    engine = _ai_voice_engine()
    if engine == 'gemini':
        return _ai_voice_speak_gemini(text, request_id, source)
    if engine == 'system':
        ok = _ai_voice_speak_system(text, request_id)
        if ok:
            return True
        if _ai_voice_speak_gemini(text, request_id, source):
            return True
    return _ai_voice_speak_openai(text, request_id, source)


def _ai_voice_speak_async(text, source='chat'):
    if not _ai_voice_enabled():
        return
    # ZMIANA (2026-05) [BUGFIX]: limit 1200 dla źródła 'preview' — pełny opis bez ucinania.
    # POWOD: 600 znaków nie wystarczało dla długich opisów TMDB (np. Matrix); zwiększono do 1200.
    # NIE ZMIENIAC: dla czatu (source='chat') limit 260 pozostaje — krótkie komunikaty AI.
    limit = 1200 if source == 'preview' else 260
    text = _ai_voice_clean_text(text, limit=limit)
    if not text:
        return
    try:
        import threading as _threading
        request_id = _ai_voice_next_request_id()
        thread = _threading.Thread(target=_ai_voice_speak, args=(text, request_id, limit, source or 'chat'))
        thread.daemon = True
        thread.start()
        log('[AI_VOICE] async queued source={} request={} engine={} chars={} fast_start={}'.format(
            source or 'chat', request_id, _ai_voice_engine(), len(text), _ai_voice_fast_start_enabled()), 1)
    except Exception as exc:
        log('[AI_VOICE] async start error: {}'.format(_safe_exception_text(exc, 160)), 1)


def _ai_token_int(value):
    try:
        if value is None:
            return 0
        return int(value)
    except Exception:
        return 0


def _set_last_ai_token_usage(provider, model='', input_tokens=None, output_tokens=None, total_tokens=None):
    global _AI_LAST_TOKEN_USAGE
    inp = _ai_token_int(input_tokens)
    out = _ai_token_int(output_tokens)
    total = _ai_token_int(total_tokens) or (inp + out)
    _AI_LAST_TOKEN_USAGE = {
        'provider': provider or '',
        'model': model or '',
        'input': inp,
        'output': out,
        'total': total,
    }
    try:
        log('[AI_SEARCH] token usage provider={} model={} input={} output={} total={}'.format(
            provider or '-', model or '-', inp, out, total), 1)
    except Exception:
        pass


def _pop_last_ai_token_usage():
    global _AI_LAST_TOKEN_USAGE
    usage = _AI_LAST_TOKEN_USAGE
    _AI_LAST_TOKEN_USAGE = None
    return usage or {}


_GEMINI_KEY_IDX = 0


def _gemini_all_keys():
    keys = []
    for setting_id in (
        'ai_search.key.gemini',
        'ai_search.key.gemini2',
        'ai_search.key.gemini3',
        'ai_search.key.gemini4',
        'ai_search.key.gemini5',
        'ai_search.key.gemini6',
        'ai_search.key.gemini7',
        'ai_search.key.gemini8',
    ):
        try:
            key = (control.setting(setting_id) or '').strip()
        except Exception:
            key = ''
        if key:
            keys.append(key)
    return keys


def _gemini_current_key():
    keys = _gemini_all_keys()
    if not keys:
        return ''
    idx = max(0, min(_GEMINI_KEY_IDX, len(keys) - 1))
    return keys[idx]


def _gemini_rotate_key(current_key='', tried_keys=None):
    global _GEMINI_KEY_IDX
    keys = _gemini_all_keys()
    if len(keys) <= 1:
        log('[AI_SEARCH] Gemini key rotation: tylko 1 klucz skonfigurowany - brak rotacji', 1)
        return ''
    tried = set(tried_keys or [])
    try:
        current_idx = keys.index(current_key) if current_key in keys else _GEMINI_KEY_IDX
    except Exception:
        current_idx = _GEMINI_KEY_IDX
    for step in range(1, len(keys) + 1):
        next_idx = (current_idx + step) % len(keys)
        next_key = keys[next_idx]
        if next_key in tried:
            continue
        _GEMINI_KEY_IDX = next_idx
        log('[AI_SEARCH] Gemini key rotation: klucz {} -> klucz {} (z {} dostepnych)'.format(
            current_idx + 1, next_idx + 1, len(keys)), 1)
        return next_key
    log('[AI_SEARCH] Gemini key rotation: wszystkie skonfigurowane klucze juz sprawdzone', 1)
    return ''


def _gemini_response_text(response, limit=800):
    try:
        return (getattr(response, 'text', '') or '')[:limit].lower()
    except Exception:
        return ''


def _gemini_should_rotate_response(response):
    try:
        status = int(getattr(response, 'status_code', 0) or 0)
    except Exception:
        status = 0
    if status == 429:
        return True
    if status not in (400, 401, 403):
        return False
    body = _gemini_response_text(response)
    key_error_tokens = (
        'api key not valid',
        'api_key_invalid',
        'api key expired',
        'permission denied',
        'permission_denied',
        'quota',
        'rate limit',
        'resource_exhausted',
        'resource exhausted',
        'user rate limit',
        'requests per minute',
        'api has not been used',
        'api not enabled',
        'service_disabled',
        'billing',
    )
    return any(token in body for token in key_error_tokens)


def _gemini_call_with_rotation(payload, timeout=20, api_key='', status_callback=None):
    import requests as _req
    import time as _t
    keys = _gemini_all_keys()
    extra_key = (api_key or '').strip()
    if extra_key and extra_key not in keys:
        keys.insert(0, extra_key)
    if not keys:
        raise RuntimeError('Brak klucza Gemini')
    key = _gemini_current_key() or extra_key or keys[0]
    if key not in keys:
        key = keys[0]
    used = set()
    url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent'
    while True:
        used.add(key)
        r = _req.post(
            url,
            headers={'Content-Type': 'application/json', 'x-goog-api-key': key},
            json=payload,
            timeout=timeout,
        )
        if _gemini_should_rotate_response(r):
            new_key = _gemini_rotate_key(key, used)
            if not new_key:
                status = getattr(r, 'status_code', '-')
                if status == 429:
                    raise RuntimeError(
                        'Wszystkie skonfigurowane klucze Gemini sa teraz w limicie 429. '
                        'Odczekaj chwile albo wybierz innego providera AI.'
                    )
                raise RuntimeError(
                    'Gemini odrzucil zapytanie na wszystkich kluczach. Status HTTP: {}'.format(status)
                )
            log('[AI_SEARCH] Gemini key rotation: status={} - probuje nastepny klucz'.format(
                getattr(r, 'status_code', '-')), 1)
            if status_callback:
                try:
                    keys_now = _gemini_all_keys()
                    key_no = keys_now.index(new_key) + 1 if new_key in keys_now else len(used) + 1
                    status_callback(u'AI: Gemini ma limit/blokade na kluczu. Probuje klucz {}/{}...'.format(
                        key_no, max(len(keys_now), key_no)))
                except Exception:
                    pass
            key = new_key
            _t.sleep(2)
            continue
        # ZMIANA: 500/502/503 to bledy przejsciowe po stronie Google - retry ten sam klucz 1x
        # POWOD: nie sa wina klucza, rotacja klucza nic nie da; krotki sleep + retry rozwiazuje wiekszosc przypadkow
        # NIE ZMIENIAC: logika 429 i rotacji kluczy powyzej pozostaje bez zmian
        transient_status = int(getattr(r, 'status_code', 0) or 0)
        if transient_status in (500, 502, 503) and key not in (used - {key}):
            log('[AI_SEARCH] Gemini transient error status={} - retry tego samego klucza po 3s'.format(
                transient_status), 1)
            if status_callback:
                try:
                    status_callback(u'AI: Gemini chwilowy blad serwera ({}), ponawiam...'.format(transient_status))
                except Exception:
                    pass
            _t.sleep(3)
            continue
        r.raise_for_status()
        return r


def _normalize_ai_provider(provider, log_change=False):
    raw = (provider or '').strip()
    aliases = dict((p.lower(), p) for p in _AI_WEB_SEARCH_PROVIDERS)
    normalized = aliases.get(raw.lower())
    if normalized:
        return normalized
    if log_change and raw:
        log('[AI_SEARCH] provider {} disabled: native web_search required; fallback={}'.format(
            raw, _AI_DEFAULT_PROVIDER), 1)
    return _AI_DEFAULT_PROVIDER


# ---------------------------------------------------------------------------
# API Callers
# ---------------------------------------------------------------------------
def _gemini_text_from_data(data):
    parts = (((data.get('candidates') or [{}])[0].get('content') or {}).get('parts') or [])
    return ''.join(p.get('text', '') for p in parts if isinstance(p, dict)).strip()


def _gemini_response_needs_json_repair(text):
    try:
        parsed = _parse_response(text)
    except Exception:
        return True
    if not isinstance(parsed, dict) or not parsed:
        return True
    if parsed.get('confirmation_title') or parsed.get('search_query') or parsed.get('next_question'):
        return False
    candidates = parsed.get('candidates') or []
    if isinstance(candidates, list) and candidates:
        return False
    msg = _ai_fold_text(parsed.get('assistant_message') or '')
    return 'kandydat' in msg and ('ponizej' in msg or 'przedstawiam' in msg or 'znalazlem' in msg)


def _gemini_repair_json_response(api_key, raw_text):
    raw_text = (raw_text or '').strip()
    if not raw_text or not _gemini_response_needs_json_repair(raw_text):
        return raw_text, {}

    repair_prompt = (
        u'Przepisz poniższą odpowiedź do poprawnego JSON zgodnego ze schematem systemowym. '
        u'Nie dodawaj tekstu poza JSON. Nie wymyślaj nowych faktów, tylko przenieś tytuły, '
        u'kandydatów, pewność i pytanie z odpowiedzi. Jeśli lista kandydatów jest ucięta i nie ma '
        u'żadnego tytułu, zwróć krótki JSON z assistant_message wyjaśniającym błąd techniczny.\n\n'
        u'ODPOWIEDŹ DO NAPRAWY:\n' + raw_text[:5000]
    )
    try:
        r = _gemini_call_with_rotation({
            'contents': [{'parts': [{'text': repair_prompt}]}],
            'systemInstruction': {'parts': [{'text': _SYSTEM_PROMPT}]},
            'generationConfig': {
                'maxOutputTokens': 1600,
                'temperature': 0.0,
                'responseMimeType': 'application/json',
            },
        }, timeout=45, api_key=api_key)
        data = r.json()
        fixed = _gemini_text_from_data(data)
        if fixed and not _gemini_response_needs_json_repair(fixed):
            log('[AI_SEARCH] Gemini JSON repair used', 1)
            return fixed, data.get('usageMetadata') or {}
        log('[AI_SEARCH] Gemini JSON repair returned weak JSON raw_preview={}'.format(
            _redact_ai_secrets((fixed or '')[:300])), 1)
    except Exception as exc:
        log('[AI_SEARCH] Gemini JSON repair skipped: {}'.format(_safe_exception_text(exc, 120)), 1)
    return raw_text, {}


def _ai_is_timeout_or_network_error(exc):
    text = str(exc or '').lower()
    return (
        'timed out' in text or
        'timeout' in text or
        'read timed' in text or
        'connection aborted' in text or
        'connection reset' in text or
        'connection error' in text or
        'max retries exceeded' in text or
        'temporarily unavailable' in text
    )


def _call_gemini(api_key, query, status_callback=None):
    model = 'gemini-2.5-flash'
    payload = {
        'contents': [{'parts': [{'text': query}]}],
        'tools': [{'google_search': {}}],
        'systemInstruction': {'parts': [{'text': _SYSTEM_PROMPT}]},
        'generationConfig': {'maxOutputTokens': 4096, 'temperature': 0.1},
    }
    last_exc = None
    for attempt in (1, 2):
        try:
            r = _gemini_call_with_rotation(
                payload,
                timeout=75,
                api_key=api_key,
                status_callback=status_callback,
            )
            break
        except Exception as exc:
            last_exc = exc
            if attempt == 1 and _ai_is_timeout_or_network_error(exc):
                log('[AI_SEARCH] Gemini timeout/network retry 1/1: {}'.format(
                    _safe_exception_text(exc, 120)), 1)
                if status_callback:
                    try:
                        status_callback(u'AI: Gemini odpowiada wolno, ponawiam próbę...')
                    except Exception:
                        pass
                continue
            raise
    else:
        raise last_exc
    data = r.json()
    usage = data.get('usageMetadata') or {}
    try:
        cand0 = (data.get('candidates') or [{}])[0]
        finish = cand0.get('finishReason') or ''
        thoughts = usage.get('thoughtsTokenCount') or usage.get('thoughtTokenCount') or 0
        log('[AI_SEARCH] Gemini response finishReason={} thoughts={} parts={}'.format(
            finish or '-', thoughts, len(((cand0.get('content') or {}).get('parts') or []))), 1)
    except Exception:
        pass
    text = _gemini_text_from_data(data)
    text, repair_usage = _gemini_repair_json_response(api_key, text)
    _set_last_ai_token_usage(
        'Gemini',
        model,
        input_tokens=_ai_token_int(usage.get('promptTokenCount')) + _ai_token_int(repair_usage.get('promptTokenCount')),
        output_tokens=_ai_token_int(usage.get('candidatesTokenCount')) + _ai_token_int(repair_usage.get('candidatesTokenCount')),
        total_tokens=_ai_token_int(usage.get('totalTokenCount')) + _ai_token_int(repair_usage.get('totalTokenCount')),
    )
    return text


def _call_claude(api_key, query):
    import requests
    model = 'claude-sonnet-4-6'
    headers = {
        'x-api-key': api_key,
        'anthropic-version': '2023-06-01',
        'Content-Type': 'application/json',
    }
    payload = {
        'model': model,
        'max_tokens': 2500,
        'system': _SYSTEM_PROMPT,
        'messages': [{'role': 'user', 'content': query}],
        # ZMIANA (2026-05) [PATCH]: max_uses 3 -> 5 dla wariantow jezykowych.
        # POWOD: System prompt w _build_mini_chat_prompt prosi 2-3 warianty jezykowe per zapytanie
        #        (polski + angielski/originalny). Limit 3 wyczerpywal sie szybko przy iteracyjnym dopytywaniu.
        # NIE ZMIENIAC: 5 to bezpieczny gorny pulap — Anthropic nalicza za kazde wyszukanie, wiec wyzej = drozej.
        'tools': [{'type': 'web_search_20250305', 'name': 'web_search', 'max_uses': 5}],
    }
    last_exc = None
    for attempt in (1, 2):
        try:
            r = requests.post(
                'https://api.anthropic.com/v1/messages',
                headers=headers,
                json=payload,
                timeout=35,
            )
            r.raise_for_status()
            break
        except Exception as exc:
            last_exc = exc
            if attempt == 1 and _ai_is_timeout_or_network_error(exc):
                log('[AI_SEARCH] Claude timeout/network retry 1/1: {}'.format(
                    _safe_exception_text(exc, 120)), 1)
                continue
            raise
    else:
        raise last_exc
    data = r.json()
    usage = data.get('usage') or {}
    _set_last_ai_token_usage(
        'Claude',
        model,
        input_tokens=usage.get('input_tokens'),
        output_tokens=usage.get('output_tokens'),
    )
    out = []
    for block in data.get('content') or []:
        if isinstance(block, dict) and block.get('type') == 'text':
            out.append(block.get('text') or '')
    return ''.join(out).strip()


# ZMIANA (2026-05) [PATCH]: OpenAI przepięty na gpt-4o-search-preview z web_search_options dla natywnego web search.
# POWOD: Poprzedni model 'gpt-4o' przez /v1/chat/completions NIE MA wbudowanego web search, mimo ze plik
#        deklarowal OpenAI w _AI_WEB_SEARCH_PROVIDERS i system prompt obiecywal "Google Search Grounding".
#        Skutek: dla uzytkownikow z providerem OpenAI bot halucynowal tytuly z training data zamiast szukac w internecie.
# NIE ZMIENIAC:
# 1) gpt-4o-search-preview NIE WSPIERA response_format, temperature, top_p, frequency_penalty, presence_penalty, n
#    — usuniete celowo. Wymuszanie JSON-a odbywa sie wylacznie przez system prompt + parser _parse_response
#    (ktory ma fallback markdown strip + relaxed JSON + regex). Nie wolno dodawac z powrotem response_format,
#    bo API zwroci 400 Bad Request.
# 2) web_search_options={} jest WYMAGANE — bez tego klucza model wraca do trybu bez search.
#    Pusta wartosc dict to "default search behaviour" wg dokumentacji OpenAI.
# 3) Endpoint zostaje /v1/chat/completions — search-preview to model chat, nie Responses API.
def _call_openai(api_key, query):
    import requests
    model = 'gpt-4o-search-preview'
    payload = {
        'model': model,
        'web_search_options': {},
        'messages': [
            {'role': 'system', 'content': _SYSTEM_PROMPT},
            {'role': 'user', 'content': query + u'\n\nWAZNE: Zwroc WYLACZNIE czysty JSON wg schematu. Bez markdown, bez ```json, bez preambuly tekstowej, bez URL-i w polach tytulu.'},
        ],
        'max_tokens': 1400,
    }
    last_exc = None
    for attempt in (1, 2):
        try:
            r = requests.post(
                'https://api.openai.com/v1/chat/completions',
                headers={'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'},
                json=payload,
                timeout=45,
            )
            r.raise_for_status()
            break
        except Exception as exc:
            last_exc = exc
            if attempt == 1 and _ai_is_timeout_or_network_error(exc):
                log('[AI_SEARCH] OpenAI timeout/network retry 1/1: {}'.format(
                    _safe_exception_text(exc, 120)), 1)
                continue
            raise
    else:
        raise last_exc
    data = r.json()
    usage = data.get('usage') or {}
    _set_last_ai_token_usage(
        'OpenAI',
        model,
        input_tokens=usage.get('prompt_tokens'),
        output_tokens=usage.get('completion_tokens'),
        total_tokens=usage.get('total_tokens'),
    )
    return data['choices'][0]['message']['content']


_CALLERS = {
    'Gemini':  _call_gemini,
    'OpenAI':  _call_openai,
    'Claude':  _call_claude,
}

# ---------------------------------------------------------------------------
# Parser odpowiedzi JSON od AI
# ---------------------------------------------------------------------------
def _extract_candidates_from_text(text, limit=10):
    text = text or ''
    candidates = []
    seen = set()

    def _add_candidate(title, year='', confidence=0, reason='', media_type=''):
        title = (title or '').strip().strip('"').strip("'")
        year = (year or '').strip()
        reason = (reason or '').strip()
        if not title or len(title) < 2:
            return
        key = title.lower()
        if key in seen:
            return
        seen.add(key)
        item = {'title': title}
        if year:
            item['year'] = year
        if confidence:
            item['confidence'] = confidence
        if reason:
            item['reason'] = reason[:220]
        # ZMIANA (2026-05) [PATCH]: regex-fallback parser wyciaga teraz media_type per kandydata.
        # POWOD: Przy popsutym JSON-ie (np. Gemini ucina output) kod schodzil do regex-fallback i tracil
        #        kandydatowy type. Pozniej _ai_apply_requested_media_type lub default 'movie' zgadywal zle.
        # NIE ZMIENIAC: _ai_normalize_media_type kanonizuje rozne formy (movie/film/movies, tv/show/series).
        if media_type:
            normalized = _ai_normalize_media_type(media_type)
            if normalized:
                item['type'] = normalized
                item['media_type'] = normalized
        candidates.append(item)

    for match in re.finditer(r'"title"\s*:\s*"([^"]+)"', text, re.S | re.I):
        chunk = text[match.start():match.start() + 700]
        year = ''
        confidence = 0
        reason = ''
        media_type = ''
        m_year = re.search(r'"year"\s*:\s*"?(19\d{2}|20\d{2})"?', chunk, re.I)
        if m_year:
            year = m_year.group(1)
        m_conf = re.search(r'"confidence"\s*:\s*(\d+)', chunk, re.I)
        if m_conf:
            try:
                confidence = int(m_conf.group(1))
            except Exception:
                confidence = 0
        m_reason = re.search(r'"reason"\s*:\s*"([^"]+)"', chunk, re.S | re.I)
        if m_reason:
            reason = re.sub(r'\s+', ' ', m_reason.group(1))
        # ZMIANA (2026-05) [PATCH]: dociagamy media_type/type per kandydata z regex-fallback.
        # POWOD: P3 z planu naprawczego — bez tego pole bylo tracone przy popsutym JSON.
        # NIE ZMIENIAC: kolejnosc kluczy "media_type" przed "type" — bardziej specyficzny pierwszy.
        m_type = re.search(r'"(?:media_type|type)"\s*:\s*"([^"]+)"', chunk, re.I)
        if m_type:
            media_type = m_type.group(1)
        _add_candidate(match.group(1), year, confidence, reason, media_type)
        if len(candidates) >= limit:
            return candidates

    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        match = re.match(
            r'^(?:\d{1,2}[\).\-\s]+|[-*]\s+)(?:"([^"]+)"|([^(\-–:]{3,90}))\s*(?:\((19\d{2}|20\d{2})\))?\s*(?:[-–:]\s*(.+))?$',
            line,
            re.I,
        )
        if not match:
            continue
        title = match.group(1) or match.group(2) or ''
        reason = match.group(4) or ''
        _add_candidate(title, match.group(3) or '', 0, reason)
        if len(candidates) >= limit:
            break

    return candidates


def _parse_response(text):
    text = (text or '').strip()
    if not text:
        return {}

    # ZMIANA (2026-05) [PATCH]: Naprawiono uszkodzony regex wycinający JSON z bloku markdown.
    # POWOD: Poprzedni fragment `re.search(r'...` był niedomknięty i powodował SyntaxError.
    # NIE ZMIENIAC: Parser ma nadal przyjmować czysty JSON oraz JSON opakowany w ```json ... ```.
    m = re.search(r'```(?:json)?\s*(.*?)\s*```', text, re.S | re.I)
    if m:
        text = m.group(1).strip()

    try:
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        pass

    # Gemini czasem zwraca prawie poprawny JSON, np. z tekstem przed blokiem
    # albo przecinkiem po ostatnim elemencie. Spróbuj naprawić takie drobiazgi,
    # zanim przejdziemy do bardzo ubogiego parsera ratunkowego.
    relaxed_text = text
    object_match = re.search(r'\{.*\}', relaxed_text, re.S)
    if object_match:
        relaxed_text = object_match.group(0).strip()
    relaxed_text = re.sub(r',\s*([}\]])', r'\1', relaxed_text)
    if relaxed_text != text:
        try:
            parsed = json.loads(relaxed_text)
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            pass

    recovered_candidates = _extract_candidates_from_text(text)

    # Ratunkowe parsowanie, jeśli LLM wypluje zepsuty JSON
    def _extract_string(key):
        pattern = r'"' + re.escape(key) + r'"\s*:\s*"((?:\\.|[^"\\])*)"'
        match = re.search(pattern, text)
        if match:
            raw = match.group(1)
            try:
                return json.loads('"' + raw + '"')
            except Exception:
                return raw.replace('\\"', '"').strip()

        pattern = r'"' + re.escape(key) + r'"\s*:\s*"([^"\r\n,}]*)'
        match = re.search(pattern, text)
        return match.group(1).strip() if match else ''

    def _extract_number(key):
        match = re.search(r'"' + re.escape(key) + r'"\s*:\s*(\d+)', text)
        if not match:
            return 0
        try:
            return int(match.group(1))
        except Exception:
            return 0

    def _extract_bool(key):
        match = re.search(r'"' + re.escape(key) + r'"\s*:\s*(true|false)', text, re.I)
        if not match:
            return False
        return match.group(1).lower() == 'true'

    return {
        'assistant_message': _extract_string('assistant_message'),
        'voice_text': _extract_string('voice_text'),
        'next_question': _extract_string('next_question'),
        'hide_candidates': _extract_bool('hide_candidates'),
        'ready_to_confirm': _extract_bool('ready_to_confirm'),
        'confirmation_title': _extract_string('confirmation_title'),
        'search_query': _extract_string('search_query'),
        'english_title': _extract_string('english_title'),
        'pl_title': _extract_string('pl_title'),
        'original_title': _extract_string('original_title'),
        'is_polish': _extract_bool('is_polish'),
        'year': _extract_string('year'),
        # ZMIANA (2026-05) [BUGFIX]: fallback type z 'movie' na '' gdy AI nie zwróci type.
        # POWOD: poprzednio gdy AI zwracalo "type": null lub brak pola, kod zgadywal 'movie'
        #        i wyszukiwal jako film nawet gdy uzytkownik pytal o serial.
        # ZMIANA (2026-05) [PATCH]: korekta komentarza — wczesniejsza wersja klamliwie twierdzila ze
        #        "TMDB szuka w 'multi' (film i serial)". To bylo NIEPRAWDA — ai_search_action
        #        defaultowal do MoviesClass dla pustego type. Po P2b/P2c flow jest teraz:
        #        1) _ai_apply_requested_media_type bierze type z history (slowo "film"/"serial"),
        #        2) _ai_confirmed_search_target jako fallback bierze type z pierwszego kandydata,
        #        3) ai_search_action gdy nadal puste -> dialog wyboru u uzytkownika, nie cichy MOVIE.
        # NIE ZMIENIAC: nie wracac do or 'movie' — pusty string jest bezpieczniejszy niz zly zgad,
        #               a 3-warstwowy fallback ponizej pokrywa wszystkie sciezki.
        'type': _extract_string('type'),
        'confidence': _extract_number('confidence'),
        'candidates': recovered_candidates,
    }


def _ai_has_candidates(ai_data):
    candidates = (ai_data or {}).get('candidates') or []
    return isinstance(candidates, list) and len(candidates) > 0


def _ai_has_title(ai_data):
    return bool((ai_data or {}).get('confirmation_title') or (ai_data or {}).get('search_query'))


def _ai_needs_quality_retry(ai_data):
    if not isinstance(ai_data, dict):
        return True
    if _ai_has_title(ai_data) or _ai_has_candidates(ai_data):
        return False
    if ai_data.get('next_question'):
        return False
    msg = (ai_data.get('assistant_message') or '').strip()
    return len(msg) <= 40


def _ai_is_empty_candidate_promise(ai_data):
    if _ai_has_title(ai_data) or _ai_has_candidates(ai_data):
        return False
    msg = _ai_fold_text((ai_data or {}).get('assistant_message') or '')
    return 'kandydat' in msg and ('ponizej' in msg or 'przedstawiam' in msg)


def _ai_message_claims_showable_title(ai_data):
    if not isinstance(ai_data, dict):
        return False
    msg = _ai_fold_text(u' '.join([
        u'{}'.format(ai_data.get('assistant_message') or ''),
        u'{}'.format(ai_data.get('voice_text') or ''),
        u'{}'.format(ai_data.get('next_question') or ''),
    ]))
    if not msg:
        return False
    if _ai_preflight_has_any(msg, ('nie znalazl', 'nie znalazlem', 'nie znalazlam', 'nie mam tytul', 'brak tytul')):
        return False
    return _ai_preflight_has_any(msg, (
        'znalazl', 'znalazlem', 'znalazlam', 'mam tytul', 'mam wynik',
        'to jest ten film', 'to ta bajka', 'to ten tytul', 'chodzi o tytul',
        'tytul to', 'tytulem jest', 'film to', 'bajka to', 'chodzi o',
        'to sa', 'to jest', 'najpewniej', 'najprawdopodobniej', 'prawdopodobnie',
        'moze to byc', 'może to być'
    ))


def _ai_needs_structured_title_retry(ai_data):
    if not isinstance(ai_data, dict):
        return False
    if ai_data.get('ready_to_confirm') and _ai_has_title(ai_data):
        return False
    return _ai_message_claims_showable_title(ai_data)


def _ai_bool_value(value):
    if isinstance(value, bool):
        return value
    folded = _ai_fold_text(u'{}'.format(value or '')).strip()
    return folded in ('1', 'true', 'tak', 'yes', 'y', 'hide', 'ukryj', 'ukryte')


def _ai_candidate_confidence(item):
    if not isinstance(item, dict):
        return 0
    value = item.get('confidence')
    if value is None:
        value = item.get('score')
    try:
        return max(0, min(100, int(float(value))))
    except Exception:
        pass
    match = re.search(r'\d+', u'{}'.format(value or ''))
    if not match:
        return 0
    try:
        return max(0, min(100, int(match.group(0))))
    except Exception:
        return 0


def _ai_candidate_year(item):
    if not isinstance(item, dict):
        return 0
    for key in ('year', 'release_year', 'first_air_date', 'date'):
        match = re.search(r'\b(19\d{2}|20\d{2})\b', u'{}'.format(item.get(key) or ''))
        if match:
            try:
                return int(match.group(1))
            except Exception:
                return 0
    return 0


def _ai_candidate_unique_values(candidates, keys):
    values = set()
    for item in candidates or []:
        if not isinstance(item, dict):
            continue
        for key in keys:
            raw = item.get(key)
            raw_values = raw if isinstance(raw, list) else [raw]
            for value in raw_values:
                folded = _ai_fold_text(u'{}'.format(value or '')).strip()
                folded = re.sub(r'\s+', ' ', folded)
                if not folded or folded in ('null', 'none', 'unknown', 'nie wiem', 'n/a', '-'):
                    continue
                values.add(folded[:60])
    return values


def _ai_candidate_decades(candidates):
    decades = set()
    for item in candidates or []:
        year = _ai_candidate_year(item)
        if year:
            decades.add((year // 10) * 10)
    return decades


def _ai_candidates_are_spread(candidates):
    candidates = [item for item in (candidates or []) if isinstance(item, dict)]
    if len(candidates) < 2:
        return False
    if len(_ai_candidate_decades(candidates)) >= 2:
        return True
    spread_keys = (
        ('country', 'production_country', 'origin_country', 'language', 'original_language'),
        ('genre', 'genres'),
        ('type', 'media_type'),
    )
    for keys in spread_keys:
        if len(_ai_candidate_unique_values(candidates, keys)) >= 2:
            return True
    return False


def _ai_candidate_top_confidence(candidates):
    top = 0
    for item in candidates or []:
        top = max(top, _ai_candidate_confidence(item))
    return top


def _ai_should_hide_ambiguous_candidates(ai_data, hidden_rounds=0):
    if not isinstance(ai_data, dict) or ai_data.get('ready_to_confirm'):
        return False
    candidates = ai_data.get('candidates') or []
    if not isinstance(candidates, list) or not candidates:
        return False
    top_confidence = _ai_candidate_top_confidence(candidates)
    # ZMIANA (2026-05) [BUGFIX]: kandydaci sa wewnetrznymi hipotezami, nie lista do pokazania przy braku pewnosci.
    # POWOD: log 17:17-17:18 pokazal ready=False, candidates=1/2, a UI mimo to pokazywalo karty.
    # NIE ZMIENIAC: dopoki ready_to_confirm=False, uzytkownik ma dostac pytanie doprecyzowujace, nie robocze tytuly.
    if not _ai_bool_value(ai_data.get('ready_to_confirm')):
        return True
    if _ai_bool_value(ai_data.get('hide_candidates')) and len(candidates) >= 3:
        return True
    has_question = bool(u'{}'.format(ai_data.get('next_question') or '').strip())
    spread = _ai_candidates_are_spread(candidates)
    if has_question and spread and len(candidates) >= 4 and top_confidence < 75:
        return True
    if spread and len(candidates) >= 4 and top_confidence < 75:
        return True
    if len(candidates) >= 5 and top_confidence < 55:
        return True
    return False


def _ai_join_or(items):
    items = [item for item in (items or []) if item]
    if not items:
        return ''
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return items[0] + u' albo ' + items[1]
    return u', '.join(items[:-1]) + u' albo ' + items[-1]


def _ai_hidden_candidates_message(ai_data):
    candidates = (ai_data or {}).get('candidates') or []
    spread = []
    if len(_ai_candidate_unique_values(candidates, ('country', 'production_country', 'origin_country', 'language', 'original_language'))) >= 2:
        spread.append(u'krajów')
    if len(_ai_candidate_decades(candidates)) >= 2:
        spread.append(u'dekad lub epok')
    if len(_ai_candidate_unique_values(candidates, ('genre', 'genres'))) >= 2:
        spread.append(u'gatunków')
    if spread:
        return u'Mam kilka tropów z różnych {}. Zawęźmy jednym szczegółem.'.format(_ai_join_or(spread))
    if len(candidates) <= 1:
        return u'Mam trop, ale za mało pewności, żeby pokazać tytuł.'
    return u'Mam kilka tropów, ale jeszcze za mało danych na sensowną listę.'


def _ai_hidden_candidates_question(ai_data):
    question = u'{}'.format((ai_data or {}).get('next_question') or '').strip()
    if question:
        return question
    candidates = (ai_data or {}).get('candidates') or []
    missing = []
    if len(_ai_candidate_unique_values(candidates, ('country', 'production_country', 'origin_country', 'language', 'original_language'))) >= 2:
        missing.append(u'kraj albo język')
    if len(_ai_candidate_decades(candidates)) >= 2:
        missing.append(u'mniej więcej lata lub dekadę')
    if len(_ai_candidate_unique_values(candidates, ('genre', 'genres'))) >= 2:
        missing.append(u'gatunek albo klimat')
    if not missing:
        missing = [u'kraj lub język', u'lata produkcji/premiery', u'aktor albo czas akcji']
    return u'Pamiętasz {}?'.format(_ai_join_or(missing))


def _ai_compact_text(text, max_len=110, question=False):
    text = re.sub(r'\s+', ' ', u'{}'.format(text or '')).strip()
    if not text or len(text) <= max_len:
        return text
    separators = ('?', '!', '.') if question else ('.', '?', '!')
    for sep in separators:
        pos = text.find(sep)
        if 20 <= pos + 1 <= max_len:
            return text[:pos + 1].strip()
    clipped = text[:max(20, max_len - 3)].rstrip(' ,;:-')
    if question:
        return clipped.rstrip('?.!') + u'?'
    return clipped + u'...'


def _ai_merge_token_usage(first, second):
    if not first:
        return second or {}
    if not second:
        return first or {}
    merged = dict(second)
    merged['input'] = _ai_token_int(first.get('input')) + _ai_token_int(second.get('input'))
    merged['output'] = _ai_token_int(first.get('output')) + _ai_token_int(second.get('output'))
    merged['total'] = _ai_token_int(first.get('total')) + _ai_token_int(second.get('total'))
    if not merged.get('provider'):
        merged['provider'] = first.get('provider') or ''
    if not merged.get('model'):
        merged['model'] = first.get('model') or ''
    return merged


def _build_force_candidates_prompt(history, previous_raw=''):
    prompt = _build_mini_chat_prompt(history)
    previous = (previous_raw or '').strip()
    if len(previous) > 500:
        previous = previous[:500]
    return (
        prompt +
        u'\n\nUWAGA TECHNICZNA: Poprzednia odpowiedź była bezużyteczna, bo nie zawierała tytułu, pytania ani kandydatów.\n'
        u'Odpowiedz WYŁĄCZNIE poprawnym JSON-em. Pierwszy znak odpowiedzi ma być {, ostatni znak ma być }.\n'
        u'Teraz MUSISZ użyć web search i zwrócić niepustą tablicę "candidates" z 3-6 wewnętrznymi hipotezami.\n'
        u'Nie wolno napisać "poniżej kandydaci" bez rzeczywistej tablicy candidates.\n'
        u'Jeśli hipotezy są z różnych krajów, dekad, epok albo gatunków, ustaw hide_candidates=true, '
        u'ready_to_confirm=false i zadaj jedno krótkie pytanie w "next_question". Nie wypisuj tytułów w assistant_message.\n'
        u'Wzór minimalny:\n'
        u'{"candidates":[{"title":"Tytuł","year":"2000","country":"USA","genre":"komedia","confidence":50,"reason":"pasujący trop"}],'
        u'"hide_candidates":true,"assistant_message":"Mam kilka tropów z różnych krajów i epok.","voice_text":"Mam kilka tropów, zawęźmy je.","next_question":"Pamiętasz kraj, lata albo gatunek?","ready_to_confirm":false,'
        u'"confirmation_title":null,"search_query":null}\n'
        u'Poprzednia odpowiedź AI do korekty:\n' + previous
    )


def _build_structured_title_retry_prompt(history, ai_data, previous_raw=''):
    prompt = _build_mini_chat_prompt(history)
    previous = (previous_raw or '').strip()
    if not previous:
        try:
            previous = json.dumps(ai_data or {}, ensure_ascii=False)
        except Exception:
            previous = u'{}'.format(ai_data or '')
    if len(previous) > 900:
        previous = previous[:900]
    return (
        prompt +
        u'\n\nUWAGA TECHNICZNA: Poprzednia odpowiedź powiedziała użytkownikowi, że tytuł jest znaleziony, '
        u'ale nie podała go w polach technicznych confirmation_title/search_query albo zostawiła ready_to_confirm=false.\n'
        u'Jeśli naprawdę znasz tytuł: zwróć JSON z ready_to_confirm=true, confirmation_title, search_query, year, type i confidence >= 95.\n'
        u'Jeśli nie masz 95% pewności: NIE pisz, że znalazłeś tytuł; ustaw ready_to_confirm=false i zadaj konkretne next_question.\n'
        u'Nie zostawiaj tytułu wyłącznie w assistant_message, bo UI nie ma wtedy czego pokazać.\n'
        u'Odpowiedz WYŁĄCZNIE poprawnym JSON-em.\n\n'
        u'Poprzednia odpowiedź AI do korekty:\n' + previous
    )


# ---------------------------------------------------------------------------
# Logika czatu i GUI
# ---------------------------------------------------------------------------
def _ai_fold_text(text):
    text = (text or '').lower()
    repl = {
        u'ą': 'a', u'ć': 'c', u'ę': 'e', u'ł': 'l', u'ń': 'n',
        u'ó': 'o', u'ś': 's', u'ź': 'z', u'ż': 'z',
    }
    for src, dst in repl.items():
        text = text.replace(src, dst)
    return text


def _ai_preflight_user_text(history):
    return u' '.join([
        (item.get('content') or '').strip()
        for item in (history or [])
        if item.get('role') == 'user' and (item.get('content') or '').strip()
    ]).strip()


def _ai_preflight_has_any(text, words):
    return any(word in text for word in words)


_AI_PREFLIGHT_MAX_QUESTIONS = 3


def _ai_question_mentions_story_time(folded):
    return (
        _ai_preflight_has_any(folded, ('akcja', 'dzial', 'toczy', 'dzieje', 'swiat filmu', 'realia')) and
        _ai_preflight_has_any(folded, ('czas', 'czasy', 'epok', 'okres', 'kiedy'))
    ) or _ai_preflight_has_any(folded, ('epoka akcji', 'czas akcji', 'realia akcji'))


def _ai_question_mentions_production_time(folded):
    return (
        _ai_preflight_has_any(folded, ('produkcj', 'premier', 'wyszedl', 'powstal', 'nakrecony', 'nakrecono')) and
        _ai_preflight_has_any(folded, ('rok', 'lata', 'kiedy', 'okres'))
    ) or _ai_preflight_has_any(folded, ('rok produkcji', 'lata produkcji', 'rok premiery'))


def _ai_preflight_rare_scene_axes(folded):
    words = re.findall(r'[a-z0-9]+', folded or '')
    mentions_scene = _ai_preflight_has_any(folded, (
        'scena', 'w scenie', 'pamietam jak', 'pamiętam jak', 'moment', 'fragment', 'ujecie', 'ujęcie'
    ))
    action = _ai_preflight_has_any(folded, (
        'scena', 'robil', 'robila', 'robi', 'czyscil', 'myla', 'myje', 'kapal', 'kapiel',
        'uciekal', 'gonil', 'szukal', 'znalazl', 'ukradl', 'zabil', 'uratowal', 'walczyl',
        'przebral', 'udawal', 'schowal', 'otworzyl', 'zamknal', 'wyciagal', 'nosił', 'nosil',
        'trzymal', 'trzymał', 'trzymala', 'trzymała', 'podal', 'podał', 'podala', 'podała',
        'rzucil', 'rzucił', 'zabral', 'zabrał', 'wlozyl', 'włożył', 'wyjal', 'wyjął',
    ))
    generic_action = re.search(
        r'\b[a-z0-9]{4,}(?:al|ala|ali|alo|yl|yla|yli|owal|owala|owali|uje|ujez|ac|ic)\b',
        folded or ''
    ) is not None
    relation = _ai_preflight_has_any(folded, (
        'sluga', 'sluzacy', 'lokaj', 'kamerdyner', 'pan', 'pani', 'wladca', 'krol',
        'ojciec', 'matka', 'syn', 'corka', 'brat', 'siostra', 'maz', 'zona', 'szef',
        'uczen', 'nauczyciel', 'policjant', 'zlodziej', 'więzien', 'wiezien',
        'bohater', 'bohaterka', 'mezczyzna', 'mężczyzna', 'kobieta', 'dziecko', 'dzieck',
        'aktor', 'facet', 'chlopak', 'chłopak', 'dziewczyn',
    ))
    place = _ai_preflight_has_any(folded, (
        'wanna', 'lazien', 'palac', 'zamek', 'dwor', 'dom', 'hotel', 'szkola', 'szpital',
        'wiezienie', 'statek', 'pociag', 'samolot', 'las', 'jaskinia', 'kosmos', 'miasto',
        'francja', 'paryz', 'londyn', 'nowy jork', 'wieś', 'wies', 'miasteczko', 'ulica',
        'winda', 'windz', 'pokoj', 'pokój', 'korytarz', 'sklep', 'restauracja', 'most',
        'ulica', 'ulic',
    ))
    prop = _ai_preflight_has_any(folded, (
        'uszy', 'ucho', 'miecz', 'pistolet', 'bron', 'walizka', 'klucz', 'list', 'ksiega',
        'pierścień', 'pierscien', 'auto', 'samochod', 'telefon', 'drzwi', 'okno', 'lustro',
        'przedmiot', 'rzecz', 'rekwizyt', 'narzedzie', 'narzędzie', 'szmatka', 'chustka',
    ))
    axis_count = sum(1 for value in (action or generic_action, relation, place, prop) if value)
    # Zamknieta lista przedmiotow nie moze decydowac o trybie. Gdy opis wyglada jak konkretna
    # scena, traktujemy go jako rzadki trop nawet z innym, nieznanym przedmiotem.
    generic_scene = bool((mentions_scene and (len(words) >= 5 or axis_count >= 1)) or (generic_action and len(words) >= 8))
    return {
        'action': bool(action or generic_action),
        'relation': bool(relation),
        'place': bool(place),
        'prop': bool(prop),
        'rare_scene': axis_count >= 2 or generic_scene,
    }


def _ai_preflight_facts(history):
    raw = _ai_preflight_user_text(history)
    folded = _ai_fold_text(raw)
    words = re.findall(r'[a-z0-9]+', folded)
    rare_scene_axes = _ai_preflight_rare_scene_axes(folded)
    # ZMIANA (2026-05) [PATCH]: has_type uzywa wspolnej funkcji _ai_media_type_from_text zamiast lokalnego regexa.
    # POWOD: Lokalny regex pomijal "filmy", "movie", "bajki", "bajek", "animacji", "tv show", "series",
    #        "seriale" — przez co preflight pytal "film czy serial?" mimo ze uzytkownik napisal "szukam filmow".
    # NIE ZMIENIAC: _ai_media_type_from_text zwraca 'movie'/'tv'/'' — bool() pokrywa wszystkie 3 przypadki.
    #               Spojnosc z _ai_media_type_from_history (uzywanym w _build_mini_chat_prompt i _ai_apply_requested_media_type).
    has_type = bool(_ai_media_type_from_text(raw))
    has_story_time = _ai_question_mentions_story_time(folded) or _ai_preflight_has_any(folded, (
        'epoka', 'epoce', 'czasy akcji', 'czas akcji', 'realia', 'dzialo sie', 'działało się',
        'dzieje sie', 'dzieje się', 'toczy sie', 'toczy się', 'sredniowiecz', 'średniowiecz',
        'starozyt', 'starożyt', 'renesans', 'barok', 'wiktoriansk', 'wiktoriańsk',
        'przyszlosc', 'przyszłość', 'wspolczesn', 'współczesn'
    ))
    # Produkcja/premiera to osobny trop od czasu akcji. Preflight ma pytac o lata produkcji,
    # nawet gdy uzytkownik podal mocny szczegol sceny albo epoke w fabule.
    has_time = (
        (bool(_ai_extract_year_ranges(raw)) and not has_story_time) or
        _ai_question_mentions_production_time(folded) or
        (re.search(r'\b(?:po|przed|okolo)\s*(?:19|20)\d{2}\b', folded) is not None and not has_story_time) or
        _ai_preflight_has_any(folded, (
            'rok produkcji', 'lata produkcji', 'rok premiery', 'lata premiery',
            'stary film', 'starszy film', 'nowy film', 'nowszy film', 'nowsza produkcja',
            'klasyk', 'czarno bialy', 'niemy'
        ))
    )
    has_country = _ai_preflight_has_any(folded, (
        'polsk', 'polski', 'polska', 'usa', 'ameryk', 'stany', 'stanow', 'franc', 'francj',
        'wloch', 'wlosk', 'niemiec', 'niemieck', 'angli', 'bryt', 'hiszpan', 'japon',
        'chin', 'rosj', 'radzieck', 'czesk', 'slowac', 'szwed', 'norweg', 'dunsk',
        'kanad', 'austral', 'meksyk', 'indie', 'kore', 'hongkong', 'belg', 'holend',
        'paryz', 'londyn', 'nowy jork', 'hollywood',
    ))
    has_actor = _ai_preflight_has_any(folded, (
        'aktor', 'aktorka', 'obsada', 'gral', 'grał', 'grala', 'grała', 'wystepowal',
        'występował', 'wystepowala', 'występowała', 'znany aktor', 'znana aktorka',
        'de funes', 'belmondo', 'delon', 'gabinem', 'gabin', 'bardot', 'ventura',
    ))
    has_genre = _ai_preflight_has_any(folded, (
        'fantasy', 'horror', 'komedia', 'kryminal', 'sensacja', 'thriller', 'sci-fi', 'scifi',
        'science fiction', 'dramat', 'western', 'wojenny', 'romans', 'przygod', 'animowan',
        'bajka', 'magia', 'kosmos', 'zombie', 'wampir', 'superbohater', 'postapo', 'apokalip',
        'familijn', 'dla dzieci', 'mroczn', 'straszn', 'smieszn'
    ))
    has_clue = (
        len(words) >= 12 or
        _ai_preflight_has_any(folded, (
            # osoby / postacie
            'aktor', 'aktorka', 'postac', 'bohater', 'bohaterka', 'czlowiek', 'mezczyzna',
            'kobieta', 'chlopak', 'dziewczyna', 'dziecko', 'dzieci', 'starzec', 'staruszek',
            'karzel', 'krasnolud', 'olbrzym', 'gigant', 'mutant', 'klon', 'android', 'cyborg',
            'robot', 'alien', 'kosmita', 'duch', 'zombie', 'wampir', 'wilkolak', 'potwor',
            'morderca', 'zabojca', 'seryjny', 'terrorysta', 'szpieg', 'agent', 'najemnik',
            'zolnierz', 'oficer', 'general', 'kapitan', 'pilot', 'astronauta', 'naukowiec',
            'lekarz', 'doktor', 'chirurg', 'detektyw', 'policjant', 'policja', 'komisarz',
            'prokurator', 'sedzia', 'prawnik', 'adwokat', 'gangster', 'mafia', 'bandyta',
            'zlodziej', 'wlamywacz', 'haker', 'programista', 'wynalazca', 'czarodziej',
            'czarownic', 'wiedzma', 'wiedzmin', 'elf', 'elfy', 'hobbit', 'rycerz', 'wojownik',
            'ninja', 'samuraj', 'pirat', 'piraci', 'krol', 'krolowa', 'ksiaze', 'ksiezniczka',
            'superbohater', 'superzlodziej', 'sportowiec', 'bokser', 'zawodnik', 'trener',
            'strazak', 'ratownik', 'uciekinier', 'sierota', 'blizniaki', 'muzyk', 'piosenkarz',
            'kierowca', 'taksowkarz', 'kosmonauta',
            # stworzenia / nadprzyrodzone
            'smok', 'demon', 'aniol', 'diabel', 'mumia', 'szkielet', 'upior', 'zjawa',
            'ork', 'orkowie', 'goblin', 'troll', 'syrena', 'feniks', 'smoczycа',
            # miejsca
            'zamek', 'palac', 'szkola', 'akademia', 'uniwersytet', 'szpital', 'wiezienie',
            'wiez', 'bunkier', 'laboratorium', 'fabryka', 'kopalnia', 'farma', 'wioska',
            'miasto', 'metropolia', 'stolica', 'wyspa', 'pustynia', 'dzungla', 'las',
            'gory', 'podziemia', 'jaskinia', 'ocean', 'morze', 'rzeka', 'jezioro',
            'kosmos', 'statek kosmiczny', 'stacja kosmiczna', 'planeta', 'statek', 'okret',
            'lodz', 'samolot', 'helikopter', 'pociag', 'metro', 'tunel', 'most',
            'muzeum', 'biblioteka', 'kosciol', 'swiatynia', 'ruiny', 'cmentarz',
            'plaz', 'hotel', 'dom', 'willa', 'apartament', 'slumsy', 'ghetto',
            'lotnisko', 'port', 'oboz', 'twierdza', 'fort', 'arena', 'stadion', 'ring',
            'wirtualna rzeczywistosc', 'symulacja', 'alternatywna rzeczywistosc',
            # akcje / zdarzenia
            'scena', 'walczyl', 'walka', 'bitwa', 'wojna', 'inwazja', 'atak', 'ucieczka',
            'uciekal', 'sciganym', 'pogon', 'wypadek', 'katastrofa', 'apokalips', 'zaglanda',
            'eksplozja', 'pozar', 'powodz', 'trzesienie', 'epidemia', 'wirus', 'zaraza',
            'zabojstwo', 'morderstwo', 'zbrodnia', 'kradzie', 'wlamanie', 'napad', 'porwanie',
            'szukal', 'poszukiwal', 'odkryl', 'znalazl', 'uciekl', 'ocalal', 'przetrwal',
            'zdradzil', 'oszukal', 'umiera', 'umierajac', 'zniknal', 'zaginiony',
            'ratuje', 'ratowac', 'ocalic', 'uratow', 'ucieka', 'sciganym', 'poluje',
            'rewolucja', 'powstanie', 'bunt', 'spisek', 'konspirac', 'podroz w czasie',
            'wyscig', 'turniej', 'zawody', 'mistrzostwa', 'olimpiada',
            # przedmioty / rekwizyty
            'miecz', 'bron', 'pistolet', 'karabin', 'bomba', 'rakieta', 'tarcza',
            'pierscien', 'amulet', 'artefakt', 'skarb', 'mapa', 'klucz', 'kod',
            'walizka', 'teczka', 'paczka', 'ksiega', 'zwoj', 'krysztal', 'krysztaly',
            'auto', 'samochod', 'motocykl', 'czolg', 'zbroja', 'tron', 'korona',
            'rozdzka', 'zaklety', 'zakleta', 'magiczny', 'magiczna',
            # relacje / wątki
            'milosc', 'zakochali', 'romans', 'przyjazn', 'zdrada', 'zemsta', 'wendeta',
            'rodzina', 'ojciec', 'matka', 'brat', 'siostra', 'syn', 'corka', 'dziadek',
            'babcia', 'wuj', 'ciocia', 'przyjaciel', 'wrog', 'rywal', 'mentor', 'mistrz',
            'maz', 'zona', 'malzenstwo', 'rozwod', 'kochanek', 'kochanka', 'adopcja',
            # tajemnica / zagadka
            'tajemnica', 'zagadka', 'sekret', 'tajny', 'ukryty', 'zaginiony',
            'mysterium', 'niewyjasnion', 'nieznany', 'poszukiwany',
            # nadprzyrodzone / horror
            'klatwa', 'nawiedzon', 'opetany', 'opetanie', 'szalenstwo', 'szalony',
            'amnezja', 'obsesja', 'pieklo', 'raj', 'czar', 'zaklecie',
            # zbiorowości / organizacje
            'gang', 'szajka', 'banda', 'klan', 'sekta', 'kult', 'bractwo', 'gildia',
            # podróż / wyprawa
            'podroz', 'wyprawa', 'wedrowka', 'wycieczka', 'pielgrzymka', 'misja',
            # kontekst / styl
            'wystepowal', 'byl tam', 'pamietam', 'przypominam', 'chyba', 'podobny',
            'animacja', 'animowan', 'anime', 'lalkowy', 'czarno bialy', 'niemy',
            'polski', 'polsk', 'american', 'japon', 'francusk', 'rosyjsk', 'chinski',
            'prawdziwa historia', 'oparty na', 'inspirowany', 'biografia', 'biopic',
            # armia / historia
            'armia', 'wojsko', 'oddzial', 'operacja', 'front',
            'nazist', 'hitlerow', 'sowiet', 'komando', 'snajper', 'zwiad',
        ))
    )
    return {
        'raw': raw,
        'word_count': len(words),
        'type': bool(has_type),
        'time': bool(has_time),
        'story_time': bool(has_story_time),
        'country': bool(has_country),
        'genre': bool(has_genre),
        'actor': bool(has_actor),
        'clue': bool(has_clue),
        'rare_scene': bool(rare_scene_axes.get('rare_scene')),
        'scene_action': bool(rare_scene_axes.get('action')),
        'scene_relation': bool(rare_scene_axes.get('relation')),
        'scene_place': bool(rare_scene_axes.get('place')),
        'scene_prop': bool(rare_scene_axes.get('prop')),
    }


def _ai_preflight_has_context_for_scene(facts):
    return any(facts.get(key) for key in (
        'country', 'story_time', 'actor'
    ))


def _ai_preflight_user_said_unknown(text):
    folded = _ai_fold_text(text or '')
    if not folded:
        return False
    return _ai_preflight_has_any(folded, (
        'nie wiem', 'nie pamietam', 'nie kojarze', 'nie mam pojecia',
        'nie jestem pewien', 'nie jestem pewna', 'nie jestem pewny',
        'brak pewnosci', 'nie mam pewnosci'
    ))


def _ai_preflight_fields_from_question(question):
    folded = _ai_fold_text(question or '')
    fields = set()
    if not folded:
        return fields
    if (
            _ai_preflight_has_any(folded, ('film czy serial', 'film, serial', 'serial czy bajka', 'bajka/animacja', 'typ')) or
            (re.search(r'\bfilm\b', folded) is not None and re.search(r'\bserial\b', folded) is not None)):
        fields.add('type')
    if (
            _ai_question_mentions_production_time(folded) or
            _ai_preflight_has_any(folded, ('lata produkcji', 'lata premiery', 'rok produkcji', 'rok premiery', 'produkcji/premiery'))):
        fields.add('time')
    if _ai_question_mentions_story_time(folded) or _ai_preflight_has_any(folded, (
            'gdzie i kiedy', 'czasach', 'miejscu dziala', 'miejscu dzieje', 'miejsce akcji')):
        fields.add('story_time')
        fields.add('scene_context')
    if _ai_preflight_has_any(folded, ('kraj', 'jezyk')):
        fields.add('country')
        fields.add('scene_context')
    if _ai_preflight_has_any(folded, ('aktor', 'aktorka', 'postac')):
        fields.add('actor')
        fields.add('scene_context')
    if _ai_preflight_has_any(folded, ('gatunek', 'klimat')):
        fields.add('genre')
    if _ai_preflight_has_any(folded, ('konkretny trop', 'dopisz jeden trop', 'dopisz trop')):
        fields.add('clue')
    return fields


def _ai_preflight_unknown_fields(history):
    unknown_fields = set()
    pending_fields = set()
    for item in (history or []):
        try:
            role = item.get('role')
            content = item.get('content') or ''
        except Exception:
            continue
        if role == 'assistant':
            fields = _ai_preflight_fields_from_question(content)
            if fields:
                pending_fields = set(fields)
            continue
        if role == 'user':
            if pending_fields and _ai_preflight_user_said_unknown(content):
                unknown_fields.update(pending_fields)
            pending_fields = set()
    return unknown_fields


def _ai_question_asks_unknown_field(question, unknown_fields):
    fields = _ai_preflight_fields_from_question(question)
    common = fields & set(unknown_fields or [])
    if common:
        return sorted(common)[0]
    return ''


def _ai_preflight_enough(facts, asked_count=0, asked_fields=None, unknown_fields=None):
    # ZMIANA (2026-05) [FEATURE]: przy samej scenie prowadzimy uzytkownika przez kilka tropow.
    # POWOD: jeden prompt o lata nie wystarczal; AI startowalo bez kraju, czasu/miejsca akcji lub aktora.
    # NIE ZMIENIAC: samo zadanie pytania nie liczy sie jako odpowiedz; dopiero fakt albo "nie wiem".
    asked_fields = set(asked_fields or [])
    unknown_fields = set(unknown_fields or [])
    if asked_count >= _AI_PREFLIGHT_MAX_QUESTIONS:
        return True
    if not facts.get('type') and 'type' not in unknown_fields:
        return False
    if not facts.get('time') and 'time' not in unknown_fields:
        return False
    if facts.get('rare_scene') and not _ai_preflight_has_context_for_scene(facts):
        if not ({'scene_context', 'story_time', 'country', 'actor'} & unknown_fields):
            return False
        if asked_count < 2:
            return False
    score = sum(1 for key in ('type', 'time', 'genre', 'clue') if facts.get(key))
    if facts.get('clue'):
        return True
    if facts.get('word_count', 0) >= 5:
        return True
    if score >= 2:
        return True
    return False


def _ai_preflight_next_question(facts, asked_fields, unknown_fields=None):
    asked_fields = set(asked_fields or [])
    unknown_fields = set(unknown_fields or [])
    missing_type = (not facts.get('type')) and 'type' not in unknown_fields
    missing_time = (not facts.get('time')) and 'time' not in unknown_fields
    context_fields = {'scene_context', 'story_time', 'country', 'actor'}
    context_unknown = bool(context_fields & unknown_fields)
    if missing_type and missing_time and not ({'type', 'time'} & asked_fields):
        return ('type', 'time'), u'Zanim uruchomię AI: film czy serial i jakie lata produkcji/premiery?'
    if missing_type:
        if 'type' in asked_fields:
            return ('type',), u'Nadal potrzebuje typu: film, serial czy bajka/animacja? Jesli naprawde nie pamietasz, wpisz "nie wiem".'
        return ('type',), u'To był film czy serial? Jeśli nie pamiętasz, wpisz „nie wiem”.'
    if missing_time:
        if 'time' in asked_fields:
            return ('time',), u'Nadal potrzebuje przyblizonych lat produkcji/premiery, np. lata 70., po 2000 albo "nie wiem".'
        return ('time',), u'Mniej więcej z jakich lat produkcji/premiery to może być? Np. lata 90, po 2000 albo „nie wiem”.'
    if facts.get('rare_scene') and not _ai_preflight_has_context_for_scene(facts) and not context_unknown:
        if context_fields & asked_fields:
            return ('scene_context', 'country', 'actor', 'story_time'), u'Nadal brakuje kontekstu sceny: kraj/jezyk, czas albo miejsce akcji, aktor/postac. Jesli nie pamietasz, wpisz "nie wiem".'
        return ('scene_context', 'country', 'actor', 'story_time'), u'Gdzie i kiedy działa się akcja? Pamiętasz kraj/język albo aktora/postać?'
    if facts.get('rare_scene') and (not facts.get('country')) and (not facts.get('actor')) and not ({'country', 'actor'} & asked_fields) and not ({'country', 'actor'} & unknown_fields):
        return ('country', 'actor'), u'Pamiętasz kraj pochodzenia, język albo aktora? Jeśli nie, wpisz „nie wiem”.'
    if facts.get('rare_scene') and (not facts.get('story_time')) and (not facts.get('scene_place')) and 'story_time' not in asked_fields and 'story_time' not in unknown_fields:
        return ('story_time',), u'W jakich czasach albo miejscu działa się akcja?'
    if (not facts.get('genre')) and 'genre' not in asked_fields and 'genre' not in unknown_fields:
        return ('genre',), u'Jaki klimat albo gatunek? Np. fantasy, horror, komedia, kryminał, sci-fi, bajka. Możesz wpisać „nie wiem”.'
    if (not facts.get('clue')) and 'clue' not in asked_fields and 'clue' not in unknown_fields:
        return ('clue',), u'Dopisz jeden konkretny trop, który najbardziej pamiętasz.'
    if (not facts.get('type')) and 'type' not in asked_fields and 'type' not in unknown_fields:
        return ('type',), u'To był film czy serial? Jeśli nie pamiętasz, wpisz „nie wiem”.'
    return (), ''


def _ai_question_asks_known_field(question, facts):
    folded = _ai_fold_text(question or '')
    if not folded:
        return ''
    if facts.get('story_time') and _ai_question_mentions_story_time(folded):
        return 'story_time'
    if facts.get('time') and (
        _ai_question_mentions_production_time(folded) or (
            _ai_preflight_has_any(folded, ('rok', 'rocznik', 'lata', 'dekad', 'kiedy', '80', '90', 'nowsz', 'starsz')) and
            not _ai_question_mentions_story_time(folded)
        )
    ):
        return 'time'
    if facts.get('country') and _ai_preflight_has_any(folded, (
        'kraj', 'panstwo', 'państwo', 'jezyk', 'język', 'polsk', 'usa', 'ameryk',
        'franc', 'wloch', 'niemiec', 'angli', 'bryt'
    )):
        return 'country'
    if facts.get('genre') and _ai_preflight_has_any(folded, (
        'gatunek', 'klimat', 'komedia', 'horror', 'dramat', 'thriller', 'kryminal',
        'sci-fi', 'scifi', 'fantasy', 'przygod'
    )):
        return 'genre'
    if facts.get('actor') and _ai_preflight_has_any(folded, (
        'aktor', 'aktorka', 'obsada', 'gral', 'grał', 'grala', 'grała', 'wystepowal', 'występował'
    )):
        return 'actor'
    if _ai_preflight_has_context_for_scene(facts) and _ai_preflight_has_any(folded, (
        'gdzie', 'miejsce', 'kraj', 'jezyk', 'język', 'aktor', 'postac', 'postać', 'czas akcji'
    )):
        return 'scene_context'
    if facts.get('type') and ('film czy serial' in folded or ('film' in folded and 'serial' in folded)):
        return 'type'
    return ''


def _ai_replacement_question_for_known_facts(ai_data, history):
    facts = _ai_preflight_facts(history)
    unknown_fields = _ai_preflight_unknown_fields(history)
    candidates = (ai_data or {}).get('candidates') or []
    if facts.get('rare_scene') and not facts.get('story_time') and 'story_time' not in unknown_fields:
        return u'W jakich czasach działa się akcja tego filmu?'
    if not facts.get('country') and 'country' not in unknown_fields and len(_ai_candidate_unique_values(
            candidates, ('country', 'production_country', 'origin_country', 'language', 'original_language'))) >= 2:
        return u'Pamiętasz kraj albo język?'
    if not facts.get('genre') and 'genre' not in unknown_fields and len(_ai_candidate_unique_values(candidates, ('genre', 'genres'))) >= 2:
        return u'Pamiętasz gatunek albo klimat?'
    if not facts.get('time') and 'time' not in unknown_fields and len(_ai_candidate_decades(candidates)) >= 2:
        return u'To była produkcja raczej z lat 80., 90. czy coś nowszego?'
    if not facts.get('genre') and 'genre' not in unknown_fields:
        return u'Pamiętasz gatunek albo klimat?'
    if not facts.get('country') and 'country' not in unknown_fields:
        return u'Pamiętasz kraj albo język?'
    return u'Co jeszcze pasuje albo nie pasuje do pokazanych tropów?'


def _ai_guard_repeated_next_question(ai_data, history):
    if not isinstance(ai_data, dict):
        return ai_data
    question = u'{}'.format(ai_data.get('next_question') or '').strip()
    if not question:
        return ai_data
    facts = _ai_preflight_facts(history)
    unknown_fields = _ai_preflight_unknown_fields(history)
    repeated_field = _ai_question_asks_known_field(question, facts)
    if not repeated_field:
        unknown_field = _ai_question_asks_unknown_field(question, unknown_fields)
        if unknown_field:
            repeated_field = 'unknown:' + unknown_field
    if not repeated_field:
        return ai_data
    data = dict(ai_data)
    replacement = _ai_replacement_question_for_known_facts(data, history)
    if (
            replacement and
            not _ai_question_asks_known_field(replacement, facts) and
            not _ai_question_asks_unknown_field(replacement, unknown_fields)):
        data['next_question'] = replacement
    else:
        data['next_question'] = None
    try:
        log('[AI_SEARCH] repeated next_question blocked field={} replacement={}'.format(
            repeated_field, 'yes' if data.get('next_question') else 'no'), 1)
    except Exception:
        pass
    return data


def _ai_guard_found_without_showable_result(ai_data):
    if not isinstance(ai_data, dict):
        return ai_data
    title = u'{}'.format(ai_data.get('confirmation_title') or ai_data.get('search_query') or '').strip()
    if ai_data.get('ready_to_confirm') and title:
        return ai_data
    msg = u'{}'.format(ai_data.get('assistant_message') or '').strip()
    folded = _ai_fold_text(msg)
    if not folded or not _ai_preflight_has_any(folded, (
        'znalazl', 'znalazlem', 'znalazlam', 'mam tytul', 'mam wynik', 'to jest ten film'
    )):
        return ai_data
    data = dict(ai_data)
    data['assistant_message'] = u'Mam trop, ale jeszcze nie mam pewności, żeby pokazać tytuł.'
    if not u'{}'.format(data.get('next_question') or '').strip():
        data['next_question'] = u'Co jeszcze pamiętasz: kraj, aktora, czas akcji albo mniej więcej rok?'
    try:
        log('[AI_SEARCH] found-without-title message guarded ready={} title=no'.format(
            bool(data.get('ready_to_confirm'))), 1)
    except Exception:
        pass
    return data


def _ai_decade_range_from_short(value):
    try:
        number = int(value)
    except Exception:
        return None
    if number < 0 or number > 99:
        return None
    if number <= 29:
        start = 2000 + number
    else:
        start = 1900 + number
    return (start, start + 9)


def _ai_extract_year_ranges(text, allow_bare_decades=False):
    folded = _ai_fold_text(text or '')
    ranges = []

    for match in re.finditer(r'\b((?:19|20)\d{2})\s*[-–]\s*((?:19|20)\d{2})\b', folded):
        start, end = int(match.group(1)), int(match.group(2))
        if start > end:
            start, end = end, start
        ranges.append((start, end))

    for match in re.finditer(r'\b(?:od\s*)?((?:19|20)\d{2})\s*(?:do|po)\s*((?:19|20)\d{2})\b', folded):
        start, end = int(match.group(1)), int(match.group(2))
        if start > end:
            start, end = end, start
        ranges.append((start, end))

    for match in re.finditer(r'\bpo\s*((?:19|20)\d{2})\b', folded):
        year = int(match.group(1))
        ranges.append((year, 2099))

    for match in re.finditer(r'\bprzed\s*((?:19|20)\d{2})\b', folded):
        year = int(match.group(1))
        ranges.append((1880, max(1880, year - 1)))

    for match in re.finditer(r'\b(?:okolo|około|mniej\s*wiecej|mniej\s*więcej)\s*((?:19|20)\d{2})\b', folded):
        year = int(match.group(1))
        ranges.append((max(1880, year - 5), min(2099, year + 5)))

    for match in re.finditer(r'\b((?:19|20)\d{2})\b', folded):
        year = int(match.group(1))
        ranges.append((year, year))

    decade_context = _ai_preflight_has_any(folded, ('lata', 'dekad', 'rocznik', 'produkcj', 'premier'))
    if decade_context or allow_bare_decades or re.search(r'\b\d{2}\s*[/,]\s*\d{2}\b', folded):
        for match in re.finditer(r'\b([0-9]0)(?:\s*[-–]\s*(?:te|tych))?\b', folded):
            rng = _ai_decade_range_from_short(match.group(1))
            if rng:
                ranges.append(rng)

    if _ai_preflight_has_any(folded, ('dwutysieczne', 'dwutysięczne')):
        ranges.append((2000, 2009))

    normalized = []
    seen = set()
    for start, end in ranges:
        if start < 1880 or end > 2099:
            continue
        key = (start, end)
        if key in seen:
            continue
        seen.add(key)
        normalized.append(key)
    return normalized


def _ai_previous_assistant_asked_approx_year(previous_assistant):
    folded = _ai_fold_text(previous_assistant or '')
    if not folded:
        return False
    return (
        _ai_preflight_has_any(folded, ('mniej wiecej', 'mniej więcej', 'przybliz', 'przybliż', 'jakich lat', 'lata produkcji')) and
        _ai_preflight_has_any(folded, ('produkcj', 'premier', 'rok', 'lata'))
    )


def _ai_previous_assistant_asked_production_year(previous_assistant):
    folded = _ai_fold_text(previous_assistant or '')
    if not folded:
        return False
    return _ai_question_mentions_production_time(folded) or _ai_preflight_has_any(folded, (
        'jakich lat', 'lata 90', 'lata 80', 'lata 70', 'lata 60',
        'po 2000', 'produkcji/premiery'
    ))


def _ai_expand_approx_production_ranges(ranges, content, previous_assistant=''):
    folded = _ai_fold_text(content or '')
    if not ranges:
        return []
    if not _ai_previous_assistant_asked_approx_year(previous_assistant):
        return list(ranges)
    exact_context = _ai_preflight_has_any(folded, (
        'dokladnie', 'dokładnie', 'konkretnie', 'pewny', 'pewna', 'na pewno',
        'rok produkcji', 'rok premiery', 'z roku', 'rocznik'
    ))
    if exact_context:
        return list(ranges)
    if _ai_preflight_has_any(folded, ('po ', 'przed', 'okolo', 'około', 'mniej wiecej', 'mniej więcej', 'lata', 'dekad')):
        return [(max(1880, start - 5), min(2099, end + 5)) for start, end in ranges]
    words = re.findall(r'[a-z0-9]+', folded)
    if len(words) > 3:
        return list(ranges)
    expanded = []
    for start, end in ranges:
        if start == end and re.match(r'^(?:19|20)\d{2}$', str(start)):
            # Odpowiedz typu "2000" po pytaniu "mniej wiecej z jakich lat" znaczy okolice roku,
            # nie twardy filtr jednego rocznika. Bez tego log TV pokazywal ranges=2000-2000
            # i usuwal trafienia z 2001/2002 zanim UI moglo je pokazac.
            expanded.append((max(1880, start - 5), min(2099, start + 5)))
        else:
            expanded.append((start, end))
    return expanded


def _ai_requested_production_year_ranges(history):
    ranges = []
    previous_assistant = ''
    for item in history or []:
        content = re.sub(r'\s+', ' ', (item.get('content') or '').strip())
        if item.get('role') == 'assistant':
            previous_assistant = content
            continue
        if item.get('role') != 'user' or not content:
            continue
        folded = _ai_fold_text(content)
        allow_bare_decades = _ai_previous_assistant_asked_production_year(previous_assistant)
        extracted = _ai_extract_year_ranges(content, allow_bare_decades=allow_bare_decades)
        production_context = (
            _ai_question_mentions_production_time(folded) or
            _ai_question_mentions_production_time(_ai_fold_text(previous_assistant)) or
            (
                extracted and
                not _ai_question_mentions_story_time(folded) and
                not _ai_preflight_has_any(folded, ('akcja', 'dziala', 'działa', 'dzieje', 'toczy'))
            )
        )
        if production_context:
            ranges.extend(_ai_expand_approx_production_ranges(extracted, content, previous_assistant))
    normalized = []
    seen = set()
    for item in ranges:
        if item in seen:
            continue
        seen.add(item)
        normalized.append(item)
    return normalized


def _ai_preflight_history_has_time_answer(history):
    previous_assistant = ''
    for item in history or []:
        content = re.sub(r'\s+', ' ', (item.get('content') or '').strip())
        if item.get('role') == 'assistant':
            previous_assistant = content
            continue
        if item.get('role') != 'user' or not content:
            continue
        if not _ai_previous_assistant_asked_production_year(previous_assistant):
            continue
        if _ai_extract_year_ranges(content, allow_bare_decades=True):
            return True
    return False


def _ai_year_from_value(value):
    match = re.search(r'\b((?:19|20)\d{2})\b', u'{}'.format(value or ''))
    if not match:
        return 0
    try:
        return int(match.group(1))
    except Exception:
        return 0


def _ai_year_in_ranges(year, ranges):
    try:
        year = int(year)
    except Exception:
        return False
    for start, end in ranges or []:
        if start <= year <= end:
            return True
    return False


def _ai_filter_requested_production_year(ai_data, history):
    if not isinstance(ai_data, dict):
        return ai_data
    ranges = _ai_requested_production_year_ranges(history)
    if not ranges:
        return ai_data
    data = dict(ai_data)
    removed = 0

    title_year = _ai_year_from_value(data.get('year') or '')
    if data.get('ready_to_confirm') and title_year and not _ai_year_in_ranges(title_year, ranges):
        # Przyblizone lata od uzytkownika sa tropem, a nie twardym zakazem.
        # Jezeli AI ma pewny tytul, pokazujemy go fizycznie i tylko oznaczamy rozjazd rocznika.
        data['_year_mismatch'] = True
        removed += 1

    candidates = data.get('candidates') or []
    if isinstance(candidates, list) and candidates:
        filtered = []
        for item in candidates:
            year = _ai_candidate_year(item) if isinstance(item, dict) else 0
            if year and not _ai_year_in_ranges(year, ranges):
                if data.get('ready_to_confirm') and isinstance(item, dict):
                    item_title_keys = _ai_candidate_title_keys(item)
                    confirmed_keys = _ai_candidate_title_keys({
                        'title': data.get('confirmation_title') or data.get('search_query') or '',
                        'search_query': data.get('search_query') or '',
                        'confirmation_title': data.get('confirmation_title') or '',
                        'pl_title': data.get('pl_title') or '',
                        'original_title': data.get('original_title') or '',
                        'english_title': data.get('english_title') or '',
                    })
                    if item_title_keys & confirmed_keys:
                        kept = dict(item)
                        kept['_year_mismatch'] = True
                        reason = u'{}'.format(kept.get('reason') or '').strip()
                        if reason:
                            kept['reason'] = u'Poza podanymi latami, ale pasuje trop sceny: {}'.format(reason)
                        else:
                            kept['reason'] = u'Poza podanymi latami, ale AI wskazało ten tytuł jako najmocniejszy trop.'
                        filtered.append(kept)
                        removed += 1
                        continue
                removed += 1
                continue
            filtered.append(item)
        data['candidates'] = filtered

    if removed:
        if data.get('_year_mismatch') and data.get('ready_to_confirm'):
            msg = u'{}'.format(data.get('assistant_message') or '').strip()
            note = u'Rocznik nie pasuje do podanych przybliżonych lat, ale pokazuję ten tytuł jako mocny trop.'
            if note not in msg:
                data['assistant_message'] = (msg + u' ' + note).strip() if msg else note
        if not data.get('candidates') and not data.get('ready_to_confirm'):
            data['assistant_message'] = u'Odrzuciłem wyniki spoza podanych lat produkcji.'
            data['next_question'] = u'Co jeszcze pasuje albo nie pasuje do tych tropów?'
            data['confirmation_title'] = None
            data['search_query'] = None
        try:
            range_text = ','.join(['{}-{}'.format(start, end) for start, end in ranges])
            log('[AI_SEARCH] production year filter removed={} ranges={}'.format(removed, range_text), 1)
        except Exception:
            pass
    return data


def _ai_user_clues_for_prompt(history, limit=900):
    clues = []
    skip = set((
        'tak', 'nie', 'no', 'yes', 'ok', 'nie wiem', 'niewiem', 'raczej tak',
        'raczej nie', 'to nie ten', 'to nie to', 'to ten', 'dokladnie', 'dokładnie'
    ))
    for item in history or []:
        if item.get('role') != 'user':
            continue
        text = re.sub(r'\s+', ' ', (item.get('content') or '').strip())
        if not text:
            continue
        folded = _ai_fold_text(text)
        if folded in skip and len(text) <= 16:
            continue
        clues.append(text)
    if not clues:
        return ''
    joined = u' | '.join(clues)
    if len(joined) > limit:
        joined = joined[-limit:]
        cut = joined.find('|')
        if cut >= 0 and cut + 1 < len(joined):
            joined = joined[cut + 1:].strip()
    return joined


def _ai_recent_candidates_for_prompt(history, limit=700):
    for item in reversed(history or []):
        if item.get('role') != 'assistant':
            continue
        content = re.sub(r'\s+', ' ', (item.get('content') or '').strip())
        if content.startswith(u'Kandydaci pokazani użytkownikowi:'):
            content = content.split(':', 1)[1].strip()
            return content[:limit]
    return ''


def _ai_rejected_titles_for_prompt(history, limit=500):
    titles = []
    for item in history or []:
        if item.get('role') != 'assistant':
            continue
        content = re.sub(r'\s+', ' ', (item.get('content') or '').strip())
        if not content.startswith(u'ODRZUCONY TYTUŁ:'):
            continue
        content = content.split(':', 1)[1].strip()
        for title in re.split(r'\s*;\s*', content):
            title = title.strip()
            if title and title not in titles:
                titles.append(title)
    joined = u'; '.join(titles)
    return joined[:limit]


def _ai_title_key(title):
    folded = _ai_fold_text(title or '')
    return re.sub(r'[^a-z0-9]+', '', folded)


def _ai_title_keys(title):
    raw = u'{}'.format(title or '').strip()
    if not raw:
        return set()
    variants = set([raw])
    cleaned = raw
    patterns = (
        r'\s*\((?:19|20)\d{2}(?:\s+(?:film|movie|tv\s*series|tv\s*show|television\s*series|serial))?\)\s*$',
        r'\s*[-:/,]?\s*(?:19|20)\d{2}\s*$',
        r'\s*[-:/,]?\s*(?:tv\s*series|tv\s*show|television\s*series|serial\s*tv|series\s*tv|serial|movie|film)\s*$',
    )
    for _ in range(3):
        changed = False
        for pattern in patterns:
            next_value = re.sub(pattern, '', cleaned, flags=re.I).strip(' -:/,')
            if next_value and next_value != cleaned:
                variants.add(next_value)
                cleaned = next_value
                changed = True
        if not changed:
            break
    for variant in list(variants):
        without_article = re.sub(r'^(?:the|a|an)\s+', '', variant, flags=re.I).strip()
        if without_article and without_article != variant:
            variants.add(without_article)
    keys = set()
    for variant in variants:
        key = _ai_title_key(variant)
        if key:
            keys.add(key)
    return keys


def _ai_rejected_title_variants(ai_data, fallback=''):
    titles = []

    def _add(value):
        value = u'{}'.format(value or '').strip()
        if value and value not in titles:
            titles.append(value)

    _add(fallback)
    if isinstance(ai_data, dict):
        for field in ('confirmation_title', 'search_query', 'title', 'english_title', 'pl_title', 'original_title'):
            _add(ai_data.get(field))
    return titles


def _ai_is_rejection_text(text):
    folded = _ai_fold_text(text or '').strip()
    return folded in (
        'nie', 'no', 'to nie', 'to nie ten', 'to nie to', 'nie ten', 'nie to',
        'pudlo', 'pudło', 'zly', 'zły', 'zly tytul', 'zły tytuł'
    )


def _ai_candidate_title_keys(item):
    if not isinstance(item, dict):
        return _ai_title_keys(item)
    keys = set()
    for field in ('title', 'search_query', 'confirmation_title', 'english_title', 'pl_title', 'original_title'):
        keys.update(_ai_title_keys(item.get(field) or ''))
    return keys


def _ai_filter_rejected_titles(ai_data, rejected_titles):
    if not isinstance(ai_data, dict) or not rejected_titles:
        return ai_data
    rejected = set()
    for title in rejected_titles:
        rejected.update(_ai_title_keys(title))
    if not rejected:
        return ai_data
    data = dict(ai_data)
    title_keys = set()
    for field in ('confirmation_title', 'search_query', 'title', 'english_title', 'pl_title', 'original_title'):
        title_keys.update(_ai_title_keys(data.get(field) or ''))
    title_blocked = bool(title_keys & rejected)
    if title_blocked:
        data['ready_to_confirm'] = False
        data['confirmation_title'] = None
        data['search_query'] = None
    candidates = data.get('candidates') or []
    removed = 0
    if isinstance(candidates, list):
        filtered = []
        for item in candidates:
            if _ai_candidate_title_keys(item) & rejected:
                removed += 1
                continue
            filtered.append(item)
        data['candidates'] = filtered
        if removed:
            try:
                log('[AI_SEARCH] rejected title filter removed={} remaining={}'.format(removed, len(filtered)), 1)
            except Exception:
                pass
    if (title_blocked or removed) and not data.get('ready_to_confirm') and not data.get('candidates'):
        data['assistant_message'] = u'Odrzucony tytuł został usunięty z wyników.'
        data['next_question'] = data.get('next_question') or u'Mniej więcej z jakich lat produkcji/premiery to może być?'
        data['confirmation_title'] = None
        data['search_query'] = None
    return data


def _build_mini_chat_prompt(history):
    conv_lines = []
    for item in history[-8:]:
        role = u'UZYTKOWNIK' if item.get('role') == 'user' else u'AI'
        content = (item.get('content') or '').strip()
        if content:
            conv_lines.append(u'{}: {}'.format(role, content))
    conversation = u'\n'.join(conv_lines)
    user_clues = _ai_user_clues_for_prompt(history)
    recent_candidates = _ai_recent_candidates_for_prompt(history)
    rejected_titles = _ai_rejected_titles_for_prompt(history)
    requested_type = _ai_media_type_from_history(history)
    if requested_type == 'tv':
        type_directive = (
            u'\nTWARDY WARUNEK TYPU: uzytkownik prosi o SERIAL. '
            u'Zwracaj tylko kandydatow typu tv/serial, ustaw "type":"tv" i nie dodawaj filmow.\n'
        )
    elif requested_type == 'movie':
        type_directive = (
            u'\nTWARDY WARUNEK TYPU: uzytkownik prosi o FILM. '
            u'Zwracaj tylko kandydatow typu movie/film, ustaw "type":"movie" i nie dodawaj seriali.\n'
        )
    else:
        type_directive = u''

    return (
        u'Jesteś śledczym pomagającym ustalić tytuł filmu/serialu. Działasz jak wyszukiwarka Google.\n'
        u'Nawet przy krótkim tropie najpierw użyj web search i zwróć 3-6 hipotez w polu "candidates". '
        u'To są hipotezy wewnętrzne, nie lista do automatycznego pokazania użytkownikowi.\n'
        u'Jeśli nie masz 95% pewności, nie pokazuj tytułów użytkownikowi; ustaw ready_to_confirm=false i zadaj konkretne pytanie.\n'
        u'W odpowiedzi JSON wpisz "candidates" jako pierwsze pole. Dopiero potem krótki "assistant_message" maks. 110 znaków.\n'
        u'Dodaj też "voice_text": naturalne mówione zdanie po polsku maks. 80 znaków, bez czytania całej listy.\n'
        u'Jeśli masz PEWNOŚĆ (ponad 95%), ustaw ready_to_confirm=true i podaj dane.\n'
        u'Przy konkretnym tropie ready_to_confirm=true wolno ustawić tylko wtedy, gdy pasuje ten trop; sam kraj/gatunek/epoka nie wystarcza.\n'
        u'Jeśli nie masz 95% pewności, ustaw ready_to_confirm=false i zadaj jedno logiczne pytanie w "next_question".\n'
        u'Nie pisz "znalazłem", "mam tytuł" ani "to jest ten film", jeśli ready_to_confirm=false albo nie podajesz confirmation_title/search_query.\n'
        u'Jeśli kandydaci są z różnych krajów, języków, dekad, epok albo gatunków, ustaw "hide_candidates": true.\n\n'
        u'STYL ROZMOWY:\n'
        u'Rozmawiasz naturalnie, ale krótko — bez długich wyjaśnień i bez kilku zdań naraz.\n'
        u'Powiedz krótko, czego brakuje do pewności, ale nie wypisuj roboczej listy tytułów.\n'
        u'Naprowadzaj użytkownika żeby sobie przypomniał — nie pytaj sucho, pomóż mu myśleć.\n\n'
        u'MYŚLENIE O PEWNOŚCI (rób to zawsze przed odpowiedzią):\n'
        u'  1. Oceń swoją pewność dla każdego kandydata: czy mam 95%+ pewności dla któregoś?\n'
        u'  2. Jeśli TAK → ustaw ready_to_confirm=true dla tego kandydata.\n'
        u'  3. Jeśli NIE → sprawdź czy kandydaci różnią się krajem/językiem, dekadą/epoką, gatunkiem albo typem.\n'
        u'  4. Jeśli różnią się mocno, ustaw hide_candidates=true i NIE pokazuj tytułów użytkownikowi.\n'
        u'  5. Wybierz JEDEN brakujący element, który najbardziej zawęzi wyniki.\n'
        u'  6. Zadaj o to pytanie naturalnie — niezależnie od liczby kandydatów.\n\n'
        u'ZASADA: ZAWSZE pytaj gdy pewność jest niska.\n'
        u'Nie patrz na liczbę kandydatów — patrz na pewność.\n'
        u'2 kandydatów z pewnością 30% = MUSISZ zapytać.\n'
        u'1 kandydat z pewnością 95% = ready_to_confirm=true, nie pytaj.\n\n'
        u'ZASADA PAMIĘCI TROPÓW:\n'
        u'Nie gub pierwszego konkretnego tropu użytkownika, nawet jeśli rozmowa ma wiele rund. '
        u'Konkretny szczegół traktuj jako mocniejszy trop niż ogólne pytania o kraj/dekadę.\n'
        u'Nie pytaj drugi raz o lata, kraj, typ albo gatunek, jeśli użytkownik już to podał w swoich tropach.\n'
        u'Odróżniaj lata produkcji/premiery od czasu akcji w świecie filmu. To są dwa różne tropy.\n'
        u'Jeśli użytkownik podał lata produkcji/premiery, traktuj je jako twarde ograniczenie kandydatów.\n'
        u'Jeśli użytkownik odrzucił tytuł, nie proponuj go ponownie jako głównego wyniku ani jako alias.\n\n'
        u'STRATEGIA DLA KONKRETNEGO TROPU:\n'
        u'Sam oceń, który element opisu jest najbardziej nietypowy i najbardziej zawęża wyniki. '
        u'Nie korzystaj z gotowych przykładów scen ani przedmiotów; wyciągnij je wyłącznie z tekstu użytkownika. '
        u'Pytaj o wymiar, który rozróżnia kandydatów, a nie automatycznie o kraj/dekadę.\n\n'
        u'STRATEGIA PORÓWNAWCZA:\n'
        u'Jeśli użytkownik odnosi nowy trop do poprzednio pokazanych kandydatów, wykorzystaj to jako silne ograniczenie wyszukiwania. '
        u'Nie traktuj poprzednich kandydatów jako odpowiedzi, tylko jako punkty odniesienia.\n\n'
        u'STRATEGIA KRAJ + EPOKA + AKTORZY:\n'
        u'Jeśli użytkownik poda kraj/język i lata produkcji, szukaj najpierw tropów z tego kraju i dekady. '
        u'Gdy aktora nie pamięta, nie zgaduj go jako faktu, ale użyj kraju i dekady jako osi: znani aktorzy, filmy z epoki, scena/opis. '
        u'Przykład myślenia: Francja + lata 60-80 + scena -> francuskie filmy i aktorzy tej epoki, potem weryfikacja sceny.\n\n'
        u'W web search dla konkretnego tropu użyj 2-3 wariantów językowych/synonimów: polski + angielski/originalny, '
        u'tłumacząc tylko kluczowe elementy podane przez użytkownika.\n\n'
        u'ZASADA ANTY-ŚMIETNIK:\n'
        u'Jeśli masz kilka kandydatów z różnych krajów/epok/gatunków, assistant_message ma brzmieć jak: '
        u'"Mam kilka tropów z różnych krajów i epok." '
        u'Nie podawaj tytułów, numerów ani listy. Kandydaci zostają tylko w JSON.\n\n'
        u'JAK FORMUŁOWAĆ PYTANIE (next_question):\n'
        u'KROK 1 — porównaj kandydatów i tropy użytkownika bez używania gotowych przykładów.\n'
        u'KROK 2 — wybierz jeden brak, który najlepiej rozdziela kandydatów; nie wybieraj automatycznie kraju/dekady.\n'
        u'Jeśli produkcja i czas akcji mogą być różne, możesz zapytać konkretnie o czas akcji.\n'
        u'KROK 3 — zadaj jedno krótkie, naturalne pytanie, maks. 90 znaków, bez listy przykładów.\n'
        u'ZAKAZ: NIE pisz "podaj więcej szczegółów" — to Ty musisz naprowadzić, nie użytkownik.\n'
        u'ZAKAZ: NIE pytaj o coś co użytkownik już powiedział w historii.\n'
        u'ZAKAZ: NIE zadawaj suchej listy opcji — to ma być rozmowa, nie ankieta.\n'
        u'ZAKAZ: NIE dawaj przykładowych scen, przedmiotów ani gotowych odpowiedzi, jeśli nie pochodzą z tekstu użytkownika.\n\n' +
        type_directive +
        (u'WSZYSTKIE TROPY UŻYTKOWNIKA (nie gub ich):\n' + user_clues + u'\n\n' if user_clues else u'') +
        (u'OSTATNIO POKAZANI KANDYDACI (kontekst, nie odpowiedź):\n' + recent_candidates + u'\n\n' if recent_candidates else u'') +
        (u'ODRZUCONE TYTUŁY (nie proponuj ponownie, także jako alias):\n' + rejected_titles + u'\n\n' if rejected_titles else u'') +
        u'HISTORIA ROZMOWY:\n' + conversation +
        u'\n\nTwoja kolej. Odpowiedz WYŁĄCZNIE używając JSON.'
    )


_AI_CHAT_XML_FILE = 'FanVodPL_AIChat.xml'


class _AIChatXMLDialog(xbmcgui.WindowXMLDialog):
    CTRL_TITLE        = 100
    CTRL_CHAT_TEXT    = 101
    CTRL_HINT         = 102
    CTRL_TOKENS       = 103
    CTRL_INPUT        = 201
    CTRL_CANCEL       = 204
    CTRL_CLEAR        = 205
    CTRL_TMDB         = 206
    CTRL_YOUTUBE      = 207
    CTRL_POSTER       = 301
    CTRL_POSTER_TEXT  = 302
    CTRL_CANDIDATE_PREV = 480
    CTRL_CANDIDATE_NEXT = 481
    CTRL_CANDIDATE_PAGE = 482
    # ZMIANA (2026-05) [PATCH]: natywna lista mobilna kandydatow/plakatow tylko dla telefonu/tabletu Android.
    # POWOD: gest palcem dziala na prawdziwych listach Kodi, a statyczne grupy 410/430/450 nie sa naturalnie przewijalne dotykiem.
    # NIE ZMIENIAC: id=490 jest osobnym trybem mobilnym; Android TV/PC dalej uzywa kart 410/430/450.
    CTRL_CANDIDATE_MOBILE_LIST = 490
    # ZMIANA (2026-05) [PATCH]: dodatkowe duze przyciski dotykowe do przewijania listy kandydatow/plakatow na telefonie/tablecie Android.
    # POWOD: test uzytkownika potwierdzil, ze przewijany ma byc obszar kandydatow, a nie lista rozmowy AI id=101.
    # NIE ZMIENIAC: id=483/484 przewijaja te same karty kandydatow co 480/481; nie podpinac ich ponownie pod czat.
    CTRL_CANDIDATE_TOUCH_PREV = 483
    CTRL_CANDIDATE_TOUCH_NEXT = 484

    CANDIDATE_CARD_SLOTS = (
        {'group': 410, 'bg': 411, 'poster': 412, 'title': 413, 'reason': 414, 'desc': 415, 'trailer': 416, 'preview': 417, 'select': 418, 'cast': 419, 'related': 420},
        {'group': 430, 'bg': 431, 'poster': 432, 'title': 433, 'reason': 434, 'desc': 435, 'trailer': 436, 'preview': 437, 'select': 438, 'cast': 439, 'related': 440},
        {'group': 450, 'bg': 451, 'poster': 452, 'title': 453, 'reason': 454, 'desc': 455, 'trailer': 456, 'preview': 457, 'select': 458, 'cast': 459, 'related': 460},
    )

    def __init__(self, *args, **kwargs):
        import threading as _threading
        self._caller   = kwargs['caller']
        self._api_key  = kwargs['api_key']
        self._provider = kwargs.get('provider', '')
        self._history  = list(kwargs.get('history') or [])
        self.result    = {'action': 'cancel', 'ai_data': {}, 'history': []}
        self._lock         = _threading.Lock()
        self._thinking_idx = -1
        self._ai_data      = {}
        self._ready        = False
        self._busy         = False
        self._current_title = ''
        self._ai_usage_calls = 0
        self._ai_usage_total = 0
        self._ai_started_once = bool(self._history)
        self._preflight_done = bool(self._history)
        self._preflight_questions_asked = 0
        self._preflight_asked_fields = set()
        self._hidden_candidate_rounds = 0
        self._rejected_titles = []
        self._selected_candidate_index = 0
        self._youtube_url = ''
        self._candidate_card_rows = []
        self._candidate_scroll_offset = 0
        self._last_candidate_focus_id = 0
        self._candidate_scroll_focus_guard = False
        self._candidate_scroll_focus_guard_id = 0
        self._last_candidate_nav_action_id = 0
        self._touch_scroll_buttons = _ai_is_android_phone_touch_device()
        # ZMIANA (2026-05) [PATCH]: mobilna lista kandydatow nie zalezy juz od AUTO-detekcji, tylko od ustawienia KAFELKI/MOBILNA.
        # POWOD: jeden telefon dzialal w AUTO, drugi nie; reczne ustawienie usuwa ryzyko blednego rozpoznania modelu/DPI.
        # NIE ZMIENIAC: MOBILNA jest dodatkowo blokowana poza Androidem, wiec komputer i Android TV zostaja na starych kafelkach.
        self._candidate_view_mode = _ai_candidate_view_mode_setting()
        self._mobile_candidate_list = bool(_ai_candidate_mobile_forced())
        try:
            log('[AI_SEARCH] candidate view mode={} mobile_list={} android={}'.format(
                self._candidate_view_mode, self._mobile_candidate_list, _ai_android_platform()), 1)
        except Exception:
            pass

    def onInit(self):
        try:
            self.getControl(self.CTRL_TITLE).setLabel(u'FanVodPL AI — Asystent wyszukiwania')
        except Exception:
            pass
        self._set_token_usage()
        for msg in self._history:
            prefix = u'TY' if msg.get('role') == 'user' else u'AI'
            self._add_line(u'{}: {}'.format(prefix, msg.get('content', '')), role=msg.get('role'))

        if not self._history:
            self._add_line(u'AI: Cześć. Opisz film albo serial, a ja pomogę Ci go znaleźć.', role='assistant')
            self._set_hint(u'Przy konkretnym tropie od razu uruchomię AI/web search. Dopytam bez tokenów najwyżej raz, tylko gdy opis jest zbyt pusty.')
        else:
            self._start_ai_call()
        self._set_result_buttons(False)
        self._set_preview_panel('', '')
        self._clear_candidate_cards()

        # ZMIANA: focus na CTRL_INPUT tylko przy pierwszym otwarciu (brak historii)
        # POWOD: przy powrocie z odtwarzacza focus na CTRL_INPUT triggeruje klawiature Android
        #   ktora zakrywa okno i wyglada jak niebieski ekran. Bezpieczny focus na CTRL_CANCEL (204)
        #   renderuje okno poprawnie bez wywolywania klawiatury
        # NIE ZMIENIAC: CTRL_INPUT=201 (text input), CTRL_CANCEL=204 (przycisk Anuluj - nie triggeruje klawiatury)
        try:
            if not self._history:
                self.setFocusId(self.CTRL_INPUT)
            else:
                self.setFocusId(self.CTRL_CANCEL)
        except Exception:
            try:
                xbmc.sleep(100)
                self.setFocusId(self.CTRL_CANCEL)
            except Exception:
                pass

    def _set_hint(self, text):
        try:
            self.getControl(self.CTRL_HINT).setLabel(text or '')
        except Exception:
            pass

    def _set_token_usage(self, last_usage=None):
        try:
            if last_usage:
                total = _ai_token_int(last_usage.get('total'))
                self._ai_usage_calls += 1
                self._ai_usage_total += total
                label = u'Tokeny: {} ostatnio / {} razem'.format(total, self._ai_usage_total)
            else:
                label = u'Tokeny: {} razem'.format(self._ai_usage_total)
            self.getControl(self.CTRL_TOKENS).setLabel(label)
        except Exception:
            pass

    def _has_control(self, control_id):
        try:
            self.getControl(control_id)
            return True
        except Exception:
            return False

    def _set_control_enabled(self, control_id, enabled):
        try:
            self.getControl(control_id).setEnabled(bool(enabled))
        except Exception:
            pass

    def _set_control_visible(self, control_id, visible, enabled=None):
        try:
            ctrl = self.getControl(control_id)
            ctrl.setVisible(bool(visible))
            if enabled is not None:
                try:
                    ctrl.setEnabled(bool(enabled))
                except Exception:
                    pass
        except Exception:
            pass

    def _set_control_label(self, control_id, text):
        try:
            ctrl = self.getControl(control_id)
            try:
                ctrl.setLabel(text or '')
            except Exception:
                ctrl.setText(text or '')
        except Exception:
            pass

    def _set_control_image(self, control_id, image):
        try:
            self.getControl(control_id).setImage(image or '')
        except Exception:
            pass

    def _set_result_buttons(self, enabled):
        self._set_control_enabled(self.CTRL_TMDB, enabled)
        self._set_control_enabled(self.CTRL_YOUTUBE, enabled and bool(self._youtube_url))

    def _set_preview_panel(self, poster='', text=''):
        try:
            self.getControl(self.CTRL_POSTER).setImage(poster or '')
        except Exception:
            pass
        try:
            ctrl = self.getControl(self.CTRL_POSTER_TEXT)
            try:
                ctrl.setText(text or '')
            except Exception:
                ctrl.setLabel(text or '')
        except Exception:
            pass

    def _clear_chat(self):
        if self._busy:
            self._set_hint(u'AI jeszcze szuka. Poczekaj chwilę przed wyczyszczeniem rozmowy.')
            return
        self._history = []
        self._ai_data = {}
        self._ready = False
        self._current_title = ''
        self._selected_candidate_index = 0
        self._youtube_url = ''
        self._thinking_idx = -1
        self._ai_started_once = False
        self._preflight_done = False
        self._preflight_questions_asked = 0
        self._preflight_asked_fields = set()
        self._hidden_candidate_rounds = 0
        self._rejected_titles = []
        self._set_result_buttons(False)
        self._set_preview_panel('', '')
        self._clear_candidate_cards()
        try:
            self._ctrl().reset()
        except Exception:
            pass
        self._add_line(u'AI: Cześć. Opisz film albo serial, a ja pomogę Ci go znaleźć.', role='assistant')
        self._set_hint(u'Rozmowa wyczyszczona. Wpisz nowy opis filmu albo serialu.')
        try:
            self.setFocusId(self.CTRL_INPUT)
        except Exception:
            pass

    def _tmdb_auth(self):
        headers = _legal_research_headers()
        try:
            bearer = (control.setting('tm.user_bearer') or '').strip()
        except Exception:
            bearer = ''
        if bearer:
            if bearer.lower().startswith('bearer '):
                bearer = bearer[7:].strip()
            if bearer:
                headers['Authorization'] = 'Bearer ' + bearer
                return headers, ''
        try:
            from ptw.libraries import apis as _apis
            api_key = (control.setting('tm.user') or getattr(_apis, 'tmdb_API', '') or '').strip()
        except Exception:
            try:
                api_key = (control.setting('tm.user') or '').strip()
            except Exception:
                api_key = ''
        return headers, api_key

    def _candidate_basic_fields(self, item):
        if isinstance(item, dict):
            title = (
                item.get('title') or item.get('search_query') or item.get('confirmation_title') or
                item.get('english_title') or item.get('pl_title') or
                item.get('original_title') or item.get('name') or ''
            )
            year = item.get('year') or ''
            media_type = item.get('type') or item.get('media_type') or ''
        else:
            title = item
            year = ''
            media_type = ''
        return (
            u'{}'.format(title or '').strip(),
            u'{}'.format(year or '').strip(),
            _ai_normalize_media_type(media_type),
        )

    def _candidate_explicit_poster(self, item):
        if not isinstance(item, dict):
            return ''
        for key in ('poster', 'poster_url', 'poster_path', 'thumbnail', 'thumb', 'image'):
            value = item.get(key)
            if isinstance(value, dict):
                value = value.get('url') or value.get('path')
            if isinstance(value, list):
                value = value[0] if value else ''
            value = u'{}'.format(value or '').strip()
            if not value:
                continue
            if value.startswith('//'):
                return 'https:' + value
            if value.startswith('/'):
                return 'https://image.tmdb.org/t/p/w185' + value
            if value.startswith('http'):
                return value
        return ''

    def _candidate_english_title(self, item):
        # ZMIANA (2026-05) [P3]: wyciąga angielski/oryginalny tytuł z kandydata do fallback search TMDB.
        # POWOD: kandydaci zagraniczni mają polski tytuł jako 'title' (np. 'Święty'), ale TMDB może trafić
        #        na nowy polski serial o tej nazwie; english_title ('The Saint') daje jednoznaczne trafienie.
        # NIE ZMIENIAC: zwraca '' gdy brak — fallback jest opcjonalny, nie blokuje głównego flow.
        if not isinstance(item, dict):
            return ''
        return u'{}'.format(item.get('english_title') or item.get('original_title') or '').strip()

    def _tmdb_best_match(self, queries, year, media_type, need_poster, headers, api_key, requests_mod, timeout=3.0):
        # ZMIANA (2026-05) [P1+P3]: wspólna logika scoringu TMDB dla poster i preview.
        # POWOD: poprzednia duplikacja kodu utrudniała spójną poprawkę scoringu (P1: kara za rok) i
        #        fallback po angielskim tytule (P3). Teraz obie funkcje używają jednego miejsca.
        # NIE ZMIENIAC: queries to lista tytułów — pierwszy to polski, kolejny to english_title (fallback).
        #        Scoring jest globalny: wygrywa najlepszy wynik ze wszystkich queries łącznie.
        try:
            from urllib.parse import quote as _quote
        except ImportError:
            from urllib import quote as _quote
        if media_type == 'tv':
            endpoints = (('tv', 'first_air_date_year'),)
        elif media_type == 'movie':
            endpoints = (('movie', 'year'),)
        else:
            endpoints = (('multi', ''),)
        best_item = None
        best_endpoint = ''
        best_score = -1
        for query_title in (queries or []):
            query_title = u'{}'.format(query_title or '').strip()
            if not query_title:
                continue
            try:
                query = _quote(query_title)
            except Exception:
                query = _quote(query_title.encode('utf-8'))
            query_fold = _ai_fold_text(query_title)
            for endpoint, year_param in endpoints:
                url = 'https://api.themoviedb.org/3/search/{}?language=pl-PL&query={}&page=1'.format(endpoint, query)
                if api_key:
                    url += '&api_key=' + api_key
                if year and year_param:
                    url += '&{}={}'.format(year_param, year)
                try:
                    r = requests_mod.get(url, headers=headers or None, timeout=timeout)
                    r.raise_for_status()
                except Exception as exc:
                    log('[AI_SEARCH] TMDB search error: {}'.format(_safe_exception_text(exc, 80)), 1)
                    continue
                for result in (r.json().get('results') or [])[:8]:
                    if endpoint == 'multi' and result.get('media_type') not in ('movie', 'tv'):
                        continue
                    if need_poster and not result.get('poster_path'):
                        continue
                    titles = (
                        result.get('title'), result.get('name'),
                        result.get('original_title'), result.get('original_name'),
                    )
                    folded_titles = [_ai_fold_text(x or '') for x in titles if x]
                    score = 1
                    if query_fold and any(query_fold == x for x in folded_titles):
                        score += 60
                    elif query_fold and any(query_fold in x or x in query_fold for x in folded_titles):
                        score += 25
                    result_year = str((result.get('release_date') or result.get('first_air_date') or '')[:4])
                    # P1: kara za odległość roku — dominuje nad popularnością nowego show
                    if year and result_year:
                        if result_year == year:
                            score += 30
                        else:
                            try:
                                diff = abs(int(result_year) - int(year))
                                if diff > 5:
                                    score -= 80
                                elif diff > 2:
                                    score -= 20
                            except Exception:
                                pass
                    if result.get('poster_path'):
                        score += 5
                    if result.get('overview'):
                        score += 5
                    try:
                        score += min(float(result.get('popularity') or 0), 50.0) / 100.0
                    except Exception:
                        pass
                    if score > best_score:
                        best_item = result
                        best_endpoint = endpoint
                        best_score = score
        return best_item, best_endpoint, best_score

    def _tmdb_verify_requested_candidate_type(self, item, requested_type, headers, api_key, requests_mod):
        requested_type = _ai_normalize_media_type(requested_type)
        if requested_type not in ('movie', 'tv') or requests_mod is None:
            return None
        title, year, _media_type = self._candidate_basic_fields(item)
        title = u'{}'.format(title or '').strip()
        if not title:
            return False
        english_title = self._candidate_english_title(item)
        if not re.match(r'^\d{4}$', year or ''):
            _ym = re.search(r'((?:19|20)\d{2})', year or '')
            year = _ym.group(1) if _ym else ''
        cache_key = u'{}|{}|{}|{}'.format(
            requested_type, _ai_fold_text(title), year, _ai_fold_text(english_title)
        )
        if cache_key in _AI_REQUESTED_MEDIA_VERIFY_CACHE:
            cached = _AI_REQUESTED_MEDIA_VERIFY_CACHE.get(cache_key)
            return dict(cached) if isinstance(cached, dict) else cached
        try:
            from urllib.parse import quote as _quote
        except ImportError:
            from urllib import quote as _quote
        endpoint = 'tv' if requested_type == 'tv' else 'movie'
        year_param = 'first_air_date_year' if requested_type == 'tv' else 'year'
        queries = [title]
        if english_title and _ai_fold_text(english_title) != _ai_fold_text(title):
            queries.append(english_title)
        best_item = None
        best_score = -1
        had_response = False
        had_error = False
        for query_title in queries:
            query_title = u'{}'.format(query_title or '').strip()
            if not query_title:
                continue
            try:
                query = _quote(query_title)
            except Exception:
                query = _quote(query_title.encode('utf-8'))
            url = 'https://api.themoviedb.org/3/search/{}?language=pl-PL&query={}&page=1'.format(endpoint, query)
            if api_key:
                url += '&api_key=' + api_key
            if year:
                url += '&{}={}'.format(year_param, year)
            try:
                response = requests_mod.get(url, headers=headers or None, timeout=2.5)
                response.raise_for_status()
                had_response = True
                results = (response.json().get('results') or [])[:8]
            except Exception as exc:
                had_error = True
                log('[AI_SEARCH] requested media_type verify TMDB error: {}'.format(
                    _safe_exception_text(exc, 100)), 1)
                continue
            query_fold = _ai_fold_text(query_title)
            for result in results:
                titles = (
                    result.get('title'), result.get('name'),
                    result.get('original_title'), result.get('original_name'),
                )
                folded_titles = [_ai_fold_text(x or '') for x in titles if x]
                score = 1
                if query_fold and any(query_fold == x for x in folded_titles):
                    score += 60
                elif query_fold and any(query_fold in x or x in query_fold for x in folded_titles):
                    score += 25
                result_year = str((result.get('release_date') or result.get('first_air_date') or '')[:4])
                if year and result_year:
                    if result_year == year:
                        score += 30
                    else:
                        try:
                            diff = abs(int(result_year) - int(year))
                            if diff > 5:
                                score -= 80
                            elif diff > 2:
                                score -= 20
                        except Exception:
                            pass
                if result.get('poster_path'):
                    score += 5
                if result.get('overview'):
                    score += 5
                try:
                    score += min(float(result.get('popularity') or 0), 50.0) / 100.0
                except Exception:
                    pass
                if score > best_score:
                    best_score = score
                    best_item = result
        if not had_response and had_error:
            _AI_REQUESTED_MEDIA_VERIFY_CACHE[cache_key] = None
            return None
        if not best_item or best_score < 20:
            _AI_REQUESTED_MEDIA_VERIFY_CACHE[cache_key] = False
            return False
        payload = {'item': best_item, 'score': best_score}
        _AI_REQUESTED_MEDIA_VERIFY_CACHE[cache_key] = payload
        return dict(payload)

    def _filter_requested_media_type_candidates(self, ai_data):
        if not isinstance(ai_data, dict):
            return ai_data
        requested_type = _ai_normalize_media_type(ai_data.get('_requested_media_type') or '')
        requested_type = requested_type or _ai_media_type_from_history(self._history)
        if requested_type not in ('movie', 'tv'):
            return ai_data
        candidates = ai_data.get('candidates') or []
        if not isinstance(candidates, list) or not candidates:
            return ai_data
        try:
            headers, api_key = self._tmdb_auth()
            if not api_key and not (headers or {}).get('Authorization'):
                log('[AI_SEARCH] requested media_type verify skipped: missing TMDB credentials', 1)
                return ai_data
            import requests as _requests
        except Exception as exc:
            log('[AI_SEARCH] requested media_type verify unavailable: {}'.format(
                _safe_exception_text(exc, 120)), 1)
            return ai_data
        verified = []
        unavailable = 0
        rejected = 0
        for item in candidates:
            check = self._tmdb_verify_requested_candidate_type(
                item, requested_type, headers, api_key, _requests,
            )
            if check is None:
                unavailable += 1
                continue
            if not check:
                rejected += 1
                continue
            title, year, _media_type = self._candidate_basic_fields(item)
            fixed = dict(item) if isinstance(item, dict) else {'title': title}
            fixed['type'] = requested_type
            fixed['media_type'] = requested_type
            tmdb_item = check.get('item') if isinstance(check, dict) else {}
            if isinstance(tmdb_item, dict):
                result_year = str((tmdb_item.get('release_date') or tmdb_item.get('first_air_date') or '')[:4])
                if result_year and not re.match(r'^\d{4}$', u'{}'.format(fixed.get('year') or '')):
                    fixed['year'] = result_year
                poster_path = tmdb_item.get('poster_path') or ''
                if poster_path and not fixed.get('poster'):
                    fixed['poster'] = 'https://image.tmdb.org/t/p/w185' + poster_path
                fixed['_tmdb_verified_media_type'] = requested_type
            verified.append(fixed)
        data = dict(ai_data)
        if verified:
            data['candidates'] = verified
            log('[AI_SEARCH] requested media_type verified type={} kept={} rejected={} unavailable={}'.format(
                requested_type, len(verified), rejected, unavailable), 1)
            return data
        if unavailable and not rejected:
            log('[AI_SEARCH] requested media_type verify fallback: TMDB unavailable for all candidates type={}'.format(
                requested_type), 1)
            return ai_data
        data['candidates'] = []
        data['ready_to_confirm'] = False
        data['confirmation_title'] = ''
        data['search_query'] = ''
        data['assistant_message'] = (
            u'Nie znalazlem kandydatow zgodnych z prosba: {}. Dopisz jeszcze jeden szczegol.'
        ).format(u'serial' if requested_type == 'tv' else u'film')
        log('[AI_SEARCH] requested media_type verified type={} kept=0 rejected={} unavailable={}'.format(
            requested_type, rejected, unavailable), 1)
        return data

    def _fetch_candidate_poster(self, title, year='', media_type='', english_title=''):
        title = u'{}'.format(title or '').strip()
        year = u'{}'.format(year or '').strip()
        media_type = _ai_normalize_media_type(media_type)
        english_title = u'{}'.format(english_title or '').strip()
        if not title:
            return ''
        # ZMIANA (2026-05) [BUGFIX]: rok zakresowy "1962-1969" → wyciągnij rok startowy zamiast zerować.
        # POWOD: re.match(^\d{4}$) odrzucał zakresy → year='' → TMDB bez filtra → błędny wynik.
        # NIE ZMIENIAC: jeśli year już jest dokładnym 4-cyfrowym rokiem, nic się nie zmienia.
        if not re.match(r'^\d{4}$', year or ''):
            _ym = re.search(r'((?:19|20)\d{2})', year or '')
            year = _ym.group(1) if _ym else ''
        cache_key = u'{}|{}|{}|{}'.format(media_type, _ai_fold_text(title), year, _ai_fold_text(english_title))
        if cache_key in _AI_CANDIDATE_POSTER_CACHE:
            return _AI_CANDIDATE_POSTER_CACHE.get(cache_key) or ''
        try:
            headers, api_key = self._tmdb_auth()
            if not api_key and not headers.get('Authorization'):
                _AI_CANDIDATE_POSTER_CACHE[cache_key] = ''
                return ''
            import requests as _requests
            # P3: próbuj po polskim tytule, fallback po angielskim gdy różny
            queries = [title]
            if english_title and _ai_fold_text(english_title) != _ai_fold_text(title):
                queries.append(english_title)
            best_item, _, _ = self._tmdb_best_match(
                queries, year, media_type, need_poster=True,
                headers=headers, api_key=api_key, requests_mod=_requests, timeout=2.5,
            )
            poster = ''
            if best_item:
                poster = 'https://image.tmdb.org/t/p/w185' + best_item.get('poster_path')
            _AI_CANDIDATE_POSTER_CACHE[cache_key] = poster
            return poster
        except Exception as exc:
            log('[AI_SEARCH] candidate poster fetch ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        _AI_CANDIDATE_POSTER_CACHE[cache_key] = ''
        return ''

    def _candidate_poster(self, item, title='', year='', media_type=''):
        poster = self._candidate_explicit_poster(item)
        if poster:
            return poster
        english_title = self._candidate_english_title(item)
        return self._fetch_candidate_poster(title, year, media_type, english_title=english_title)

    def _tmdb_web_url(self, media_endpoint, tmdb_id, title='', suffix=''):
        media_endpoint = (media_endpoint or '').strip()
        tmdb_id = u'{}'.format(tmdb_id or '').strip()
        if media_endpoint not in ('movie', 'tv') or not tmdb_id:
            return ''
        slug = re.sub(r'[^a-z0-9]+', '-', _ai_fold_text(title or '')).strip('-')
        tmdb_part = tmdb_id + (('-' + slug) if slug else '')
        suffix = ('/' + suffix.strip('/')) if suffix else ''
        return u'https://www.themoviedb.org/{}/{}{}?language=pl-PL'.format(media_endpoint, tmdb_part, suffix)

    def _fetch_candidate_preview(self, title, year='', media_type='', include_trailer=True, english_title=''):
        title = u'{}'.format(title or '').strip()
        year = u'{}'.format(year or '').strip()
        media_type = _ai_normalize_media_type(media_type)
        english_title = u'{}'.format(english_title or '').strip()
        if not title:
            return {'poster': '', 'overview': ''}
        # ZMIANA (2026-05) [BUGFIX]: rok zakresowy "1962-1969" → wyciągnij rok startowy zamiast zerować.
        # POWOD: re.match(^\d{4}$) odrzucał zakresy → year='' → TMDB bez filtra → błędny wynik.
        # NIE ZMIENIAC: jeśli year już jest dokładnym 4-cyfrowym rokiem, nic się nie zmienia.
        if not re.match(r'^\d{4}$', year or ''):
            _ym = re.search(r'((?:19|20)\d{2})', year or '')
            year = _ym.group(1) if _ym else ''
        cache_key = u'{}|{}|{}|{}'.format(media_type, _ai_fold_text(title), year, _ai_fold_text(english_title))
        if cache_key in _AI_CANDIDATE_PREVIEW_CACHE:
            cached = _AI_CANDIDATE_PREVIEW_CACHE.get(cache_key) or {'poster': '', 'overview': ''}
            if not include_trailer or cached.get('_trailer_loaded') or cached.get('youtube_url'):
                return cached
        payload = {'poster': '', 'overview': '', 'tmdb_url': '', 'cast_url': '', '_trailer_loaded': False}
        try:
            headers, api_key = self._tmdb_auth()
            if not api_key and not headers.get('Authorization'):
                _AI_CANDIDATE_PREVIEW_CACHE[cache_key] = payload
                return payload
            import requests as _requests
            # P3: próbuj po polskim tytule, fallback po angielskim gdy różny
            queries = [title]
            if english_title and _ai_fold_text(english_title) != _ai_fold_text(title):
                queries.append(english_title)
            best_item, best_endpoint, _ = self._tmdb_best_match(
                queries, year, media_type, need_poster=False,
                headers=headers, api_key=api_key, requests_mod=_requests, timeout=3.5,
            )
            if best_item:
                poster_path = best_item.get('poster_path') or ''
                media_endpoint = best_item.get('media_type') or best_endpoint
                tmdb_id = best_item.get('id') or ''
                tmdb_title = best_item.get('title') or best_item.get('name') or title
                payload = {
                    'poster': ('https://image.tmdb.org/t/p/w342' + poster_path) if poster_path else '',
                    'overview': u' '.join((best_item.get('overview') or '').split()),
                    'youtube_url': self._fetch_tmdb_trailer_url(best_item, media_endpoint, headers, api_key, _requests) if include_trailer else '',
                    'tmdb_url': self._tmdb_web_url(media_endpoint, tmdb_id, tmdb_title),
                    'cast_url': self._tmdb_web_url(media_endpoint, tmdb_id, tmdb_title, 'cast'),
                    '_trailer_loaded': bool(include_trailer),
                }
        except Exception as exc:
            log('[AI_SEARCH] candidate preview fetch ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        _AI_CANDIDATE_PREVIEW_CACHE[cache_key] = payload
        return payload

    def _prefetch_candidate_voices_bg(self, candidate_rows):
        # ZMIANA (2026-05) [PERFORMANCE]: pre-fetch TMDB + pre-generowanie TTS w tle po wyswietleniu kandydatow.
        # POWOD: uzytkownik czekal ~10s na glos Podgladu; ta metoda wypelnia cache podczas czytania listy.
        # NIE ZMIENIAC: request_id=-999 gwarantuje ze _ai_voice_request_is_current() = False
        #        → xbmc.Player().play() NIGDY nie jest wywolany podczas pre-generowania.
        # BUGFIX (include_trailer): prefetch uzywa include_trailer=True (tak samo jak _preview_candidate_choice)
        #        → main thread znajdzie _trailer_loaded=True w cache → TMDB nie fetchowany ponownie (oszczedza 2s).
        # PERFORMANCE (prefetch delay): pierwszy kandydat generuje glos po 2s, kolejne po 8s.
        #        -> najczestszy Podglad startuje szybciej, a dalsze pozycje nadal mniej obciazaja Gemini API.
        if not _ai_voice_enabled() or not _ai_voice_preview_enabled():
            return
        import time as _time
        try:
            base_request_id = int(_AI_VOICE_REQUEST_SEQ)
        except Exception:
            base_request_id = 0
        # ZMIANA (2026-05) [PERFORMANCE]: TTS pre-generowane tylko dla 3 pierwszych kandydatów.
        # POWOD: 7 kandydatów × TTS Gemini powodowalo 429 (widoczne w logu: key rotation podczas prefetcha).
        #        3 kandydatow pokrywa najczesciej klikane pozycje; TMDB pozostaje dla wszystkich.
        # NIE ZMIENIAC: TMDB fetch nizej pozostaje bez limitu — jest szybki i nie wywoluje 429.
        tts_limit = 3
        for tts_idx, row in enumerate(candidate_rows or []):
            try:
                title = row.get('title') or ''
                year = row.get('year') or ''
                media_type = row.get('media_type') or ''
                item = row.get('item') or {}
                if not title:
                    continue
                english_title = self._candidate_english_title(item)
                # Pre-fetch TMDB z include_trailer=True — identyczne jak w _preview_candidate_choice
                # → main thread znajdzie cache hit z _trailer_loaded=True
                preview = self._fetch_candidate_preview(
                    title, year, media_type, include_trailer=True, english_title=english_title,
                )
                log('[AI_SEARCH] prefetch TMDB cached title={}'.format(
                    _redact_ai_secrets(title[:60])), 1)
                # Pre-generuj TTS tylko dla pierwszych 3 kandydatów
                if tts_idx >= tts_limit:
                    continue
                # First candidate gets voice cache sooner; later candidates keep the old delay to protect Gemini quota.
                prefetch_voice_delay = 2 if tts_idx == 0 else 8
                log('[AI_SEARCH] prefetch voice delay={}s title={}'.format(
                    prefetch_voice_delay, _redact_ai_secrets(title[:60])), 1)
                _time.sleep(prefetch_voice_delay)
                try:
                    if int(_AI_VOICE_REQUEST_SEQ) != base_request_id:
                        log('[AI_SEARCH] prefetch voice skipped: newer voice request active title={}'.format(
                            _redact_ai_secrets(title[:60])), 1)
                        continue
                except Exception:
                    pass
                overview = preview.get('overview') or ''
                voice_text = _ai_voice_build_preview_text(title, year, media_type, overview)
                if voice_text:
                    _ai_voice_speak(voice_text, request_id=-999, limit=1200)
                    log('[AI_SEARCH] prefetch voice cached title={}'.format(
                        _redact_ai_secrets(title[:60])), 1)
            except Exception as exc:
                log('[AI_SEARCH] prefetch voice bg error: {}'.format(_safe_exception_text(exc, 80)), 1)

    def _fetch_tmdb_trailer_url(self, item, media_endpoint, headers, api_key, requests_mod):
        media_endpoint = (media_endpoint or '').strip()
        tmdb_id = item.get('id') if isinstance(item, dict) else ''
        if media_endpoint not in ('movie', 'tv') or not tmdb_id:
            return ''
        for lang, include_langs in (('pl-PL', 'pl-PL,pl,en-US,en'), ('en-US', '')):
            try:
                url = 'https://api.themoviedb.org/3/{}/{}/videos?language={}'.format(media_endpoint, tmdb_id, lang)
                if include_langs:
                    url += '&include_video_language=' + include_langs
                if api_key:
                    url += '&api_key=' + api_key
                r = requests_mod.get(url, headers=headers or None, timeout=3.5)
                r.raise_for_status()
                trailer = self._select_tmdb_trailer((r.json() or {}).get('results') or [], preferred_lang='pl' if lang == 'pl-PL' else '')
                if trailer:
                    return trailer
            except Exception as exc:
                log('[AI_SEARCH] TMDB trailer fetch ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        return ''

    def _select_tmdb_trailer(self, videos, preferred_lang=''):
        preferred_lang = (preferred_lang or '').lower()[:2]
        dubbing_markers = ('dubbing', 'dubbing pl', 'polski dubbing', 'z dubbingiem', 'po polsku', 'wersja polska', 'polska wersja', 'pl dubbing', 'dubbingowany')
        subtitle_markers = ('napisy', 'napisy pl', 'polskie napisy', 'sub pl', 'subtitles')
        polish_markers = ('zwiastun', 'polski', 'polska', 'lektor', 'napisy pl', 'pl zwiastun') + dubbing_markers
        candidates = []
        for video in videos or []:
            if not isinstance(video, dict):
                continue
            if (video.get('site') or '').lower() != 'youtube':
                continue
            key = (video.get('key') or '').strip()
            if not key:
                continue
            video_type = (video.get('type') or '').lower()
            name = _ai_fold_text(video.get('name') or '')
            iso_lang = (video.get('iso_639_1') or '').lower()
            iso_region = (video.get('iso_3166_1') or '').upper()
            has_dubbing_marker = any(marker in name for marker in dubbing_markers)
            has_subtitle_marker = any(marker in name for marker in subtitle_markers)
            score = 1
            if preferred_lang == 'pl':
                if iso_lang == 'pl':
                    score += 120
                if iso_region == 'PL':
                    score += 30
                if has_dubbing_marker:
                    score += 220
                elif has_subtitle_marker:
                    score += 10
                if any(marker in name for marker in polish_markers):
                    score += 45
            if video_type == 'trailer':
                score += 50
            elif video_type == 'teaser':
                score += 20
            if video.get('official'):
                score += 20
            if 'trailer' in name or 'zwiastun' in name:
                score += 15
            if 'official' in name or 'oficjal' in name:
                score += 10
            candidates.append((score, video.get('published_at') or '', key))
        if not candidates:
            return ''
        candidates.sort(key=lambda row: (row[0], row[1]), reverse=True)
        return 'https://www.youtube.com/watch?v=' + candidates[0][2]

    def _add_wrapped_lines(self, text, role='assistant', icon=''):
        text = u' '.join((text or '').split())
        if not text:
            return
        words = text.split()
        line = ''
        first = True
        for word in words:
            candidate = (line + ' ' + word).strip()
            if line and len(candidate) > 105:
                self._add_line((u'AI: ' if first else u'AI:    ') + line, role=role, icon=icon if first else '')
                first = False
                line = word
            else:
                line = candidate
        if line:
            self._add_line((u'AI: ' if first else u'AI:    ') + line, role=role, icon=icon if first else '')

    def _preview_candidate_choice(self, text, speak=True):
        match = re.match(r'^\s*(\d{1,2})\s*$', text or '')
        if not match:
            return False
        index = int(match.group(1))
        candidates = (self._ai_data or {}).get('candidates') or []
        if not isinstance(candidates, list) or index < 1 or index > len(candidates):
            return False
        item = candidates[index - 1]
        title, year, media_type = self._candidate_basic_fields(item)
        if not title:
            return False

        # ZMIANA (2026-05) [BUGFIX]: natychmiast unieważnij in-flight TTS i zatrzymaj player przed fetchem preview.
        # POWOD: stary TTS (lista kandydatów) kończył się podczas ~3.5s blokującego fetchu TMDB i wywoływał
        #        xbmc.Player().play() z własnym audio — użytkownik słyszał głos z listy zamiast opisu podglądu.
        #        Inkrementacja seq PRZED fetchem sprawia, że stary wątek sprawdzi is_current → False → pominie play().
        #        Dodatkowy stop() czyści player jeśli audio zdążyło już wystartować przed inkrementacją.
        # NIE ZMIENIAC: _ai_voice_next_request_id musi być wywołane PRZED fetch i PRZED kolejnym _ai_voice_speak_async.
        try:
            _ai_voice_next_request_id()
        except Exception:
            pass
        try:
            _player = xbmc.Player()
            if _player.isPlaying():
                _player.stop()
        except Exception:
            pass

        self._add_line(u'TY: ' + (text or '').strip(), role='user')
        self._history.append({'role': 'user', 'content': (text or '').strip()})

        full_preview_voice = bool(speak and _ai_voice_preview_enabled())
        if full_preview_voice:
            self._set_hint(u'Przygotowuje pelny opis glosowy. Wlaczy sie automatycznie po przygotowaniu audio...')
            try:
                control.infoDialog(
                    'Przygotowuje pelny opis glosowy...',
                    heading='Glos AI',
                    icon='INFO',
                    time=2500,
                    sound=False,
                )
            except Exception as exc:
                log('[AI_VOICE] preview loading notice skipped: {}'.format(_safe_exception_text(exc, 120)), 1)

        if full_preview_voice and _ai_android_tv_platform():
            intro_voice_text = _ai_voice_build_preview_intro_text(title, year, media_type)
            if intro_voice_text:
                _ai_voice_speak_async(intro_voice_text, source='preview_intro')

        preview = self._fetch_candidate_preview(title, year, media_type, english_title=self._candidate_english_title(item))
        poster = preview.get('poster') or self._candidate_poster(item, title, year, media_type)
        overview = preview.get('overview') or ''
        self._youtube_url = preview.get('youtube_url') or ''
        display_title = title + (u' ({})'.format(year) if year else '')
        panel_text = u'Wybrany kandydat {}:\n{}\n\n{}'.format(
            index,
            display_title,
            overview or u'Brak opisu z TMDB.'
        )
        self._set_preview_panel(poster, panel_text)

        # ZMIANA (2026-05) [FEATURE]: po kliknięciu Podgląd TTS czyta krótki opis filmu/serialu.
        # POWOD: użytkownik chce efekt narratora przy podglądzie, bez dodatkowego czekania na nowe AI-search.
        # NIE ZMIENIAC: używamy już pobranego opisu TMDB i obecnego TTS/cache; nie zmienia to wyboru kandydata ani wyszukiwania Kodi.
        if speak:
            preview_voice_text = _ai_voice_build_preview_text(title, year, media_type, overview)
            if preview_voice_text:
                _ai_voice_speak_async(preview_voice_text, source='preview')

        data = dict(self._ai_data or {})
        if isinstance(item, dict):
            data.update(item)
        data['ready_to_confirm'] = True
        data['confirmation_title'] = title
        data['search_query'] = title
        data['year'] = year
        if media_type:
            data['type'] = media_type
        self._ai_data = data
        self._ready = True
        self._current_title = title
        self._selected_candidate_index = index
        self._set_result_buttons(True)

        self._add_line(u'AI: Podgląd kandydata {}: {}'.format(index, display_title), role='assistant', icon=poster)
        if overview:
            self._add_wrapped_lines(u'Pełny opis: ' + overview, role='assistant')
        else:
            self._add_line(u'AI: Brak opisu z TMDB dla tego kandydata.', role='assistant')
        if self._youtube_url:
            self._add_line(u'AI: Zwiastun TMDB jest gotowy pod przyciskiem. Jeśli to ten tytuł, wpisz TAK, a wyszukam go w Kodi.', role='assistant')
        else:
            self._add_line(u'AI: TMDB nie zwróciło zwiastuna dla tego kandydata. Jeśli to ten tytuł, wpisz TAK, a wyszukam go w Kodi.', role='assistant')
        self._add_line(u'AI: Jeśli to nie ten tytuł, wpisz inny numer albo dopisz szczegół.', role='assistant')
        if full_preview_voice:
            self._set_hint(u'Podglad kandydata {}. Pelny opis glosowy wlaczy sie automatycznie. Zwiastun TMDB {}.'.format(
                index, u'gotowy' if self._youtube_url else u'niedostepny'))
        else:
            self._set_hint(u'Podgląd kandydata {}. Zwiastun TMDB {}. Wpisz TAK, inny numer albo dopisz szczegół.'.format(
                index, u'gotowy' if self._youtube_url else u'niedostępny'))
        log('[AI_SEARCH] AI chat candidate preview index={} title={}'.format(
            index, _redact_ai_secrets(title[:80])), 1)
        return True

    def _candidate_card_title(self, index, row):
        title = row.get('title') or ''
        year = row.get('year') or ''
        text = u'{}. {}'.format(index, title)
        if year:
            text += u' ({})'.format(year)
        return text

    def _candidate_card_reason(self, row):
        reason = row.get('reason') or ''
        confidence = row.get('confidence') or ''
        parts = []
        if confidence:
            parts.append(u'pewność {}%'.format(confidence))
        if reason:
            parts.append(reason)
        if not parts:
            parts.append(u'AI wskazało ten tytuł jako możliwego kandydata.')
        return u'Dlaczego pasuje: ' + u' - '.join(parts)

    # ZMIANA (2026-05) [PATCH]: typ kandydata do akcji „Części serii” jest dociągany z TMDB, jeśli AI nie podało media_type.
    # POWÓD: po v12 filmy bez jawnego media_type, np. „The Matrix (1999)”, traciły przycisk „Części serii”, mimo że seriale miały pozostać ukryte.
    # NIE ZMIENIAĆ: akcję pokazujemy wyłącznie po potwierdzeniu typu movie; seriale i typy niepewne nadal nie mogą dostać „Części serii”.
    def _infer_candidate_media_type(self, row):
        row = row if isinstance(row, dict) else {}
        media_type = _ai_normalize_media_type(row.get('media_type') or row.get('type') or '')
        if media_type in ('movie', 'tv'):
            return media_type
        inferred = _ai_normalize_media_type(row.get('_inferred_media_type') or '')
        if inferred in ('movie', 'tv'):
            return inferred
        title = u'{}'.format(row.get('title') or row.get('search_query') or '').strip()
        year = u'{}'.format(row.get('year') or '').strip()
        if not title:
            return ''
        cache_key = u'{}|{}'.format(_ai_fold_text(title), year if re.match(r'^\d{4}$', year or '') else '')
        if cache_key in _AI_CANDIDATE_MEDIA_TYPE_CACHE:
            inferred = _AI_CANDIDATE_MEDIA_TYPE_CACHE.get(cache_key) or ''
            if inferred:
                row['_inferred_media_type'] = inferred
            return inferred
        try:
            import requests as _requests
            headers, api_key = self._tmdb_auth()
            if not api_key and not (headers or {}).get('Authorization'):
                _AI_CANDIDATE_MEDIA_TYPE_CACHE[cache_key] = ''
                return ''
            endpoint, best_item = self._tmdb_search_best_item(title, year, '', headers, api_key, _requests)
            inferred = _ai_normalize_media_type(endpoint or ((best_item or {}).get('media_type') if isinstance(best_item, dict) else ''))
            if inferred not in ('movie', 'tv'):
                inferred = ''
            _AI_CANDIDATE_MEDIA_TYPE_CACHE[cache_key] = inferred
            if inferred:
                row['_inferred_media_type'] = inferred
                log('[AI_SEARCH] inferred candidate media_type={} title={}'.format(inferred, _redact_ai_secrets(title[:80])), 1)
            return inferred
        except Exception as exc:
            log('[AI_SEARCH] infer candidate media_type ERROR: {}'.format(_safe_exception_text(exc, 140)), 1)
            _AI_CANDIDATE_MEDIA_TYPE_CACHE[cache_key] = ''
            return ''

    # ZMIANA (2026-05) [PATCH]: akcja „Części serii” jest dostępna wyłącznie dla kandydatów potwierdzonych jako film.
    # POWÓD: seriale mają być ukryte, ale filmy bez media_type muszą odzyskać przycisk po bezpiecznym rozpoznaniu przez TMDB.
    # NIE ZMIENIAĆ: warunek musi pozostać pozytywny (tylko movie), a nie negatywny (nie-tv), żeby nie przepuszczać seriali bez typu.
    def _candidate_related_allowed(self, row):
        return self._infer_candidate_media_type(row) == 'movie'

    def _clear_mobile_candidate_list(self):
        try:
            ctrl = self.getControl(self.CTRL_CANDIDATE_MOBILE_LIST)
            try:
                ctrl.reset()
            except Exception:
                pass
            ctrl.setVisible(False)
            try:
                ctrl.setEnabled(False)
            except Exception:
                pass
        except Exception:
            pass

    def _mobile_candidate_enabled(self):
        return bool(self._mobile_candidate_list and self._has_control(self.CTRL_CANDIDATE_MOBILE_LIST))

    def _mobile_candidate_label2(self, row):
        if not row:
            return ''
        bits = []
        confidence = row.get('confidence') or ''
        year = row.get('year') or ''
        reason = row.get('reason') or ''
        if year:
            bits.append(u'rok {}'.format(year))
        if confidence:
            bits.append(u'pewność {}%'.format(confidence))
        if reason:
            bits.append(reason)
        return u' | '.join([b for b in bits if b])

    def _build_mobile_candidate_item(self, index, row):
        title = self._candidate_card_title(index, row)
        label2 = self._mobile_candidate_label2(row)
        try:
            item = xbmcgui.ListItem(label=title, label2=label2)
        except TypeError:
            item = xbmcgui.ListItem(title)
            try:
                item.setLabel2(label2)
            except Exception:
                pass
        poster = row.get('poster') or ''
        if poster:
            try:
                item.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
            except Exception:
                try:
                    item.setIconImage(poster)
                    item.setThumbnailImage(poster)
                except Exception:
                    pass
        try:
            item.setProperty('candidate_index', u'{}'.format(index))
        except Exception:
            pass
        return item

    def _update_mobile_candidate_list(self, rows):
        if not self._mobile_candidate_enabled():
            return False
        try:
            ctrl = self.getControl(self.CTRL_CANDIDATE_MOBILE_LIST)
            try:
                ctrl.reset()
            except Exception:
                pass
            items = []
            for index, row in enumerate(rows or [], 1):
                items.append(self._build_mobile_candidate_item(index, row))
            if items:
                try:
                    ctrl.addItems(items)
                except Exception:
                    for item in items:
                        ctrl.addItem(item)
            # ZMIANA (2026-05) [PATCH]: pokazanie listy mobilnej odbywa sie w Pythonie, nie przez stale <visible>false</visible> w XML.
            # POWOD: stale <visible>false</visible> w skorce Kodi ukrywalo id=490 mimo setVisible(True), przez co lista miala dane, ale nie byla widoczna ani fokusowalna.
            # NIE ZMIENIAC: XML id=490 musi zostac bez stalego visible=false; reset/ukrywanie kontroluje _clear_mobile_candidate_list().
            visible = bool(items)
            ctrl.setVisible(visible)
            try:
                ctrl.setEnabled(visible)
            except Exception:
                pass
            if visible:
                try:
                    ctrl.selectItem(0)
                except Exception:
                    pass
            self._set_control_label(
                self.CTRL_CANDIDATE_PAGE,
                u'Kandydaci 1-{} z {} - przewijaj palcem listę plakatów'.format(len(items), len(items)) if items else ''
            )
            if items:
                log('[AI_SEARCH] mobile candidate native list visible rows={} xml_visible_controlled_by_python=True'.format(len(items)), 1)
            return True
        except Exception as exc:
            log('[AI_SEARCH] mobile candidate native list ERROR fallback cards err={}'.format(_safe_exception_text(exc, 120)), 1)
            return False

    def _hide_static_candidate_cards(self):
        for slot in self.CANDIDATE_CARD_SLOTS:
            for key in ('group', 'bg', 'poster', 'title', 'reason'):
                self._set_control_visible(slot[key], False)
            self._set_control_visible(slot['desc'], False, False)
            self._set_control_visible(slot['cast'], False, False)
            self._set_control_visible(slot['trailer'], False, False)
            self._set_control_visible(slot['preview'], False, False)
            self._set_control_visible(slot['select'], False, False)
            self._set_control_visible(slot['related'], False, False)
        self._set_control_visible(self.CTRL_CANDIDATE_PREV, False, False)
        self._set_control_visible(self.CTRL_CANDIDATE_NEXT, False, False)
        self._set_control_visible(self.CTRL_CANDIDATE_TOUCH_PREV, False, False)
        self._set_control_visible(self.CTRL_CANDIDATE_TOUCH_NEXT, False, False)

    def _mobile_candidate_index(self):
        rows = self._candidate_card_rows or []
        if not rows:
            return 0, None
        try:
            ctrl = self.getControl(self.CTRL_CANDIDATE_MOBILE_LIST)
            pos = int(ctrl.getSelectedPosition())
        except Exception:
            pos = 0
        if pos < 0 or pos >= len(rows):
            return 0, None
        return pos + 1, rows[pos]

    def _handle_mobile_candidate_click(self):
        index, row = self._mobile_candidate_index()
        if not row:
            return True
        title = row.get('title') or ''
        log('[AI_SEARCH] mobile candidate clicked index={} title={}'.format(index, _redact_ai_secrets(title[:80])), 1)
        choices = [u'Podgląd', u'Szukaj Kodi', u'Opis TMDB', u'Aktorzy', u'Zwiastun']
        # ZMIANA (2026-05) [PATCH]: w menu mobilnym opcję „Części serii” dodajemy tylko dla filmów.
        # POWÓD: seriale mają własną logikę sezonów w Kodi/FanVodPL, a sztuczne kandydaty sezonów powodowały błąd wyszukiwania.
        # NIE ZMIENIAĆ: kolejność pierwszych pięciu akcji pozostaje stała, żeby nie zepsuć istniejącej obsługi kliknięć.
        if self._candidate_related_allowed(row):
            choices.append(u'Części serii')
        try:
            choice = xbmcgui.Dialog().select(u'Kandydat {} — wybierz akcję'.format(index), choices)
        except Exception:
            choice = 0
        if choice == 0:
            self._preview_candidate_choice(u'{}'.format(index))
        elif choice == 1:
            self._search_candidate_in_kodi(index, row)
        elif choice == 2:
            self._show_candidate_description(index, row)
        elif choice == 3:
            self._open_candidate_cast(index, row)
        elif choice == 4:
            self._open_candidate_trailer(index, row)
        elif choice == 5 and self._candidate_related_allowed(row):
            self._show_candidate_related(index, row)
        return True

    def _clear_candidate_cards(self):
        self._candidate_card_rows = []
        self._candidate_scroll_offset = 0
        self._last_candidate_focus_id = 0
        self._candidate_scroll_focus_guard = False
        self._candidate_scroll_focus_guard_id = 0
        self._last_candidate_nav_action_id = 0
        for slot in self.CANDIDATE_CARD_SLOTS:
            for key in ('group', 'bg', 'poster', 'title', 'reason'):
                self._set_control_visible(slot[key], False)
            self._set_control_visible(slot['desc'], False, False)
            self._set_control_visible(slot['cast'], False, False)
            self._set_control_visible(slot['trailer'], False, False)
            self._set_control_visible(slot['preview'], False, False)
            self._set_control_visible(slot['select'], False, False)
            self._set_control_visible(slot['related'], False, False)
            self._set_control_image(slot['poster'], '')
            self._set_control_label(slot['title'], '')
            self._set_control_label(slot['reason'], '')
        self._set_control_visible(self.CTRL_CANDIDATE_PREV, False, False)
        self._set_control_visible(self.CTRL_CANDIDATE_NEXT, False, False)
        self._set_control_visible(self.CTRL_CANDIDATE_TOUCH_PREV, False, False)
        self._set_control_visible(self.CTRL_CANDIDATE_TOUCH_NEXT, False, False)
        self._set_control_visible(self.CTRL_CANDIDATE_PAGE, False)
        self._set_control_label(self.CTRL_CANDIDATE_PAGE, '')
        self._clear_mobile_candidate_list()

    def _render_candidate_cards(self, rows, reset_page=True):
        self._candidate_card_rows = list(rows or [])
        if reset_page:
            self._candidate_scroll_offset = 0
        self._update_candidate_cards()

    def _candidate_max_scroll_offset(self):
        rows = self._candidate_card_rows or []
        return max(0, len(rows) - len(self.CANDIDATE_CARD_SLOTS))

    def _clamp_candidate_scroll_offset(self):
        max_offset = self._candidate_max_scroll_offset()
        if self._candidate_scroll_offset < 0:
            self._candidate_scroll_offset = 0
        if self._candidate_scroll_offset > max_offset:
            self._candidate_scroll_offset = max_offset
        return max_offset

    def _update_candidate_cards(self):
        rows = self._candidate_card_rows or []
        slot_count = len(self.CANDIDATE_CARD_SLOTS)
        if not rows:
            self._clear_candidate_cards()
            return
        # ZMIANA (2026-05) [PATCH]: na telefonie/tablecie Android kandydaci sa prawdziwa lista Kodi id=490 przewijalna palcem.
        # POWOD: statyczne grupy kafelkow 410/430/450 nie przyjmuja natywnego scrolla dotykowego tak jak control type=list.
        # NIE ZMIENIAC: fallback do starych kart zostaje dla Android TV/PC i gdy skorka nie ma kontrolki 490.
        if self._mobile_candidate_enabled() and self._update_mobile_candidate_list(rows):
            self._hide_static_candidate_cards()
            self._candidate_scroll_offset = 0
            return
        self._clear_mobile_candidate_list()
        max_offset = self._clamp_candidate_scroll_offset()
        start = self._candidate_scroll_offset
        for slot_index, slot in enumerate(self.CANDIDATE_CARD_SLOTS):
            absolute = start + slot_index
            if absolute >= len(rows):
                for key in ('group', 'bg', 'poster', 'title', 'reason'):
                    self._set_control_visible(slot[key], False)
                self._set_control_visible(slot['desc'], False, False)
                self._set_control_visible(slot['cast'], False, False)
                self._set_control_visible(slot['trailer'], False, False)
                self._set_control_visible(slot['preview'], False, False)
                self._set_control_visible(slot['select'], False, False)
                self._set_control_visible(slot['related'], False, False)
                self._set_control_image(slot['poster'], '')
                self._set_control_label(slot['title'], '')
                self._set_control_label(slot['reason'], '')
                continue
            row = rows[absolute]
            index = absolute + 1
            for key in ('group', 'bg', 'poster', 'title', 'reason'):
                self._set_control_visible(slot[key], True)
            self._set_control_image(slot['poster'], row.get('poster') or '')
            self._set_control_label(slot['title'], self._candidate_card_title(index, row))
            self._set_control_label(slot['reason'], self._candidate_card_reason(row))
            self._set_control_visible(slot['desc'], True, True)
            self._set_control_visible(slot['cast'], True, True)
            self._set_control_visible(slot['trailer'], True, True)
            self._set_control_visible(slot['preview'], True, True)
            self._set_control_visible(slot['select'], True, True)
            # ZMIANA (2026-05) [PATCH]: przycisk „Części serii” pokazujemy tylko dla filmów.
            # POWÓD: w serialach akcja sezonów generowała błędną ścieżkę wyszukiwania po tytule „Serial - Sezon X”.
            # NIE ZMIENIAĆ: Opis, Aktorzy, Zwiastun, Podgląd i Szukaj Kodi muszą pozostać widoczne dla seriali.
            self._set_control_visible(slot['related'], self._candidate_related_allowed(row), self._candidate_related_allowed(row))
        needs_scroll = len(rows) > slot_count
        self._set_control_visible(self.CTRL_CANDIDATE_PAGE, needs_scroll)
        self._set_control_label(
            self.CTRL_CANDIDATE_PAGE,
            u'Kandydaci {}-{} z {} - przewijaj góra/dół'.format(start + 1, min(start + slot_count, len(rows)), len(rows)) if needs_scroll else ''
        )
        # ZMIANA (2026-05) [PATCH]: na telefonie/tablecie pokazujemy przyciski przewijania kandydatow przy samej liscie plakatow.
        # POWOD: uzytkownik nie potrzebuje przewijania rozmowy AI; potrzebuje szybkiego przejscia po 5-10 kandydatach/plakatach.
        # NIE ZMIENIAC: przewijamy tylko _candidate_scroll_offset; nie zmieniamy historii czatu, odpowiedzi AI ani wyboru tytulu.
        show_touch_scroll = bool(needs_scroll and self._touch_scroll_buttons)
        self._set_control_visible(self.CTRL_CANDIDATE_PREV, show_touch_scroll, show_touch_scroll)
        self._set_control_visible(self.CTRL_CANDIDATE_NEXT, show_touch_scroll, show_touch_scroll)
        self._set_control_visible(self.CTRL_CANDIDATE_TOUCH_PREV, show_touch_scroll, show_touch_scroll)
        self._set_control_visible(self.CTRL_CANDIDATE_TOUCH_NEXT, show_touch_scroll, show_touch_scroll)
        if show_touch_scroll:
            log('[AI_SEARCH] candidate touch scroll buttons visible rows={} offset={} max_offset={}'.format(
                len(rows), self._candidate_scroll_offset, max_offset), 1)

    def _candidate_row_for_slot(self, slot_index):
        absolute = self._candidate_scroll_offset + slot_index
        rows = self._candidate_card_rows or []
        if absolute < 0 or absolute >= len(rows):
            return 0, None
        return absolute + 1, rows[absolute]

    def _candidate_focus_location(self, control_id):
        for slot_index, slot in enumerate(self.CANDIDATE_CARD_SLOTS):
            for key in ('desc', 'cast', 'trailer', 'preview', 'select', 'related'):
                if control_id == slot[key]:
                    return slot_index, key
        return None, None

    def _visible_candidate_slot_count(self):
        rows = self._candidate_card_rows or []
        if not rows:
            return 0
        return max(0, min(len(self.CANDIDATE_CARD_SLOTS), len(rows) - self._candidate_scroll_offset))

    def _candidate_cards_active(self):
        return bool(self._candidate_card_rows or [])

    def _focus_first_candidate_card(self):
        if not self._candidate_cards_active():
            return False
        if self._mobile_candidate_enabled() and self._candidate_card_rows:
            try:
                self.setFocusId(self.CTRL_CANDIDATE_MOBILE_LIST)
                return True
            except Exception:
                pass
        try:
            self.setFocusId(self.CANDIDATE_CARD_SLOTS[0]['desc'])
            return True
        except Exception:
            return False

    def _focus_last_visible_candidate_card(self):
        if not self._candidate_cards_active():
            return False
        visible_count = self._visible_candidate_slot_count()
        if visible_count <= 0:
            return False
        slot_index = min(visible_count, len(self.CANDIDATE_CARD_SLOTS)) - 1
        try:
            self.setFocusId(self.CANDIDATE_CARD_SLOTS[slot_index]['desc'])
            return True
        except Exception:
            return False

    def _candidate_scroll_focus_target(self, focus_id):
        slot_index, key = self._candidate_focus_location(focus_id)
        if slot_index is None:
            return focus_id
        visible_count = self._visible_candidate_slot_count()
        if visible_count <= 0:
            return focus_id
        slot_index = max(0, min(slot_index, visible_count - 1))
        slot = self.CANDIDATE_CARD_SLOTS[slot_index]
        if key == 'related':
            index, row = self._candidate_row_for_slot(slot_index)
            if not row or not self._candidate_related_allowed(row):
                return slot['desc']
        return slot.get(key) or slot['desc']

    def _scroll_candidate_cards(self, delta, focus_id=None):
        rows = self._candidate_card_rows or []
        if not rows:
            return False
        old_offset = self._candidate_scroll_offset
        max_offset = self._candidate_max_scroll_offset()
        self._candidate_scroll_offset = max(0, min(max_offset, self._candidate_scroll_offset + int(delta or 0)))
        if self._candidate_scroll_offset == old_offset:
            return False
        self._update_candidate_cards()
        start = self._candidate_scroll_offset + 1
        end = min(self._candidate_scroll_offset + len(self.CANDIDATE_CARD_SLOTS), len(rows))
        self._set_hint(u'Kandydaci {}-{} z {}. Przewijaj strzałkami góra/dół, pilotem albo kółkiem myszy.'.format(start, end, len(rows)))
        if focus_id:
            focus_id = self._candidate_scroll_focus_target(focus_id)
            guard_candidate_focus = self._candidate_focus_location(focus_id)[0] is not None
            try:
                self.setFocusId(focus_id)
                self._last_candidate_focus_id = focus_id
                self._candidate_scroll_focus_guard = guard_candidate_focus
                self._candidate_scroll_focus_guard_id = focus_id if guard_candidate_focus else 0
            except Exception:
                slot_index, key = self._candidate_focus_location(focus_id)
                if slot_index is not None and slot_index < self._visible_candidate_slot_count():
                    try:
                        fallback_id = self.CANDIDATE_CARD_SLOTS[slot_index]['desc']
                        self.setFocusId(fallback_id)
                        self._last_candidate_focus_id = fallback_id
                        self._candidate_scroll_focus_guard = True
                        self._candidate_scroll_focus_guard_id = fallback_id
                    except Exception:
                        pass
        return True

    def _scroll_down_from_last_candidate_focus(self):
        focus_id = self._last_candidate_focus_id
        slot_index, key = self._candidate_focus_location(focus_id)
        if slot_index is None:
            return False
        visible_count = self._visible_candidate_slot_count()
        if visible_count <= 0 or slot_index < visible_count - 1:
            return False
        return self._scroll_candidate_cards(1, focus_id)

    def _scroll_up_from_first_candidate_focus(self):
        focus_id = self._last_candidate_focus_id
        slot_index, key = self._candidate_focus_location(focus_id)
        if slot_index is None or slot_index > 0:
            return False
        if self._candidate_scroll_offset <= 0:
            return False
        return self._scroll_candidate_cards(-1, focus_id)

    def _handle_candidate_scroll_action(self, action_id):
        if action_id not in (5, 6, 104, 105):
            return False
        self._candidate_scroll_focus_guard = False
        self._candidate_scroll_focus_guard_id = 0
        try:
            focus_id = self.getFocusId()
        except Exception:
            focus_id = None
        rows = self._candidate_card_rows or []
        if action_id in (104, 105) and rows:
            slot_index, key = self._candidate_focus_location(focus_id)
            delta = -1 if action_id == 104 else 1
            return self._scroll_candidate_cards(delta, focus_id if slot_index is not None else None)
        slot_index, key = self._candidate_focus_location(focus_id)
        if slot_index is None:
            return False
        visible_count = self._visible_candidate_slot_count()
        if visible_count <= 0:
            return False
        if action_id == 104:
            return self._scroll_candidate_cards(-1, focus_id)
        if action_id == 105:
            return self._scroll_candidate_cards(1, focus_id)
        if action_id == 5:
            return self._scroll_candidate_cards(-len(self.CANDIDATE_CARD_SLOTS), focus_id)
        if action_id == 6:
            return self._scroll_candidate_cards(len(self.CANDIDATE_CARD_SLOTS), focus_id)
        return False

    def _show_candidate_description(self, index, row):
        title = row.get('title') or ''
        year = row.get('year') or ''
        media_type = row.get('media_type') or ''
        english_title = row.get('english_title') or row.get('original_title') or ''
        if not title:
            return
        preview = self._fetch_candidate_preview(title, year, media_type, include_trailer=False, english_title=english_title)
        poster = row.get('poster') or preview.get('poster') or ''
        overview = row.get('overview') or preview.get('overview') or ''
        display_title = self._candidate_card_title(index, row)
        self._set_preview_panel(poster, u'{}\n\n{}'.format(display_title, overview or u'Otwieram stronę TMDB.'))
        # ZMIANA: otwiera strone TMDB w przegladarce zamiast wpisywac opis do czatu
        # POWOD: uzytkownik chce widziec pelny opis na stronie TMDB tak jak przy Aktorzy
        # NIE ZMIENIAC: _set_preview_panel powyzej pokazuje podreczny podglad - zostaje
        url = (preview.get('tmdb_url') or '').strip()
        if not url:
            xbmcgui.Dialog().notification(
                'FanVodPL AI',
                u'Nie udało się znaleźć strony TMDB dla tego kandydata.',
                xbmcgui.NOTIFICATION_INFO,
                3500,
            )
            self._set_hint(u'Brak strony TMDB dla kandydata {}.'.format(index))
            return
        if not self._open_external_url(url):
            xbmcgui.Dialog().notification(
                'FanVodPL AI',
                u'Nie udało się otworzyć strony TMDB.',
                xbmcgui.NOTIFICATION_ERROR,
                3500,
            )
        else:
            self._add_line(u'AI: Otwieram stronę TMDB dla kandydata {}.'.format(index), role='assistant')
            self._set_hint(u'Otwieram stronę TMDB dla kandydata {}.'.format(index))
        log('[AI_SEARCH] AI chat candidate card description index={} title={}'.format(
            index, _redact_ai_secrets(title[:80])), 1)

    def _open_candidate_trailer(self, index, row):
        title = row.get('title') or ''
        year = row.get('year') or ''
        media_type = row.get('media_type') or ''
        english_title = row.get('english_title') or row.get('original_title') or ''
        if not title:
            return
        preview = self._fetch_candidate_preview(title, year, media_type, english_title=english_title)
        poster = row.get('poster') or preview.get('poster') or ''
        overview = row.get('overview') or preview.get('overview') or ''
        display_title = self._candidate_card_title(index, row)
        self._set_preview_panel(poster, u'{}\n\n{}'.format(display_title, overview or u'Zwiastun zostanie otwarty poza Kodi, jeśli TMDB go zwróci.'))
        url = (preview.get('youtube_url') or '').strip()
        if not url:
            xbmcgui.Dialog().notification(
                'FanVodPL AI',
                u'TMDB nie zwróciło zwiastuna dla tego kandydata.',
                xbmcgui.NOTIFICATION_INFO,
                3500,
            )
            self._set_hint(u'Brak zwiastuna TMDB dla kandydata {}.'.format(index))
            return
        if not self._open_external_url(url):
            xbmcgui.Dialog().notification(
                'FanVodPL AI',
                u'Nie udało się otworzyć zwiastuna.',
                xbmcgui.NOTIFICATION_ERROR,
                3500,
            )
        else:
            self._set_hint(u'Otwieram zwiastun dla kandydata {}.'.format(index))
        log('[AI_SEARCH] AI chat candidate card trailer index={} title={}'.format(
            index, _redact_ai_secrets(title[:80])), 1)

    def _open_candidate_cast(self, index, row):
        title = row.get('title') or ''
        year = row.get('year') or ''
        media_type = row.get('media_type') or ''
        english_title = row.get('english_title') or row.get('original_title') or ''
        if not title:
            return
        preview = self._fetch_candidate_preview(title, year, media_type, include_trailer=False, english_title=english_title)
        poster = preview.get('poster') or row.get('poster') or ''
        overview = preview.get('overview') or ''
        display_title = self._candidate_card_title(index, row)
        self._set_preview_panel(poster, u'{}\n\n{}'.format(display_title, overview or u'Otwieram stronę obsady TMDB.'))
        url = (preview.get('cast_url') or preview.get('tmdb_url') or '').strip()
        if not url:
            xbmcgui.Dialog().notification(
                'FanVodPL AI',
                u'Nie udało się znaleźć strony obsady TMDB dla tego kandydata.',
                xbmcgui.NOTIFICATION_INFO,
                3500,
            )
            self._set_hint(u'Brak strony obsady TMDB dla kandydata {}.'.format(index))
            return
        if not self._open_external_url(url):
            xbmcgui.Dialog().notification(
                'FanVodPL AI',
                u'Nie udało się otworzyć obsady TMDB.',
                xbmcgui.NOTIFICATION_ERROR,
                3500,
            )
        else:
            self._set_hint(u'Otwieram aktorów/obsadę TMDB dla kandydata {}.'.format(index))
        log('[AI_SEARCH] AI chat candidate card cast index={} title={}'.format(
            index, _redact_ai_secrets(title[:80])), 1)


    def _tmdb_image_url(self, path, size='w185'):
        path = u'{}'.format(path or '').strip()
        if not path:
            return ''
        if path.startswith('http'):
            return path
        if path.startswith('/'):
            return 'https://image.tmdb.org/t/p/{}{}'.format(size, path)
        return ''

    def _tmdb_get_json(self, url, headers, requests_mod, timeout=3.5):
        try:
            r = requests_mod.get(url, headers=headers or None, timeout=timeout)
            r.raise_for_status()
            data = r.json() or {}
            return data if isinstance(data, dict) else {}
        except Exception as exc:
            log('[AI_SEARCH] TMDB related request ERROR: {}'.format(_safe_exception_text(exc, 140)), 1)
            return {}

    def _tmdb_search_best_item(self, title, year='', media_type='', headers=None, api_key='', requests_mod=None):
        title = u'{}'.format(title or '').strip()
        year = u'{}'.format(year or '').strip()
        media_type = _ai_normalize_media_type(media_type)
        if not title or requests_mod is None:
            return '', None
        if not re.match(r'^\d{4}$', year or ''):
            year = ''
        try:
            from urllib.parse import quote as _quote
        except ImportError:
            from urllib import quote as _quote
        try:
            query = _quote(title)
        except Exception:
            query = _quote(title.encode('utf-8'))
        if media_type == 'tv':
            endpoints = (('tv', 'first_air_date_year'),)
        elif media_type == 'movie':
            endpoints = (('movie', 'year'),)
        else:
            endpoints = (('multi', ''),)
        best_item = None
        best_endpoint = ''
        best_score = -1
        query_fold = _ai_fold_text(title)
        for endpoint, year_param in endpoints:
            url = 'https://api.themoviedb.org/3/search/{}?language=pl-PL&query={}&page=1'.format(endpoint, query)
            if api_key:
                url += '&api_key=' + api_key
            if year and year_param:
                url += '&{}={}'.format(year_param, year)
            data = self._tmdb_get_json(url, headers, requests_mod, timeout=3.5)
            for result in (data.get('results') or [])[:8]:
                if endpoint == 'multi' and result.get('media_type') not in ('movie', 'tv'):
                    continue
                titles = (result.get('title'), result.get('name'), result.get('original_title'), result.get('original_name'))
                folded_titles = [_ai_fold_text(x or '') for x in titles if x]
                score = 1
                if query_fold and any(query_fold == x for x in folded_titles):
                    score += 60
                elif query_fold and any(query_fold in x or x in query_fold for x in folded_titles):
                    score += 25
                result_year = str((result.get('release_date') or result.get('first_air_date') or '')[:4])
                if year and result_year == year:
                    score += 30
                if result.get('poster_path'):
                    score += 5
                try:
                    score += min(float(result.get('popularity') or 0), 50.0) / 100.0
                except Exception:
                    pass
                if score > best_score:
                    best_item = result
                    best_endpoint = result.get('media_type') or endpoint
                    best_score = score
        return best_endpoint, best_item

    def _related_rows_from_tmdb(self, row):
        title = row.get('title') or ''
        year = row.get('year') or ''
        media_type = row.get('media_type') or ''
        title = u'{}'.format(title or '').strip()
        if not title:
            return [], ''
        try:
            import requests as _requests
        except Exception as exc:
            log('[AI_SEARCH] TMDB related import requests ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
            return [], ''
        headers, api_key = self._tmdb_auth()
        if not api_key and not headers.get('Authorization'):
            return [], ''
        endpoint, best_item = self._tmdb_search_best_item(title, year, media_type, headers, api_key, _requests)
        if not best_item or endpoint not in ('movie', 'tv'):
            return [], ''
        tmdb_id = best_item.get('id') or ''
        if not tmdb_id:
            return [], ''
        base = 'https://api.themoviedb.org/3/{}/{}?language=pl-PL'.format(endpoint, tmdb_id)
        if api_key:
            base += '&api_key=' + api_key
        details = self._tmdb_get_json(base, headers, _requests, timeout=3.5)
        rows = []
        if endpoint == 'movie':
            collection = details.get('belongs_to_collection') or {}
            collection_id = collection.get('id') if isinstance(collection, dict) else ''
            collection_name = collection.get('name') if isinstance(collection, dict) else ''
            if not collection_id:
                return [], 'movie_no_collection'
            url = 'https://api.themoviedb.org/3/collection/{}?language=pl-PL'.format(collection_id)
            if api_key:
                url += '&api_key=' + api_key
            collection_data = self._tmdb_get_json(url, headers, _requests, timeout=3.5)
            parts = collection_data.get('parts') or []
            def _movie_sort_key(item):
                return item.get('release_date') or '9999-99-99'
            for part in sorted([p for p in parts if isinstance(p, dict)], key=_movie_sort_key)[:12]:
                p_title = part.get('title') or part.get('name') or ''
                if not p_title:
                    continue
                p_year = (part.get('release_date') or '')[:4]
                rows.append({
                    'title': p_title,
                    'year': p_year,
                    'confidence': '',
                    'reason': u'Część serii: {}'.format(collection_name or collection_data.get('name') or title),
                    'media_type': 'movie',
                    'poster': self._tmdb_image_url(part.get('poster_path') or '', 'w185'),
                    'overview': u' '.join((part.get('overview') or '').split()),
                    'item': part,
                    'line': p_title,
                })
            return rows, 'movie_collection'
        if endpoint == 'tv':
            series_title = details.get('name') or details.get('title') or title
            seasons = details.get('seasons') or []
            for season in [s for s in seasons if isinstance(s, dict)][:30]:
                number = season.get('season_number')
                try:
                    number_int = int(number)
                except Exception:
                    number_int = -1
                if number_int < 0:
                    continue
                name = season.get('name') or u'Sezon {}'.format(number_int)
                air_year = (season.get('air_date') or '')[:4]
                episode_count = season.get('episode_count') or ''
                s_title = u'{} - {}'.format(series_title, name)
                rows.append({
                    'title': s_title,
                    'year': air_year,
                    'confidence': '',
                    'reason': u'Sezon serialu{}{}'.format(
                        u' nr {}'.format(number_int) if number_int >= 0 else '',
                        u', odcinków {}'.format(episode_count) if episode_count else ''
                    ),
                    'media_type': 'tv',
                    'poster': self._tmdb_image_url(season.get('poster_path') or details.get('poster_path') or '', 'w185'),
                    'overview': u' '.join((season.get('overview') or details.get('overview') or '').split()),
                    'item': season,
                    'line': s_title,
                })
            return rows, 'tv_seasons'
        return [], ''

    def _show_candidate_related(self, index, row):
        if not row:
            return
        # ZMIANA (2026-05) [PATCH]: zabezpieczenie przed uruchomieniem części/sezonów dla seriali także z poziomu starego/fokusowanego przycisku.
        # POWÓD: przy serialach sezon nie jest samodzielnym tytułem do wyszukiwarki Kodi; akcja ma być ukryta i ignorowana.
        # NIE ZMIENIAĆ: filmy nadal mogą pobierać kolekcję TMDB i pokazywać części serii.
        if not self._candidate_related_allowed(row):
            log('[AI_SEARCH] related parts ignored for tv candidate index={}'.format(index), 1)
            return
        title = row.get('title') or ''
        display_title = self._candidate_card_title(index, row)
        self._set_hint(u'Sprawdzam części serii dla {}...'.format(display_title))
        related_rows, related_kind = self._related_rows_from_tmdb(row)
        if not related_rows:
            xbmcgui.Dialog().notification(
                'FanVodPL AI',
                u'Nie znalazłem części serii dla tego filmu.',
                xbmcgui.NOTIFICATION_INFO,
                3500,
            )
            self._add_line(u'AI: Nie znalazłem w TMDB części serii dla {}.'.format(display_title), role='assistant')
            self._set_hint(u'Brak części serii. Możesz użyć Opis, Podgląd albo Szukaj Kodi.')
            log('[AI_SEARCH] related parts empty index={} title={} kind={}'.format(index, _redact_ai_secrets(title[:80]), related_kind), 1)
            return
        candidates = []
        for item in related_rows:
            candidates.append({
                'title': item.get('title') or '',
                'year': item.get('year') or '',
                'confidence': item.get('confidence') or '',
                'reason': item.get('reason') or '',
                'media_type': item.get('media_type') or '',
                'poster': item.get('poster') or '',
                'overview': item.get('overview') or '',
            })
        data = dict(self._ai_data or {})
        data['candidates'] = candidates
        data['assistant_message'] = u'Znalazłem części serii. Wybierz film i użyj Podgląd albo Szukaj Kodi.'
        self._ai_data = data
        self._render_candidate_cards(related_rows, reset_page=True)
        self._add_line(u'AI: Pokażę części serii dla {}.'.format(display_title), role='assistant')
        for idx, item in enumerate(related_rows[:10], 1):
            self._add_line(u'AI: {}. {}'.format(idx, self._candidate_card_title(idx, item)), role='assistant', icon=item.get('poster') or '')
        self._set_hint(u'Wyświetlono części serii. Wybierz pozycję, potem Podgląd albo Szukaj Kodi.')
        log('[AI_SEARCH] related parts shown source_index={} rows={} title={} kind={}'.format(
            index, len(related_rows), _redact_ai_secrets(title[:80]), related_kind), 1)

    def _search_candidate_in_kodi(self, index, row):
        if not row:
            return
        if not self._preview_candidate_choice(u'{}'.format(index), speak=False):
            return
        log('[AI_SEARCH] AI chat candidate card confirm index={} title={}'.format(
            index, _redact_ai_secrets((row.get('title') or '')[:80])), 1)
        self.result = {'action': 'confirm', 'ai_data': self._ai_data, 'history': self._history}
        self.close()

    def _handle_candidate_card_click(self, control_id):
        if control_id == self.CTRL_CANDIDATE_MOBILE_LIST:
            return self._handle_mobile_candidate_click()
        if control_id in (self.CTRL_CANDIDATE_PREV, self.CTRL_CANDIDATE_TOUCH_PREV):
            self._scroll_candidate_cards(-1, control_id)
            return True
        if control_id in (self.CTRL_CANDIDATE_NEXT, self.CTRL_CANDIDATE_TOUCH_NEXT):
            self._scroll_candidate_cards(1, control_id)
            return True
        for slot_index, slot in enumerate(self.CANDIDATE_CARD_SLOTS):
            if control_id not in (slot['desc'], slot['cast'], slot['trailer'], slot['preview'], slot['select'], slot['related']):
                continue
            index, row = self._candidate_row_for_slot(slot_index)
            if not row:
                return True
            if control_id == slot['desc']:
                self._show_candidate_description(index, row)
            elif control_id == slot['cast']:
                self._open_candidate_cast(index, row)
            elif control_id == slot['trailer']:
                self._open_candidate_trailer(index, row)
            elif control_id == slot['preview']:
                self._preview_candidate_choice(u'{}'.format(index))
            elif control_id == slot['related']:
                self._show_candidate_related(index, row)
            else:
                self._search_candidate_in_kodi(index, row)
            return True
        return False

    def _candidate_rows(self, ai_data, limit=10):
        candidates = ai_data.get('candidates') or []
        if not isinstance(candidates, list):
            candidates = []
        if (not candidates) and ai_data.get('ready_to_confirm'):
            confirmed_title = u'{}'.format(
                ai_data.get('confirmation_title') or ai_data.get('search_query') or ''
            ).strip()
            if confirmed_title:
                reason = u'{}'.format(ai_data.get('match_reason') or ai_data.get('reason') or '').strip()
                if not reason:
                    if ai_data.get('_year_mismatch'):
                        reason = u'Pewny trop AI, ale rocznik nie pasuje do przybliżonych lat.'
                    else:
                        reason = u'Pewny wynik AI.'
                candidates = [{
                    'title': confirmed_title,
                    'search_query': ai_data.get('search_query') or confirmed_title,
                    'confirmation_title': ai_data.get('confirmation_title') or confirmed_title,
                    'pl_title': ai_data.get('pl_title') or '',
                    'english_title': ai_data.get('english_title') or '',
                    'original_title': ai_data.get('original_title') or '',
                    'year': ai_data.get('year') or '',
                    'type': ai_data.get('type') or '',
                    'media_type': ai_data.get('type') or '',
                    'confidence': ai_data.get('confidence') or 95,
                    'reason': reason,
                    '_year_mismatch': bool(ai_data.get('_year_mismatch')),
                }]
        rows = []
        for idx, item in enumerate(candidates[:limit], 1):
            if isinstance(item, dict):
                title = (
                    item.get('title') or item.get('confirmation_title') or
                    item.get('english_title') or item.get('pl_title') or
                    item.get('original_title') or item.get('name') or ''
                )
                year = item.get('year') or ''
                confidence = item.get('confidence')
                reason = item.get('reason') or item.get('matched') or item.get('match') or item.get('why') or item.get('evidence') or ''
                media_type = item.get('type') or item.get('media_type') or ''
            else:
                title = item
                year = ''
                confidence = None
                reason = ''
                media_type = ''

            try:
                title = u'{}'.format(title).strip()
                year = u'{}'.format(year).strip()
                confidence = u'{}'.format(confidence).strip() if confidence is not None else ''
                if isinstance(reason, list):
                    reason = u', '.join([u'{}'.format(x).strip() for x in reason[:3] if u'{}'.format(x).strip()])
                else:
                    reason = u'{}'.format(reason).strip()
            except Exception:
                continue

            if not title:
                continue
            line = u'{}. {}'.format(idx, title)
            if year:
                line += u' ({})'.format(year)
            if confidence:
                line += u' - pewność {}%'.format(confidence)
            if reason:
                line += u' - {}'.format(reason)
            rows.append({
                'index': idx,
                'title': title,
                'year': year,
                'confidence': confidence,
                'reason': reason,
                'media_type': media_type,
                'item': item,
                'line': line,
                'poster': self._candidate_poster(item, title, year, media_type),
            })
        return rows

    def _candidate_lines(self, ai_data, limit=10):
        return [row.get('line') or '' for row in self._candidate_rows(ai_data, limit)]

    def _open_external_url(self, url):
        url = (url or '').strip()
        if not url:
            return False
        try:
            import webbrowser
            if webbrowser.open(url):
                return True
        except Exception as exc:
            log('[AI_SEARCH] open external url ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        try:
            xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,{})'.format(url))
            return True
        except Exception as exc:
            log('[AI_SEARCH] android external url ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        return False

    def _open_result_link(self, youtube=False):
        title = (self._current_title or '').strip()
        if not title:
            xbmcgui.Dialog().notification(
                'FanVodPL AI',
                u'Najpierw poczekaj na tytuł od AI.',
                xbmcgui.NOTIFICATION_INFO,
                3500,
            )
            return
        if youtube:
            url = (self._youtube_url or '').strip()
            if not url:
                xbmcgui.Dialog().notification(
                    'FanVodPL AI',
                    u'Najpierw wybierz numer kandydata. TMDB musi zwrócić zwiastun.',
                    xbmcgui.NOTIFICATION_INFO,
                    3500,
                )
                return
            if not self._open_external_url(url):
                xbmcgui.Dialog().notification(
                    'FanVodPL AI',
                    u'Nie udało się otworzyć zwiastuna.',
                    xbmcgui.NOTIFICATION_ERROR,
                    3500,
                )
            return
        try:
            from urllib import quote_plus
        except Exception:
            from urllib.parse import quote_plus
        query = quote_plus(title.encode('utf-8') if not isinstance(title, str) else title)
        url = 'https://www.themoviedb.org/search?query={}'.format(query)
        if not self._open_external_url(url):
            xbmcgui.Dialog().notification(
                'FanVodPL AI',
                u'Nie udało się otworzyć przeglądarki.',
                xbmcgui.NOTIFICATION_ERROR,
                3500,
            )

    def _ctrl(self):
        return self.getControl(self.CTRL_CHAT_TEXT)

    def _add_line(self, text, role=None, icon=''):
        ctrl = self._ctrl()
        item = xbmcgui.ListItem(label=text)
        # ZMIANA: ustawia wlasciwosc role na elemencie listy - uzywana przez XML do kolorowania chmurki
        # POWOD: itemlayout w XML moze warunkowo pokazywac rozne tla na podstawie ListItem.Property(role)
        # NIE ZMIENIAC: wartosc 'user' musi pasowac do warunku String.IsEqual(ListItem.Property(role),user) w XML
        try:
            item.setProperty('role', role or '')
        except Exception:
            pass
        if icon:
            try:
                item.setArt({'icon': icon, 'thumb': icon})
            except Exception:
                pass
        ctrl.addItem(item)
        idx = ctrl.size() - 1
        ctrl.selectItem(idx)
        return idx

    def _set_line(self, idx, text, role=None):
        if idx < 0:
            return
        try:
            ctrl = self._ctrl()
            if idx >= ctrl.size():
                return
            item = ctrl.getListItem(idx)
            item.setLabel(text)
            ctrl.selectItem(idx)
        except Exception:
            pass

    def _start_ai_call(self):
        import threading as _threading
        self._ai_started_once = True
        self._preflight_done = True
        self._busy = True
        log('[AI_SEARCH] AI chat request started provider={} history_items={}'.format(
            self._provider or '-', len(self._history)), 1)
        self._youtube_url = ''
        self._set_hint(u'AI szuka w internecie. Poczekaj na odpowiedź albo pytanie doprecyzowujące.')
        self._set_token_usage()
        self._set_result_buttons(False)
        self._clear_candidate_cards()
        self._thinking_idx = self._add_line(u'AI: Szukam w AI/web search...', role='assistant')
        t = _threading.Thread(target=self._ai_thread)
        t.daemon = True
        t.start()

    def _maybe_local_preflight_question(self):
        if self._ai_started_once or self._preflight_done:
            return False
        facts = _ai_preflight_facts(self._history)
        if not facts.get('time') and _ai_preflight_history_has_time_answer(self._history):
            facts = dict(facts)
            facts['time'] = True
        unknown_fields = _ai_preflight_unknown_fields(self._history)
        if _ai_preflight_enough(facts, self._preflight_questions_asked, self._preflight_asked_fields, unknown_fields):
            self._preflight_done = True
            log('[AI_SEARCH] local preflight skipped/enough type={} time={} country={} actor={} context={} clue={} words={} asked={} unknown={}'.format(
                facts.get('type'), facts.get('time'), facts.get('country'), facts.get('actor'),
                _ai_preflight_has_context_for_scene(facts), facts.get('clue'), facts.get('word_count'),
                self._preflight_questions_asked, ','.join(sorted(unknown_fields))), 1)
            return False
        fields, question = _ai_preflight_next_question(facts, self._preflight_asked_fields, unknown_fields)
        if not question or self._preflight_questions_asked >= _AI_PREFLIGHT_MAX_QUESTIONS:
            self._preflight_done = True
            return False
        for field in fields:
            self._preflight_asked_fields.add(field)
        self._preflight_questions_asked += 1
        self._add_line(u'AI: ' + question, role='assistant')
        self._history.append({'role': 'assistant', 'content': question})
        self._set_hint(u'Pytanie kontrolne bez tokenów ({}/{}). Odpowiedz krótko albo wpisz „nie wiem”.'.format(
            self._preflight_questions_asked, _AI_PREFLIGHT_MAX_QUESTIONS))
        log('[AI_SEARCH] local preflight question {}/{} fields={} words={} unknown={}'.format(
            self._preflight_questions_asked, _AI_PREFLIGHT_MAX_QUESTIONS,
            ','.join(fields), facts.get('word_count'), ','.join(sorted(unknown_fields))), 1)
        try:
            self.setFocusId(self.CTRL_INPUT)
        except Exception:
            pass
        return True

    def _on_ai_status(self, text):
        self._set_line(self._thinking_idx, text, role='assistant')

    def _ai_thread(self):
        prompt = _build_mini_chat_prompt(self._history)
        try:
            if self._provider == 'Gemini':
                raw = self._caller(self._api_key, prompt, status_callback=self._on_ai_status)
            else:
                raw = self._caller(self._api_key, prompt)
            token_usage = _pop_last_ai_token_usage()
            ai_data = _parse_response(raw)
            if _ai_needs_quality_retry(ai_data) or _ai_is_empty_candidate_promise(ai_data):
                log('[AI_SEARCH] AI chat empty/weak response; forcing candidates retry raw_preview={}'.format(
                    _redact_ai_secrets((raw or '')[:900])), 1)
                self._on_ai_status(u'AI: Odpowiedź była pusta, wymuszam listę kandydatów...')
                retry_prompt = _build_force_candidates_prompt(self._history, raw)
                if self._provider == 'Gemini':
                    raw_retry = self._caller(self._api_key, retry_prompt, status_callback=self._on_ai_status)
                else:
                    raw_retry = self._caller(self._api_key, retry_prompt)
                retry_usage = _pop_last_ai_token_usage()
                retry_data = _parse_response(raw_retry)
                token_usage = _ai_merge_token_usage(token_usage, retry_usage)
                if _ai_needs_quality_retry(retry_data) or _ai_is_empty_candidate_promise(retry_data):
                    log('[AI_SEARCH] AI chat forced retry still weak raw_preview={}'.format(
                        _redact_ai_secrets((raw_retry or '')[:900])), 1)
                    retry_data['assistant_message'] = (
                        u'AI obiecało kandydatów, ale nie zwróciło listy technicznej. '
                        u'Spróbuj ponownie albo dopisz jeszcze jeden charakterystyczny trop.'
                    )
                ai_data = retry_data
            if _ai_needs_structured_title_retry(ai_data):
                log('[AI_SEARCH] AI chat title spoken without structured result; forcing structured retry', 1)
                self._on_ai_status(u'AI: Tytuł padł w odpowiedzi, poprawiam dane techniczne wyniku...')
                structured_prompt = _build_structured_title_retry_prompt(self._history, ai_data, raw)
                if self._provider == 'Gemini':
                    raw_structured = self._caller(self._api_key, structured_prompt, status_callback=self._on_ai_status)
                else:
                    raw_structured = self._caller(self._api_key, structured_prompt)
                structured_usage = _pop_last_ai_token_usage()
                structured_data = _parse_response(raw_structured)
                token_usage = _ai_merge_token_usage(token_usage, structured_usage)
                if _ai_needs_structured_title_retry(structured_data):
                    log('[AI_SEARCH] AI chat structured title retry still missing technical title raw_preview={}'.format(
                        _redact_ai_secrets((raw_structured or '')[:900])), 1)
                else:
                    ai_data = structured_data
        except Exception as exc:
            token_usage = _pop_last_ai_token_usage()
            safe_exc = _safe_exception_text(exc, 160)
            if self._provider == 'Gemini' and ('429' in safe_exc or 'limicie' in safe_exc):
                ai_data = {
                    'assistant_message': (
                        u'Gemini odrzucił zapytanie, bo wszystkie skonfigurowane klucze są teraz w limicie. '
                        u'Odczekaj chwilę albo przełącz provider AI.'
                    )
                }
            else:
                ai_data = {'assistant_message': u'Błąd połączenia z API: {}'.format(safe_exc[:90])}
            log('[AI_SEARCH] AI chat API error provider={} err={}'.format(
                self._provider or '-', safe_exc), 1)
        ai_data = _ai_apply_requested_media_type(ai_data, self._history)
        ai_data = self._filter_requested_media_type_candidates(ai_data)
        ai_data = _ai_filter_rejected_titles(ai_data, getattr(self, '_rejected_titles', []))
        ai_data = _ai_filter_requested_production_year(ai_data, self._history)
        ai_data = _ai_guard_repeated_next_question(ai_data, self._history)
        ai_data = _ai_guard_found_without_showable_result(ai_data)
        if token_usage:
            ai_data['_token_usage'] = token_usage
        self._on_ai_response(ai_data)

    def _on_ai_response(self, ai_data):
        with self._lock:
            self._ai_data = ai_data
            self._set_token_usage(ai_data.get('_token_usage') or None)
            if ai_data.get('next_question'):
                ai_data['next_question'] = _ai_compact_text(ai_data.get('next_question'), 95, question=True)
            msg = _ai_compact_text(ai_data.get('assistant_message') or '', 125)
            if not msg and ai_data.get('next_question'):
                msg = str(ai_data.get('next_question'))
            if not msg:
                msg = u'Nie potrafię tego przetworzyć. Powiedz coś więcej.'

            title = ai_data.get('confirmation_title') or ai_data.get('search_query') or ''
            self._ready = bool(ai_data.get('ready_to_confirm'))
            self._current_title = title if self._ready and title else ''
            display_msg = msg
            if self._ready and title:
                display_msg = u'{} Czy chodzi o tytuł: {}?'.format(msg, title)
            hide_ambiguous_candidates = _ai_should_hide_ambiguous_candidates(
                ai_data, getattr(self, '_hidden_candidate_rounds', 0))
            hidden_question = ''
            if hide_ambiguous_candidates and not self._ready:
                display_msg = _ai_hidden_candidates_message(ai_data)
                hidden_question = _ai_hidden_candidates_question(ai_data)
                if hidden_question and not ai_data.get('next_question'):
                    ai_data['next_question'] = hidden_question
                self._hidden_candidate_rounds = getattr(self, '_hidden_candidate_rounds', 0) + 1

            # ZMIANA (2026-05) [PERFORMANCE]: głos startuje przed budową kart kandydatów.
            # POWOD: pobieranie posterow/kart moze trwac; TTS ma startowac rownolegle z GUI, niezaleznie od providera AI.
            # NIE ZMIENIAC: kandydaci i JSON pozostaja bez zmian; do glosu uzywamy tylko tekstu koncowego.
            voice_candidate_count = 0 if hide_ambiguous_candidates else _ai_voice_fast_candidate_count(ai_data)
            voice_text = _ai_voice_build_text(ai_data, display_msg, voice_candidate_count)
            _ai_voice_speak_async(voice_text, source='chat')

            candidate_rows = [] if hide_ambiguous_candidates else self._candidate_rows(ai_data)
            candidate_lines = [row.get('line') or '' for row in candidate_rows]

            self._set_line(self._thinking_idx, u'AI: ' + display_msg, role='assistant')
            self._history.append({'role': 'assistant', 'content': display_msg})
            if candidate_lines:
                self._add_line(u'AI: Kandydaci z web search są pokazani poniżej jako karty.', role='assistant')
                self._render_candidate_cards(candidate_rows)
                self._history.append({
                    'role': 'assistant',
                    'content': u'Kandydaci pokazani użytkownikowi: ' + u'; '.join(candidate_lines)
                })
                # ZMIANA (2026-05) [PERFORMANCE]: po wyswietleniu kart startuj pre-fetch TMDB + TTS w tle.
                # POWOD: uzytkownik czyta liste przez kilka-kilkadziesiat sekund; pre-fetch wypelnia cache
                #        zanim kliknie Podglad → cache hit → glos startuje natychmiast zamiast po ~10s.
                # NIE ZMIENIAC: daemon thread umiera z dialogiem; nie modyfikuje stanu UI ani ai_data.
                try:
                    import threading as _threading
                    _pf = _threading.Thread(
                        target=self._prefetch_candidate_voices_bg,
                        args=(list(candidate_rows),),
                    )
                    _pf.daemon = True
                    _pf.start()
                except Exception:
                    pass
            else:
                self._clear_candidate_cards()
            self._set_result_buttons(self._ready and bool(title))
            log('[AI_SEARCH] AI chat response ready={} title={} next_question={} candidates={} msg_len={} year_mismatch={} title_preview={}'.format(
                bool(self._ready), 'yes' if title else 'no',
                'yes' if ai_data.get('next_question') else 'no', len(candidate_lines), len(display_msg or ''),
                'yes' if ai_data.get('_year_mismatch') else 'no',
                _redact_ai_secrets((title or '')[:80])), 1)
            if self._ready and title:
                if candidate_lines:
                    self._add_line(u'AI: Wynik jest pokazany poniżej jako karta. Możesz użyć Szukaj Kodi albo wpisać TAK.', role='assistant')
                self._add_line(u'AI: Jeśli to ten tytuł, wpisz TAK. Jeśli nie, wpisz NIE i dopisz kolejny szczegół.', role='assistant')
                self._set_hint(u'Wynik jest w karcie. Użyj Szukaj Kodi albo wpisz TAK. Jeśli nie pasuje, wpisz NIE albo dopisz szczegół.')
            elif candidate_lines:
                if getattr(self, '_hidden_candidate_rounds', 0):
                    self._add_line(u'AI: Zawęziłem tropy i pokazuję najlepszych kandydatów poniżej.', role='assistant')
                self._add_line(u'AI: Użyj Podgląd albo Szukaj Kodi przy kandydacie. Jeśli nie pasuje, dopisz krótki szczegół.', role='assistant')
                # ZMIANA: podpowiedź dla użytkownika że może poprosić o więcej wyników
                # POWOD: użytkownik nie wiedział że może napisać "pokaż więcej" lub dopisać szczegół
                # NIE ZMIENIAC: linia powyżej zostaje, ta jest dodatkiem
                self._add_line(u'AI: [B]Nie widzisz swojego wyniku?[/B] Napisz: [B]pokaż więcej[/B] lub [B]dopisz szczegół.[/B]', role='assistant')
                # ZMIANA (2026-05) [BUGFIX]: wyswietl next_question od Gemini gdy sa kandydaci.
                # POWOD: Gemini generuje inteligentne pytanie naprowadzajace (next_question=yes w logu)
                #        ale kod go ignorowal gdy byli kandydaci — uzytkownik widzial tylko sztywna instrukcje.
                # NIE ZMIENIAC: next_question wyswietlamy DODATKOWO po sztywnej linii, nie zamiast niej.
                nq = str(ai_data.get('next_question') or '').strip()
                if nq:
                    self._add_line(u'AI: ' + nq, role='assistant')
                    self._history.append({'role': 'assistant', 'content': nq})
                self._set_hint(u'Kandydaci są w kartach. Jeśli żaden nie pasuje, napisz co się zgadza albo co jest inne.')
            elif hide_ambiguous_candidates:
                nq = hidden_question or str(ai_data.get('next_question') or '').strip()
                if nq and nq not in display_msg:
                    self._add_line(u'AI: ' + nq, role='assistant')
                    self._history.append({'role': 'assistant', 'content': nq})
                self._set_hint(u'Kandydaci zostali ukryci, bo wynik jest zbyt szeroki. Odpowiedz krajem, latami, gatunkiem albo dopisz kolejny trop.')
            elif ai_data.get('next_question'):
                nq = str(ai_data.get('next_question') or '').strip()
                if nq and nq not in display_msg:
                    self._add_line(u'AI: ' + nq, role='assistant')
                    self._history.append({'role': 'assistant', 'content': nq})
                self._set_hint(u'Odpowiedz na pytanie AI albo dopisz kolejny szczegół. Przyciski TMDB/YouTube odblokują się dopiero po tytule.')
            else:
                self._add_line(u'AI: Odpowiedz na pytanie powyżej albo dopisz kolejny szczegół.', role='assistant')
                self._set_hint(u'Odpowiedz na pytanie AI albo dopisz kolejny szczegół. Przyciski TMDB/YouTube odblokują się dopiero po tytule.')

            self._busy = False
            try:
                if candidate_lines:
                    self._focus_first_candidate_card()
                else:
                    self.setFocusId(self.CTRL_INPUT)
            except Exception:
                pass

    def onClick(self, control_id):
        if self._handle_candidate_card_click(control_id):
            return
        if control_id == self.CTRL_CANCEL:
            self.result = {'action': 'cancel', 'ai_data': {}, 'history': self._history}
            self.close()
            return
        if control_id == self.CTRL_CLEAR:
            self._clear_chat()
            return
        if control_id in (self.CTRL_TMDB, self.CTRL_YOUTUBE):
            self._open_result_link(youtube=(control_id == self.CTRL_YOUTUBE))
            return
        if control_id == self.CTRL_INPUT:
            if self._busy:
                self._set_hint(u'AI jeszcze szuka. Poczekaj chwilę na odpowiedź.')
                return
            try:
                kb = control.keyboard('', u'Odpowiedz')
                kb.doModal()
                if not kb.isConfirmed():
                    return
                text = (kb.getText() or '').strip()
                if not text:
                    return
            except Exception:
                return

            if self._preview_candidate_choice(text):
                return

            confirm_words = (
                'tak', 'yes', 'ok', 'zgadza się', 'zgadza sie', 'dokładnie', 'dokladnie',
                'to ten', 'to jest to', 'pokaż', 'pokaz', 'pokaż wynik', 'pokaz wynik',
                'wyszukaj', 'szukaj', 'szukaj w kodi', 'otwórz', 'otworz'
            )
            if self._ready and text.lower() in confirm_words:
                log('[AI_SEARCH] AI chat confirmed by user text={}'.format(_redact_ai_secrets(text[:40])), 1)
                self.result = {'action': 'confirm', 'ai_data': self._ai_data, 'history': self._history}
                self.close()
                return

            rejected_title = ''
            if self._ready and self._current_title and _ai_is_rejection_text(text):
                rejected_title = self._current_title
                rejected_variants = _ai_rejected_title_variants(self._ai_data, rejected_title)
                for rejected_variant in rejected_variants:
                    if rejected_variant not in self._rejected_titles:
                        self._rejected_titles.append(rejected_variant)
                self._ready = False
                self._current_title = ''
                log('[AI_SEARCH] AI chat rejected title={}'.format(
                    _redact_ai_secrets(u'; '.join(rejected_variants or [rejected_title])[:120])), 1)

            self._add_line(u'TY: ' + text, role='user')
            self._history.append({'role': 'user', 'content': text})
            if rejected_title:
                self._history.append({
                    'role': 'assistant',
                    'content': u'ODRZUCONY TYTUŁ: {}'.format(u'; '.join(rejected_variants or [rejected_title]))
                })
            log('[AI_SEARCH] AI chat user message len={} history_items={}'.format(
                len(text or ''), len(self._history)), 1)
            if self._maybe_local_preflight_question():
                return
            self._start_ai_call()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = 0
        if action_id in (3, 4, 5, 6, 104, 105):
            self._last_candidate_nav_action_id = action_id
        else:
            self._last_candidate_nav_action_id = 0
        if self._handle_candidate_scroll_action(action_id):
            return True
        return False

    def onFocus(self, control_id):
        if self._candidate_focus_location(control_id)[0] is not None:
            self._last_candidate_focus_id = control_id
            self._candidate_scroll_focus_guard = False
            self._candidate_scroll_focus_guard_id = 0
            return
        if control_id == self.CTRL_CHAT_TEXT and self._candidate_cards_active() and not self._mobile_candidate_enabled():
            if self._last_candidate_nav_action_id == 3 and self._scroll_up_from_first_candidate_focus():
                self._last_candidate_nav_action_id = 0
                return
            self._last_candidate_nav_action_id = 0
        if control_id == self.CTRL_INPUT and self._candidate_cards_active() and not self._mobile_candidate_enabled():
            if self._last_candidate_nav_action_id == 4 and self._scroll_down_from_last_candidate_focus():
                self._last_candidate_nav_action_id = 0
                return
            self._last_candidate_nav_action_id = 0


def _finish_ai_cancel_directory(handle):
    if handle is None or handle < 0:
        return
    try:
        item = xbmcgui.ListItem(label=u'[COLOR gray]Anulowano wyszukiwanie AI — wróć do menu[/COLOR]')
        xbmcplugin.addDirectoryItem(handle, '', item, False)
        xbmcplugin.endOfDirectory(handle, succeeded=True)
    except Exception:
        pass


def _ai_media_type_from_text(text):
    folded = _ai_fold_text(text or '')
    tv_matches = list(re.finditer(r'\b(serial|serialu|seriale|sezon|odcinek|odcinki|tv show|series)\b', folded))
    # ZMIANA (2026-05) [BUGFIX]: dodano bajka/animacja/anime jako movie.
    # POWOD: uzytkownik piszacy "bajka z lat 90" dostawal multi zamiast movie — brak filtrowania.
    # NIE ZMIENIAC: anime i animacja trafiaja do movie (sa zazwyczaj filmami lub maja odpowiednik filmowy).
    movie_matches = list(re.finditer(r'\b(film|filmu|filmy|movie|bajka|bajki|bajek|animacja|animacji|anime)\b', folded))
    has_tv = bool(tv_matches)
    has_movie = bool(movie_matches)
    if has_tv and not has_movie:
        return 'tv'
    if has_movie and not has_tv:
        return 'movie'
    if has_tv and has_movie:
        return 'tv' if tv_matches[-1].start() > movie_matches[-1].start() else 'movie'
    return ''


def _ai_media_type_from_history(history):
    for item in reversed(history or []):
        if item.get('role') != 'user':
            continue
        media_type = _ai_media_type_from_text(item.get('content') or '')
        if media_type:
            return media_type
    return ''


def _ai_apply_requested_media_type(ai_data, history=None):
    requested_type = _ai_media_type_from_history(history)
    if requested_type not in ('movie', 'tv') or not isinstance(ai_data, dict):
        return ai_data
    data = dict(ai_data)
    data['type'] = requested_type
    data['_requested_media_type'] = requested_type
    candidates = data.get('candidates') or []
    if isinstance(candidates, list):
        normalized = []
        for item in candidates:
            if isinstance(item, dict):
                fixed = dict(item)
                fixed['type'] = requested_type
                fixed['media_type'] = requested_type
                normalized.append(fixed)
            else:
                normalized.append({'title': u'{}'.format(item or '').strip(), 'type': requested_type, 'media_type': requested_type})
        data['candidates'] = normalized
    try:
        log('[AI_SEARCH] requested media_type enforced type={} candidates={}'.format(
            requested_type, len(data.get('candidates') or []) if isinstance(data.get('candidates'), list) else 0), 1)
    except Exception:
        pass
    return data


def _ai_normalize_media_type(value):
    value = (value or '').strip().lower()
    if value in ('tv', 'show', 'series', 'serial', 'tvshow', 'tv_show'):
        return 'tv'
    if value in ('movie', 'film', 'movies'):
        return 'movie'
    return ''


def _ai_clean_confirmed_search_title(title, year=''):
    title = (title or '').strip()
    year = str(year or '').strip()

    found_year = re.search(
        r'(?:\(|y:)\s*((?:19|20)\d{2})(?:\s+(?:film|movie|tv\s*series|tv\s*show|television\s*series))?\s*\)?',
        title or '',
        re.I
    )
    if found_year and not re.match(r'^\d{4}$', year or ''):
        year = found_year.group(1)

    title = re.sub(
        r'\s*(?:\(|y:)\s*(?:19|20)\d{2}(?:\s+(?:film|movie|tv\s*series|tv\s*show|television\s*series))?\s*\)?',
        ' ',
        title or '',
        flags=re.I
    )
    title = re.sub(
        r'\s*[-:/,]?\s*(?:tv\s*series|tv\s*show|television\s*series|serial\s*tv|series\s*tv|movie|film)\s*$',
        '',
        title,
        flags=re.I
    )
    title = re.sub(r'\s+', ' ', title).strip(' -:/,')

    if not re.match(r'^\d{4}$', year or ''):
        year = ''
    return title, year


def _ai_confirmed_search_target(ai_data, history=None):
    ai_data = ai_data or {}
    title = (ai_data.get('search_query') or ai_data.get('confirmation_title') or '').strip()
    media_type = _ai_normalize_media_type(ai_data.get('type'))
    year = str(ai_data.get('year') or '').strip()

    candidates = ai_data.get('candidates') or []
    if isinstance(candidates, list):
        for item in candidates:
            if not isinstance(item, dict):
                continue
            cand_title = (
                item.get('title') or item.get('search_query') or item.get('confirmation_title') or
                item.get('original_title') or item.get('english_title') or item.get('pl_title') or ''
            ).strip()
            if not cand_title:
                continue
            if (not title) or cand_title.lower() == title.lower():
                title = title or cand_title
                media_type = media_type or _ai_normalize_media_type(item.get('type') or item.get('media_type'))
                year = year or str(item.get('year') or '').strip()
                break

    media_type = media_type or _ai_media_type_from_history(history)
    # ZMIANA (2026-05) [PATCH]: jesli media_type wciaz pusty, weź type z PIERWSZEGO kandydata ktory go ma.
    # POWOD: AI czasami zwraca top-level "type": null ale candidates[].type prawidlowo wypelnione.
    #        Bez tego fallback'a ai_search_action defaultowal cicho do MOVIE — zle dla serialu.
    # NIE ZMIENIAC: bierzemy PIERWSZY dostepny (z najwiekszym confidence — kandydaci sa juz posortowani
    #               przez AI), a nie skanujemy wszystkich i nie robimy majority vote, zeby nie ryzykowac
    #               sprzeczosci gdy AI da mieszany typ z niska pewnosca.
    if not media_type and isinstance(candidates, list):
        for item in candidates:
            if not isinstance(item, dict):
                continue
            inferred = _ai_normalize_media_type(item.get('type') or item.get('media_type'))
            if inferred:
                media_type = inferred
                break
    title, year = _ai_clean_confirmed_search_title(title, year)
    match = re.search(r'^(.*?)\s*(?:\(|y:)(\d{4})\)?$', title or '')
    if match:
        title = match.group(1).strip()
        year = year or match.group(2)
    if not re.match(r'^\d{4}$', year or ''):
        year = ''
    return title, media_type, year


def ai_search_action():
    import sys
    handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1

    provider = _normalize_ai_provider(control.setting('ai_search.provider') or _AI_DEFAULT_PROVIDER)
    key_id   = 'ai_search.key.' + provider.lower()
    api_key  = (control.setting(key_id) or '').strip()

    if not api_key:
        xbmcgui.Dialog().ok('Błąd', 'Brak klucza API dla {}'.format(provider))
        _finish_ai_cancel_directory(handle)
        return

    import xbmcaddon
    try:
        addon_path = xbmcaddon.Addon().getAddonInfo('path')
        dialog = _AIChatXMLDialog(
            _AI_CHAT_XML_FILE, addon_path, 'Default', '1080i',
            caller=_CALLERS[provider], api_key=api_key, provider=provider,
            history=[], addon_path=addon_path,
        )
        # ZMIANA (2026-05) [PATCH]: ustaw property przed doModal() — service.py sprawdza to w _activate_to()
        # POWOD: Dialog.Close(all,true) w _activate_to() zamykalo AI chat dialog → crash GetDirectory(plugin://)
        # NIE ZMIENIAC: property musi byc ustawione PRZED doModal() i czyszczone ZAWSZE po (nawet przy wyjatku)
        try:
            xbmcgui.Window(10000).setProperty('FanVodPL.ai_chat_active', '1')
        except Exception:
            pass
        try:
            dialog.doModal()
        finally:
            try:
                xbmcgui.Window(10000).clearProperty('FanVodPL.ai_chat_active')
            except Exception:
                pass
        result = dict(getattr(dialog, 'result', {'action': 'cancel'}))
        del dialog
    except Exception as exc:
        log('[AI_SEARCH] window ERROR: {}'.format(str(exc)), 1)
        _finish_ai_cancel_directory(handle)
        return

    if result.get('action') != 'confirm':
        _finish_ai_cancel_directory(handle)
        return

    ai_data = result.get('ai_data') or {}
    search_query, media_type, year = _ai_confirmed_search_target(ai_data, result.get('history') or [])

    if not search_query:
        xbmcgui.Dialog().notification('Błąd', 'Brak tytułu do wyszukania', xbmcgui.NOTIFICATION_WARNING)
        _finish_ai_cancel_directory(handle)
        return

    try:
        # ZMIANA (2026-05) [PATCH]: rozdzielono branch na 3 sciezki — tv / movie / dialog wyboru.
        # POWOD: Poprzedni 'if tv else movie' cicho zgadywal MOVIE przy pustym media_type.
        #        Po 3-warstwowym fallback'u (history -> candidates[].type) sytuacja "pusty type" oznacza,
        #        ze NIKT (ani AI, ani historia, ani zaden kandydat) nie wskazal typu — wiec pytamy uzytkownika
        #        zamiast zgadywac. Cancel dialogu = anulowanie wyszukiwania.
        # NIE ZMIENIAC: kolejnosc 'Film' / 'Serial' w select() — Film jako pierwszy (index 0),
        #               bo to czesciejszy przypadek; zmiana indeksow zlamie mapowanie ponizej.
        if media_type == 'tv':
            from resources.lib.indexers.tvshows import tvshows as TVShowsClass
            log('[AI_SEARCH] confirmed search -> tv title={} year={}'.format(
                _redact_ai_secrets(search_query[:80]), year or '-'), 1)
            TVShowsClass().search_term(search_query, year=year)
        elif media_type == 'movie':
            from resources.lib.indexers.movies import movies as MoviesClass
            log('[AI_SEARCH] confirmed search -> movie title={} year={}'.format(
                _redact_ai_secrets(search_query[:80]), year or '-'), 1)
            kwargs = {}
            if year:
                kwargs['year'] = year
            MoviesClass().search_term(search_query, **kwargs)
        else:
            # Pusty media_type: zapytaj uzytkownika zamiast zgadywac.
            log('[AI_SEARCH] confirmed search -> media_type empty, asking user title={}'.format(
                _redact_ai_secrets(search_query[:80])), 1)
            try:
                choice = xbmcgui.Dialog().select(
                    u'Nie jestem pewny typu „{}" — wybierz:'.format(search_query[:50]),
                    [u'Film', u'Serial']
                )
            except Exception as exc:
                log('[AI_SEARCH] media_type select dialog ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
                choice = -1
            if choice == 0:
                from resources.lib.indexers.movies import movies as MoviesClass
                log('[AI_SEARCH] user picked movie title={}'.format(_redact_ai_secrets(search_query[:80])), 1)
                kwargs = {}
                if year:
                    kwargs['year'] = year
                MoviesClass().search_term(search_query, **kwargs)
            elif choice == 1:
                from resources.lib.indexers.tvshows import tvshows as TVShowsClass
                log('[AI_SEARCH] user picked tv title={}'.format(_redact_ai_secrets(search_query[:80])), 1)
                TVShowsClass().search_term(search_query, year=year)
            else:
                _finish_ai_cancel_directory(handle)
                return
    except Exception as exc:
        log('[AI_SEARCH] search ERROR: {}'.format(str(exc)), 1)
        xbmcgui.Dialog().notification('Błąd', 'Wystąpił problem przy wyszukiwaniu w TMDB', xbmcgui.NOTIFICATION_ERROR)


def year_range_search_action():
    import sys
    handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1

    kb = control.keyboard('', u'Od roku (np. 2016)')
    kb.doModal()
    if not kb.isConfirmed():
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    year_from = (kb.getText() or '').strip()

    kb = control.keyboard('', u'Do roku (np. 2025)')
    kb.doModal()
    if not kb.isConfirmed():
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    year_to = (kb.getText() or '').strip()

    try:
        if int(year_from) > int(year_to):
            year_from, year_to = year_to, year_from
    except ValueError:
        pass  # Ignorujemy błąd jeśli wpisano np. litery, TMDB zwróci błąd później.

    date_from = year_from + '-01-01'
    date_to   = year_to   + '-12-31'

    # ZMIANA (2026-05) [PATCH]: Naprawiono rozbity import `movie\ns`, który blokował kompilację pliku.
    # POWOD: Import był przecięty znakiem nowej linii i powodował SyntaxError przed uruchomieniem dodatku.
    # NIE ZMIENIAC: Import ma dalej wskazywać na `resources.lib.indexers.movies.movies`, bo tej klasy używa dalsza logika.
    from resources.lib.indexers.movies import movies as MoviesClass
    m = MoviesClass()
    url = m.tmdb_discover_years % (date_from, date_to)
    movies_mod = __import__('resources.lib.indexers.movies', fromlist=['movies'])
    movies_mod.movies.get(m, url, category=u'Filmy {}\u2013{}'.format(year_from, year_to))
