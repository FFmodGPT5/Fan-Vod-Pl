"""
    FanVodPL — Wyszukiwanie AI
    Obsługiwane providery z natywnym web search: Gemini, OpenAI, Claude
"""

import json
import re

# ZMIANA (2026-05) [NOWA FUNKCJA]: import xbmc potrzebny do otwierania strony TMDB z okna AI.
# POWOD: przycisk TMDB uzywa Kodi built-in na Androidzie i sprawdza platforme bez ruszania logiki wyszukiwania.
# NIE ZMIENIAC: ten import obsluguje tylko akcje GUI; nie dotyka rozliczen, providerow AI ani hostow.
import xbmc
import xbmcgui
import xbmcplugin

from ptw.libraries import control
from ptw.libraries.log_utils import log as _unsafe_log


_AI_LAST_TOKEN_USAGE = None

_AI_SECRET_SETTING_IDS = (
    'ai_search.key.gemini',
    'ai_search.key.openai',
    'ai_search.key.claude',
    'google_search.api_key',
    'tm.user',
    'tm.user_bearer',
    'fanart.tv.user',
    'fanart.tv.dev',
)


_LEGAL_RESEARCH_USER_AGENT = 'FanVodPL-Kodi/2.0 legal metadata search'
_AI_WEB_SEARCH_PROVIDERS = ('Gemini', 'OpenAI', 'Claude')
_AI_DEFAULT_PROVIDER = 'Gemini'
_AI_REASONING_AGENT_PROMPT_FILE = 'ai_reasoning_agent_prompt.txt'
_AI_REASONING_AGENT_PROMPT_CACHE = None
_AI_DESCRIPTION_ANALYZER_PROMPT_FILE = 'ai_description_analyzer_prompt.txt'
_AI_DESCRIPTION_ANALYZER_PROMPT_CACHE = None


def _legal_research_headers(accept='application/json'):
    # ZMIANA (2026-04) [LEGAL]: wspolny User-Agent dla legalnych API metadanych.
    # POWOD: Wikipedia/Wikimedia wymaga rozpoznawalnego UA; nie udajemy przegladarki i nie pobieramy stron do parsowania.
    return {
        'User-Agent': _LEGAL_RESEARCH_USER_AGENT,
        'Accept': accept,
    }


def _ai_secret_values():
    values = []
    try:
        for setting_id in _AI_SECRET_SETTING_IDS:
            value = (control.setting(setting_id) or '').strip()
            if value and value.lower() != 'true' and len(value) >= 8:
                values.append(value)
    except Exception:
        pass
    return values


def _redact_ai_secrets(value):
    # ZMIANA (2026-04) [PATCH]: centralne maskowanie sekretow w logach AI.
    # POWOD: HTTPError z requests moze zawierac pelny URL Gemini/TMDB z parametrem key/api_key.
    # NIE ZMIENIAC: wszystkie log() w tym module przechodza przez ten filtr, zanim trafia do kodi.log.
    text = str(value or '')
    try:
        for secret in _ai_secret_values():
            if secret:
                text = text.replace(secret, '[REDACTED_KEY]')
        patterns = [
            (r'([?&])(?:key|api_key|apiKey|access_token)=[^&\s\'")]+', r'\1[REDACTED_QUERY_SECRET]'),
            (r'((?:Authorization|authorization)[\'"]?\s*:\s*[\'"]?Bearer\s+)[A-Za-z0-9._\-]+', r'\1[REDACTED_KEY]'),
            (r'((?:x-api-key|X-API-Key|x-goog-api-key|X-Goog-Api-Key|api-key)[\'"]?\s*:\s*[\'"]?)[A-Za-z0-9._\-]+', r'\1[REDACTED_KEY]'),
            (r'([\'"](?:key|api_key|apiKey|access_token)[\'"]\s*:\s*[\'"])[^\'"]+', r'\1[REDACTED_KEY]'),
            (r'\bAIza[0-9A-Za-z_\-]{20,}\b', '[REDACTED_GEMINI_KEY]'),
            (r'\bsk-proj-[0-9A-Za-z_\-]{20,}\b', '[REDACTED_OPENAI_KEY]'),
            (r'\bsk-ant-[0-9A-Za-z_\-]{20,}\b', '[REDACTED_CLAUDE_KEY]'),
        ]
        for pattern, repl in patterns:
            text = re.sub(pattern, repl, text)
    except Exception:
        return '[REDACTED_LOG_ERROR]'
    return text


def _safe_exception_text(exc, limit=140):
    text = _redact_ai_secrets(str(exc))
    status = ''
    try:
        response = getattr(exc, 'response', None)
        status_code = getattr(response, 'status_code', None)
        if status_code:
            status = 'HTTP {}'.format(status_code)
    except Exception:
        status = ''
    if status and status not in text:
        text = '{} {}'.format(status, text)
    return text[:limit]


def _tmdb_auth():
    # ZMIANA (2026-04) [PATCH]: preferuj TMDB Bearer header zamiast api_key w URL.
    # POWOD: query parametry latwiej trafiaja do logow bibliotek/proxy; header nie pojawia sie w HTTPError URL.
    # NIE ZMIENIAC: api_key zostaje jako fallback dla istniejacych konfiguracji uzytkownika.
    try:
        bearer = (control.setting('tm.user_bearer') or '').strip()
    except Exception:
        bearer = ''
    if bearer:
        if bearer.lower().startswith('bearer '):
            bearer = bearer[7:].strip()
        if bearer:
            return {'Authorization': 'Bearer ' + bearer}, ''
    try:
        from ptw.libraries import apis as _apis
        api_key = (control.setting('tm.user') or getattr(_apis, 'tmdb_API', '') or '').strip()
    except Exception:
        try:
            api_key = (control.setting('tm.user') or '').strip()
        except Exception:
            api_key = ''
    return {}, api_key


def log(message, level=0):
    try:
        return _unsafe_log(_redact_ai_secrets(message), level)
    except TypeError:
        return _unsafe_log(_redact_ai_secrets(message))


def _normalize_ai_provider(provider, log_change=False):
    # ZMIANA (2026-04) [PATCH]: tylko providery z natywnym web search sa aktywne.
    # POWOD: wyszukiwanie tytulu ma opierac sie na oficjalnym web search providera.
    # NIE ZMIENIAC: stara lub pusta konfiguracja ma bezpiecznie spasc na Gemini, bez crasha Kodi.
    raw = (provider or '').strip()
    aliases = dict((p.lower(), p) for p in _AI_WEB_SEARCH_PROVIDERS)
    normalized = aliases.get(raw.lower())
    if normalized:
        return normalized
    if log_change and raw:
        log('[AI_SEARCH] provider {} disabled: native web_search required; fallback={}'.format(
            raw, _AI_DEFAULT_PROVIDER), 1)
    return _AI_DEFAULT_PROVIDER


def _ai_token_int(value):
    try:
        if value is None:
            return None
        return int(value)
    except Exception:
        return None


def _ai_token_label(value):
    value = _ai_token_int(value)
    return str(value) if value is not None else '-'


def _clear_last_ai_token_usage():
    global _AI_LAST_TOKEN_USAGE
    _AI_LAST_TOKEN_USAGE = None


def _pop_last_ai_token_usage():
    global _AI_LAST_TOKEN_USAGE
    usage = _AI_LAST_TOKEN_USAGE
    _AI_LAST_TOKEN_USAGE = None
    return usage


def _log_ai_token_usage(provider, model, input_tokens=None, output_tokens=None, total_tokens=None, extra=None):
    # ZMIANA (2026-04) [PATCH]: logujemy tylko liczniki tokenow, nigdy klucze ani tresc promptu.
    global _AI_LAST_TOKEN_USAGE
    input_tokens = _ai_token_int(input_tokens)
    output_tokens = _ai_token_int(output_tokens)
    total_tokens = _ai_token_int(total_tokens)
    if total_tokens is None and input_tokens is not None and output_tokens is not None:
        total_tokens = input_tokens + output_tokens
    extra = extra or {}
    extra_txt = ''
    for key in sorted(extra.keys()):
        val = _ai_token_int(extra.get(key))
        if val is not None:
            extra_txt += ' {}={}'.format(key, val)
    if input_tokens is None and output_tokens is None and total_tokens is None and not extra_txt:
        log('[AI_SEARCH] AI_TOKEN_USAGE provider={} model={} unavailable'.format(provider, model), 1)
    else:
        log('[AI_SEARCH] AI_TOKEN_USAGE provider={} model={} input={} output={} total={}{}'.format(
            provider, model, _ai_token_label(input_tokens), _ai_token_label(output_tokens),
            _ai_token_label(total_tokens), extra_txt), 1)
    _AI_LAST_TOKEN_USAGE = {
        'provider': provider,
        'model': model,
        'input': input_tokens,
        'output': output_tokens,
        'total': total_tokens,
    }


def _log_openai_compatible_usage(provider, model, data):
    usage = (data or {}).get('usage') or {}
    _log_ai_token_usage(
        provider,
        model,
        input_tokens=usage.get('prompt_tokens') or usage.get('input_tokens'),
        output_tokens=usage.get('completion_tokens') or usage.get('output_tokens'),
        total_tokens=usage.get('total_tokens'),
    )

# ---------------------------------------------------------------------------
# Prompt systemowy dla AI
# ---------------------------------------------------------------------------
_SYSTEM_PROMPT = (
    # ZMIANA (2026-04) [PATCH]: prompt uproszczony do minimum — rola + schemat JSON.
    # POWOD: cała logika wyszukiwania przeniesiona do _build_mini_chat_prompt z danymi TMDB;
    #        długi coaching w system prompt marnował tokeny i dezorientował AI.
    # NIE ZMIENIAC: schemat JSON musi pozostać — parser odpowiedzi zależy od tych pól.
    "Jesteś asystentem wyszukiwania filmów i seriali. Odpowiadasz WYŁĄCZNIE w JSON.\n\n"
    "Odpowiedz WYŁĄCZNIE w JSON bez tekstu przed/po:\n"
    "Dla filmu/serialu zagranicznego confirmation_title i search_query musza byc oryginalnym albo angielskim tytulem TMDB; polski tytul wpisuj tylko w pl_title.\n"
    "{\n"
    "  \"assistant_message\": \"odpowiedź dla użytkownika — lista filmów lub pytanie\",\n"
    "  \"next_question\": \"jedno pytanie albo null\",\n"
    "  \"ready_to_confirm\": true albo false,\n"
    "  \"confirmation_title\": \"tytuł do potwierdzenia albo null\",\n"
    "  \"search_query\": \"tytuł do TMDB albo null\",\n"
    "  \"english_title\": \"angielski tytuł lub null\",\n"
    "  \"pl_title\": \"polski tytuł lub null\",\n"
    "  \"original_title\": \"oryginalny tytuł lub null\",\n"
    "  \"is_polish\": true albo false,\n"
    "  \"year\": \"rok lub null\",\n"
    "  \"type\": \"movie lub tv lub null\",\n"
    "  \"confidence\": 0-100,\n"
    "  \"candidates\": [{\"title\":\"...\",\"year\":\"...\",\"confidence\":0}],\n"
    "  \"matched_rare_clues\": [\"rzadki trop potwierdzony w web/API\"],\n"
    "  \"missing_rare_clues\": [\"wazny trop bez potwierdzenia\"],\n"
    "  \"evidence_score\": 0-100,\n"
    "  \"fallback_queries\": [\"fraza1\", \"fraza2\"]\n"
    "}\n"
)
# ---------------------------------------------------------------------------
# Provider callers
# ---------------------------------------------------------------------------
def _call_gemini(api_key, query):
    # ZMIANA (2026-04) [NOWA FUNKCJA]: Gemini z Google Search grounding — prawdziwe wyszukiwanie
    # stron internetowych (filmweb.pl, imdb.com, wikipedia itd.) tak jak Google.
    # POWOD: Gemini ma natywny dostęp do Google Search w API; bez dodatkowego klucza ani konfiguracji.
    # NIE ZMIENIAC: 'google_search' tool musi być w tools[]; bez niego Gemini działa bez web search.
    # ZMIANA (2026-05) [PATCH]: usunięto responseMimeType z zapytania z google_search — API zwracało 400.
    # POWOD: Gemini API nie pozwala łączyć google_search grounding z responseMimeType application/json.
    # NIE ZMIENIAC: nie dodawać z powrotem responseMimeType do zapytania z tools google_search.
    import requests
    r = requests.post(
        'https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent'.format(_gemini_model_choice()),
        headers={'Content-Type': 'application/json', 'x-goog-api-key': api_key},
        json={
            'contents': [{'parts': [{'text': query}]}],
            'tools': [{'google_search': {}}],
            'systemInstruction': {'parts': [{'text': _SYSTEM_PROMPT}]},
            'generationConfig': {'maxOutputTokens': 1400, 'temperature': 0.1},
        },
        timeout=20,
    )
    r.raise_for_status()
    data = r.json()
    parts = (((data.get('candidates') or [{}])[0].get('content') or {}).get('parts') or [])
    return ''.join(p.get('text', '') for p in parts)

def _call_claude(api_key, query):
    import requests
    model = 'claude-sonnet-4-5-20251022'
    headers = {
        'x-api-key': api_key,
        'anthropic-version': '2023-06-01',
        'Content-Type': 'application/json',
    }
    payload = {
        'model': model,
        'max_tokens': 1400,
        'system': _SYSTEM_PROMPT,
        'messages': [{'role': 'user', 'content': query}],
        'tools': [{'type': 'web_search_20250305', 'name': 'web_search', 'max_uses': 3}],
    }
    r = requests.post(
        'https://api.anthropic.com/v1/messages',
        headers=headers,
        json=payload,
        timeout=35,
    )
    if r.status_code >= 400:
        log('[AI_SEARCH] Claude web_search unavailable status={} fallback=no_tool'.format(r.status_code), 1)
        payload.pop('tools', None)
        r = requests.post(
            'https://api.anthropic.com/v1/messages',
            headers=headers,
            json=payload,
            timeout=15,
        )
    r.raise_for_status()
    data = r.json()
    usage = data.get('usage') or {}
    _log_ai_token_usage(
        'Claude',
        model,
        input_tokens=usage.get('input_tokens'),
        output_tokens=usage.get('output_tokens'),
        extra={
            'cache_create': usage.get('cache_creation_input_tokens'),
            'cache_read': usage.get('cache_read_input_tokens'),
        },
    )
    out = []
    for block in data.get('content') or []:
        if isinstance(block, dict) and block.get('type') == 'text':
            out.append(block.get('text') or '')
    try:
        srcs = _claude_sources_from_response(data)
        search_count = _claude_web_search_count(data)
        log('[AI_SEARCH] Claude final web_search grounding: sources={} searches={}'.format(
            len(srcs), search_count), 1)
    except Exception:
        pass
    return ''.join(out).strip()


def _call_openai(api_key, query):
    import requests

    def _extract_text(data):
        if data.get('output_text'):
            return data.get('output_text')
        out = []
        for item in data.get('output', []) or []:
            if item.get('type') == 'message':
                for part in item.get('content', []) or []:
                    if part.get('type') in ('output_text', 'text'):
                        out.append(part.get('text', ''))
        return ''.join(out).strip()

    _primary_model, fallback_model = _openai_model_choice()
    r = None
    model = _primary_model
    # ZMIANA (2026-05) [PATCH]: OpenAI próbuje najpierw GPT-5.4, potem GPT-5.4 mini i GPT-4.1 w Responses API.
    # POWOD: GPT-5.4 jest docelowym modelem wyszukiwania, ale brak dostępu na koncie nie może zablokować całego czatu AI.
    # NIE ZMIENIAC: każdy wariant używa oficjalnego web_search/tool_choice=required; nie dodajemy scrapowania HTML stron.
    for model in _openai_response_model_candidates():
        payload = {
            'model': model,
            'tools': [{'type': 'web_search', 'search_context_size': 'high'}],
            'tool_choice': 'required',
            'include': ['web_search_call.action.sources'],
            'text': {'format': {'type': 'json_object'}},
            'input': [
                {'role': 'system', 'content': _SYSTEM_PROMPT},
                {'role': 'user', 'content': query},
            ],
            'max_output_tokens': 1400,
        }
        r = requests.post(
            'https://api.openai.com/v1/responses',
            headers={'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'},
            json=payload,
            timeout=45,
        )
        if r.status_code >= 400:
            log('[AI_SEARCH] OpenAI web_search unavailable status={} model={} fallback=web_search_preview'.format(r.status_code, model), 1)
            payload['tools'] = [{'type': 'web_search_preview'}]
            r = requests.post(
                'https://api.openai.com/v1/responses',
                headers={'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'},
                json=payload,
                timeout=45,
            )
        if r.status_code < 400:
            break
    if r.status_code < 400:
        data = r.json()
        usage = data.get('usage') or {}
        output_details = usage.get('output_tokens_details') or {}
        _log_ai_token_usage(
            'OpenAI',
            model,
            input_tokens=usage.get('input_tokens'),
            output_tokens=usage.get('output_tokens'),
            total_tokens=usage.get('total_tokens'),
            extra={'reasoning': output_details.get('reasoning_tokens')},
        )
        return _extract_text(data)
    r2 = requests.post(
        'https://api.openai.com/v1/chat/completions',
        headers={'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'},
        json={
            'model': fallback_model,
            'web_search_options': {},
            'messages': [
                {'role': 'system', 'content': _SYSTEM_PROMPT},
                {'role': 'user', 'content': query},
            ],
            'max_tokens': 1400,
        },
        timeout=45,
    )
    r2.raise_for_status()
    data2 = r2.json()
    _log_openai_compatible_usage('OpenAI', fallback_model, data2)
    return data2['choices'][0]['message']['content']


_CALLERS = {
    'Gemini':  _call_gemini,
    'OpenAI':  _call_openai,
    'Claude':  _call_claude,
}

_KEY_URLS = {
    'Gemini':  'aistudio.google.com  (free tier / platne limity)',
    'OpenAI':  'platform.openai.com  (platne limity API)',
    'Claude':  'console.anthropic.com  (platne limity API)',
}

def _gemini_model_choice():
    # ZMIANA (2026-05) [PATCH]: wybor modelu Gemini z ustawien: darmowy Flash albo platny Pro.
    # POWOD: gemini-2.5-pro jest lepszy dla platnych kluczy, ale darmowy web grounding dziala bezpieczniej na gemini-2.5-flash.
    # NIE ZMIENIAC: nie ustawiaj Pro automatycznie, bo darmowe klucze moga nie miec Google Search grounding dla Pro.
    allowed = ('gemini-2.5-flash', 'gemini-2.5-pro')
    try:
        model = (control.setting('ai_search.gemini_model') or '').strip()
    except Exception:
        model = ''
    if model in allowed:
        return model
    return 'gemini-2.5-flash'

# ---------------------------------------------------------------------------
# Parser odpowiedzi AI
# ---------------------------------------------------------------------------
def _parse_response(text):
    # ZMIANA (2026-04) [PATCH]: odporny parser odpowiedzi AI + awaryjne wyciąganie pól mini-czatu.
    # POWOD: LLM czasem zwraca niepełny JSON; mini-czat musi odzyskać pytanie, tytuł i confidence zamiast wracać do szukania po całym opisie.
    # NIE ZMIENIAC: jeśli JSON jest uszkodzony, próbujemy odzyskać pola rozmowy oraz search_query/pl_title/year/confidence.
    text = (text or '').strip()
    if not text:
        return {}

    m = re.search(r'```(?:json)?\s*([\s\S]+?)\s*```', text)
    if m:
        text = m.group(1).strip()

    candidates = [text]
    start = text.find('{')
    end = text.rfind('}')
    if start != -1 and end != -1 and end > start:
        candidates.append(text[start:end + 1].strip())

    cleaned = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', ' ', text)
    candidates.append(cleaned.strip())

    for candidate in candidates:
        if not candidate:
            continue
        try:
            parsed = json.loads(candidate)
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            pass

    def _extract_string(key):
        pattern = r'"' + re.escape(key) + r'"\s*:\s*"((?:\\.|[^"\\])*)"'
        match = re.search(pattern, text)
        if match:
            raw = match.group(1)
            try:
                return json.loads('"' + raw + '"')
            except Exception:
                return raw.replace('\\"', '"').strip()

        pattern = r'"' + re.escape(key) + r'"\s*:\s*"([^"\r\n,}]*)'
        match = re.search(pattern, text)
        return match.group(1).strip() if match else ''

    def _extract_number(key):
        match = re.search(r'"' + re.escape(key) + r'"\s*:\s*(\d+)', text)
        if not match:
            return 0
        try:
            return int(match.group(1))
        except Exception:
            return 0

    def _extract_bool(key):
        match = re.search(r'"' + re.escape(key) + r'"\s*:\s*(true|false)', text, re.I)
        if not match:
            return False
        return match.group(1).lower() == 'true'

    recovered = {
        'assistant_message': _extract_string('assistant_message'),
        'next_question': _extract_string('next_question'),
        'ready_to_confirm': _extract_bool('ready_to_confirm'),
        'confirmation_title': _extract_string('confirmation_title'),
        'search_query': _extract_string('search_query'),
        'english_title': _extract_string('english_title'),
        'pl_title': _extract_string('pl_title'),
        'original_title': _extract_string('original_title'),
        'is_polish': _extract_bool('is_polish'),
        'year': _extract_string('year'),
        'type': _extract_string('type'),
        'confidence': _extract_number('confidence'),
        'candidates': [],
        'fallback_queries': [],
    }

    if (recovered['assistant_message'] or recovered['next_question'] or recovered['search_query'] or
            recovered['pl_title'] or recovered['english_title'] or recovered['original_title'] or
            recovered['confirmation_title']):
        if not recovered['confidence'] and (recovered['search_query'] or recovered['confirmation_title']):
            recovered['confidence'] = 75
        try:
            log('[AI_SEARCH] JSON parse salvage: recovered={!r}'.format(recovered), 1)
        except Exception:
            pass
        return recovered

    try:
        log('[AI_SEARCH] JSON parse fallback: invalid AI response prefix={!r}'.format(text[:180]), 1)
    except Exception:
        pass
    return {}

# ---------------------------------------------------------------------------
# Fallback mini-czatu AI
# ---------------------------------------------------------------------------
def _fallback_keyboard_chat(history, ai_data, allow_confirm=False, initial=False):
    # ZMIANA (2026-04) [PATCH]: awaryjny fallback, gdy dana wersja Kodi/skórka nie obsłuży okna konsolowego.
    # POWOD: funkcja AI nie może się całkiem wyłożyć na starszym środowisku; fallback zachowuje działanie kosztem gorszego UI.
    # NIE ZMIENIAC: używać tylko awaryjnie, gdy natywne Dialog().select albo keyboard zwrócą błąd.
    text = _chat_ai_message(ai_data) if ai_data else u'Napisz pierwszy opis filmu/serialu.'
    if allow_confirm and _best_title_from_ai(ai_data):
        choice = xbmcgui.Dialog().yesno('FanVodPL AI', text, yeslabel='TAK — szukaj', nolabel='NIE')
        if choice:
            return {'action': 'confirm', 'text': ''}
    heading = text.replace('\n', ' ')
    if len(heading) > 120:
        heading = heading[:117] + '...'
    kb = control.keyboard('', heading)
    kb.doModal()
    if not kb.isConfirmed():
        return {'action': 'cancel', 'text': ''}
    return {'action': 'send', 'text': (kb.getText() or '').strip()}


def _render_safe_chat_text(history=None, ai_data=None, allow_confirm=False, initial=False):
    # ZMIANA (2026-04) [PATCH]: renderuje pełną rozmowę do stabilnego widoku konsolowego Kodi.
    # POWOD: sam textviewer nie pozwala pisać, a okno konsolowe ma pokazywać tę samą pełną historię.
    # NIE ZMIENIAC: pełna treść pytania AI ma być widoczna w konsoli, a nie w uciętym nagłówku klawiatury.
    history = list(history or [])
    ai_data = ai_data or {}
    lines = []
    if initial and not history:
        lines.append(u'AI: Napisz, co pamiętasz o filmie/serialu. Możesz podać scenę, aktora, kraj, rok, przedmiot, cytat albo dziwny szczegół.')
    for item in history:
        prefix = u'TY' if item.get('role') == 'user' else u'AI'
        content = (item.get('content') or '').strip()
        if content:
            lines.append(u'{}: {}'.format(prefix, content))
    current_ai = _chat_ai_message(ai_data).strip() if ai_data else ''
    if current_ai:
        lines.append(u'AI: {}'.format(current_ai))
    if allow_confirm:
        lines.append(u'')
        lines.append(u'AI: Jeśli to ten film, wybierz „TAK — szukaj”. Jeśli nie, dopisz kolejny szczegół.')
    return '\n\n'.join(lines).strip() or u'AI: Napisz pierwszy opis filmu/serialu.'


# ZMIANA (2026-04) [FEATURE]: okno mini-czatu przeniesione do stabilnego XML Kodi.
# POWOD: natywne Dialog().select ucinał długie pytania, a ręczny WindowDialog potrafił blokować UI Kodi.
# NIE ZMIENIAC: UI czatu ma używać WindowXMLDialog + FanVodPL_AIChat.xml; w razie błędu zostaje fallback na natywne dialogi.
_AI_CHAT_XML_FILE = 'FanVodPL_AIChat.xml'
_AI_CHAT_AI_ICON = 'search.png'
_AI_CHAT_USER_ICON = 'people.png'
# ZMIANA (2026-04) [FEATURE]: statusowe ikonki czatu jako lokalne PNG.
# POWOD: Kodi/skorki roznie renderuja emoji tekstowe, a uzytkownik chce widoczne reakcje jak w prawdziwym czacie.
_AI_CHAT_ICON_SMILE = 'ai_status_smile.png'
_AI_CHAT_ICON_QUESTION = 'ai_status_question.png'
_AI_CHAT_ICON_SEARCH = 'ai_status_search.png'
_AI_CHAT_ICON_OK = 'ai_status_ok.png'
_AI_CHAT_ICON_WARNING = 'ai_status_warning.png'
_AI_CHAT_ICON_SAD = 'ai_status_sad.png'
_AI_CHAT_ICON_HEART = 'ai_status_heart.png'
# ZMIANA (2026-04) [PATCH]: cache URL-i plakatow w czasie zycia okna.
# POWOD: ponowne odrzucanie/doprecyzowanie nie ma jeszcze raz pobierac tego samego plakatu z TMDB.
_AI_POSTER_CACHE = {}
_AI_RESEARCH_CACHE = {}
_AI_RESEARCH_CACHE_TTL = 15 * 60


def _ai_cache_get(key):
    try:
        import time as _time
        item = _AI_RESEARCH_CACHE.get(key)
        if not item:
            return None
        ts, value = item
        if (_time.time() - ts) > _AI_RESEARCH_CACHE_TTL:
            try:
                del _AI_RESEARCH_CACHE[key]
            except Exception:
                pass
            return None
        return value
    except Exception:
        return None


def _ai_cache_set(key, value):
    try:
        import time as _time
        if len(_AI_RESEARCH_CACHE) > 60:
            oldest = sorted(_AI_RESEARCH_CACHE.items(), key=lambda kv: kv[1][0])[:20]
            for old_key, _old_val in oldest:
                _AI_RESEARCH_CACHE.pop(old_key, None)
        _AI_RESEARCH_CACHE[key] = (_time.time(), value or '')
    except Exception:
        pass
    return value or ''


class _AIChatXMLDialog(xbmcgui.WindowXMLDialog):
    """
    Prawdziwy czat — okno zyje przez cala rozmowe.
    Wiadomosci uzytkownika i AI dodawane do listy na biezaco.
    Watek w tle wywoluje AI; w tym czasie lista pokazuje 'AI: mysle...'.
    ZMIANA (2026-04) [FEATURE]: architektura live-chat zamiast open/close per runda.
    NIE ZMIENIAC: GUI aktualizuje watek AI przez getListItem(idx).setLabel(); dziala w Kodi.
    """
    CTRL_TITLE        = 100
    CTRL_CHAT_TEXT    = 101
    CTRL_HINT         = 102
    CTRL_TOKEN_USAGE  = 103
    CTRL_INPUT        = 201
    CTRL_CANCEL       = 204
    CTRL_CLEAR        = 205
    CTRL_TMDB         = 206  # button — otwarcie strony TMDB w przegladarce
    CTRL_YOUTUBE      = 207  # button — otwarcie zwiastuna YouTube
    CTRL_POSTER       = 301  # image — plakat TMDB
    CTRL_POSTER_TITLE = 302  # label  — tytuł pod plakatem

    def __init__(self, *args, **kwargs):
        import os as _os
        import threading as _threading
        self._caller   = kwargs['caller']
        self._api_key  = kwargs['api_key']
        self._provider = kwargs['provider']
        self._addon_path = kwargs.get('addon_path') or (args[1] if len(args) > 1 else '')
        self._media_path = _os.path.join(self._addon_path, 'resources', 'media', 'incursion')
        self._history  = list(kwargs.get('history') or [])
        self.result    = {'action': 'cancel', 'ai_data': {}, 'history': []}
        self._lock         = _threading.Lock()
        self._thinking_idx = -1
        self._ai_data      = {}
        self._ready        = False
        self._busy         = False
        self._ai_usage_calls = 0
        self._ai_usage_input = 0
        self._ai_usage_output = 0
        self._ai_usage_total = 0
        self._ai_usage_unknown = 0
        self._poster_request_id = 0
        self._last_poster_overview_key = ''
        self._last_tmdb_url_line_key = ''
        self._last_youtube_url_line_key = ''
        self._tmdb_url = ''
        self._youtube_url = ''

    # ── GUI helpers ──────────────────────────────────────────────────────────

    def _ctrl(self):
        return self.getControl(self.CTRL_CHAT_TEXT)

    def _chat_icon(self, role, text='', status=''):
        try:
            import os as _os
            if role == 'user' or (text or '').startswith(u'TY:'):
                path = _os.path.join(self._media_path, _AI_CHAT_USER_ICON)
            elif status == 'ok':
                path = _os.path.join(self._media_path, _AI_CHAT_ICON_OK)
            elif status in ('heart', 'love'):
                path = _os.path.join(self._media_path, _AI_CHAT_ICON_HEART)
            elif status == 'question':
                path = _os.path.join(self._media_path, _AI_CHAT_ICON_QUESTION)
            elif status == 'search':
                path = _os.path.join(self._media_path, _AI_CHAT_ICON_SEARCH)
            elif status == 'sad':
                path = _os.path.join(self._media_path, _AI_CHAT_ICON_SAD)
            elif status == 'warning':
                path = _os.path.join(self._media_path, _AI_CHAT_ICON_WARNING)
            else:
                path = _os.path.join(self._media_path, _AI_CHAT_ICON_SMILE)
                if not _os.path.exists(path):
                    path = _os.path.join(self._media_path, _AI_CHAT_AI_ICON)
            return path if _os.path.exists(path) else ''
        except Exception:
            return ''

    def _apply_item_icon(self, item, role=None, text='', status=''):
        icon = self._chat_icon(role, text, status)
        if icon:
            try:
                item.setArt({'icon': icon, 'thumb': icon})
            except Exception:
                pass

    def _add_line(self, text, role=None, status=''):
        ctrl = self._ctrl()
        item = xbmcgui.ListItem(label=text)
        self._apply_item_icon(item, role, text, status)
        ctrl.addItem(item)
        idx = ctrl.size() - 1
        ctrl.selectItem(idx)
        return idx

    def _set_line(self, idx, text, role=None, status=''):
        # ZMIANA (2026-05) [PATCH]: guard idx < 0 przed dostępem do Kodi ListItem.
        # POWOD: gdy okno jest zamknięte podczas działania wątku AI, _thinking_idx = -1
        #        lub kontrolka nie istnieje — Kodi rzucało C++ "Index out of range" nie łapane przez except.
        # NIE ZMIENIAC: idx musi być >= 0 zanim trafi do getListItem/selectItem.
        if idx < 0:
            return
        try:
            ctrl = self._ctrl()
            if idx >= ctrl.size():
                return
            item = ctrl.getListItem(idx)
            item.setLabel(text)
            self._apply_item_icon(item, role, text, status)
            ctrl.selectItem(idx)
        except Exception:
            pass

    def _set_hint(self, text):
        try:
            self.getControl(self.CTRL_HINT).setLabel(text)
        except Exception:
            pass

    def _token_usage_label(self, busy=False):
        # ZMIANA (2026-04) [PATCH]: licznik tokenow widoczny w oknie czatu.
        # POWOD: uzytkownik chce na biezaco widziec koszt/zuzycie bez grzebania w logach.
        # NIE ZMIENIAC: pokazujemy tylko liczniki, nigdy tresc promptu ani klucze API.
        if self._ai_usage_calls <= 0:
            return u'Tokeny: 0' + (u' | trwa...' if busy else u'')
        if self._ai_usage_total > 0:
            text = u'Tokeny: {}'.format(self._ai_usage_total)
            if self._ai_usage_input or self._ai_usage_output:
                text += u' | we:{} wy:{}'.format(
                    self._ai_usage_input, self._ai_usage_output)
        else:
            text = u'Tokeny: brak danych'
        text += u' | {}x'.format(self._ai_usage_calls)
        if self._ai_usage_unknown:
            text += u' | ?{}'.format(self._ai_usage_unknown)
        if busy:
            text += u' | trwa...'
        return text

    def _set_token_usage(self, busy=False):
        try:
            self.getControl(self.CTRL_TOKEN_USAGE).setLabel(
                self._token_usage_label(busy=busy))
        except Exception:
            pass

    def _set_input(self, enabled):
        try:
            self.getControl(self.CTRL_INPUT).setEnabled(enabled)
        except Exception:
            pass

    def _set_tmdb_button(self, url=''):
        # ZMIANA (2026-05) [NOWA FUNKCJA]: przycisk 206 aktywny tylko gdy TMDB zwroci adres strony.
        # POWOD: uzytkownik ma jasna akcje "TMDB (przegladarka)", ale bez martwego przycisku przed wynikiem.
        # NIE ZMIENIAC: _tmdb_url jest tylko stanem GUI; nie bierze udzialu w wyszukiwaniu ani rozliczeniach AI.
        self._tmdb_url = (url or '').strip()
        try:
            self.getControl(self.CTRL_TMDB).setEnabled(bool(self._tmdb_url))
        except Exception:
            pass

    def _set_youtube_button(self, url=''):
        # ZMIANA (2026-05) [NOWA FUNKCJA]: przycisk 207 aktywny tylko dla oficjalnego linku zwiastuna z TMDB.
        # POWOD: uzytkownik chce otwierac zwiastun w YouTube/aplikacji YouTube bez pobierania pliku na dysk.
        # NIE ZMIENIAC: _youtube_url jest tylko stanem GUI; nie zmienia wyszukiwania, hostow ani rozliczen.
        self._youtube_url = (url or '').strip()
        try:
            self.getControl(self.CTRL_YOUTUBE).setEnabled(bool(self._youtube_url))
        except Exception:
            pass

    def _set_poster(self, url):
        # ZMIANA (2026-04) [NOWA FUNKCJA]: wyświetla plakat TMDB w oknie czatu (kontrolka 301).
        # POWOD: użytkownik chce wizualnie potwierdzić film przed zaakceptowaniem tytułu.
        # NIE ZMIENIAC: setImage('') czyści plakat; błąd GUI ignorowany (stare skórki bez kontrolki 301).
        try:
            self.getControl(self.CTRL_POSTER).setImage(url or '')
        except Exception:
            pass

    def _set_poster_title(self, text):
        try:
            ctrl = self.getControl(self.CTRL_POSTER_TITLE)
            try:
                ctrl.setLabel(text or '')
            except Exception:
                ctrl.setText(text or '')
        except Exception:
            pass

    def _poster_overview_line(self, overview):
        # ZMIANA (2026-05) [PATCH]: opis TMDB trafia do przewijalnej listy czatu w pelnej tresci.
        # POWOD: poprzednio opis byl skrocony do 240 znakow; teraz lista czatu przewija caly tekst.
        # NIE ZMIENIAC: panel plakatu zostaje tylko dla tytulu; opis jest prezentacyjna trescia czatu.
        overview = u' '.join((overview or '').strip().split())
        if not overview:
            return ''
        return u'Opis: ' + overview

    def _add_wrapped_chat_lines(self, text, role=None, status='', width=88):
        # ZMIANA (2026-05) [PATCH]: dlugi opis/TMDB dzielony jest na kilka linii w przewijalnej liscie.
        # POWOD: Kodi ListItem nie zawija automatycznie etykiety w tym layoucie, wiec pelny opis inaczej ucinalby sie w poziomie.
        # NIE ZMIENIAC: metoda dodaje tylko linie GUI; nie zmienia historii rozmowy ani danych wyszukiwania.
        text = u' '.join((text or '').strip().split())
        if not text:
            return
        words = text.split(u' ')
        row = []
        rows = []
        for word in words:
            candidate = u' '.join(row + [word])
            if row and len(candidate) > width:
                rows.append(u' '.join(row))
                row = [word]
            else:
                row.append(word)
        if row:
            rows.append(u' '.join(row))
        for idx, line in enumerate(rows):
            prefix = u'' if idx == 0 else u'    '
            self._add_line(prefix + line, role=role, status=status)

    def _tmdb_page_url(self, item, endpoint):
        # ZMIANA (2026-05) [NOWA FUNKCJA]: z wybranego wyniku TMDB budowany jest publiczny link do strony filmu/serialu.
        # POWOD: przycisk w oknie AI ma otwierac dokladnie ten sam wynik, z ktorego pochodzi plakat i opis.
        # NIE ZMIENIAC: URL powstaje dopiero po wyborze best_item; scoring i kolejnosc wynikow pozostaja bez zmian.
        try:
            tmdb_id = item.get('id')
            media = item.get('media_type') or endpoint
            if media not in ('movie', 'tv') or not tmdb_id:
                return ''
            return u'https://www.themoviedb.org/{}/{}'.format(media, tmdb_id)
        except Exception:
            return ''

    def _youtube_watch_url(self, key):
        # ZMIANA (2026-05) [NOWA FUNKCJA]: klucz wideo TMDB zamieniany jest na legalny publiczny URL YouTube.
        # POWOD: wtyczka ma otwierac zwiastun w YouTube, a nie pobierac ani parsowac strony YouTube.
        # NIE ZMIENIAC: akceptujemy tylko bezpieczne znaki klucza YouTube zwrocone przez API TMDB.
        key = (key or '').strip()
        if not key or not re.match(r'^[A-Za-z0-9_-]+$', key):
            return ''
        return u'https://www.youtube.com/watch?v={}'.format(key)

    def _select_youtube_trailer(self, videos):
        # ZMIANA (2026-05) [NOWA FUNKCJA]: wybiera tylko YouTube Trailer/Teaser z listy wideo TMDB.
        # POWOD: funkcja ma sluzyc legalnie do zwiastunow, bez klipow, featurette i przypadkowych materialow.
        # NIE ZMIENIAC: brak Trailera/Teasera oznacza pusty URL i nieaktywny przycisk 207.
        candidates = []
        for video in videos or []:
            try:
                if not isinstance(video, dict):
                    continue
                if (video.get('site') or '').strip().lower() != 'youtube':
                    continue
                video_type = (video.get('type') or '').strip().lower()
                if video_type not in ('trailer', 'teaser'):
                    continue
                url = self._youtube_watch_url(video.get('key') or '')
                if not url:
                    continue
                score = 0
                if video_type == 'trailer':
                    score += 100
                elif video_type == 'teaser':
                    score += 60
                if bool(video.get('official')):
                    score += 30
                lang = (video.get('iso_639_1') or '').strip().lower()
                if lang == 'pl':
                    score += 8
                elif lang == 'en':
                    score += 5
                candidates.append((score, video.get('published_at') or '', url))
            except Exception:
                continue
        if not candidates:
            return ''
        candidates.sort(key=lambda row: (row[0], row[1]), reverse=True)
        return candidates[0][2]

    def _fetch_youtube_trailer_url(self, item, endpoint, lang, tm_headers, tm_key, requests_module):
        # ZMIANA (2026-05) [NOWA FUNKCJA]: pobiera z TMDB liste wideo dla wybranego filmu/serialu.
        # POWOD: przycisk YouTube ma korzystac z oficjalnego metadanych TMDB, bez scrapowania YouTube/TMDB.
        # NIE ZMIENIAC: funkcja dziala dopiero po wyborze best_item i nie zmienia scoringu trafien.
        try:
            tmdb_id = item.get('id')
            media = item.get('media_type') or endpoint
            if media not in ('movie', 'tv') or not tmdb_id:
                return ''
            languages = []
            primary_lang = (lang or 'pl-PL').strip()
            if primary_lang:
                languages.append(primary_lang)
            if 'en-US' not in languages:
                languages.append('en-US')
            best_url = ''
            for language in languages[:2]:
                base_url = 'https://api.themoviedb.org/3/{}/{}/videos'.format(media, tmdb_id)
                params = 'language={}'.format(language)
                if media == 'tv':
                    params += '&include_video_language=pl,en,null'
                if tm_key:
                    params = 'api_key={}&'.format(tm_key) + params
                r = requests_module.get(base_url + '?' + params, timeout=3.5, headers=tm_headers or None)
                r.raise_for_status()
                best_url = self._select_youtube_trailer((r.json() or {}).get('results') or [])
                if best_url:
                    return best_url
            return best_url
        except Exception as exc:
            log('[AI_SEARCH] TMDB trailer fetch ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
            return ''

    def _open_tmdb_url(self):
        # ZMIANA (2026-05) [NOWA FUNKCJA]: przycisk TMDB otwiera strone wyniku w zewnetrznej przegladarce.
        # POWOD: uzytkownik chce przejsc do pelnego opisu TMDB bez kopiowania linku z czatu.
        # NIE ZMIENIAC: fallback z oknem OK pokazuje adres, gdy system/Kodi nie udostepni przegladarki.
        url = (self._tmdb_url or '').strip()
        if not url:
            try:
                xbmcgui.Dialog().notification(
                    'FanVodPL AI',
                    u'Najpierw poczekaj na wynik TMDB.',
                    xbmcgui.NOTIFICATION_INFO,
                    3000)
            except Exception:
                pass
            return
        opened = False
        try:
            if xbmc.getCondVisibility('System.Platform.Android'):
                xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,{})'.format(url))
                opened = True
        except Exception as exc:
            log('[AI_SEARCH] TMDB Android open ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        if not opened:
            try:
                import webbrowser as _webbrowser
                opened = bool(_webbrowser.open(url, new=2))
            except Exception as exc:
                log('[AI_SEARCH] TMDB browser open ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        try:
            if opened:
                xbmcgui.Dialog().notification(
                    'FanVodPL AI',
                    u'Otwieram TMDB w przegladarce.',
                    xbmcgui.NOTIFICATION_INFO,
                    3000)
            else:
                xbmcgui.Dialog().ok(
                    'FanVodPL AI',
                    u'Nie udalo sie otworzyc przegladarki.',
                    u'Adres TMDB:',
                    url)
        except Exception:
            pass

    def _open_youtube_url(self):
        # ZMIANA (2026-05) [NOWA FUNKCJA]: przycisk 207 otwiera zwiastun YouTube w aplikacji lub przegladarce.
        # POWOD: na Android TV system moze przekazac link do aplikacji YouTube, a na PC do przegladarki.
        # NIE ZMIENIAC: funkcja tylko otwiera publiczny URL; nie pobiera filmu i nie omija YouTube.
        url = (self._youtube_url or '').strip()
        if not url:
            try:
                xbmcgui.Dialog().notification(
                    'FanVodPL AI',
                    u'Brak zwiastuna YouTube dla tego wyniku.',
                    xbmcgui.NOTIFICATION_INFO,
                    3000)
            except Exception:
                pass
            return
        opened = False
        try:
            if xbmc.getCondVisibility('System.Platform.Android'):
                xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,{})'.format(url))
                opened = True
        except Exception as exc:
            log('[AI_SEARCH] YouTube Android open ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        if not opened:
            try:
                import webbrowser as _webbrowser
                opened = bool(_webbrowser.open(url, new=2))
            except Exception as exc:
                log('[AI_SEARCH] YouTube browser open ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        try:
            if opened:
                xbmcgui.Dialog().notification(
                    'FanVodPL AI',
                    u'Otwieram zwiastun YouTube.',
                    xbmcgui.NOTIFICATION_INFO,
                    3000)
            else:
                xbmcgui.Dialog().ok(
                    'FanVodPL AI',
                    u'Nie udalo sie otworzyc YouTube.',
                    u'Adres zwiastuna:',
                    url)
        except Exception:
            pass

    def _poster_placeholder(self):
        try:
            import os as _os
            path = _os.path.join(self._media_path, 'poster.png')
            return path if _os.path.exists(path) else ''
        except Exception:
            return ''

    def _response_status(self, ai_data, msg, title, confidence, ready):
        text = _ai_norm_text(msg or '')
        if text.startswith(u'blad polaczenia') or text.startswith(u'nadal za duzo') or 'error' in text:
            return 'sad'
        if (not title) and any(w in text for w in (u'brak', u'nie znalaz', u'niestety', u'nie kojarze')):
            return 'sad'
        if ready and confidence >= 95:
            return 'heart'
        if ready or (title and confidence >= _AI_CHAT_CONFIRM_CONFIDENCE):
            return 'ok'
        if '?' in (msg or '') or (ai_data or {}).get('next_question'):
            return 'question'
        if title:
            return 'smile'
        return 'question'

    def _poster_candidate_from_ai(self, ai_data):
        ai_data = ai_data or {}
        if not _ai_ready_to_confirm(ai_data, self._history):
            return {}
        title = _best_title_from_ai(ai_data)
        display_title = _display_title_from_ai(ai_data) or title
        if title:
            return {
                'title': title,
                'display_title': display_title,
                'year': str(ai_data.get('year') or ''),
                'type': str(ai_data.get('type') or ''),
                'ready': True,
            }
        for item in ai_data.get('candidates') or []:
            if not isinstance(item, dict):
                continue
            cand_conf = _ai_to_int(item.get('confidence') if item.get('confidence') is not None else ai_data.get('confidence'))
            if cand_conf < 70:
                continue
            cand_title = (
                item.get('original_title') or item.get('english_title') or
                item.get('search_query') or item.get('title') or item.get('pl_title')
            )
            cand_title = str(cand_title or '').strip()
            if not cand_title:
                continue
            return {
                'title': cand_title,
                'display_title': _display_title_from_ai(item) or cand_title,
                'year': str(item.get('year') or ''),
                'type': str(item.get('type') or ''),
                'ready': False,
            }
        return {}

    def _preview_candidate_choice(self, text):
        # ZMIANA (2026-05) [PATCH]: numer kandydata wlacza podglad plakatu/opisu/zwiastuna zamiast finalnego confirm.
        # POWOD: uzytkownik chce po wyborze 1/2/3 najpierw zobaczyc szczegoly tropu w tym samym oknie.
        # NIE ZMIENIAC: samo wpisanie numeru nie moze zamykac czatu ani zwracac action=confirm.
        selected = _ai_candidate_from_user_choice(self._ai_data, text)
        if not selected:
            return False
        preview_data = _ai_user_preview_data(self._ai_data, selected)
        title = _best_title_from_ai(preview_data)
        if not title:
            self._add_line(
                u'AI: Nie moge pokazac tego numeru. Wybierz numer z listy albo dopisz szczegol.',
                role='assistant', status='warning')
            return True
        if _ai_title_matches_rejected(title, self._history) or _ai_title_matches_actor_example(title, self._history):
            self._add_line(
                u'AI: Ten trop jest juz odrzucony albo wyglada na przyklad aktora. Wybierz inny numer.',
                role='assistant', status='warning')
            return True

        display_title = _display_title_from_ai(preview_data) or title
        try:
            if self._history and self._history[-1].get('role') == 'user':
                self._history[-1]['content'] = u'Wybrany trop {}: {}'.format((text or '').strip(), display_title)
        except Exception:
            pass

        self._ai_data = preview_data
        self._ready = _ai_ready_to_confirm(preview_data, self._history)
        self._add_wrapped_chat_lines(
            u'Wybrany trop: {}. Laduje plakat, opis i zwiastun. Jesli pasuje, napisz TAK.'.format(display_title),
            role='assistant', status='search')
        self._history.append({
            'role': 'assistant',
            'content': u'Wybrany trop do podgladu: {}'.format(display_title)
        })
        self._set_hint(u'Laduje plakat/opis/zwiastun. TAK = wyszukaj, NIE albo numer = inny trop.')

        poster_label = u'Wybrany trop:\n{}'.format(display_title)
        self._poster_request_id += 1
        request_id = self._poster_request_id
        self._set_tmdb_button('')
        self._set_youtube_button('')
        self._set_poster('')
        self._set_poster_title((poster_label + u'\n\nLaduje plakat...').strip())
        import threading as _threading
        _t = _threading.Thread(
            target=self._poster_thread,
            args=(
                title,
                str(preview_data.get('year') or ''),
                str(preview_data.get('type') or ''),
                request_id,
                poster_label,
            ))
        _t.daemon = True
        _t.start()
        log('[AI_SEARCH] LIVE_CHAT candidate preview title={!r} conf={}'.format(
            title, preview_data.get('confidence')), 1)
        return True

    def _fetch_poster(self, title, year='', media_type=''):
        # ZMIANA (2026-05) [NOWA FUNKCJA]: zwraca payload plakatu, opisu, TMDB i zwiastuna YouTube.
        # POWOD: panel AI ma pokazywac opis oraz legalne akcje z tego samego wyniku TMDB.
        # NIE ZMIENIAC: pusty payload jest bezpiecznym fallbackiem przy braku sieci/TMDB.
        # HISTORYCZNIE (2026-04): funkcja pobierala tylko URL plakatu TMDB.
        # TERAZ: zwraca {'poster', 'overview', 'tmdb_url', 'youtube_url'}, zachowujac cache i fallback pustych danych.
        cache_key = ''
        try:
            tm_headers, tm_key = _tmdb_auth()
            if not tm_key and not tm_headers:
                return {'poster': '', 'overview': '', 'tmdb_url': '', 'youtube_url': ''}
            cache_key = u'{}|{}|{}'.format(
                (media_type or '').strip().lower(),
                (title or '').strip().lower(),
                str(year or '').strip()
            )
            if cache_key in _AI_POSTER_CACHE:
                cached = _AI_POSTER_CACHE.get(cache_key) or {}
                if isinstance(cached, dict):
                    return cached
                return {'poster': cached or '', 'overview': '', 'tmdb_url': '', 'youtube_url': ''}
            lang = 'pl-PL'
            try:
                raw_lang = control.apiLanguage().get('tmdb', 'pl')
                lang = '{}-{}'.format(raw_lang, raw_lang.upper())
            except Exception:
                pass
            import requests as _requests
            try:
                from urllib.parse import quote as _quote
            except ImportError:
                from urllib import quote as _quote
            if media_type == 'tv':
                endpoints = [('tv', 'first_air_date_year')]
            elif media_type == 'movie':
                endpoints = [('movie', 'year')]
            else:
                endpoints = [('multi', '')]
            query = _quote(title.encode('utf-8'))
            for endpoint, year_param in endpoints:
                base_url = 'https://api.themoviedb.org/3/search/{}'.format(endpoint)
                params = 'language={}&query={}&page=1'.format(lang, query)
                if tm_key:
                    params = 'api_key={}&'.format(tm_key) + params
                url = base_url + '?' + params
                if year:
                    if endpoint == 'movie':
                        url += '&year=' + str(year)
                    elif endpoint == 'tv':
                        url += '&first_air_date_year=' + str(year)
                r = _requests.get(url, timeout=3.5, headers=tm_headers or None)
                r.raise_for_status()
                results = r.json().get('results') or []
                best_item, best_score = None, -1
                query_fold = _ai_fold_text(title or '')
                for item in results[:8]:
                    if endpoint == 'multi' and item.get('media_type') not in ('movie', 'tv'):
                        continue
                    if not item.get('poster_path'):
                        continue
                    item_titles = [
                        item.get('title'), item.get('name'),
                        item.get('original_title'), item.get('original_name'),
                    ]
                    folded_titles = [_ai_fold_text(t or '') for t in item_titles if t]
                    score = 1
                    if query_fold and any(query_fold == t for t in folded_titles):
                        score += 60
                    elif query_fold and any(query_fold in t or t in query_fold for t in folded_titles):
                        score += 25
                    item_year = str((item.get('release_date') or item.get('first_air_date') or '')[:4])
                    if year and item_year == str(year):
                        score += 30
                    if media_type and (item.get('media_type') or endpoint) == media_type:
                        score += 10
                    try:
                        score += min(float(item.get('popularity') or 0), 50.0) / 100.0
                    except Exception:
                        pass
                    if score > best_score:
                        best_item, best_score = item, score
                if best_item:
                    url = 'https://image.tmdb.org/t/p/w185' + best_item['poster_path']
                    youtube_url = self._fetch_youtube_trailer_url(
                        best_item, endpoint, lang, tm_headers, tm_key, _requests)
                    payload = {
                        'poster': url,
                        'overview': (best_item.get('overview') or '').strip(),
                        'tmdb_url': self._tmdb_page_url(best_item, endpoint),
                        'youtube_url': youtube_url,
                    }
                    log('[AI_SEARCH] poster selected: query={!r} year={!r} -> {!r}/{!r} score={}'.format(
                        title, year,
                        best_item.get('title') or best_item.get('name') or '',
                        best_item.get('original_title') or best_item.get('original_name') or '',
                        round(best_score, 2)), 1)
                    _AI_POSTER_CACHE[cache_key] = payload
                    return payload
        except Exception as exc:
            log('[AI_SEARCH] poster fetch ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        try:
            _AI_POSTER_CACHE[cache_key] = {'poster': '', 'overview': '', 'tmdb_url': '', 'youtube_url': ''}
        except Exception:
            pass
        return {'poster': '', 'overview': '', 'tmdb_url': '', 'youtube_url': ''}

    def _poster_thread(self, title, year='', media_type='', request_id=0, poster_label=''):
        # ZMIANA (2026-05) [NOWA FUNKCJA]: panel plakatu dostaje opis, TMDB i zwiastun z tego samego wyniku.
        # POWOD: przyciski TMDB/YouTube maja odnosic sie do dokladnie trafienia widocznego w czacie.
        # NIE ZMIENIAC: request_id dalej chroni przed wyswietleniem starego wyniku z poprzedniego watku.
        poster_data = self._fetch_poster(title, year, media_type)
        if isinstance(poster_data, dict):
            url = poster_data.get('poster') or ''
            overview = poster_data.get('overview') or ''
            tmdb_url = poster_data.get('tmdb_url') or ''
            youtube_url = poster_data.get('youtube_url') or ''
        else:
            url = poster_data or ''
            overview = ''
            tmdb_url = ''
            youtube_url = ''
        if request_id and request_id != self._poster_request_id:
            return
        self._set_tmdb_button(tmdb_url)
        self._set_youtube_button(youtube_url)
        if url:
            self._set_poster(url)
            self._set_poster_title(poster_label)
        else:
            self._set_poster('')
            missing = (poster_label or '').strip()
            missing = (missing + u'\n\nbrak plakatu').strip() if missing else u'brak plakatu'
            self._set_poster_title(missing)
        overview_line = self._poster_overview_line(overview)
        overview_key = u'{}|{}|{}|{}'.format(title or '', year or '', media_type or '', overview_line)
        if overview_line and overview_key != self._last_poster_overview_key:
            self._last_poster_overview_key = overview_key
            self._add_wrapped_chat_lines(overview_line, role='assistant', status='search')
        tmdb_line = u'TMDB: {} (przycisk wymaga przegladarki)'.format(tmdb_url) if tmdb_url else ''
        tmdb_key = u'{}|{}|{}|{}'.format(title or '', year or '', media_type or '', tmdb_line)
        if tmdb_line and tmdb_key != self._last_tmdb_url_line_key:
            # ZMIANA (2026-05) [NOWA FUNKCJA]: link TMDB pokazany tez tekstowo w przewijalnym czacie.
            # POWOD: gdy Kodi/system nie otworzy przegladarki, uzytkownik nadal widzi dokladny adres.
            # NIE ZMIENIAC: to tylko linia informacyjna; nie zapisuje sie do historii promptu AI.
            self._last_tmdb_url_line_key = tmdb_key
            self._add_wrapped_chat_lines(tmdb_line, role='assistant', status='search')
        youtube_line = u'YouTube: zwiastun dostepny (przycisk otwiera aplikacje YouTube albo przegladarke)' if youtube_url else ''
        youtube_key = u'{}|{}|{}|{}'.format(title or '', year or '', media_type or '', youtube_line)
        if youtube_line and youtube_key != self._last_youtube_url_line_key:
            # ZMIANA (2026-05) [NOWA FUNKCJA]: czat informuje o dostepnym zwiastunie bez wklejania dlugiego linku.
            # POWOD: uzytkownik ma jasny komunikat, ze przycisk YouTube dziala dla aktualnego wyniku.
            # NIE ZMIENIAC: linia jest tylko informacyjna i nie trafia do historii promptu AI.
            self._last_youtube_url_line_key = youtube_key
            self._add_wrapped_chat_lines(youtube_line, role='assistant', status='search')

    # ── Inicjalizacja ────────────────────────────────────────────────────────

    def onInit(self):
        try:
            self.getControl(self.CTRL_TITLE).setLabel(u'FanVodPL AI — rozmowa')
        except Exception:
            pass
        self._set_token_usage(False)
        # ZMIANA (2026-05) [NOWA FUNKCJA]: przycisk TMDB startuje w stanie nieaktywnym.
        # POWOD: adres TMDB jest znany dopiero po pobraniu plakatu/opisu konkretnego trafienia.
        # NIE ZMIENIAC: inicjalizacja przycisku nie zmienia historii ani automatycznego startu AI.
        self._set_tmdb_button('')
        # ZMIANA (2026-05) [NOWA FUNKCJA]: przycisk YouTube startuje w stanie nieaktywnym.
        # POWOD: zwiastun jest znany dopiero po pobraniu videos z TMDB dla aktualnego wyniku.
        # NIE ZMIENIAC: inicjalizacja przycisku nie zmienia historii ani automatycznego startu AI.
        self._set_youtube_button('')
        # Odbuduj historię jeśli jest (np. restart po błędzie)
        for msg in self._history:
            prefix = u'TY' if msg.get('role') == 'user' else u'AI'
            self._add_line(u'{}: {}'.format(prefix, msg.get('content', '')), role=msg.get('role'))
        if not self._history:
            self._add_line(u'AI: Cześć. Opisz po swojemu film albo serial, a ja poszukam tropów.', role='assistant', status='smile')
            self._set_hint(u'Możesz napisać scenę, aktora, kraj, rok, cytat albo dziwny szczegół.')
        else:
            # Historia istnieje — kontynuuj AI
            self._start_ai_call()
        try:
            if not self._busy:
                self.setFocusId(self.CTRL_INPUT)
        except Exception:
            pass

    # ── AI w watku ───────────────────────────────────────────────────────────

    def _start_ai_call(self):
        import threading as _threading
        self._busy = True
        self._set_input(False)
        self._set_token_usage(True)
        self._set_hint(u'AI szuka tropów...')
        self._thinking_idx = self._add_line(u'AI: Szukam tropów...', role='assistant', status='search')
        t = _threading.Thread(target=self._ai_thread)
        t.daemon = True
        t.start()

    def _note_token_usage(self):
        usage = _pop_last_ai_token_usage()
        if not usage:
            return
        self._ai_usage_calls += 1
        input_tokens = _ai_token_int(usage.get('input'))
        output_tokens = _ai_token_int(usage.get('output'))
        total_tokens = _ai_token_int(usage.get('total'))
        if input_tokens is not None:
            self._ai_usage_input += input_tokens
        if output_tokens is not None:
            self._ai_usage_output += output_tokens
        if total_tokens is not None:
            self._ai_usage_total += total_tokens
        else:
            self._ai_usage_unknown += 1
        log('[AI_SEARCH] AI_TOKEN_TOTAL provider={} calls={} input={} output={} total={} unknown_calls={}'.format(
            self._provider, self._ai_usage_calls, self._ai_usage_input, self._ai_usage_output,
            self._ai_usage_total, self._ai_usage_unknown), 1)
        self._set_token_usage(self._busy)

    def _ai_thread(self):
        import time as _time
        self._set_hint(u'AI szuka w internecie...')
        live_context = ''
        if self._provider == 'OpenAI':
            # ZMIANA (2026-05) [PATCH]: podpinamy legalny live-context przed finalnym wywołaniem OpenAI.
            # POWOD: sam prompt JSON bez doklejonych wyników web/API powodował zgadywanie; kontekst z web_search/TMDB/Wikidata/TVMaze daje modelowi materiał jak w czacie asystenta.
            # NIE ZMIENIAC: dotyczy tylko providera OpenAI; Gemini/Claude zostają bez dodatkowej zmiany kosztów i zachowania.
            try:
                live_context = _build_live_web_context_for_history(self._history)
            except Exception as exc:
                live_context = ''
                log('[AI_SEARCH] OpenAI live context build ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        prompt = _build_mini_chat_prompt(
            self._history,
            tmdb_context=live_context,
            force_answer=_ai_strong_search_from_first_turn(self._history))
        self._set_hint(u'AI układa odpowiedź...')
        try:
            _clear_last_ai_token_usage()
            raw = self._caller(self._api_key, prompt)
            self._note_token_usage()
            ai_data = _parse_response(raw)
            if not isinstance(ai_data, dict):
                ai_data = {}
        except Exception as exc:
            raw_exc_str = str(exc)
            exc_str = _safe_exception_text(exc, 160)
            is_429 = '429' in raw_exc_str or (
                hasattr(exc, 'response') and getattr(exc.response, 'status_code', 0) == 429
            )
            # ZMIANA (2026-05) [PATCH]: retry dla HTTP 503 (Service Unavailable) — serwer chwilowo przeciążony.
            # POWOD: 503 to błąd po stronie Google/Gemini (losowy), nie błąd klucza ani kodu;
            #        jedna automatyczna próba po 5s naprawia problem bez widocznego błędu dla użytkownika.
            # NIE ZMIENIAC: tylko 1 retry dla 503; nie zwiększać czasu oczekiwania powyżej 8s.
            is_503 = '503' in raw_exc_str or (
                hasattr(exc, 'response') and getattr(exc.response, 'status_code', 0) == 503
            )
            if is_429:
                retry = 10
                try:
                    retry = max(5, min(int(exc.response.headers.get('Retry-After', 10)), 30))
                except Exception:
                    pass
                self._set_line(self._thinking_idx,
                    u'AI: Limit zapytań ({}) - ponawiam za {}s...'.format(self._provider, retry),
                    role='assistant', status='warning')
                _time.sleep(retry)
                try:
                    _clear_last_ai_token_usage()
                    raw = self._caller(self._api_key, prompt)
                    self._note_token_usage()
                    ai_data = _parse_response(raw)
                    if not isinstance(ai_data, dict):
                        ai_data = {}
                except Exception as exc2:
                    ai_data = {'assistant_message': u'Nadal za dużo zapytań. Odczekaj chwilę i napisz cokolwiek.'}
                    log('[AI_SEARCH] 429 retry FAILED: {}'.format(_safe_exception_text(exc2, 160)), 1)
            elif is_503:
                self._set_line(self._thinking_idx,
                    u'AI: Serwer niedostępny (503) — ponawiam za 5s...',
                    role='assistant', status='warning')
                _time.sleep(5)
                try:
                    _clear_last_ai_token_usage()
                    raw = self._caller(self._api_key, prompt)
                    self._note_token_usage()
                    ai_data = _parse_response(raw)
                    if not isinstance(ai_data, dict):
                        ai_data = {}
                except Exception as exc2:
                    ai_data = {'assistant_message': u'Serwer nadal niedostępny. Spróbuj za chwilę.'}
                    log('[AI_SEARCH] 503 retry FAILED: {}'.format(_safe_exception_text(exc2, 160)), 1)
            else:
                ai_data = {'assistant_message': u'Błąd połączenia: {}'.format(exc_str[:60])}
                log('[AI_SEARCH] AI thread ERROR: {}'.format(exc_str), 1)

        self._on_ai_response(ai_data)

    def _on_ai_response(self, ai_data, web_context=''):
        with self._lock:
            ai_data = _ai_filter_actor_example_candidates(ai_data, self._history)
            ai_data = _ai_clear_search_phrase_titles(ai_data)
            ai_data = _ai_filter_rejected_candidates(ai_data, self._history)
            ai_data = _ai_merge_chatgpt_seed_candidates(ai_data, self._history)
            ai_data = _ai_apply_media_type_hint(ai_data, self._history)
            self._ai_data = ai_data
            msg        = _chat_ai_message(ai_data) or u'Nie rozumiem, spróbuj inaczej.'
            title      = _best_title_from_ai(ai_data)
            display_title = _display_title_from_ai(ai_data) or title
            confidence = _ai_to_int(ai_data.get('confidence'))
            raw_ready = bool(ai_data.get('ready_to_confirm'))
            self._ready = _ai_ready_to_confirm(ai_data, self._history)
            if raw_ready and title and not self._ready:
                log('[AI_SEARCH] READY downgraded title={!r} conf={} evidence_score={}'.format(
                    title, confidence, ai_data.get('evidence_score')), 1)
            if title and _ai_title_matches_actor_example(title, self._history):
                ai_data = dict(ai_data or {})
                ai_data['ready_to_confirm'] = False
                ai_data['confidence'] = min(confidence, 55)
                self._ai_data = ai_data
                self._ready = False
                msg = u'To wyglada na przyklad filmu z aktorem, nie szukany tytul. Pomijam ten trop i szukam po scenie/fabule.'
                log('[AI_SEARCH] actor-example title suppressed title={!r}'.format(title), 1)
                title = ''
                display_title = ''
                confidence = _ai_to_int(ai_data.get('confidence'))
            if self._ready and _ai_title_matches_rejected(title, self._history):
                self._ready = False
                log('[AI_SEARCH] READY blocked rejected title={!r}'.format(title), 1)
            if title and _ai_title_matches_rejected(title, self._history):
                ai_data = dict(ai_data or {})
                ai_data['ready_to_confirm'] = False
                ai_data['confidence'] = min(confidence, 55)
                self._ai_data = ai_data
                self._ready = False
                msg = u'Ten tytul juz odrzuciles, wiec go pomijam. Dopisz kolejny szczegol albo napisz: szukaj mocniej.'
                title = ''
                display_title = ''
                confidence = _ai_to_int(ai_data.get('confidence'))

            # ZMIANA (2026-04) [PATCH]: split listy numerowanej na osobne wiersze.
            # POWOD: AI zwraca "1. Film A, 2. Film B" w jednej linii — word-wrap
            #        robił blok tekstu zamiast czytelnej listy jeden film = jeden wiersz.
            # NIE ZMIENIAC: _wrap dzieli długie zdania; split_numbered rozdziela pozycje listy.
            import re as _re

            def _split_numbered(text):
                # Rozdziel "1. Tytuł, 2. Tytuł" lub "1. Tytuł\n2. Tytuł" na osobne linie
                text = _re.sub(r',?\s*(\d{1,2})\.\s+', lambda m: u'\n' + m.group(1) + u'. ', text)
                return [l.strip() for l in text.split(u'\n') if l.strip()]

            def _wrap(text, max_chars=88):
                words = text.split()
                row, out = [], []
                for w in words:
                    if sum(len(x) + 1 for x in row) + len(w) > max_chars and row:
                        out.append(u' '.join(row))
                        row = []
                    row.append(w)
                if row:
                    out.append(u' '.join(row))
                return out

            display_lines = []
            for raw_line in msg.split(u'\n'):
                raw_line = raw_line.strip()
                if not raw_line:
                    continue
                for segment in _split_numbered(raw_line):
                    display_lines.extend(_wrap(segment))

            if display_lines:
                status = self._response_status(ai_data, msg, title, confidence, self._ready)
                self._set_line(self._thinking_idx, u'AI: ' + display_lines[0], role='assistant', status=status)
                for extra in display_lines[1:]:
                    self._add_line(u'    ' + extra, role='assistant', status=status)
            else:
                status = self._response_status(ai_data, msg, title, confidence, self._ready)
                self._set_line(self._thinking_idx, u'AI: ' + msg[:90], role='assistant', status=status)

            self._history.append({'role': 'assistant', 'content': msg})
            for auto_title in _ai_list_field((ai_data or {}).get('auto_rejected_titles')):
                if auto_title and not _ai_title_matches_rejected(auto_title, self._history):
                    self._history.append({'role': 'assistant', 'content': u'AUTO_REJECTED_TITLE: ' + auto_title})
                    log('[AI_SEARCH] AUTO_REJECTED remembered title={!r}'.format(auto_title), 1)
            log('[AI_SEARCH] LIVE_CHAT ready={} title={!r} conf={} lines={}'.format(
                self._ready, title, confidence, len(display_lines)), 1)
            poster_candidate = self._poster_candidate_from_ai(ai_data)
            if poster_candidate:
                if self._ready and title:
                    self._set_hint(
                        u'Czy to ten film? TAK = wyszukaj, NIE albo nowy szczegół = szukamy dalej.')
                    poster_label = u'Czy to ten film?\n{}'.format(display_title)
                else:
                    self._set_hint(u'Spójrz na plakat: wpisz numer, TAK albo dopisz kolejny szczegół.')
                    poster_label = u'Możliwy trop:\n{}'.format(poster_candidate.get('display_title') or poster_candidate.get('title') or '')
                self._poster_request_id += 1
                request_id = self._poster_request_id
                # ZMIANA (2026-05) [NOWA FUNKCJA]: przy nowym tropie czyscimy poprzedni link TMDB.
                # POWOD: podczas ladowania nowego plakatu przycisk nie moze otwierac starego wyniku.
                # NIE ZMIENIAC: request_id nadal odpowiada za ochrone watku, a czyszczenie dotyczy tylko GUI.
                self._set_tmdb_button('')
                # ZMIANA (2026-05) [NOWA FUNKCJA]: przy nowym tropie czyscimy poprzedni zwiastun YouTube.
                # POWOD: podczas ladowania nowego wyniku przycisk 207 nie moze otwierac starego zwiastuna.
                # NIE ZMIENIAC: reset dotyczy tylko stanu GUI i nie zmienia wyszukiwania AI.
                self._set_youtube_button('')
                self._set_poster('')
                self._set_poster_title((poster_label + u'\n\nŁaduję plakat...').strip())
                import threading as _threading
                _t = _threading.Thread(
                    target=self._poster_thread,
                    args=(
                        poster_candidate.get('title') or '',
                        poster_candidate.get('year') or '',
                        poster_candidate.get('type') or '',
                        request_id,
                        poster_label,
                    ))
                _t.daemon = True
                _t.start()
            else:
                if title or (ai_data.get('candidates') or []):
                    self._set_hint(u'Napisz numer, tytuł z listy albo kolejny szczegół.')
                else:
                    self._set_hint(u'Dopisz kolejny konkretny szczegół albo napisz: szukaj mocniej.')
                self._poster_request_id += 1
                # ZMIANA (2026-05) [NOWA FUNKCJA]: brak tropu TMDB usuwa aktywny link z poprzedniej odpowiedzi.
                # POWOD: przycisk ma byc aktywny tylko dla aktualnie widocznego wyniku z plakatem/opisem.
                # NIE ZMIENIAC: to reset stanu okna, bez wplywu na tytuly, konta, hosty i rozliczenia.
                self._set_tmdb_button('')
                # ZMIANA (2026-05) [NOWA FUNKCJA]: brak tropu usuwa aktywny zwiastun z poprzedniej odpowiedzi.
                # POWOD: YouTube ma byc aktywny tylko dla aktualnie widocznego wyniku TMDB.
                # NIE ZMIENIAC: to reset stanu GUI bez wplywu na konta, hosty i rozliczenia.
                self._set_youtube_button('')
                self._set_poster('')
                self._set_poster_title('')
            self._busy = False
            self._set_token_usage(False)
            self._set_input(True)
            try:
                self.setFocusId(self.CTRL_INPUT)
            except Exception:
                pass

    # ── Zdarzenia ────────────────────────────────────────────────────────────

    def onClick(self, control_id):
        if control_id == self.CTRL_CANCEL:
            self.result = {'action': 'cancel', 'ai_data': {}, 'history': self._history}
            self.close()
            return
        if control_id == self.CTRL_CLEAR:
            # ZMIANA (2026-04) [NOWA FUNKCJA]: przycisk Wyczysc (205) resetuje historię czatu.
            # POWOD: użytkownik może chcieć zacząć nową rozmowę bez zamykania okna.
            # NIE ZMIENIAC: reset musi czyścić listę GUI, historię i flagę ready.
            try:
                self._ctrl().reset()
            except Exception:
                pass
            self._history = []
            self._ai_data = {}
            self._ready = False
            self._busy = False
            self._thinking_idx = -1
            self._ai_usage_calls = 0
            self._ai_usage_input = 0
            self._ai_usage_output = 0
            self._ai_usage_total = 0
            self._ai_usage_unknown = 0
            self._poster_request_id += 1
            self._last_poster_overview_key = ''
            self._last_tmdb_url_line_key = ''
            self._last_youtube_url_line_key = ''
            self._add_line(u'AI: Cześć. Opisz po swojemu film albo serial, a ja poszukam tropów.', role='assistant', status='smile')
            self._set_hint(u'Możesz napisać scenę, aktora, kraj, rok, cytat albo dziwny szczegół.')
            self._set_token_usage(False)
            # ZMIANA (2026-05) [NOWA FUNKCJA]: Wyczysc usuwa tez aktywny link TMDB z poprzedniego tropu.
            # POWOD: po resecie czatu przycisk nie powinien otwierac starego filmu/serialu.
            # NIE ZMIENIAC: reset dotyczy tylko stanu GUI okna AI.
            self._set_tmdb_button('')
            # ZMIANA (2026-05) [NOWA FUNKCJA]: Wyczysc usuwa tez aktywny zwiastun YouTube.
            # POWOD: po resecie czatu przycisk 207 nie powinien otwierac poprzedniego wyniku.
            # NIE ZMIENIAC: reset dotyczy tylko stanu GUI okna AI.
            self._set_youtube_button('')
            self._set_poster('')
            self._set_poster_title('')
            try:
                self.setFocusId(self.CTRL_INPUT)
            except Exception:
                pass
            return
        if control_id == self.CTRL_TMDB:
            # ZMIANA (2026-05) [NOWA FUNKCJA]: klikniecie 206 otwiera aktualny wynik TMDB.
            # POWOD: przycisk przy opisie ma prowadzic do pelnej strony w przegladarce.
            # NIE ZMIENIAC: akcja nie potwierdza tytulu i nie uruchamia wyszukiwania wtyczki.
            self._open_tmdb_url()
            return
        if control_id == self.CTRL_YOUTUBE:
            # ZMIANA (2026-05) [NOWA FUNKCJA]: klikniecie 207 otwiera zwiastun YouTube dla aktualnego wyniku.
            # POWOD: uzytkownik chce uruchomic zwiastun w aplikacji YouTube/przegladarce bez pobierania pliku.
            # NIE ZMIENIAC: akcja nie potwierdza tytulu i nie uruchamia wyszukiwania wtyczki.
            self._open_youtube_url()
            return
        if control_id == self.CTRL_INPUT:
            if self._busy:
                return
            try:
                if self._ready:
                    heading = u'Napisz TAK żeby wyszukać, NIE lub nowy szczegół'
                else:
                    heading = u'Opisz film lub odpowiedz na pytanie'
                kb = control.keyboard('', heading)
                kb.doModal()
                if not kb.isConfirmed():
                    return
                text = (kb.getText() or '').strip()
                if not text:
                    return
            except Exception as exc:
                log('[AI_SEARCH] keyboard ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
                return
            history_text = text
            if _is_user_reject(text):
                rejected_title = _display_title_from_ai(self._ai_data or {}) or _best_title_from_ai(self._ai_data or {})
                if rejected_title:
                    history_text = u'Nie, to nie "{}". To inny film.'.format(rejected_title)
                    extra = text.split(' ', 1)[1].strip() if ' ' in text else ''
                    if extra and len(extra) > 3:
                        history_text += u' ' + extra
                    log('[AI_SEARCH] LIVE_CHAT local reject remembered title={!r}'.format(rejected_title), 1)
            self._add_line(u'TY: ' + text, role='user')
            self._history.append({'role': 'user', 'content': history_text})
            if self._preview_candidate_choice(text):
                return
            # Sprawdź TAK
            can_confirm_now = self._ready
            confirmed_ai_data = _ai_user_confirmation_from_text(self._ai_data, text, self._history) if can_confirm_now else {}
            if confirmed_ai_data:
                log('[AI_SEARCH] LIVE_CHAT user confirmed locally title={!r} conf={}'.format(
                    _best_title_from_ai(confirmed_ai_data), confirmed_ai_data.get('confidence')), 1)
                self.result = {'action': 'confirm',
                               'ai_data': confirmed_ai_data,
                               'history': self._history}
                self.close()
                return
            # Kontynuuj rozmowę
            self._start_ai_call()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = 0
        if action_id in (9, 10, 92, 216, 247):
            self.result = {'action': 'cancel', 'ai_data': {}, 'history': self._history}
            self.close()


def _open_ai_chat_window(history=None, ai_data=None, allow_confirm=False, initial=False):
    # STUB — zostawiony dla kompatybilnosci; live-chat obsluguje _AIChatXMLDialog bezposrednio.
    return {'action': 'cancel', 'text': ''}


def _get_user_input():
    # STUB — live-chat zaczyna sie od _run_ai_mini_chat bezposrednio.
    return {'fabuła': '', 'chat_history': []}


# ZMIANA (2026-04) [PATCH]: wykrywa twardą podpowiedź kraju wpisaną przez użytkownika.
# POWOD: gdy użytkownik wpisze „polski” albo „zagraniczny”, AI i plan wyszukiwania nie mogą traktować tego tylko jako luźnej sugestii.
# NIE ZMIENIAC: funkcja ma wykrywać tylko intencję kraju/języka; nie dodawać tu konkretnych tytułów filmów ani przykładów.
def _detect_user_country_hint(fields):
    # ZMIANA (2026-04) [PATCH]: osobny wybór country_mode ma pierwszeństwo przed tekstem opisu.
    # POWOD: jeśli użytkownik wybierze Polski/Zagraniczny w oknie 0/6, nie wolno potem nadpisać tego zgadywaniem z opisu.
    # NIE ZMIENIAC: country_mode przyjmuje tylko wartości polish/foreign albo pusty AUTO.
    forced_mode = (fields.get('country_mode') or '').strip().lower()
    if forced_mode in ('polish', 'foreign'):
        return forced_mode

    text = ' '.join([
        fields.get('fabuła', ''),
        fields.get('postacie', ''),
        fields.get('gatunek', ''),
    ]).lower()
    polish_patterns = [
        r'\bpolski\b', r'\bpolska\b', r'\bpolskie\b', r'\bpolskiego\b',
        r'\bpolskim\b', r'\bpl\b', r'\bz\s+polski\b', r'\bprodukcja\s+polska\b',
    ]
    foreign_patterns = [
        r'\bzagraniczny\b', r'\bzagraniczna\b', r'\bzagraniczne\b',
        r'\busa\b', r'\bamerykański\b', r'\bamerykanski\b',
        r'\bangielski\b', r'\bfrancuski\b', r'\bniemiecki\b',
        r'\bhiszpański\b', r'\bhiszpanski\b', r'\bnie\s+polski\b', r'\bniepolski\b',
    ]
    for pattern in polish_patterns:
        if re.search(pattern, text, re.I):
            return 'polish'
    for pattern in foreign_patterns:
        if re.search(pattern, text, re.I):
            return 'foreign'
    return ''


def _detect_user_media_type_hint_from_text(text):
    # ZMIANA (2026-05) [PATCH]: wykrywa, czy uzytkownik jawnie szuka serialu albo filmu.
    # POWOD: brak pola type z AI spadal na movie i po wpisaniu "serial" finalne TMDB szlo w filmy.
    # NIE ZMIENIAC: to tylko twardy hint typu medium; nie podpowiada konkretnych tytulow.
    folded = _ai_fold_text(text or '')
    if not folded:
        return ''
    serial_terms = (
        'serial', 'serialu', 'seriale', 'serialem', 'serialowy', 'serialowa',
        'odcinek', 'odcinki', 'sezon', 'sezony', 'tv series', 'series',
        'show', 'sitcom', 'miniserial', 'mini serial', 'program tv'
    )
    movie_terms = (
        'film', 'filmu', 'filmie', 'filmem', 'filmowy', 'filmowa',
        'movie', 'cinema', 'kinowy', 'kinowa', 'pelny metraz'
    )
    serial_score = sum(1 for term in serial_terms if term in folded)
    movie_score = sum(1 for term in movie_terms if term in folded)
    if serial_score and re.search(r'\b(?:nie|to nie)\s+(?:film|filmu|movie)\b', folded):
        return 'tv'
    if movie_score and re.search(r'\b(?:nie|to nie)\s+(?:serial|serialu|series)\b', folded):
        return 'movie'
    if serial_score > movie_score:
        return 'tv'
    if movie_score > serial_score:
        return 'movie'
    return ''


def _detect_user_media_type_hint(history=None, fields=None):
    texts = []
    if history:
        texts.append(_chat_user_text(history or []))
    if isinstance(fields, dict):
        for value in fields.values():
            if value not in (None, ''):
                texts.append(u'{}'.format(value))
    return _detect_user_media_type_hint_from_text(u' '.join(texts))


def _ai_apply_media_type_hint(ai_data, history=None, fields=None):
    # ZMIANA (2026-05) [PATCH]: jawne "serial" z opisu nadpisuje puste/bledne type=movie.
    # POWOD: uzytkownik wpisal serial, a plan wyszukiwania i lokalne tropy kierowaly wynik do filmow.
    # NIE ZMIENIAC: przy braku jawnego hintu model nadal moze wybrac movie albo tv samodzielnie.
    hint = _detect_user_media_type_hint(history, fields)
    if hint not in ('movie', 'tv') or not isinstance(ai_data, dict):
        return ai_data
    data = dict(ai_data or {})
    original_type = (data.get('type') or '').strip()
    if original_type != hint:
        data['type'] = hint
        if original_type:
            log('[AI_SEARCH] media type forced by user hint: {} -> {}'.format(original_type, hint), 1)
    if original_type in ('movie', 'tv') and original_type != hint:
        for key in ('title', 'search_query', 'confirmation_title', 'pl_title', 'english_title', 'original_title'):
            data[key] = ''
        data['ready_to_confirm'] = False
        data['confidence'] = min(_ai_to_int(data.get('confidence')), 69)
        if hint == 'tv':
            data['assistant_message'] = u'Szukam tego jako serial. Pomijam filmowy wynik i sprawdzam kandydatow serialowych.'
    filtered = []
    removed = 0
    for item in data.get('candidates') or []:
        if not isinstance(item, dict):
            continue
        candidate_type = (item.get('type') or '').strip()
        if candidate_type in ('movie', 'tv') and candidate_type != hint:
            removed += 1
            continue
        candidate = dict(item)
        if not candidate_type:
            candidate['type'] = hint
        filtered.append(candidate)
    if data.get('candidates') is not None:
        data['candidates'] = filtered
    if removed:
        data['ready_to_confirm'] = False
        data['confidence'] = min(_ai_to_int(data.get('confidence')), 69)
        if hint == 'tv':
            data['assistant_message'] = u'Szukam tego jako serial. Pomijam filmowe tropy i potrzebuje kandydata serialowego.'
        log('[AI_SEARCH] media type filter removed candidates={} hint={}'.format(removed, hint), 1)
    return data


def _build_prompt(fields):
    parts = []
    country_hint = _detect_user_country_hint(fields)
    # ZMIANA (2026-04) [PATCH]: przekazuje do AI osobny wybór Polski/Zagraniczny jako twardy filtr.
    # POWOD: wybór z okna 0/6 ma być jednoznaczny i silniejszy niż opis fabuły.
    # NIE ZMIENIAC: przy AUTO nie dodawać sztucznego kraju; AI ma wtedy samodzielnie ocenić kandydatów.
    if country_hint == 'polish':
        # ZMIANA (2026-04) [PATCH]: wzmacnia prompt dla trybu POLSKI jako twardego filtra.
        # POWOD: AI potrafilo ratowac niepewny opis zagranicznym tytulem mimo wyboru Polski.
        # NIE ZMIENIAC: jeśli brak pewnego polskiego tytułu, AI ma zwrócić niskie confidence i polskie frazy, nie zagraniczny wynik.
        parts.append(u'TWARDY FILTR KRAJU: użytkownik wybrał POLSKI. Zwracaj wyłącznie polskie produkcje jako search_query i kandydatów. Jeśli nie rozpoznajesz polskiego tytułu, NIE podawaj zagranicznego filmu; ustaw confidence <= 50 i podaj polskie frazy ratunkowe.')
    elif country_hint == 'foreign':
        # ZMIANA (2026-04) [PATCH]: wzmacnia prompt dla trybu ZAGRANICZNY jako twardego filtra.
        # POWOD: wybór Zagraniczny ma wykluczać polskie produkcje jako główny wynik.
        # NIE ZMIENIAC: przy tym trybie search_query ma być oryginalnym/międzynarodowym tytułem albo zagraniczną frazą.
        parts.append(u'TWARDY FILTR KRAJU: użytkownik wybrał ZAGRANICZNY. Zwracaj wyłącznie zagraniczne produkcje jako search_query i kandydatów. Jeśli nie rozpoznajesz zagranicznego tytułu, NIE podawaj polskiej produkcji; ustaw confidence <= 50 i podaj zagraniczne frazy ratunkowe.')
    media_type_hint = _detect_user_media_type_hint(fields=fields)
    if media_type_hint == 'tv':
        parts.append(u'TWARDY TYP: uzytkownik szuka SERIALU. Zwracaj type="tv" i nie proponuj filmow kinowych.')
    elif media_type_hint == 'movie':
        parts.append(u'TWARDY TYP: uzytkownik szuka FILMU. Zwracaj type="movie" i nie proponuj seriali.')
    if fields.get('fabuła'):
        parts.append(u'Fabuła/scena: ' + fields['fabuła'])
    if fields.get('postacie'):
        parts.append(u'Postacie/aktor: ' + fields['postacie'])
    if fields.get('gatunek'):
        parts.append(u'Gatunek: ' + fields['gatunek'])
    rok_od = fields.get('rok_od', '')
    rok_do = fields.get('rok_do', '')
    if rok_od or rok_do:
        parts.append(u'Rok: {} - {}'.format(rok_od or '?', rok_do or '?'))
    return '\n'.join(parts)


def _extract_year(text):
    """Wyciąga pierwszy 4-cyfrowy rok z tekstu."""
    m = re.search(r'\b(19|20)\d{2}\b', text or '')
    return m.group(0) if m else ''


def _normalize_ai_title_year(title, year=''):
    title = (title or '').strip()
    year = str(year or '').strip()
    if not re.match(r'^\d{4}$', year):
        year = ''

    # ZMIANA (2026-05) [PATCH]: usun "czesc X" / "czesc. X" / "Part X" z tytulu przed wysłaniem do TMDB.
    # POWOD: TMDB nie zna polskiej nomenklatury "czesc 1/2/3" ani angielskiej "Part 1".
    #   "Garfield czesc 1" nie istnieje w TMDB — jest tylko "Garfield" (2004).
    #   Rok czesci powinien byc wpisany przez AI w pole year; ten kod usuwa sam numer.
    # NIE ZMIENIAC: wzorzec obsluguje "czesc", "cz.", "czesc." i "part" case-insensitive.
    m_part = re.search(
        r'^(.*?)\s+(?:czesc\.?|cz\.\s*|cze\s*sc\.?|part)\s*\d+\s*$',
        title, re.IGNORECASE
    )
    if not m_part:
        try:
            m_part = re.search(r'^(.*?)\s+część\s*\d+\s*$', title, re.IGNORECASE)
        except Exception:
            pass
    if m_part and m_part.group(1).strip():
        title = m_part.group(1).strip()

    # AI czasem dokleja rok do tytułu, a TMDB lepiej szuka po czystym tytule + osobnym year.
    m = re.search(r'^(.*?)\s*(?:\(|\[|y:|\s)((?:19|20)\d{2})(?:\)|\])?\s*$', title)
    if m and m.group(1).strip():
        title = m.group(1).strip()
        if not year:
            year = m.group(2)

    return title, year


# ZMIANA (2026-04) [FEATURE]: buduje bezpieczną listę kandydatów AI do wyszukiwania TMDB.
# POWOD: wcześniejsza wersja miała jeden strzał search_query, więc słabszy opis filmu dawał pusty wynik.
# NIE ZMIENIAC: zachować fallback na stare pola search_query/pl_title, bo starsze odpowiedzi providerów mogą nie mieć candidates.
def _ai_add_unique_candidate(candidates, title, pl_title='', year='', media_type='', confidence=0,
                             english_title='', original_title='', is_polish=False):
    title = (title or '').strip()
    pl_title = (pl_title or '').strip()
    english_title = (english_title or '').strip()
    original_title = (original_title or '').strip()
    year = str(year or '').strip()
    media_type = (media_type or '').strip()
    is_polish = bool(is_polish)
    try:
        confidence = int(confidence or 0)
    except Exception:
        confidence = 0

    if not title and not pl_title and not english_title and not original_title:
        return

    title, year = _normalize_ai_title_year(title, year)
    pl_title, year = _normalize_ai_title_year(pl_title, year)
    english_title, year = _normalize_ai_title_year(english_title, year)
    original_title, year = _normalize_ai_title_year(original_title, year)
    if _ai_looks_like_search_phrase(title):
        title = ''
    if _ai_looks_like_search_phrase(pl_title):
        pl_title = ''
    if _ai_looks_like_search_phrase(english_title):
        english_title = ''
    if _ai_looks_like_search_phrase(original_title):
        original_title = ''
    if not title and not pl_title and not english_title and not original_title:
        return

    if is_polish and pl_title:
        best_title = pl_title
    elif not is_polish:
        best_title = original_title or english_title or title or pl_title
    else:
        best_title = title or original_title or english_title or pl_title

    dedupe_key = best_title.lower()
    for item in candidates:
        if item.get('key') == dedupe_key:
            return

    candidates.append({
        'key': dedupe_key,
        'title': best_title,
        'pl_title': pl_title,
        'english_title': english_title,
        'original_title': original_title,
        'is_polish': is_polish,
        'year': year if re.match(r'^\d{4}$', year) else '',
        'type': media_type if media_type in ('movie', 'tv') else '',
        'confidence': confidence,
    })


# ZMIANA (2026-04) [FEATURE]: rozpoznaje sygnał polskiej produkcji z odpowiedzi AI.
# POWOD: polskie klasyki typu „Znachor” powinny iść do TMDB po polskim tytule, nie po wymuszonym angielskim tłumaczeniu.
# NIE ZMIENIAC: ma działać defensywnie także wtedy, gdy provider nie zwróci nowych pól is_polish/country.
def _ai_is_polish_item(item):
    if not isinstance(item, dict):
        return False
    if item.get('is_polish') is True:
        return True
    country = str(item.get('country') or item.get('production_country') or '').strip().lower()
    return country in ('pl', 'poland', 'polska')


def _ai_looks_like_search_phrase(value):
    # ZMIANA (2026-04) [PATCH]: nie traktuj frazy wyszukiwarkowej jako tytulu filmu.
    # POWOD: provider potrafil zwrocic opis wyszukiwarkowy w polu title/search_query.
    text = _ai_fold_text(value or '')
    if not text:
        return False
    markers = (
        ' film', ' movie', ' tv series', ' serial', ' scene', ' scena',
        ' plot', ' fabula', ' comedy', ' komedia', ' actor', ' aktor',
        'famous actor', 'znany aktor', 'old ', ' stary', 'classic ',
        'klasycz', 'french ', 'francus', 'american ', 'amerykan',
        'british ', 'brytyj', 'polish ', 'polsk', 'from the', 'lata ',
        'years ', 'about ', ' o ',
    )
    hits = sum(1 for marker in markers if marker in text)
    return hits >= 2 and len(text.split()) >= 4


def _ai_clear_search_phrase_titles(ai_data):
    # ZMIANA (2026-04) [PATCH]: opis wyszukiwarkowy nie moze byc tytulem do TAK/TMDB.
    # POWOD: po nacisnieciu TAK plugin szukal opisowej frazy zamiast realnego tytulu.
    if not isinstance(ai_data, dict):
        return ai_data
    changed = False
    data = dict(ai_data)
    for key in ('confirmation_title', 'search_query', 'pl_title', 'english_title', 'original_title', 'title'):
        value = data.get(key)
        if value and _ai_looks_like_search_phrase(value):
            data[key] = ''
            changed = True
    if changed:
        data['ready_to_confirm'] = False
        data['confidence'] = min(_ai_to_int(data.get('confidence')), 55)
        log('[AI_SEARCH] search-phrase title cleared before display/confirm', 1)
    return data if changed else ai_data


# ZMIANA (2026-04) [FEATURE]: normalizuje AUTO PL/EN, candidates/fallback_queries oraz stare search_query do jednego planu.
# POWOD: AI ma próbować kilku tropów i dla polskich filmów wybierać polski tytuł jako główny, np. „Znachor”.
# NIE ZMIENIAC: limit 5 kandydatów zostaje bezpiecznikiem przed spamem do TMDB i przypadkową pętlą wyszukiwania.
def _build_ai_search_plan(ai_data, fallback_query, country_hint='', media_type_hint=''):
    ai_data = ai_data or {}
    country_hint = country_hint if country_hint in ('polish', 'foreign') else ''
    media_type_hint = media_type_hint if media_type_hint in ('movie', 'tv') else ''
    candidates = []

    root_query = (ai_data.get('search_query') or fallback_query or '').strip()
    root_pl_title = (ai_data.get('pl_title') or '').strip()
    root_english_title = (ai_data.get('english_title') or '').strip()
    root_original_title = (ai_data.get('original_title') or '').strip()
    root_year = str(ai_data.get('year') or '').strip()
    root_type = (ai_data.get('type') or '').strip()
    if media_type_hint:
        root_type = media_type_hint
    root_confidence = ai_data.get('confidence') or 0
    try:
        root_confidence_int = int(root_confidence or 0)
    except Exception:
        root_confidence_int = 0
    root_is_polish = _ai_is_polish_item(ai_data)
    if country_hint == 'polish':
        root_is_polish = True
    elif country_hint == 'foreign':
        root_is_polish = False

    if root_is_polish:
        root_search_title = root_pl_title or root_query
    else:
        root_search_title = root_original_title or root_english_title or root_query

    _ai_add_unique_candidate(
        candidates, root_search_title, root_pl_title, root_year, root_type, root_confidence,
        root_english_title, root_original_title, root_is_polish
    )
    if _ai_ready_to_confirm(ai_data) and candidates:
        return candidates[:1]

    for item in ai_data.get('candidates') or []:
        if not isinstance(item, dict):
            continue
        item_type = (item.get('type') or root_type or '').strip()
        if media_type_hint and item_type in ('movie', 'tv') and item_type != media_type_hint:
            continue
        item_is_polish = _ai_is_polish_item(item) or root_is_polish
        if country_hint == 'polish':
            item_is_polish = True
        elif country_hint == 'foreign':
            item_is_polish = False
        if item_is_polish:
            item_search_title = item.get('pl_title') or item.get('title') or item.get('search_query')
        else:
            item_search_title = (
                item.get('original_title') or item.get('english_title') or
                item.get('search_query') or item.get('title')
            )
        _ai_add_unique_candidate(
            candidates,
            item_search_title,
            item.get('pl_title'),
            item.get('year'),
            item_type,
            item.get('confidence'),
            item.get('english_title'),
            item.get('original_title'),
            item_is_polish,
        )

    # Dla polskich filmów dodaj drugi trop po angielskim/original_title tylko jako zapas, nie jako pierwszy.
    if root_is_polish:
        _ai_add_unique_candidate(
            candidates, root_original_title or root_english_title, root_pl_title, root_year,
            root_type, max(root_confidence_int - 10, 0), root_english_title,
            root_original_title, False
        )

    for query in ai_data.get('fallback_queries') or []:
        _ai_add_unique_candidate(candidates, query, '', '', root_type or media_type_hint, 35, '', '', False)

    if not candidates:
        _ai_add_unique_candidate(candidates, fallback_query, '', '', root_type or media_type_hint, 0, '', '', country_hint == 'polish')

    # ZMIANA (2026-04) [PATCH]: twardo porządkuje kandydatów według kraju podanego przez użytkownika.
    # POWOD: po wpisaniu „polski” wtyczka nie może brać zagranicznego kandydata jako pierwszego tylko dlatego, że AI tak zgadło.
    # NIE ZMIENIAC: to jest filtr priorytetu kraju, nie lista konkretnych filmów; limit 5 kandydatów pozostaje bez zmian.
    if country_hint == 'polish':
        preferred = [c for c in candidates if c.get('is_polish') or c.get('pl_title')]
        fallback = [c for c in candidates if c not in preferred]
        for item in fallback:
            item['confidence'] = min(int(item.get('confidence') or 0), 55)
        candidates = preferred + fallback
    elif country_hint == 'foreign':
        preferred = [c for c in candidates if not c.get('is_polish')]
        fallback = [c for c in candidates if c.get('is_polish')]
        for item in fallback:
            item['confidence'] = min(int(item.get('confidence') or 0), 55)
        candidates = preferred + fallback

    return candidates[:5]

# ZMIANA (2026-04) [FEATURE]: pomocnicze funkcje mini-czatu AI przed wyszukiwaniem TMDB.
# POWOD: AI ma prowadzić rozmowę, zadawać pytania i wymagać potwierdzenia użytkownika przed pokazaniem wyników.
# NIE ZMIENIAC: wyszukiwanie TMDB uruchamia się dopiero po potwierdzeniu w _run_ai_mini_chat().
_AI_CHAT_MAX_ROUNDS = 15
_AI_CHAT_CONFIRM_CONFIDENCE = 70


def _ai_to_int(value, default=0):
    try:
        return int(value or default)
    except Exception:
        return default


def _chat_user_text(history):
    return '\n'.join([item.get('content', '') for item in history if item.get('role') == 'user']).strip()


def _best_title_from_ai(ai_data):
    ai_data = ai_data or {}
    confirmation_title = ai_data.get('confirmation_title') or ''
    search_query = ai_data.get('search_query') or ''
    pl_title = ai_data.get('pl_title') or ''
    original_title = ai_data.get('original_title') or ''
    english_title = ai_data.get('english_title') or ''
    if _ai_looks_like_search_phrase(confirmation_title):
        confirmation_title = ''
    if _ai_looks_like_search_phrase(search_query):
        search_query = ''
    if _ai_looks_like_search_phrase(pl_title):
        pl_title = ''
    if _ai_looks_like_search_phrase(original_title):
        original_title = ''
    if _ai_looks_like_search_phrase(english_title):
        english_title = ''
    if not _ai_is_polish_item(ai_data) and (original_title or english_title):
        title = original_title or english_title or search_query or confirmation_title or pl_title
    else:
        title = confirmation_title or search_query or pl_title or original_title or english_title
    return str(title or '').strip()


def _display_title_from_ai(ai_data):
    ai_data = ai_data or {}
    pl_title = str(ai_data.get('pl_title') or '').strip()
    original_title = str(ai_data.get('original_title') or '').strip()
    english_title = str(ai_data.get('english_title') or '').strip()
    main_title = _best_title_from_ai(ai_data) or str(ai_data.get('title') or '').strip()
    year = str(ai_data.get('year') or '').strip()

    titles = []
    for title in (pl_title, main_title, original_title, english_title):
        if title and title.lower() not in [t.lower() for t in titles]:
            titles.append(title)

    display = u' / '.join(titles[:2]) if titles else ''
    if display and re.match(r'^\d{4}$', year):
        display += u' ({})'.format(year)
    return display


def _ai_candidate_from_user_choice(ai_data, text):
    # ZMIANA (2026-05) [PATCH]: numer z czatu wskazuje kandydata lokalnie do podgladu.
    # POWOD: uzytkownik wpisuje "1", "2" albo "3", zeby zobaczyc plakat/opis/zwiastun bez kolejnego AI.
    # NIE ZMIENIAC: finalne wyszukiwanie po numerze wymaga osobnego TAK po podgladzie.
    ai_data = ai_data or {}
    text = (text or '').strip()
    if not re.match(r'^\d{1,2}$', text):
        return {}
    try:
        idx = int(text) - 1
    except Exception:
        return {}
    if idx < 0:
        return {}
    candidates = ai_data.get('candidates') or []
    if idx < len(candidates) and isinstance(candidates[idx], dict):
        return candidates[idx]
    if idx == 0 and _best_title_from_ai(ai_data):
        return ai_data
    return {}


def _ai_user_confirmed_data(ai_data, candidate=None):
    # ZMIANA (2026-04) [PATCH]: jawne potwierdzenie uzytkownika jest osobna bramka do TMDB.
    # POWOD: automatyczna pewnosc AI moze byc niska, ale po "TAK" nie wolno pytac AI od nowa.
    base = dict(ai_data or {})
    candidate = candidate if isinstance(candidate, dict) else {}
    if candidate and candidate is not ai_data:
        for key in ('pl_title', 'english_title', 'original_title', 'year', 'type', 'is_polish', 'country'):
            if candidate.get(key) not in (None, ''):
                base[key] = candidate.get(key)
        cand_title = (
            candidate.get('search_query') or candidate.get('title') or
            candidate.get('original_title') or candidate.get('english_title') or candidate.get('pl_title')
        )
        if cand_title:
            base['search_query'] = cand_title
            base['confirmation_title'] = cand_title
        if candidate.get('confidence') not in (None, ''):
            base['confidence'] = candidate.get('confidence')

    title = _best_title_from_ai(base)
    if not title:
        return {}
    base['confirmation_title'] = title
    base['search_query'] = title
    base['ready_to_confirm'] = True
    base['user_confirmed'] = True
    base['confidence'] = max(_ai_to_int(base.get('confidence')), _AI_CHAT_CONFIRM_CONFIDENCE)
    return base


def _ai_user_preview_data(ai_data, candidate=None):
    # ZMIANA (2026-05) [PATCH]: wybor numeru tworzy stan podgladu, ale nie ustawia user_confirmed.
    # POWOD: po wpisaniu 1/2/3 ma byc najpierw plakat, opis i zwiastun, a finalne TMDB dopiero po TAK.
    # NIE ZMIENIAC: ready_to_confirm pozwala potem przyjac TAK, ale samo wybranie numeru nie zamyka czatu.
    base = dict(ai_data or {})
    candidate = candidate if isinstance(candidate, dict) else {}
    if candidate and candidate is not ai_data:
        for key in ('pl_title', 'english_title', 'original_title', 'year', 'type', 'is_polish', 'country'):
            if candidate.get(key) not in (None, ''):
                base[key] = candidate.get(key)
        cand_title = (
            candidate.get('search_query') or candidate.get('title') or
            candidate.get('original_title') or candidate.get('english_title') or candidate.get('pl_title')
        )
        if cand_title:
            base['search_query'] = cand_title
            base['confirmation_title'] = cand_title
        if candidate.get('confidence') not in (None, ''):
            base['confidence'] = candidate.get('confidence')

    title = _best_title_from_ai(base)
    if not title:
        return {}
    base['confirmation_title'] = title
    base['search_query'] = title
    base['ready_to_confirm'] = True
    base.pop('user_confirmed', None)
    base['confidence'] = max(_ai_to_int(base.get('confidence')), _AI_CHAT_CONFIRM_CONFIDENCE)
    return base


def _ai_user_confirmation_from_text(ai_data, text, history=None):
    if _is_user_confirm(text) and _best_title_from_ai(ai_data):
        if not _ai_ready_to_confirm(ai_data, history):
            return {}
        ai_data = _ai_clear_search_phrase_titles(ai_data)
        if not _best_title_from_ai(ai_data):
            return {}
        if _ai_title_matches_rejected(_best_title_from_ai(ai_data), history):
            return {}
        if _ai_title_matches_actor_example(_best_title_from_ai(ai_data), history):
            return {}
        return _ai_user_confirmed_data(ai_data)
    return {}


def _ai_text_without_actor_examples(text):
    # ZMIANA (2026-04) [PATCH]: "gral np. w X" to trop aktora, nie tytul szukanego filmu.
    # POWOD: AI bralo przykladowy film z dorobku aktora jako glowny wynik.
    text = text or ''
    patterns = (
        r'\b(?:grał|gral|grała|grala|występował|wystepowal|występowała|wystepowala)\s+'
        r'(?:np\.?|na przykład|na przyklad|m\.?in\.?|między innymi|miedzy innymi)\s+'
        r'(?:w|we|z)\s+[^,.!?;]{2,80}',
        r'\b(?:znany|znana|kojarzony|kojarzona)\s+'
        r'(?:np\.?|na przykład|na przyklad|m\.?in\.?|między innymi|miedzy innymi)?\s*'
        r'z\s+[^,.!?;]{2,80}',
    )
    for pattern in patterns:
        text = re.sub(pattern, u'aktor znany z innego filmu', text, flags=re.I)
    return u' '.join(text.split())


def _ai_actor_example_terms_from_history(history):
    text = _chat_user_text(history or [])
    folded = _ai_fold_text(text or '')
    if not folded:
        return []
    patterns = (
        r'\b(?:gral|grala|wystepowal|wystepowala)\s+'
        r'(?:np\.?|na przyklad|m\.?in\.?|miedzy innymi)\s+'
        r'(?:w|we|z)\s+([^,.!?;]{2,80})',
        r'\b(?:znany|znana|kojarzony|kojarzona)\s+'
        r'(?:np\.?|na przyklad|m\.?in\.?|miedzy innymi)?\s*'
        r'z\s+([^,.!?;]{2,80})',
    )
    stop = set([
        'film', 'filmu', 'filmie', 'filmem', 'serial', 'serialu', 'aktor', 'aktora', 'aktorka',
        'np', 'na', 'przyklad', 'miedzy', 'innymi', 'znany', 'znana',
        'smieszny', 'francuski', 'komediowy', 'inny', 'innym',
    ])
    suffixes = ('ach', 'ami', 'owie', 'owego', 'owej', 'ego', 'iego', 'ym', 'im', 'em', 'ie', 'ow', 'a', 'u', 'y', 'i')
    terms = []
    for pattern in patterns:
        for match in re.finditer(pattern, folded):
            phrase = re.split(r'\b(?:ale|chodzi|ktory|ktora|gdzie|ten|ta|to|film|filmu|filmie|filmem)\b', match.group(1))[0]
            for token in re.split(r'[^a-z0-9]+', phrase):
                token = token.strip()
                if len(token) < 5 or token in stop:
                    continue
                stem = token
                for suffix in suffixes:
                    if stem.endswith(suffix) and len(stem) - len(suffix) >= 5:
                        stem = stem[:-len(suffix)]
                        break
                if stem not in terms:
                    terms.append(stem)
    return terms[:6]


def _ai_title_matches_actor_example(title, history):
    return False


def _ai_actor_example_terms_in_text(text, history):
    folded = _ai_fold_text(text or '')
    if not folded:
        return False
    for term in _ai_actor_example_terms_from_history(history or []):
        if len(term) >= 5 and term in folded:
            return True
    return False


def _ai_candidate_matches_actor_example(candidate, history):
    if not isinstance(candidate, dict):
        return False
    title_text = _ai_candidate_title_text(candidate)
    return _ai_actor_example_terms_in_text(title_text, history or [])


def _ai_candidate_title_text(candidate):
    if not isinstance(candidate, dict):
        return ''
    return u' '.join([
        str(candidate.get('title') or ''),
        str(candidate.get('search_query') or ''),
        str(candidate.get('confirmation_title') or ''),
        str(candidate.get('pl_title') or ''),
        str(candidate.get('english_title') or ''),
        str(candidate.get('original_title') or ''),
    ])


def _ai_title_identity_tokens(text):
    folded = _ai_fold_text(text or '')
    stop = set([
        'film', 'movie', 'serial', 'series', 'the', 'and', 'with', 'from',
        'le', 'la', 'les', 'de', 'du', 'des', 'un', 'une', 'et', 'el', 'los', 'las',
        'der', 'die', 'das', 'und', 'ein', 'eine', 'z', 'ze', 'w', 'we', 'i', 'oraz',
    ])
    out = []
    for token in re.split(r'[^a-z0-9]+', folded):
        token = token.strip()
        if len(token) < 4 or token in stop or token.isdigit():
            continue
        if token not in out:
            out.append(token)
    return out


def _ai_titles_share_identity(left, right):
    left_folded = _ai_fold_text(left or '')
    right_folded = _ai_fold_text(right or '')
    if not left_folded or not right_folded:
        return False
    if left_folded in right_folded or right_folded in left_folded:
        return True
    left_tokens = set(_ai_title_identity_tokens(left_folded))
    right_tokens = set(_ai_title_identity_tokens(right_folded))
    if not left_tokens or not right_tokens:
        return False
    shared = left_tokens.intersection(right_tokens)
    return len(shared) >= 2


def _ai_strip_actor_example_suggestions(message, history):
    # ZMIANA (2026-04) [PATCH]: nie pokazuj przykladowego filmu aktora nawet jako kandydata w tekscie.
    # POWOD: "aktor gral np. w ..." ma pomagac ustalic aktora, a nie wracac jako propozycja filmu.
    if not message or not _ai_actor_example_terms_from_history(history or []):
        return message
    kept = []
    removed = False
    for line in str(message or '').split(u'\n'):
        if _ai_actor_example_terms_in_text(line, history or []):
            removed = True
            continue
        kept.append(line)
    cleaned = u'\n'.join([x for x in kept if x.strip()]).strip()
    if removed and not cleaned:
        cleaned = u'Pominąłem przykładowy film z aktorem i szukam po scenie/fabule.'
    return cleaned


def _ai_filter_actor_example_candidates(ai_data, history):
    # ZMIANA (2026-04) [SIMPLIFY]: filtr wylaczony - dzialamy jak ChatGPT/Google.
    # POWOD: filtr kasowal poprawne wyniki gdy uzytkownik wspomnial aktora (np. Zandarm, Boniface Somnambule).
    return ai_data


def _ai_strip_rejected_suggestions(message, history):
    if not message or not _ai_collect_rejected_titles(history or []):
        return message
    kept = []
    removed = False
    for line in str(message or '').split(u'\n'):
        if any(_ai_titles_share_identity(line, rejected) for rejected in _ai_collect_rejected_titles(history or [])):
            removed = True
            continue
        kept.append(line)
    cleaned = u'\n'.join([x for x in kept if x.strip()]).strip()
    if removed and not cleaned:
        cleaned = u'Ten tytul byl juz odrzucony albo zablokowany przez brak potwierdzenia sceny. Szukam dalej po nowych szczegolach.'
    return cleaned


def _ai_filter_rejected_candidates(ai_data, history):
    # ZMIANA (2026-04) [REAL MECHANISM]: twardy filtr odrzuconych/zablokowanych tytulow.
    # POWOD: prompt nie wystarczy; model potrafil ponownie promowac tytul odrzucony przez uzytkownika albo scene-gate.
    if not isinstance(ai_data, dict) or not _ai_collect_rejected_titles(history or []):
        return ai_data
    changed = False
    data = dict(ai_data)
    candidates = []
    removed_titles = []
    for item in data.get('candidates') or []:
        if not isinstance(item, dict):
            candidates.append(item)
            continue
        title_text = _display_title_from_ai(item) or _ai_candidate_title_text(item) or _best_title_from_ai(item)
        if _ai_title_matches_rejected(title_text, history or []):
            removed_titles.append(title_text)
            changed = True
            continue
        candidates.append(item)
    if changed:
        data['candidates'] = candidates

    main_title = _display_title_from_ai(data) or _ai_candidate_title_text(data) or _best_title_from_ai(data)
    if main_title and _ai_title_matches_rejected(main_title, history or []):
        removed_titles.append(main_title)
        for key in ('title', 'search_query', 'confirmation_title', 'pl_title', 'english_title', 'original_title'):
            data[key] = ''
        data['ready_to_confirm'] = False
        data['confidence'] = min(_ai_to_int(data.get('confidence')), 55)
        data['evidence_score'] = min(_ai_to_int(data.get('evidence_score')), 55)
        changed = True

    msg = str(data.get('assistant_message') or '')
    cleaned_msg = _ai_strip_rejected_suggestions(msg, history or [])
    if cleaned_msg != msg:
        data['assistant_message'] = cleaned_msg
        changed = True
    if changed:
        log('[AI_SEARCH] rejected-title filter removed: {}'.format(
            ', '.join([x for x in removed_titles if x])[:220] or 'message'), 1)
    return data if changed else ai_data


def _ai_actor_example_note(history):
    terms = _ai_actor_example_terms_from_history(history or [])
    if not terms:
        return u''
    return (
        u'UWAGA NA PRZYKLAD AKTORA:\n'
        u'Uzytkownik podal tytul/serie po zwrocie typu "aktor gral np. w ...". '
        u'To jest przyklad dorobku aktora, NIE szukany film; dotyczy to takze oryginalnych tytulow i tlumaczen tego przykladu. '
        u'Nie promuj tego przykladowego tytulu jako wyniku, chyba ze legalny kontekst potwierdza takze rzadka scene/fabule z opisu w tym samym filmie. '
        u'Termy przykladu aktora: ' + u', '.join(terms) + u'.\n\n'
    )


def _ai_reasoning_agent_prompt_text():
    global _AI_REASONING_AGENT_PROMPT_CACHE
    fallback = (
        u'FANVODPL AI - AGENT ANALIZY TYTULU\n'
        u'Najpierw zrozum zdanie uzytkownika: oddziel opis szukanego filmu od wyjasnien, skojarzen i przykladow.\n'
        u'Rozbij opis na szukany film, rzadkie tropy sceny/fabuly, slabe tropy pamieci, trop aktora i przyklady dorobku aktora.\n'
        u'Tytul po "gral np. w", "wystepowal np. w", "znany z", "kojarzony z" jest tylko przykladem aktora, nie szukanym filmem; dotyczy to takze jego oryginalnych tytulow i tlumaczen.\n'
        u'Buduj zapytania z rzadkich tropow szukanego filmu, nie z przykladowego filmu aktora.\n'
        u'Dla kazdego opisu sam wyznacz glowny trop sceny/fabuly z tekstu uzytkownika. Nie masz gotowych scen ani tytulow w promptcie.\n'
        u'Pewny wynik wymaga potwierdzenia glownego tropu sceny/fabuly w legalnym kontekście. W matched_rare_clues dodaj wpis "SCENA/FABULA: ..." gdy ustawiasz ready_to_confirm=true.\n'
        u'Najmocniejsze sa rzadkie sceny, funkcje postaci, rekwizyty, relacje i konkretne sytuacje. Kraj, dekada, gatunek i znany aktor sa slabsze.\n'
        u'Porownuj kandydatow po calym polaczeniu tropow. Nie promuj filmu pasujacego tylko aktorem, krajem, gatunkiem albo przykladowym tytulem aktora.\n'
        u'Po "nie" poprzedni tytul jest odrzucony i nie wolno proponowac go ponownie.\n'
        u'ready_to_confirm=true tylko gdy legalny kontekst web/API potwierdza rzadkie tropy. Wypelniaj matched_rare_clues, missing_rare_clues i evidence_score.\n'
    )
    if _AI_REASONING_AGENT_PROMPT_CACHE is not None:
        return _AI_REASONING_AGENT_PROMPT_CACHE
    text = ''
    try:
        import os as _os
        import xbmcaddon as _xbmcaddon
        addon_path = _xbmcaddon.Addon().getAddonInfo('path')
        prompt_path = _os.path.join(addon_path, 'resources', 'lib', _AI_REASONING_AGENT_PROMPT_FILE)
        if _os.path.exists(prompt_path):
            with open(prompt_path, 'rb') as fh:
                text = fh.read().decode('utf-8', 'replace')
    except Exception as exc:
        try:
            log('[AI_SEARCH] reasoning prompt fallback: {}'.format(_safe_exception_text(exc, 80)), 1)
        except Exception:
            pass
    text = u'\n'.join([line.strip() for line in (text or '').replace('\r\n', '\n').splitlines() if line.strip()])
    if not text:
        text = fallback
    _AI_REASONING_AGENT_PROMPT_CACHE = text.strip()
    return _AI_REASONING_AGENT_PROMPT_CACHE


def _ai_description_analyzer_prompt_text():
    global _AI_DESCRIPTION_ANALYZER_PROMPT_CACHE
    fallback = (
        u'FANVODPL AI - AGENT ANALIZY OPISU\n'
        u'Zrozum opis uzytkownika przed wyszukiwaniem. Nie zgaduj tytulu.\n'
        u'Zwroc tylko JSON: target_description, primary_scene, must_have_clues, weak_clues, actor_clues, '
        u'excluded_actor_examples, likely_original_languages oraz queries z polami original_language, english, polish, broader.\n'
        u'Glowna scena/fabula jest najwazniejsza. Jesli kraj/jezyk wynika z opisu, queries.original_language ma zawierac zapytania w tym jezyku.\n'
    )
    if _AI_DESCRIPTION_ANALYZER_PROMPT_CACHE is not None:
        return _AI_DESCRIPTION_ANALYZER_PROMPT_CACHE
    text = ''
    try:
        import os as _os
        import xbmcaddon as _xbmcaddon
        addon_path = _xbmcaddon.Addon().getAddonInfo('path')
        prompt_path = _os.path.join(addon_path, 'resources', 'lib', _AI_DESCRIPTION_ANALYZER_PROMPT_FILE)
        if _os.path.exists(prompt_path):
            with open(prompt_path, 'rb') as fh:
                text = fh.read().decode('utf-8', 'replace')
    except Exception as exc:
        try:
            log('[AI_SEARCH] description analyzer prompt fallback: {}'.format(_safe_exception_text(exc, 80)), 1)
        except Exception:
            pass
    text = u'\n'.join([line.strip() for line in (text or '').replace('\r\n', '\n').splitlines() if line.strip()])
    if not text:
        text = fallback
    _AI_DESCRIPTION_ANALYZER_PROMPT_CACHE = text.strip()
    return _AI_DESCRIPTION_ANALYZER_PROMPT_CACHE


def _ai_parse_json_object(raw):
    raw = (raw or '').strip()
    if not raw:
        return {}
    raw = re.sub(r'```(?:json)?', '', raw, flags=re.I).replace('```', '').strip()
    candidates = [raw]
    start = raw.find('{')
    end = raw.rfind('}')
    if start != -1 and end != -1 and end > start:
        candidates.insert(0, raw[start:end + 1])
    for candidate in candidates:
        try:
            data = json.loads(candidate)
            if isinstance(data, dict):
                return data
        except Exception:
            continue
    return {}


def _ai_description_analysis_from_history(history):
    user_text = u' '.join((_chat_user_text(history or []) or '').split()).strip()
    user_text = _ai_text_without_actor_examples(user_text)
    if len(user_text) < 8:
        return {}
    try:
        provider = _normalize_ai_provider(control.setting('ai_search.provider'), log_change=True)
        api_key = (control.setting('ai_search.key.' + provider.lower()) or '').strip()
    except Exception:
        provider, api_key = '', ''
    if not provider or not api_key:
        return {}
    model_cache = _gemini_model_choice() if provider == 'Gemini' else provider
    cache_key = 'description_analyzer_v2|{}|{}|{}'.format(
        provider, model_cache, _ai_research_cache_fingerprint(history or [])[:700])
    cached = _ai_cache_get(cache_key)
    if cached is not None:
        return cached or {}
    # ZMIANA (2026-05) [PATCH]: usunieto Python-injekt jezyka — gpt-4o czyta reguly POZIOM 1/2/3 z pliku .txt.
    # POWOD: injekt byl workaroundem dla mini (krotki hint "NOT E.T."); gpt-4o stosuje pelne reguly z .txt.
    # NIE ZMIENIAC: jezyki sa wykrywane przez AI na podstawie opisu uzytkownika zgodnie z .txt.
    prompt = (
        _ai_description_analyzer_prompt_text() +
        u'\n\nNie uzywaj wiedzy o konkretnym tytule. Nie odpowiadaj tytulem filmu. '
        u'Analizuj tylko slowa uzytkownika i przygotuj plan wyszukiwania.\n\n'
        + _ai_actor_example_note(history or []) +
        u'OPIS UZYTKOWNIKA:\n' + user_text[:1200]
    )
    try:
        import requests as _req
        raw = ''
        if provider == 'OpenAI':
            model = _openai_model_choice()[0]
            r = _req.post(
                'https://api.openai.com/v1/responses',
                headers={'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'},
                json={'model': model, 'input': prompt, 'max_output_tokens': 650},
                timeout=18,
            )
            r.raise_for_status()
            raw = _extract_openai_response_text(r.json())
        elif provider == 'Gemini':
            r = _req.post(
                'https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent'.format(_gemini_model_choice()),
                headers={'Content-Type': 'application/json', 'x-goog-api-key': api_key},
                json={'contents': [{'parts': [{'text': prompt}]}],
                      'generationConfig': {'maxOutputTokens': 650, 'temperature': 0.0, 'responseMimeType': 'application/json'}},
                timeout=14,
            )
            r.raise_for_status()
            parts = (((r.json().get('candidates') or [{}])[0].get('content') or {}).get('parts') or [])
            raw = ''.join(p.get('text', '') for p in parts)
        elif provider == 'Claude':
            r = _req.post(
                'https://api.anthropic.com/v1/messages',
                headers={'x-api-key': api_key, 'anthropic-version': '2023-06-01', 'Content-Type': 'application/json'},
                json={'model': 'claude-sonnet-4-5-20251022', 'max_tokens': 650,
                      'system': 'Return only JSON.',
                      'messages': [{'role': 'user', 'content': prompt}]},
                timeout=14,
            )
            r.raise_for_status()
            raw = ''.join((b.get('text') or '') for b in (r.json().get('content') or []) if isinstance(b, dict))
        data = _ai_parse_json_object(raw)
        if data:
            try:
                scene = str(data.get('primary_scene') or '')[:140]
                languages = data.get('likely_original_languages') or []
                log('[AI_SEARCH] DESCRIPTION_ANALYZER scene={!r} languages={!r}'.format(scene, languages), 1)
            except Exception:
                pass
            return _ai_cache_set(cache_key, data)
    except Exception as exc:
        log('[AI_SEARCH] DESCRIPTION_ANALYZER skipped: {}'.format(_safe_exception_text(exc, 120)), 1)
    return _ai_cache_set(cache_key, {})


def _ai_queries_from_description_analysis(analysis):
    if not isinstance(analysis, dict):
        return []
    queries = analysis.get('queries') or analysis.get('search_queries') or {}
    ordered = []
    if isinstance(queries, dict):
        for key in ('original_language', 'original', 'native_language', 'english', 'en', 'polish', 'pl', 'broader'):
            value = queries.get(key)
            if isinstance(value, list):
                ordered.extend(value)
            elif isinstance(value, str) and value.strip():
                ordered.append(value)
    elif isinstance(queries, list):
        ordered.extend(queries)
    out = []
    seen = set()
    for item in ordered:
        if isinstance(item, dict):
            item = item.get('query') or item.get('q') or item.get('text') or ''
        q = u' '.join(str(item or '').split()).strip(' "\'.,;')
        key = _ai_fold_text(q)
        if 6 <= len(q) <= 160 and key not in seen:
            seen.add(key)
            out.append(q)
        if len(out) >= 10:
            break
    return out


def _ai_codex_reasoning_contract(history=None):
    # ZMIANA (2026-04) [PATCH]: jeden kontrakt "myslenia jak Codex" dla wszystkich promptow.
    # POWOD: model mial te zasady rozproszone i wracal do jednego slowa/aktora zamiast laczyc tropy.
    rejected = _ai_collect_rejected_titles(history or [])
    rejected_line = u''
    if rejected:
        rejected_line = u'Odrzucone tytuly sa zakazane w tej rundzie: ' + u'; '.join(rejected[:8]) + u'.\n'
    return _ai_reasoning_agent_prompt_text() + u'\n' + rejected_line + u'\n'



# ZMIANA (2026-04) [PATCH]: pamięć dialogu AI — odrzucone tytuły, brak znanego aktora i tryb mocnego researchu.
# POWOD: mini-czat zbyt długo zgadywał, pytał ponownie o aktora mimo odpowiedzi „nie znam” i nie wymuszał mocniejszego wyszukiwania po kilku dopowiedziach.
# NIE ZMIENIAC: te funkcje nie zmieniają TMDB ani hostów; służą tylko do sterowania promptem i retry w trybie „Nie pamiętam tytułu”.
def _ai_norm_text(value):
    value = (value or '').lower()
    repl = {
        u'ą': u'a', u'ć': u'c', u'ę': u'e', u'ł': u'l', u'ń': u'n',
        u'ó': u'o', u'ś': u's', u'ż': u'z', u'ź': u'z',
    }
    for src, dst in repl.items():
        value = value.replace(src, dst)
    return value


def _ai_user_turn_count(history):
    return len([h for h in (history or []) if h.get('role') == 'user' and (h.get('content') or '').strip()])


def _ai_latest_user_text(history):
    for h in reversed(history or []):
        if h.get('role') == 'user':
            return (h.get('content') or '').strip()
    return ''


def _ai_user_said_unknown_actor(history):
    text = _ai_norm_text(_chat_user_text(history or []))
    actor_words = (u'aktor', u'aktora', u'aktorem', u'rola', u'role', u'glowna', u'glowny', u'obsada')
    unknown_words = (u'nie znam', u'nie znamy', u'nie wiem', u'nie pamietam', u'nie kojarze', u'nie znany', u'nieznany')
    if any(a in text for a in actor_words) and any(u in text for u in unknown_words):
        return True

    # ZMIANA (2026-04) [PATCH]: odpowiedź „nie” po pytaniu AI o aktora też oznacza, że aktor jest nieznany.
    # POWOD: użytkownik często odpowiada krótko „nie”/„nie ale znany”, bez powtarzania słowa „aktor”, a AI pytało potem o to samo.
    # NIE ZMIENIAC: sprawdzamy parę poprzednie pytanie AI -> odpowiedź użytkownika, nie każdy losowy komunikat „nie”.
    prev_ai = ''
    for item in history or []:
        role = item.get('role', '')
        content = (item.get('content') or '').strip()
        if role == 'assistant':
            prev_ai = _ai_norm_text(content)
            continue
        if role == 'user' and prev_ai:
            user_reply = _ai_norm_text(content)
            asked_actor = any(a in prev_ai for a in actor_words)
            user_denied = any(u in user_reply for u in unknown_words) or user_reply in (u'nie', u'no', u'n') or user_reply.startswith(u'nie ')
            if asked_actor and user_denied:
                return True
            prev_ai = ''
    return False


def _ai_user_said_unknown_year(history):
    text = _ai_norm_text(_chat_user_text(history or []))
    year_words = (u'rok', u'roku', u'lata', u'rocznik')
    unknown_words = (u'nie znam', u'nie wiem', u'nie pamietam', u'nie kojarze')
    return any(y in text for y in year_words) and any(u in text for u in unknown_words)


def _ai_extract_rejected_titles_from_text(text):
    text = text or ''
    found = []
    for m in re.finditer(r'(?im)^\s*To\s+wygl[aą]da\s+na:\s*(.+?)(?:\s*\(|$)', text):
        title = m.group(1).strip(' -:;.,"\'')[:120]
        if title and title not in found:
            found.append(title)
    # Najważniejsze: tytuł po linii „Trop:” — to jest realny kandydat, którego użytkownik zwykle odrzuca słowem „nie”.
    for m in re.finditer(r'(?im)^\s*(?:Trop|Moj trop|Mam mocny trop):\s*(.+?)(?:\s*\(|$)', text):
        title = m.group(1).strip(' -–—:;.,"\'')[:120]
        if title and title not in found:
            found.append(title)
    # Linie numerowane z listą kandydatów: „1. Tytuł / Original (rok)”.
    for m in re.finditer(r'(?m)^\s*\d{1,2}\.\s*(.+?)(?:\s+—|\s*\(|$)', text):
        title = m.group(1).strip(' -–—:;.,"\'')[:120]
        if title and title not in found:
            found.append(title)
    # Cudzysłowy, np. „Les Visiteurs”.
    for m in re.finditer(r'[„\"]([^„”\"]{3,90})[”\"]', text):
        title = m.group(1).strip(' -–—:;.,"\'')[:120]
        if title and title not in found:
            found.append(title)
    return found[:8]


def _ai_extract_auto_rejected_titles_from_text(text):
    text = text or ''
    found = []
    for m in re.finditer(r'(?im)^\s*(?:AUTO_REJECTED_TITLE|AUTO_BLOCKED_TITLE|SCENE_GATE_REJECTED_TITLE)\s*:\s*(.+?)\s*$', text):
        title = m.group(1).strip(' -:;.,"\'')[:160]
        if title and title not in found:
            found.append(title)
    return found[:8]


def _ai_add_rejected_title(rejected, title):
    title = (title or '').strip(' -:;.,"\'')[:160]
    if not title:
        return
    for existing in rejected:
        if _ai_titles_share_identity(existing, title):
            return
    rejected.append(title)


def _ai_collect_rejected_titles(history):
    rejected = []
    prev_ai = ''
    for h in history or []:
        role = h.get('role', '')
        content = (h.get('content') or '').strip()
        for title in _ai_extract_auto_rejected_titles_from_text(content):
            _ai_add_rejected_title(rejected, title)
        if role == 'assistant':
            prev_ai = content
            continue
        if role == 'user' and prev_ai:
            c_low = _ai_norm_text(content)
            if _is_user_reject(content) or any(w in c_low for w in (u'nie', u'no', u'zly', u'bledny', u'inny', u'nie ten', u'nie ta', u'nie to')):
                for title in _ai_extract_rejected_titles_from_text(content):
                    _ai_add_rejected_title(rejected, title)
                for title in _ai_extract_rejected_titles_from_text(prev_ai):
                    _ai_add_rejected_title(rejected, title)
            prev_ai = ''
        elif role == 'user':
            c_low = _ai_norm_text(content)
            if _is_user_reject(content) or any(w in c_low for w in (u'nie', u'no', u'zly', u'bledny', u'inny', u'nie ten', u'nie ta', u'nie to')):
                for title in _ai_extract_rejected_titles_from_text(content):
                    _ai_add_rejected_title(rejected, title)
    return rejected[:10]


def _ai_has_rejection(history):
    return bool(_ai_collect_rejected_titles(history))


def _ai_title_matches_rejected(title, history):
    title_folded = _ai_fold_text(title or '')
    if not title_folded:
        return False
    for rejected in _ai_collect_rejected_titles(history or []):
        rejected_folded = _ai_fold_text(rejected or '')
        if not rejected_folded:
            continue
        if title_folded == rejected_folded or title_folded in rejected_folded or rejected_folded in title_folded:
            return True
    return False


def _ai_research_cache_fingerprint(history):
    user_text = u' '.join((_chat_user_text(history or []) or '').split()).strip()
    user_text = _ai_text_without_actor_examples(user_text)
    rejected = u' | '.join(_ai_collect_rejected_titles(history or []))
    raw = u'{} | turns={} | rejected={}'.format(user_text[-900:], _ai_user_turn_count(history or []), rejected)
    folded = _ai_fold_text(raw)
    folded = re.sub(r'\s+', ' ', folded).strip()
    return folded[-900:]


def _ai_should_force_deep_search(history):
    # Po kilku turach albo po odrzuceniu tropu model nie ma dalej „pogadywać” — ma zrobić ranking z mocniejszego researchu.
    latest = _ai_norm_text(_ai_latest_user_text(history or []))
    wants_deep = any(w in latest for w in (
        u'szukaj mocniej', u'szukaj glebiej', u'poszukaj mocniej',
        u'poszukaj glebiej', u'sprawdz mocniej', u'jeszcze raz',
    ))
    return wants_deep or _ai_user_turn_count(history) >= 3 or _ai_has_rejection(history)


def _ai_strong_search_from_first_turn(history):
    # ZMIANA (2026-04) [PATCH]: mocne wyszukiwanie od pierwszej wiadomosci dla wszystkich providerow.
    # POWOD: providery bez natywnego web-search bez web-search zbyt dlugo dopytywaly; lepiej od razu prosic o ranking kandydatow.
    # NIE ZMIENIAC: to wzmacnia pierwszy prompt, ale nie wymusza automatycznego drugiego wywolania API.
    return _ai_user_turn_count(history or []) >= 1


def _ai_question_hits_known_unknown(ai_data, history):
    ai_data = ai_data or {}
    q = _ai_norm_text(u' '.join([
        str(ai_data.get('assistant_message') or ''),
        str(ai_data.get('next_question') or ''),
    ]))
    if _ai_user_said_unknown_actor(history) and any(w in q for w in (u'aktor', u'aktora', u'rola', u'glowna', u'obsada')):
        return True
    if _ai_user_said_unknown_year(history) and any(w in q for w in (u'rok', u'roku', u'lata')):
        return True
    return False


def _ai_needs_deep_retry(ai_data, history):
    # Drugi strzał AI tylko przy konkretnych objawach: pytanie o coś już wykluczonego albo zbyt długi dialog bez pewnego tytułu.
    title = _best_title_from_ai(ai_data)
    confidence = _ai_to_int((ai_data or {}).get('confidence'))
    if _ai_message_is_wait_only(ai_data):
        return True
    if _ai_question_hits_known_unknown(ai_data, history):
        return True
    if _ai_strong_search_from_first_turn(history) and not title and confidence <= 70:
        return True
    if _ai_should_force_deep_search(history) and not title and confidence < 85:
        return True
    return False


def _ai_message_is_wait_only(ai_data):
    ai_data = ai_data or {}
    title = _best_title_from_ai(ai_data)
    confidence = _ai_to_int(ai_data.get('confidence'))
    candidates = ai_data.get('candidates') or []
    if title or candidates or confidence >= 50:
        return False
    msg = _ai_norm_text(u' '.join([
        str(ai_data.get('assistant_message') or ''),
        str(ai_data.get('next_question') or ''),
    ]))
    if not msg:
        return False
    wait_words = (
        u'czekaj', u'czekac', u'poczekaj', u'chwile', u'chwileczke', u'momencik',
        u'szukam teraz', u'poszukam', u'sprawdzam', u'zaraz sprawdze',
        u'prosze chwile', u'prosze czekac', u'wroce z wynikiem',
    )
    actionable_words = (
        u'?', u'podaj', u'dopisz', u'napisz', u'czy to', u'wybierz',
        u'ktory', u'jaki', u'jaka', u'jesli', u'jezeli',
    )
    return any(w in msg for w in wait_words) and not any(w in msg for w in actionable_words)


def _chat_ai_message(ai_data):
    # ZMIANA (2026-04) [PATCH]: fallback z candidates gdy assistant_message to sam naglowek.
    # POWOD: AI zwracalo "Oto lista filmow:" bez filmow — lista byla tylko w candidates.
    # NIE ZMIENIAC: fallback nie nadpisuje pelnej listy, tylko uzupelnia pusty naglowek.
    ai_data    = ai_data or {}
    message    = str(ai_data.get('assistant_message') or '').strip()
    question   = str(ai_data.get('next_question') or '').strip()
    title      = _best_title_from_ai(ai_data)
    display_title = _display_title_from_ai(ai_data)
    confidence = _ai_to_int(ai_data.get('confidence'))
    candidates = ai_data.get('candidates') or []

    def _has_numbered_candidate_list(text):
        return bool(re.search(r'(?m)(?:^|\n)\s*\d{1,2}[\.\)]\s+\S.{2,}', text or ''))

    def _message_promises_list(text):
        folded = _ai_fold_text(text or '')
        promised = (
            u'oto kilka', u'kilka tytul', u'kilka kandydat', u'mam kilka',
            u'znalazlem kilka', u'wybralem kilka', u'ponizej kilka',
            u'te tytuly', u'tych tytulow', u'lista kandydat',
        )
        return any(p in folded for p in promised)

    def _candidate_line(item, index):
        t = _display_title_from_ai(item) or item.get('pl_title') or item.get('title') or item.get('original_title') or ''
        yr = str(item.get('year') or '').strip()
        clue = (
            item.get('reason') or item.get('why') or item.get('match_reason') or
            item.get('overview') or item.get('description') or ''
        )
        if not clue:
            matched = _ai_list_field(item.get('matched_rare_clues'))
            if matched:
                clue = '; '.join(matched[:2])
        clue = u' '.join(str(clue or '').split())[:110]
        ln = u'{}. {}'.format(index, t)
        if yr and not re.search(r'\(\d{4}\)$', t):
            ln += u' ({})'.format(yr)
        if clue:
            ln += u' - ' + clue
        return ln

    if _ai_message_is_wait_only(ai_data):
        message = u'Nie mam jeszcze pewnego tytulu. Dopisz jeden konkretny szczegol: aktora, scene, cytat albo przyblizony rok.'
        question = u''
    if title and _ai_ready_to_confirm(ai_data):
        message = u'To wyglada na: {}'.format(display_title or title)
        candidates = []

    # Fallback: jesli AI zwraca candidates bez prawdziwej listy "1. Tytul", dopisz liste w kodzie.
    # POWOD: sama cyfra w tekscie (np. "lata 40/50") nie oznacza, ze lista kandydatow zostala pokazana.
    if candidates and (not message or not _has_numbered_candidate_list(message) or _message_promises_list(message)):
        built = []
        for i, c in enumerate(candidates[:15], 1):
            t  = _display_title_from_ai(c) or c.get('pl_title') or c.get('title') or c.get('original_title') or ''
            yr = c.get('year') or ''
            ds = str(c.get('overview') or c.get('description') or c.get('reason') or c.get('why') or c.get('match_reason') or '')[:110]
            ln = u'{}. {}'.format(i, t)
            if yr and not re.search(r'\(\d{4}\)$', t): ln += u' ({})'.format(yr)
            if ds: ln += u' — ' + ds
            built.append(ln)
        if built:
            prefix = (message or u'Mam takie kandydaty').rstrip(':').strip()
            if _message_promises_list(prefix):
                prefix = u'Mam takie kandydaty'
            message = prefix + u':\n' + u'\n'.join(built)

    if (not candidates) and (not title) and message and _message_promises_list(message) and not _has_numbered_candidate_list(message):
        message = u'Nie mam jeszcze konkretnych tytulow do pokazania. Ten opis nadal nie ma potwierdzonego kandydata w wynikach, wiec potrzebuje jeszcze jednego szczegolu sceny albo aktora.'

    parts = []
    if message:
        parts.append(message)
    if display_title or title:
        label = u'Mam mocny trop' if confidence >= _AI_CHAT_CONFIRM_CONFIDENCE else u'Moj trop'
        parts.append(u'{}: {} (pewnosc {}%)'.format(label, display_title or title, confidence))
    if question and question.strip() not in message:
        parts.append(question)
    return u'\n'.join(parts).strip() or u'Dopisz prosze jeszcze jeden szczegol, ktory pamietasz.'


def _web_search_films(query_text):
    # ZMIANA (2026-04) [PATCH]: Wikipedia Search API — dziala bez klucza dla wszystkich providerow.
    # POWOD: Wikipedia API jest otwarte i ma polskie opisy filmow.
    # NIE ZMIENIAC: blad sieci zwraca '' — fallback na TMDB.
    import requests as _req
    import re as _re
    try:
        from urllib.parse import quote as _q
    except ImportError:
        from urllib import quote as _q

    results = []
    headers = _legal_research_headers()
    q = query_text[:80].strip()
    if not q:
        return ''

    # Wikipedia PL — streszczenia artykulow po polsku
    try:
        r = _req.get(
            'https://pl.wikipedia.org/w/api.php',
            params={'action':'query','list':'search','srsearch':q,
                    'srnamespace':0,'srlimit':6,'utf8':1,'format':'json'},
            timeout=8, headers=headers)
        items = r.json().get('query',{}).get('search',[])
        fetch_titles = [i['title'] for i in items if i.get('title')][:4]
        if fetch_titles:
            r2 = _req.get(
                'https://pl.wikipedia.org/w/api.php',
                params={'action':'query','prop':'extracts','exintro':1,
                        'exsentences':3,'explaintext':1,
                        'titles':'|'.join(fetch_titles),'format':'json','utf8':1},
                timeout=8, headers=headers)
            for page in r2.json().get('query',{}).get('pages',{}).values():
                title   = page.get('title','')
                extract = (page.get('extract') or '').strip()[:200]
                if title and extract:
                    results.append(u'[Wikipedia PL] {} — {}'.format(title, extract))
    except Exception as exc:
        log('[AI_SEARCH] Wikipedia PL ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)

    # Wikipedia EN — wiecej filmow po angielsku
    try:
        r = _req.get(
            'https://en.wikipedia.org/w/api.php',
            params={'action':'query','list':'search','srsearch':'film '+q,
                    'srnamespace':0,'srlimit':5,'utf8':1,'format':'json'},
            timeout=8, headers=headers)
        for item in r.json().get('query',{}).get('search',[])[:4]:
            title   = item.get('title','')
            snippet = _re.sub(r'<[^>]+>','', item.get('snippet','')).strip()[:150]
            if title and snippet:
                results.append(u'[Wikipedia EN] {} — {}'.format(title, snippet))
    except Exception as exc:
        log('[AI_SEARCH] Wikipedia EN ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)

    if results:
        log('[AI_SEARCH] Wikipedia: {} wynikow dla {!r}'.format(len(results), q[:40]), 1)
    return u'\n'.join(results[:10])


def _extract_clues(all_user_text):
    """
    ZMIANA (2026-04) [PATCH v2]: wyciaga clues bezposrednio ze slow uzytkownika.
    Wyrzucono PHRASE_MAP — bez gotowych przykladow i recznych podpowiedzi.
    Teraz: pelny opis jako jedno zapytanie + osobno kazde slowo dluzsze niz 3 litery.
    NIE ZMIENIAC: zwraca liste stringow; pusta lista = brak danych.
    """
    import re as _re
    text = all_user_text.strip()
    text_lower = text.lower()

    clues = []
    seen = set()

    # 1. Pelny opis uzytkownika jako pierwsze zapytanie (najwazniejsze)
    full = u' '.join(text_lower.split())
    if len(full) > 4:
        clues.append(full + u' film')
        seen.add(full)

    # 2. Imiona/nazwiska jesli sa w tekscie (wielka litera)
    names = _re.findall(r'[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?', text)
    for name in names[:2]:
        key = name.lower()
        if key not in seen:
            clues.append(name + u' film')
            seen.add(key)

    # 3. Kazde unikalne slowo dluzsze niz 3 litery jako osobne zapytanie
    STOP = {u'film', u'seria', u'przez', u'sobie', u'tego', u'jest', u'byla',
            u'tego', u'jako', u'ktory', u'ktora', u'moze', u'byly', u'jego',
            u'oraz', u'albo', u'gdzie', u'kiedy', u'jesli', u'tylko', u'roku',
            u'stary', u'nowy', u'duzy', u'maly', u'dobry', u'zlym', u'taki'}
    words = [w for w in _re.split(r'\W+', text_lower) if len(w) > 3 and w not in STOP]
    for w in words[:6]:
        if w not in seen:
            clues.append(w + u' film')
            seen.add(w)

    return clues[:6]  # max 6 zapytan


def _web_search_multi(clues):
    """
    ZMIANA (2026-04) [NOWA FUNKCJA]: osobne zapytanie Wikipedia dla kazdej wskazowki.
    POWOD: Wikipedia uzywa keyword matching — krotkie frazy z opisu bywaja skuteczniejsze niz jedno zbiorowe query.
    NIE ZMIENIAC: blad sieci dla jednego clue jest ignorowany — pozostale sa uzywane.
    """
    import requests as _req
    try:
        from urllib.parse import quote as _q
    except ImportError:
        from urllib import quote as _q
    import re as _re

    headers = _legal_research_headers()
    all_results = []
    seen_titles = set()

    for idx, clue in enumerate(clues or []):
        for wiki_url, wiki_tag in [
            (u'https://pl.wikipedia.org/w/api.php', u'PL'),
            (u'https://en.wikipedia.org/w/api.php', u'EN'),
        ]:
            if wiki_tag == u'EN' and idx > 2:
                continue
            try:
                r = _req.get(
                    wiki_url,
                    params={u'action': u'query', u'list': u'search',
                            u'srsearch': clue, u'srnamespace': 0,
                            u'srlimit': 4, u'utf8': 1, u'format': u'json'},
                    timeout=6, headers=headers)
                items = r.json().get(u'query', {}).get(u'search', [])
                fetch_titles = [i[u'title'] for i in items
                               if i.get(u'title') and i[u'title'] not in seen_titles][:3]
                if not fetch_titles:
                    continue
                r2 = _req.get(
                    wiki_url,
                    params={u'action': u'query', u'prop': u'extracts',
                            u'exintro': 1, u'exsentences': 2, u'explaintext': 1,
                            u'titles': u'|'.join(fetch_titles),
                            u'format': u'json', u'utf8': 1},
                    timeout=6, headers=headers)
                for page in r2.json().get(u'query', {}).get(u'pages', {}).values():
                    title   = page.get(u'title', u'')
                    extract = (page.get(u'extract') or u'').strip()[:180]
                    if title and extract and title not in seen_titles:
                        seen_titles.add(title)
                        all_results.append(u'[Wiki{} {}] {}'.format(
                            wiki_tag, clue, title + u' \u2014 ' + extract))
            except Exception as exc:
                log(u'[AI_SEARCH] wiki{} clue {!r} ERROR: {}'.format(
                    wiki_tag, clue, _safe_exception_text(exc, 120)), 1)

    log(u'[AI_SEARCH] web_search_multi: {} wynikow dla {} clues'.format(
        len(all_results), len(clues or [])), 1)
    return u'\n'.join(all_results[:12])


# ZMIANA (2026-04) [PATCH]: wspolna warstwa legalnego kontekstu dla providerow AI.
# POWOD: ta warstwa robi zapytania przez oficjalne API/search tools i dokleja wyniki do promptu providera.
# NIE ZMIENIAC: funkcje musza zwracac pusty tekst przy bledzie sieci - AI ma wtedy dzialac starym trybem, bez crasha Kodi.
def _ai_clean_api_text(value):
    # ZMIANA (2026-04) [PATCH]: neutralne czyszczenie opisow zwracanych przez API.
    # POWOD: Google CSE/TVMaze czasem zwracaja tagi lub encje w polu snippet/summary; nie pobieramy zadnych stron.
    import re as _re
    text = value or ''
    text = _re.sub(r'(?is)<script[^>]*>.*?</script>', ' ', text)
    text = _re.sub(r'(?is)<style[^>]*>.*?</style>', ' ', text)
    text = _re.sub(r'(?is)<[^>]+>', ' ', text)
    replacements = {
        '&nbsp;': ' ', '&#160;': ' ', '&amp;': '&', '&quot;': '"',
        '&#34;': '"', '&#39;': "'", '&apos;': "'", '&lt;': '<', '&gt;': '>',
    }
    for src, dst in replacements.items():
        text = text.replace(src, dst)
    return _re.sub(r'\s+', ' ', text).strip()


def _ai_fold_text(value):
    # ZMIANA (2026-04) [FEATURE]: normalizacja tekstu do szukania tropow.
    # POWOD: uzytkownik pisze z polskimi znakami albo bez; wyszukiwarka ma widziec oba przypadki tak samo.
    try:
        import unicodedata as _unicodedata
        text = _unicodedata.normalize('NFKD', value or '')
        text = ''.join([c for c in text if not _unicodedata.combining(c)])
    except Exception:
        text = value or ''
    # NFKD nie rozklada polskiego "ł", a bez tego "grał" nie pasuje do reguly "gral np. w ...".
    for src, dst in ((u'ł', u'l'), (u'Ł', u'L'), (u'ß', u'ss'), (u'ø', u'o'), (u'Ø', u'O')):
        text = text.replace(src, dst)
    return text.lower()


def _translate_common_movie_clues(text):
    # Bez recznych slownikow/podpowiedzi. Tlumaczenie robi provider w query plannerze.
    return ''


def _ai_research_hypotheses_from_text(text):
    # Bez recznych hipotez. Model ma sam zbudowac kierunki z rozmowy i web contextu.
    return []


def _ai_query_terms_from_text(text, limit=10):
    folded = _ai_fold_text(_ai_text_without_actor_examples(text or ''))
    stop = set([
        'film', 'filmu', 'filmie', 'serial', 'serialu', 'movie', 'series',
        'tytul', 'tytulu', 'szukam', 'pamietam', 'chyba', 'jakis', 'jaki',
        'jaka', 'ktory', 'ktora', 'gdzie', 'kiedy', 'byla', 'bylo', 'jest',
        'tam', 'ten', 'tego', 'taki', 'taka', 'oraz', 'albo', 'jego', 'jej',
        'aktor', 'aktora', 'aktorem', 'aktorka', 'znany', 'znana',
        'innego', 'innym', 'przyklad', 'przykladowy',
        'bardzo', 'stary', 'stara', 'stare', 'lata', 'roku', 'moze', 'nim',
        'scena', 'scenie', 'sceny', 'scen', 'smieszny', 'komediowy',
        'francuski', 'polski', 'amerykanski', 'angielski', 'brytyjski',
        'niemiecki', 'wloski', 'hiszpanski', 'komedia', 'horror', 'dramat',
        'thriller', 'wystepowal', 'wystepowala', 'gral', 'grala',
    ])
    terms = []
    for token in re.split(r'[^a-z0-9]+', folded):
        token = token.strip()
        if len(token) < 4 or token.isdigit() or token in stop:
            continue
        if token not in terms:
            terms.append(token)
        if len(terms) >= limit:
            break
    return terms


def _ai_polish_precision_queries(text):
    # ZMIANA (2026-04) [PATCH]: pierwsza runda search ma zaczynac od krotkich polskich fraz.
    # POWOD: publiczne polskie snippety czesto lapia rzadkie tropy lepiej niz dlugie/angielskie query.
    terms = _ai_query_terms_from_text(text or '', limit=10)
    if not terms:
        return []

    queries = []
    seen_queries = set()

    def _add_query(q):
        q = u' '.join((q or '').split()).strip()
        key = _ai_fold_text(q)
        if q and key not in seen_queries:
            seen_queries.add(key)
            queries.append(q)

    core = terms[:6]
    _add_query(u' '.join(core[:6] + [u'film']))
    if len(core) >= 3:
        _add_query(u' '.join(core[:3] + [u'film']))
    if len(core) >= 4:
        _add_query(u' '.join(core[2:6] + [u'film']))
    _add_query(u'site:filmweb.pl/film ' + u' '.join(core[:5]))
    _add_query(u'site:telemagazyn.pl ' + u' '.join(core[:5]))

    return queries[:6]


def _ai_search_result_score(item, user_text):
    # ZMIANA (2026-04) [PATCH]: wyniki z wieloma rzadkimi tropami ida wyzej w kontekscie.
    # POWOD: provider ma najpierw widziec snippety podobne do realnego opisu, nie tylko pierwsze z API.
    folded_user = _ai_fold_text(user_text or '')
    hay = _ai_fold_text(u' '.join([
        item.get('title') or '',
        item.get('snippet') or '',
        item.get('url') or '',
    ]))
    if not folded_user or not hay:
        return 0

    score = 0
    for term in _ai_query_terms_from_text(user_text or '', limit=12):
        if term in hay:
            score += 3

    stop = set([
        'film', 'filmu', 'serial', 'serialu', 'stary', 'stara', 'znany',
        'znanym', 'aktor', 'aktorem', 'jest', 'ktory', 'ktora', 'gdzie',
        'jakis', 'jaki', 'chyba', 'pamietam', 'szukam', 'tytul',
    ])
    for word in re.split(r'[^a-z0-9]+', folded_user):
        if len(word) >= 5 and word not in stop and word in hay:
            score += 1
    return score


def _build_reasoning_hypothesis_note(history):
    # Bez recznych hipotez/podpowiedzi. Rozumowanie robi sam provider na podstawie rozmowy i web/API contextu.
    return ''


def _ai_signal_old_fantasy_dwarf_actor(history):
    # ZMIANA (2026-05) [FEATURE]: wykrywa potoczny trop „stare fantasy + aktor z karłowatością”.
    # POWOD: log pokazał, że AI błędnie zamieniało „aktor był karzełkiem/chorował” na fabułę o chorym karle i promowało Leprechaun.
    # NIE ZMIENIAC: to tylko detektor zapytań i kandydatów-seed; nie pobiera HTML, nie omija web/API i nie potwierdza automatycznie filmu.
    text = _ai_fold_text(_chat_user_text(history or []))
    if not text:
        return False
    if _detect_user_media_type_hint_from_text(text) == 'tv':
        return False
    fantasy = any(w in text for w in (
        'fantasy', 'fantazy', 'fantast', 'fantastyka', 'fantastyczny', 'basn', 'bajk', 'magia'
    ))
    actor = any(w in text for w in (
        'aktor', 'aktorem', 'aktorka', 'gral', 'grala', 'wystepowal', 'wystepowala'
    ))
    dwarf = any(w in text for w in (
        'karzel', 'karzelek', 'karlem', 'karlowatosc', 'karlowaty',
        'niskiego wzrostu', 'niski wzrost', 'dwarf', 'little person', 'short actor'
    ))
    old_or_memory = any(w in text for w in (
        'stary', 'stare', 'dawny', 'dawne', 'z dziecinstwa', 'lata 80', 'lata 90', 'vhs'
    ))
    illness_words = any(w in text for w in ('chorowal', 'choroba', 'chory', 'schorzenie'))
    horror_words = any(w in text for w in (
        'horror', 'straszny', 'zabijal', 'zabija', 'mordowal', 'morderca', 'leprechaun', 'skrzat'
    ))
    return bool(fantasy and dwarf and (actor or old_or_memory or illness_words) and not horror_words)


def _ai_chatgpt_seed_queries_from_history(history):
    # ZMIANA (2026-05) [FEATURE]: dokładane zapytania „jak ChatGPT” dla krótkich, potocznych opisów.
    # POWOD: samo tłumaczenie na „sick dwarf” kierowało OpenAI w stronę horroru; trzeba dodać wariant „actor with dwarfism / little person actor”.
    # NIE ZMIENIAC: zapytania są tylko do oficjalnych web/API search; funkcja nie pobiera ani nie parsuje stron.
    if not _ai_signal_old_fantasy_dwarf_actor(history):
        return []
    return [
        u'old fantasy film actor with dwarfism',
        u'1980s fantasy movie little person actor',
        u'old fantasy film dwarf actor',
        u'Warwick Davis Willow 1988 fantasy actor dwarfism',
        u'Willow 1988 Warwick Davis fantasy film',
        u'stary film fantasy aktor niskiego wzrostu Warwick Davis',
    ]


def _ai_chatgpt_seed_context_from_history(history):
    # ZMIANA (2026-05) [FEATURE]: lokalny seed kandydatów do porównania, bez scrapowania.
    # POWOD: ChatGPT często trafia po skojarzeniu aktor→Warwick Davis→Willow; wtyczka ma dostać taki sam trop, ale nadal traktować go jako kandydat do weryfikacji.
    # NIE ZMIENIAC: opis „seed” nie jest dowodem; finalny AI nadal ma porównać go z web/TMDB i pokazać ranking, nie wymuszać wyniku.
    if not _ai_signal_old_fantasy_dwarf_actor(history):
        return ''
    return (
        u'[LOCAL_CANDIDATE_HINTS - do sprawdzenia, NIE jako dowod]\n'
        u'- Willow / Willow (1988) — stary film fantasy; główny aktor Warwick Davis, aktor niskiego wzrostu/karłowatość; motyw misji i dziecka/księżniczki.\n'
        u'- Time Bandits / Bandyci czasu (1981) — stare fantasy/przygoda z obsadą aktorów niskiego wzrostu; kandydat zapasowy, gdy użytkownik pamięta grupę postaci.\n'
        u'- Labyrinth / Labirynt (1986) — stare fantasy z wieloma postaciami niskiego wzrostu; kandydat słabszy, jeśli trop aktora nie jest główną rolą.\n'
        u'Instrukcja: jeśli opis brzmi „aktor chorował/był karzełkiem”, interpretuj to jako możliwą karłowatość/niskorosłość aktora, niekoniecznie chorobę postaci w fabule.'
    )


def _ai_chatgpt_seed_candidates_from_history(history):
    # ZMIANA (2026-05) [FEATURE]: fallback listy propozycji, gdy provider po odrzuceniu zostawia użytkownika bez kandydatów.
    # POWOD: w logu po odrzuceniu Leprechaun filtr wyczyścił wiadomość i LIVE_CHAT miał title='' oraz brak sensownych nowych propozycji.
    # NIE ZMIENIAC: kandydaci są tylko widoczną listą do wyboru; TAK/numerek nadal przechodzi przez istniejący flow potwierdzenia/TMDB.
    if not _ai_signal_old_fantasy_dwarf_actor(history):
        return []
    raw = [
        {'title': 'Willow', 'pl_title': 'Willow', 'english_title': 'Willow', 'original_title': 'Willow', 'year': '1988', 'type': 'movie', 'confidence': 86,
         'reason': u'Najmocniejszy trop: stare fantasy + Warwick Davis, aktor niskiego wzrostu/karłowatość.',
         'matched_rare_clues': [u'AKTOR: niskiego wzrostu/karłowatość', u'GATUNEK: stare fantasy']},
        {'title': 'Time Bandits', 'pl_title': 'Bandyci czasu', 'english_title': 'Time Bandits', 'original_title': 'Time Bandits', 'year': '1981', 'type': 'movie', 'confidence': 66,
         'reason': u'Słabszy trop zapasowy: stare fantasy/przygoda z aktorami niskiego wzrostu.',
         'matched_rare_clues': [u'AKTORZY: niskiego wzrostu', u'GATUNEK: stare fantasy/przygoda']},
        {'title': 'Labyrinth', 'pl_title': 'Labirynt', 'english_title': 'Labyrinth', 'original_title': 'Labyrinth', 'year': '1986', 'type': 'movie', 'confidence': 56,
         'reason': u'Kandydat rezerwowy: stare fantasy z wieloma małymi postaciami, ale mniej pasuje do głównego aktora.',
         'matched_rare_clues': [u'GATUNEK: stare fantasy', u'POSTACIE: małe postacie fantasy']},
    ]
    out = []
    for item in raw:
        label = _display_title_from_ai(item) or item.get('title') or ''
        if label and _ai_title_matches_rejected(label, history or []):
            continue
        out.append(item)
    return out


def _ai_merge_chatgpt_seed_candidates(ai_data, history):
    # ZMIANA (2026-05) [PATCH]: połącz wynik providera z lokalnymi seedami ChatGPT-style.
    # POWOD: gdy OpenAI wybierze fałszywy trop Leprechaun albo po odrzuceniu nie pokaże listy, użytkownik ma dostać ranking alternatyw jak w rozmowie z ChatGPT.
    # NIE ZMIENIAC: nie kasować legalnych kandydatów providera; seed tylko uzupełnia/porządkuje listę i nie dodaje żadnego scrapowania.
    seeds = _ai_chatgpt_seed_candidates_from_history(history or [])
    if not seeds or not isinstance(ai_data, dict):
        return ai_data
    data = dict(ai_data or {})
    current_title = _display_title_from_ai(data) or _best_title_from_ai(data)
    current_fold = _ai_fold_text(current_title or '')
    current_candidates = [c for c in (data.get('candidates') or []) if isinstance(c, dict)]
    false_dwarf_horror = ('leprechaun' in current_fold or current_fold.strip() in ('karzel', 'karzel 1'))
    if false_dwarf_horror:
        for key in ('title', 'search_query', 'confirmation_title', 'pl_title', 'english_title', 'original_title'):
            data[key] = ''
        data['ready_to_confirm'] = False
        data['confidence'] = min(_ai_to_int(data.get('confidence')), 55)
        data['assistant_message'] = u'Ten trop wygląda na horror „Leprechaun”, ale opis bardziej brzmi jak stare fantasy z aktorem niskiego wzrostu. Sprawdź te propozycje:'
        current_candidates = []
        log('[AI_SEARCH] local seed blocked false dwarf-horror title={!r}'.format(current_title), 1)
    seen = set()
    merged = []
    for item in seeds + current_candidates:
        title = _display_title_from_ai(item) or _ai_candidate_title_text(item) or _best_title_from_ai(item)
        if not title or _ai_title_matches_rejected(title, history or []):
            continue
        key = _ai_fold_text(title)
        if key in seen:
            continue
        seen.add(key)
        merged.append(item)
    if merged and (false_dwarf_horror or not current_title or not current_candidates):
        data['candidates'] = merged[:5]
        data['ready_to_confirm'] = False
        data['confidence'] = max(_ai_to_int(data.get('confidence')), _ai_to_int(merged[0].get('confidence')))
        if not data.get('assistant_message') or _ai_message_is_wait_only(data):
            data['assistant_message'] = u'Mam takie kandydaty po analizie tropow:'
        log('[AI_SEARCH] local seed candidates added: {}'.format(
            ' | '.join([_display_title_from_ai(c) or _best_title_from_ai(c) for c in merged[:3]])[:240]), 1)
    return data


def _ai_parse_planner_queries(raw):
    raw = (raw or '').strip()
    if not raw:
        return []
    raw = re.sub(r'```(?:json)?', '', raw, flags=re.I).replace('```', '').strip()
    candidates = [raw]
    if '[' in raw and ']' in raw:
        candidates.insert(0, raw[raw.find('['):raw.rfind(']') + 1])
    for candidate in candidates:
        try:
            data = json.loads(candidate)
        except Exception:
            continue
        if isinstance(data, dict):
            ordered = []
            for key in (
                    'original_language', 'original', 'native_language', 'country_language',
                    'english', 'en', 'polish', 'pl', 'broader', 'queries', 'search_queries'):
                value = data.get(key)
                if isinstance(value, list):
                    ordered.extend(value)
                elif isinstance(value, str) and value.strip():
                    ordered.append(value)
            data = ordered
        if not isinstance(data, list):
            continue
        out = []
        seen = set()
        for item in data:
            if isinstance(item, dict):
                item = item.get('query') or item.get('q') or item.get('text') or ''
            q = u' '.join(str(item or '').split()).strip(' "\'.,;')
            q = re.sub(r'^\d+[\.\)]\s*', '', q).strip()
            key = q.lower()
            if 6 <= len(q) <= 140 and key not in seen:
                seen.add(key)
                out.append(q)
            if len(out) >= 8:
                break
        if out:
            return out
    return []


# ZMIANA (2026-05) [FEATURE]: Detekcja "starego filmu" po stronie Pythona — niezalezna od modelu AI.
# POWOD: mini modele (gpt-4o-mini) ignoruja wielopoziomowe reguly w promptach .txt i nie generuja zapytan
#   po francusku/wlosku dla starych filmow europejskich. Detekcja w Pythonie jest niezawodna niezaleznie od modelu.
# ZMIANA (2026-05) [PATCH]: hint dla query_planner — wykrywa stary film i wskazuje jezyki wyszukiwania.
# POWOD: query_planner ma wlasny hardcoded prompt (bez pliku .txt); bez hintu pomija jezyki europejskie.
# NIE ZMIENIAC: funkcja zwraca (poziom, hint_en); poziom 3 = FR+IT+DE+ES+RU, poziom 2 = FR+IT, poziom 1 = brak.
def _detect_old_film_level(user_text):
    import re as _re
    text_low = (user_text or '').lower()
    LEVEL3 = [
        'stary', 'stara', 'stare', 'dawny', 'dawna', 'dawne',
        'klasyk', 'klasyczny', 'klasyczna', 'klasyczne',
        'z dziecinstwa', u'z dzieciństwa',
        'lata 60', 'lata 70', 'lata 80', 'lata 90',
        'lata szescdziesiatych', u'lata sześćdziesiątych',
        'lata siedemdziesiatych', u'lata siedemdziesiątych',
        'lata osiemdziesiatych', u'lata osiemdziesiątych',
        'lata dziewiecdziesiatych', u'lata dziewięćdziesiątych',
    ]
    LEVEL2 = [
        'kaseta', 'vhs', 'pager', 'western', 'giallo', 'noir',
        u'czarno-biały', 'czarno-bialy', u'czarno biały', 'czarno bialy',
        'niemy',
    ]
    year_old = bool(_re.search(r'\b19[0-9]{2}\b', text_low))
    decade_old = bool(_re.search(r'\blata\s*[678]0', text_low))
    if year_old or decade_old or any(kw in text_low for kw in LEVEL3):
        return 3, (
            u'LEVEL 3 — OLD FILM: This is likely a pre-2000 European film (French, Italian, German, Spanish or Russian). '
            u'original_language MUST contain queries in French AND Italian AND German — translate the scene/plot clue into each language. '
            u'Do not fill original_language with Polish or English.\n'
        )
    if any(kw in text_low for kw in LEVEL2):
        return 2, (
            u'LEVEL 2 — POSSIBLY EUROPEAN: This may be an older European film. '
            u'Add French and Italian queries to original_language (translate the scene/plot clue, not just the genre).\n'
        )
    return 1, u''


def _ai_dynamic_search_queries_from_history(history):
    # ZMIANA (2026-04) [FEATURE]: AI samo planuje zapytania po opisie, zamiast dopisywac kolejne reczne slowa-klucze.
    # POWOD: ma dzialac blizej Codex/ChatGPT: poprawia literowki i tlumaczy sens opisu na zapytania w czasie rzeczywistym.
    user_text = u' '.join((_chat_user_text(history or []) or '').split()).strip()
    user_text = _ai_text_without_actor_examples(user_text)
    if len(user_text) < 8:
        return []
    try:
        provider = _normalize_ai_provider(control.setting('ai_search.provider'), log_change=True)
        api_key = (control.setting('ai_search.key.' + provider.lower()) or '').strip()
    except Exception:
        provider, api_key = '', ''
    if not provider or not api_key:
        return []

    model_cache = _gemini_model_choice() if provider == 'Gemini' else provider
    cache_key = 'query_planner_v5_structured_multilang|{}|{}|{}'.format(
        provider, model_cache, _ai_research_cache_fingerprint(history or [])[:700])
    cached = _ai_cache_get(cache_key)
    if cached is not None:
        return cached or []

    # ZMIANA (2026-05) [PATCH]: wstrzyknij hint jezykowy dla starych filmow do query_planner.
    # POWOD: query_planner uzywa hardcoded prompt (bez pliku .txt) — bez hintu pomija jezyki europejskie.
    # NIE ZMIENIAC: description_analyzer nie potrzebuje hintu (gpt-4o czyta .txt z POZIOM 1/2/3).
    _, _old_film_hint = _detect_old_film_level(user_text)
    prompt = (
        u'Generate search-engine queries to identify a movie or TV series from this rough Polish user description. '
        u'First understand the sentence: separate the target movie description from actor examples, side comments and memory uncertainty. '
        u'Correct typos mentally, infer the meaning, and keep rare plot/scene clues as the first priority. '
        u'Return multilingual search variants in separate JSON fields: original_language, english, polish, broader. '
        u'If the description implies a country/language, original_language MUST contain 2 short queries written in that likely original language, not in Polish. '
        u'English MUST contain 2 short English queries. Polish may contain 1-2 Polish queries. '
        u'Every original_language and English query must translate the scene/plot meaning, not only the genre/country. '
        u'If all queries are in Polish, the answer is invalid. '
        u'Use synonym variants for rare relations, not only literal translation, but only when those meanings are present in the user description. '
        u'If the user says an actor played "for example" in another title, treat that title only as an actor clue, never as the target movie title; do not use that example title as a main movie-search query. '
        u'Do NOT answer with a title and do NOT invent facts. Return ONLY JSON like: '
        u'{"original_language":["...","..."],"english":["...","..."],"polish":["..."],"broader":["..."]}.\n'
        + _old_film_hint
        + _ai_codex_reasoning_contract(history or [])
        + _ai_actor_example_note(history or []) +
        u'Opis: ' + user_text[:900]
    )

    try:
        import requests as _req
        raw = ''
        if provider == 'OpenAI':
            model = _openai_model_choice()[0]
            r = _req.post(
                'https://api.openai.com/v1/responses',
                headers={'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'},
                json={'model': model, 'input': prompt, 'max_output_tokens': 320},
                timeout=18,
            )
            r.raise_for_status()
            raw = _extract_openai_response_text(r.json())
        elif provider == 'Gemini':
            r = _req.post(
                'https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent'.format(_gemini_model_choice()),
                headers={'Content-Type': 'application/json', 'x-goog-api-key': api_key},
                json={'contents': [{'parts': [{'text': prompt}]}],
                      'generationConfig': {'maxOutputTokens': 320, 'temperature': 0.0, 'responseMimeType': 'application/json'}},
                timeout=12,
            )
            r.raise_for_status()
            parts = (((r.json().get('candidates') or [{}])[0].get('content') or {}).get('parts') or [])
            raw = ''.join(p.get('text', '') for p in parts)
        elif provider == 'Claude':
            r = _req.post(
                'https://api.anthropic.com/v1/messages',
                headers={'x-api-key': api_key, 'anthropic-version': '2023-06-01', 'Content-Type': 'application/json'},
                json={'model': 'claude-sonnet-4-5-20251022', 'max_tokens': 320,
                      'system': 'Return only JSON.',
                      'messages': [{'role': 'user', 'content': prompt}]},
                timeout=12,
            )
            r.raise_for_status()
            raw = ''.join((b.get('text') or '') for b in (r.json().get('content') or []) if isinstance(b, dict))
        queries = _ai_parse_planner_queries(raw)
        if queries:
            log('[AI_SEARCH] AI query planner ({}): {}'.format(provider, ' | '.join(queries[:8])[:650]), 1)
            return _ai_cache_set(cache_key, queries)
    except Exception as exc:
        log('[AI_SEARCH] AI query planner skipped: {}'.format(_safe_exception_text(exc, 120)), 1)
    return _ai_cache_set(cache_key, [])


def _build_web_queries_from_history(history):
    text = _chat_user_text(history or [])
    text = u' '.join((text or '').split())[:220]
    text = _ai_text_without_actor_examples(text)
    if not text:
        return []
    queries = []
    seen = set()
    media_type_hint = _detect_user_media_type_hint(history=history)

    def _add(q):
        q = u' '.join((q or '').split()).strip()
        key = q.lower()
        if q and key not in seen:
            seen.add(key)
            queries.append(q)

    # ZMIANA (2026-04) [FEATURE]: zapytania w stylu Codex/ChatGPT Search.
    # POWOD: najpierw laczymy rzadkie tropy, potem pelny opis; aktora dodajemy tylko, gdy uzytkownik go podal.
    # NIE ZMIENIAC: to sa tylko publiczne zapytania do legalnych search/API, bez pobierania stron do parsowania.
    # ASCII-only: Kodi/Python moze zepsuc zakresy znakow po przekodowaniu pliku.
    for q in _ai_chatgpt_seed_queries_from_history(history or []):
        _add(q)

    names = re.findall(r'\b[A-Z][A-Za-z]{2,}(?:\s+[A-Z][A-Za-z]{2,})?\b', text)
    rare_terms = _ai_query_terms_from_text(text, limit=10)
    scene_terms = _ai_primary_scene_terms_from_history(history or [], limit=8)
    description_analysis = _ai_description_analysis_from_history(history or [])

    for q in _ai_queries_from_description_analysis(description_analysis):
        _add(q)

    if scene_terms:
        if media_type_hint == 'tv':
            _add(u' '.join(scene_terms[:6] + [u'serial']))
            _add(u' '.join(scene_terms[:6] + [u'tv series plot']))
        elif media_type_hint == 'movie':
            _add(u' '.join(scene_terms[:6] + [u'film']))
            _add(u' '.join(scene_terms[:6] + [u'movie plot']))
        else:
            _add(u' '.join(scene_terms[:6] + [u'film']))
            _add(u' '.join(scene_terms[:6] + [u'movie plot']))
            _add(u' '.join(scene_terms[:6] + [u'tv series plot']))

    for q in _ai_dynamic_search_queries_from_history(history or []):
        _add(q)

    for q in _ai_polish_precision_queries(text):
        _add(q)

    if media_type_hint != 'tv':
        _add(text + u' film')
        _add(text + u' movie plot')
    if media_type_hint != 'movie':
        _add(text + u' serial')
        _add(text + u' tv series')

    if rare_terms:
        base = u' '.join(rare_terms[:8])
        if media_type_hint != 'tv':
            _add(base + u' movie plot')
            _add(base + u' film')
        if media_type_hint != 'movie':
            _add(base + u' tv series plot')
    # ZMIANA (2026-04) [PATCH]: osobne narzedzie hipotez, a nie twarda podpowiedz pod jeden tytul.
    for name in names[:2]:
        if rare_terms:
            if media_type_hint == 'tv':
                _add(name + u' ' + u' '.join(rare_terms[:5]) + u' tv series')
            else:
                _add(name + u' ' + u' '.join(rare_terms[:5]) + u' movie')
        else:
            _add(name + (u' tv series' if media_type_hint == 'tv' else u' movie'))

    for clue in _extract_clues(text)[:3]:
        _add(clue)
    return queries[:12]


def _google_cse_search(query, limit=5):
    # ZMIANA (2026-04) [PATCH]: stabilny web-search przez Google Custom Search dla providerow bez natywnego internetu.
    # POWOD: CSE daje normalny JSON przez oficjalne API.
    # NIE ZMIENIAC: nie logujemy URL requestu ani parametrow, bo URL zawiera klucz API.
    import requests as _req

    try:
        api_key = (control.setting('google_search.api_key') or '').strip()
        cx = (control.setting('google_search.cx') or '').strip()
    except Exception:
        api_key = ''
        cx = ''
    if not api_key or not cx or not query:
        return []
    cache_key = 'google_cse|{}|{}'.format(query[:160].lower(), int(limit or 5))
    cached = _ai_cache_get(cache_key)
    if cached is not None:
        log('[AI_SEARCH] Google CSE cache hit', 1)
        return cached

    try:
        r = _req.get(
            'https://www.googleapis.com/customsearch/v1',
            params={
                'key': api_key,
                'cx': cx,
                'q': query,
                'num': max(1, min(int(limit or 5), 10)),
                'hl': 'pl',
                'safe': 'off',
            },
            timeout=10,
        )
        if r.status_code >= 400:
            log('[AI_SEARCH] Google CSE EMPTY status={}'.format(r.status_code), 1)
            return []
        items = (r.json().get('items') or [])[:limit]
        results = []
        for item in items:
            if not isinstance(item, dict):
                continue
            url = (item.get('link') or '').strip()
            title = _ai_clean_api_text(item.get('title') or '').strip()
            snippet = _ai_clean_api_text(item.get('snippet') or '').strip()
            if url.startswith('http') and title:
                results.append({
                    'title': title[:120],
                    'url': url,
                    'snippet': snippet[:260],
                    'query': query,
                    'source': 'Google CSE',
                })
        if results:
            log('[AI_SEARCH] Google CSE: {} wynikow'.format(len(results)), 1)
        return _ai_cache_set(cache_key, results)
    except Exception as exc:
        log('[AI_SEARCH] Google CSE ERROR: {}'.format(exc.__class__.__name__), 1)
        return []


def _tvmaze_context_search(history):
    # ZMIANA (2026-04) [FEATURE]: dodatkowe legalne API dla seriali bez klucza.
    # POWOD: TMDB/Wikipedia sa dobre ogolnie, ale TVMaze czesto lepiej lapie seriale, tytuly alternatywne i lata emisji.
    import requests as _req
    import re as _re

    user_text = u' '.join((_chat_user_text(history or []) or '').split()).strip()
    user_text = _ai_text_without_actor_examples(user_text)
    if len(user_text) < 3:
        return ''
    cache_key = 'tvmaze_v2|{}'.format(_ai_research_cache_fingerprint(history or [])[:700])
    cached = _ai_cache_get(cache_key)
    if cached is not None:
        log('[AI_SEARCH] TVMaze cache hit', 1)
        return cached

    queries = [user_text] + _build_web_queries_from_history(history or [])[:2]
    seen_queries = set()
    seen = set()
    lines = []
    headers = _legal_research_headers()

    for q in queries:
        q = _re.sub(r'\b(?:film|movie|serial|tv series|series|plot)\b', ' ', q, flags=_re.I)
        q = u' '.join(q.split()).strip()[:120]
        key_q = q.lower()
        if len(q) < 3 or key_q in seen_queries:
            continue
        seen_queries.add(key_q)
        try:
            r = _req.get('https://api.tvmaze.com/search/shows',
                         params={'q': q}, timeout=8, headers=headers)
            if r.status_code >= 400:
                continue
            for result in (r.json() or [])[:5]:
                show = (result or {}).get('show') or {}
                name = (show.get('name') or '').strip()
                year = str(show.get('premiered') or '')[:4]
                lang = show.get('language') or ''
                genres = ', '.join(show.get('genres') or [])
                summary = _ai_clean_api_text(show.get('summary') or '')[:220]
                dedupe = u'{}|{}'.format(name.lower(), year)
                if not name or dedupe in seen:
                    continue
                seen.add(dedupe)
                line = u'[TVMaze] {} ({})'.format(name, year or '-')
                detail = u', '.join([x for x in (lang, genres) if x])
                if detail:
                    line += u' — ' + detail
                if summary:
                    line += u' — ' + summary
                lines.append(line[:420])
                if len(lines) >= 8:
                    break
        except Exception as exc:
            log('[AI_SEARCH] TVMaze ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        if len(lines) >= 8:
            break

    if lines:
        log('[AI_SEARCH] TVMaze context: {} wynikow'.format(len(lines)), 1)
    return _ai_cache_set(cache_key, u'\n'.join(lines[:8]))


def _wikidata_context_search(history):
    # ZMIANA (2026-04) [FEATURE]: dodatkowe legalne metadane i aliasy bez klucza.
    # POWOD: Wikidata pomaga przy tytulach oryginalnych, polskich/angielskich aliasach oraz filmach/serialach starszych.
    import requests as _req

    queries = _build_web_queries_from_history(history or [])[:5]
    if not queries:
        return ''
    user_text = u' '.join((_chat_user_text(history or []) or '').split()).strip()
    user_text = _ai_text_without_actor_examples(user_text)
    cache_key = 'wikidata_v2|{}'.format(_ai_research_cache_fingerprint(history or [])[:700])
    cached = _ai_cache_get(cache_key)
    if cached is not None:
        log('[AI_SEARCH] Wikidata cache hit', 1)
        return cached

    headers = _legal_research_headers()
    lines = []
    seen = set()
    media_words = (
        'film', 'movie', 'serial', 'series', 'television', 'tv', 'sitcom',
        'drama', 'comedy', 'horror', 'documentary', 'anime', 'miniseries',
        'telewizyj', 'komedia', 'serial telewizyjny',
    )

    for q in queries[:3]:
        q = u' '.join((q or '').split()).strip()[:120]
        if not q:
            continue
        for lang in ('pl', 'en'):
            try:
                r = _req.get(
                    'https://www.wikidata.org/w/api.php',
                    params={
                        'action': 'wbsearchentities',
                        'search': q,
                        'language': lang,
                        'uselang': lang,
                        'format': 'json',
                        'limit': 5,
                    },
                    timeout=8,
                    headers=headers,
                )
                if r.status_code >= 400:
                    continue
                for item in (r.json().get('search') or []):
                    qid = item.get('id') or ''
                    label = (item.get('label') or '').strip()
                    desc = (item.get('description') or '').strip()
                    alias = ', '.join((item.get('aliases') or [])[:3])
                    blob = _ai_fold_text(u'{} {} {}'.format(label, desc, alias))
                    if not qid or not label or qid in seen:
                        continue
                    if not any(w in blob for w in media_words):
                        continue
                    seen.add(qid)
                    line = u'[Wikidata {}] {} ({})'.format(lang.upper(), label, qid)
                    if desc:
                        line += u' — ' + desc[:180]
                    if alias:
                        line += u' — aliasy: ' + alias[:120]
                    lines.append(line[:420])
                    if len(lines) >= 10:
                        break
            except Exception as exc:
                log('[AI_SEARCH] Wikidata ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
            if len(lines) >= 10:
                break
        if len(lines) >= 10:
            break

    if lines:
        log('[AI_SEARCH] Wikidata context: {} wynikow'.format(len(lines)), 1)
    return _ai_cache_set(cache_key, u'\n'.join(lines[:10]))


def _fetch_page_brief(url):
    # ZMIANA (2026-04) [LEGAL]: wylaczone bezposrednie otwieranie znalezionych stron.
    # POWOD: Filmweb/IMDb/inne serwisy moga miec wlasne regulaminy i blokady; uzywamy snippetow z API wyszukiwarki.
    return ''


def _extract_openai_response_text(data):
    # ZMIANA (2026-04) [PATCH]: wspólny ekstraktor tekstu z OpenAI Responses API.
    # POWOD: web_search zwraca tekst w różnych polach zależnie od wersji API; bez tego kontekst WWW mógł być pusty mimo poprawnej odpowiedzi.
    # NIE ZMIENIAC: funkcja ma być defensywna i zwracać pusty string zamiast crashować okno Kodi.
    try:
        if isinstance(data, dict) and data.get('output_text'):
            return data.get('output_text') or ''
        out = []
        for item in (data.get('output') or []):
            if not isinstance(item, dict):
                continue
            if item.get('type') == 'message':
                for part in (item.get('content') or []):
                    if isinstance(part, dict) and part.get('type') in ('output_text', 'text'):
                        out.append(part.get('text') or '')
        return ''.join(out).strip()
    except Exception:
        return ''


def _openai_model_choice():
    # ZMIANA (2026-05) [PATCH]: OpenAI Search używa GPT-5.4 jako głównego modelu Responses API.
    # POWOD: GPT-5.4 oficjalnie obsługuje web_search w Responses API i ma lepsze rozumowanie dla trudnych opisów filmów niż poprzedni gpt-4.1.
    # NIE ZMIENIAC: drugi model zostaje tylko legacy fallbackiem Chat Completions; główna ścieżka ma iść przez Responses + web_search, bez scrapowania HTML.
    return 'gpt-5.4', 'gpt-5-search-api'


def _openai_response_model_candidates():
    # ZMIANA (2026-05) [PATCH]: dodano bezpieczną kolejkę modeli Responses: GPT-5.4 -> GPT-5.4 mini -> GPT-4.1.
    # POWOD: część kont może nie mieć jeszcze dostępu do GPT-5.4; fallback utrzymuje działanie OpenAI search zamiast kończyć czat błędem 400/404.
    # NIE ZMIENIAC: kolejność zaczyna się od GPT-5.4, a fallbacki nie zmieniają providera i nie pobierają HTML znalezionych stron.
    primary, _legacy_chat = _openai_model_choice()
    candidates = [primary, 'gpt-5.4-mini', 'gpt-4.1']
    out = []
    for model in candidates:
        if model and model not in out:
            out.append(model)
    return out


def _openai_legacy_search_model():
    # ZMIANA (2026-05) [PATCH]: ostatni fallback dla kont, które nie mają jeszcze gpt-5-search-api.
    # POWOD: użytkownik ma mieć działający OpenAI search także przy starszym dostępie API; fallback nie zmienia logiki Gemini/Claude.
    # NIE ZMIENIAC: ten model jest używany tylko po błędzie nowszej ścieżki i nadal nie scrapuje stron.
    return 'gpt-4o-search-preview'


def _openai_sources_from_response(data):
    # ZMIANA (2026-04) [PATCH]: wyciąga tytuły/URL źródeł z OpenAI web_search.
    # POWOD: żeby wtyczka mogła odróżnić realny research WWW od zgadywania modelu.
    # NIE ZMIENIAC: źródła są przycinane i nie zawierają sekretów; służą tylko jako kontekst dla AI.
    sources = []
    seen = set()
    try:
        for item in (data.get('output') or []):
            if not isinstance(item, dict):
                continue
            action = item.get('action') or {}
            for src in (action.get('sources') or []):
                if not isinstance(src, dict):
                    continue
                url = (src.get('url') or '').strip()
                title = (src.get('title') or '').strip()
                key = url.lower()
                if url and key not in seen:
                    seen.add(key)
                    sources.append((title, url))
            if item.get('type') == 'message':
                for part in (item.get('content') or []):
                    if not isinstance(part, dict):
                        continue
                    for ann in (part.get('annotations') or []):
                        if not isinstance(ann, dict):
                            continue
                        url = (ann.get('url') or '').strip()
                        title = (ann.get('title') or '').strip()
                        key = url.lower()
                        if url and key not in seen:
                            seen.add(key)
                            sources.append((title, url))
    except Exception:
        pass
    return sources[:6]


def _provider_web_research_prompt(history):
    # ZMIANA (2026-04) [SIMPLIFY]: prosty prompt web-research jak ChatGPT Search.
    # POWOD: stary prompt mial codex_contract+hypothesis+actor_example+strong_block - za duzo logiki dla etapu researchowego.
    user_text = u' '.join((_chat_user_text(history or []) or '').split()).strip()

    rejected_block = u''
    rejected_titles = _ai_collect_rejected_titles(history or [])
    if rejected_titles:
        rejected_block = u' Wyklucz juz odrzucone tytuly: ' + u'; '.join(rejected_titles[:8]) + u'.'

    unknown_block = u''
    if _ai_user_said_unknown_actor(history or []):
        unknown_block += u' Uzytkownik nie zna aktora - szukaj po fabule i scenach.'
    if _ai_user_said_unknown_year(history or []):
        unknown_block += u' Uzytkownik nie zna roku - uzyj przyblizonej epoki.'
    media_block = u''
    media_type_hint = _detect_user_media_type_hint(history=history)
    if media_type_hint == 'tv':
        media_block = u' Uzytkownik szuka serialu, nie filmu kinowego; szukaj tytulow TV/series.'
    elif media_type_hint == 'movie':
        media_block = u' Uzytkownik szuka filmu, nie serialu.'

    return (
        u'Znajdz tytul filmu lub serialu na podstawie opisu uzytkownika. '
        u'Uzyj web search - szukaj po polsku i angielsku. '
        u'Zwroc krotko: tytul polski / tytul oryginalny / rok / dlaczego pasuje.'
        + rejected_block + unknown_block + media_block +
        u' Opis: ' + user_text[:1000]
    )


def _gemini_sources_from_response(data):
    # ZMIANA (2026-04) [PATCH]: wyciaga URL-e z groundingMetadata Gemini.
    # POWOD: log ma pokazywac, czy Gemini realnie uzyl Google Search, a nie tylko odpowiedzial z pamieci.
    sources = []
    seen = set()
    try:
        for cand in (data.get('candidates') or []):
            meta = cand.get('groundingMetadata') or cand.get('grounding_metadata') or {}
            for chunk in (meta.get('groundingChunks') or meta.get('grounding_chunks') or []):
                if not isinstance(chunk, dict):
                    continue
                web = chunk.get('web') or {}
                url = (web.get('uri') or web.get('url') or '').strip()
                title = (web.get('title') or '').strip()
                key = url.lower()
                if url and key not in seen:
                    seen.add(key)
                    sources.append((title, url))
    except Exception:
        pass
    return sources[:8]


def _gemini_grounding_query_count(data):
    try:
        total = 0
        for cand in (data.get('candidates') or []):
            meta = cand.get('groundingMetadata') or cand.get('grounding_metadata') or {}
            total += len(meta.get('webSearchQueries') or meta.get('web_search_queries') or [])
        return total
    except Exception:
        return 0


def _claude_sources_from_response(data):
    # ZMIANA (2026-04) [PATCH]: wyciaga zrodla z blokow web_search_tool_result Claude.
    # POWOD: Claude ma byc rozliczany w logu tak jak OpenAI/Gemini - liczba realnych zrodel i searchy.
    sources = []
    seen = set()
    try:
        for block in (data.get('content') or []):
            if not isinstance(block, dict):
                continue
            blocks = []
            if block.get('type') == 'web_search_tool_result':
                blocks = block.get('content') or []
            elif block.get('type') == 'text':
                blocks = block.get('citations') or []
            for item in blocks:
                if not isinstance(item, dict):
                    continue
                url = (item.get('url') or item.get('source') or '').strip()
                title = (item.get('title') or item.get('cited_text') or '').strip()
                key = url.lower()
                if url and key not in seen:
                    seen.add(key)
                    sources.append((title, url))
    except Exception:
        pass
    return sources[:8]


def _claude_web_search_count(data):
    try:
        usage = data.get('usage') or {}
        server_tool_use = usage.get('server_tool_use') or {}
        count = _ai_token_int(server_tool_use.get('web_search_requests')) or 0
        if count:
            return count
        return len([b for b in (data.get('content') or []) if isinstance(b, dict) and b.get('type') == 'server_tool_use'])
    except Exception:
        return 0


def _openai_web_research_context_for_history(history):
    # ZMIANA (2026-04) [PATCH]: pomocniczy OpenAI web_search, nieuruchamiany automatycznie dla innych providerów.
    # POWOD: wybór "Gemini" ma nie zużywać w tle OpenAI; provider z natywnym web-search obsługuje internet we własnym callerze.
    # NIE ZMIENIAC: brak klucza OpenAI albo błąd API ma zwrócić pusty kontekst, bez crasha i bez ujawniania klucza w logach.
    try:
        api_key = (control.setting('ai_search.key.openai') or '').strip()
    except Exception:
        api_key = ''
    if not api_key:
        return ''

    user_text = u' '.join((_chat_user_text(history or []) or '').split()).strip()
    user_text = _ai_text_without_actor_examples(user_text)
    if len(user_text) < 6:
        return ''
    cache_key = 'openai_web_v4_multilang|{}'.format(_ai_research_cache_fingerprint(history or [])[:700])
    cached = _ai_cache_get(cache_key)
    if cached is not None:
        log('[AI_SEARCH] OpenAI web_search cache hit', 1)
        return cached

    import requests as _req
    headers = {'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'}
    codex_queries = _build_web_queries_from_history(history or [])[:10]
    hypothesis_block = _build_reasoning_hypothesis_note(history or [])
    actor_example_block = _ai_actor_example_note(history or [])
    codex_contract_block = _ai_codex_reasoning_contract(history or [])
    query_block = u''
    if codex_queries:
        query_block = (
            u' Uzyj procesu jak Codex Search: najpierw sprawdz te zapytania, potem porownaj kandydatow ze zrodel. '
            u'Zapytania: ' + u' | '.join(codex_queries) + u'.'
        )

    # ZMIANA (2026-04) [PATCH]: research OpenAI dostaje pamięć odrzuceń i rzeczy, których użytkownik nie zna.
    # POWOD: bez tego web_search dalej mógł krążyć po starych błędnych tropach i pytać np. o aktora mimo odpowiedzi „nie znam”.
    # NIE ZMIENIAC: to tylko steruje zapytaniem researchowym; nie zwiększa zapytań do TMDB i nie dotyka hostów.
    rejected_titles = _ai_collect_rejected_titles(history or [])
    rejected_block = u''
    if rejected_titles:
        rejected_block = u' Wyklucz już odrzucone tytuły: ' + u'; '.join(rejected_titles[:8]) + u'.'
    unknown_block = u''
    if _ai_user_said_unknown_actor(history or []):
        unknown_block += u' Użytkownik NIE ZNA aktora/obsady — nie pytaj już o aktora, szukaj po fabule/scenach.'
    if _ai_user_said_unknown_year(history or []):
        unknown_block += u' Użytkownik NIE ZNA roku — nie pytaj już o rok, użyj przybliżonej epoki z opisu.'
    strong_block = u''
    if _ai_strong_search_from_first_turn(history or []) or _ai_should_force_deep_search(history or []):
        strong_block = (
            u' TRYB MOCNEGO RESEARCHU OD RAZU: nie czekaj na kilka tur i nie dopytuj bez potrzeby. '
            u'Zrób nowe wyszukiwanie od zera po wszystkich wskazówkach i zwróć ranking 1-3 kandydatów zamiast kolejnego pytania. '
            u'Nie wybieraj wyniku, który pasuje tylko do jednego luźnego słowa; musi pasować do połączenia najrzadszych tropów.'
        )

    research_prompt = (
        u'WYKONAJ REALNE WYSZUKIWANIE INTERNETU przed odpowiedzią. '
        u'Szukasz tytułu filmu/serialu po niepełnym opisie użytkownika. '
        u'Najpierw zrozum zdanie użytkownika: oddziel opis szukanego filmu od przykladow dorobku aktora i pobocznych skojarzen. '
        u'Sam wyznacz glowny trop sceny/fabuly z opisu; nie ma wpisanych gotowych scen. '
        u'Sprawdź tropy po polsku, angielsku i jeśli pasuje — w języku kraju filmu. '
        u'Zbuduj listę MUST-HAVE z najrzadszych tropów i oceniaj kandydatów po całym połączeniu tych tropów, nie po jednym słowie. '
        u'Pewny wynik wymaga potwierdzenia glownego tropu sceny/fabuly w zrodlach. '
        u'Nie wybieraj filmu tylko dlatego, ze zgadza sie aktor/kraj/gatunek; najpierw potwierdz rzadkie tropy fabuly, sceny, zawodu postaci i rekwizytow. '
        u'Jesli uzytkownik pisze, ze aktor gral np. w innym tytule, ten tytul i jego tlumaczenia sa tylko przykladem aktora, nie wynikiem. '
        u'Nie zgaduj z pamięci. Jeśli znajdziesz kandydatów, zwróć krótko: tytuł polski / tytuł oryginalny / rok / dlaczego pasuje / 2-4 źródła. '
        + codex_contract_block + hypothesis_block + actor_example_block + query_block + rejected_block + unknown_block + strong_block +
        u' Opis użytkownika: ' + user_text[:1000]
    )

    # ZMIANA (2026-05) [PATCH]: research-context OpenAI próbuje GPT-5.4 -> GPT-5.4 mini -> GPT-4.1.
    # POWOD: GPT-5.4 ma być głównym modelem do trudnych opisów filmów, ale fallback utrzymuje działanie przy braku dostępu na koncie.
    # NIE ZMIENIAC: każdy wariant używa oficjalnego toola OpenAI i źródeł z API, bez otwierania HTML wyników.
    try:
        r = None
        for model in _openai_response_model_candidates():
            payload = {
                'model': model,
                'tools': [{'type': 'web_search', 'search_context_size': 'high'}],
                'tool_choice': 'required',
                'include': ['web_search_call.action.sources'],
                'input': research_prompt,
                'max_output_tokens': 1200,
            }
            r = _req.post('https://api.openai.com/v1/responses', headers=headers, json=payload, timeout=35)
            if r.status_code >= 400:
                log('[AI_SEARCH] OpenAI research web_search unavailable status={} model={} fallback=web_search_preview'.format(r.status_code, model), 1)
                payload['tools'] = [{'type': 'web_search_preview'}]
                r = _req.post('https://api.openai.com/v1/responses', headers=headers, json=payload, timeout=35)
            if r.status_code < 400:
                break
        if r.status_code < 400:
            data = r.json()
            body = _extract_openai_response_text(data)
            srcs = _openai_sources_from_response(data)
            if body or srcs:
                lines = []
                if body:
                    lines.append(body[:2800])
                if srcs:
                    lines.append(u'ŹRÓDŁA OPENAI WEB_SEARCH:')
                    for title, url in srcs[:8]:
                        lines.append(u'- {} ({})'.format(title or url, url))
                log('[AI_SEARCH] OpenAI web_search context OK: chars={} sources={}'.format(len(body or ''), len(srcs)), 1)
                return _ai_cache_set(cache_key, u'[OpenAI web_search live]\n' + u'\n'.join(lines))

        # ZMIANA (2026-05) [PATCH]: fallback Chat Completions próbuje najpierw gpt-5-search-api, potem legacy gpt-4o-search-preview.
        # POWOD: zgodnie z dokumentacją search-preview jest ścieżką legacy, ale musi zostać jako zapas dla starszych kont użytkownika.
        # NIE ZMIENIAC: oba warianty używają oficjalnego web_search_options i nie pobierają HTML znalezionych stron.
        r2 = None
        for chat_model in (_openai_model_choice()[1], _openai_legacy_search_model()):
            r2 = _req.post(
                'https://api.openai.com/v1/chat/completions',
                headers=headers,
                json={
                    'model': chat_model,
                    'web_search_options': {},
                    'messages': [
                        {'role': 'system', 'content': 'Odpowiadasz krótko po polsku. Podaj tylko realne kandydaty filmów ze źródeł WWW.'},
                        {'role': 'user', 'content': research_prompt},
                    ],
                    'max_tokens': 900,
                },
                timeout=35,
            )
            if r2.status_code < 400:
                txt = (((r2.json().get('choices') or [{}])[0].get('message') or {}).get('content') or '').strip()
                if txt:
                    log('[AI_SEARCH] OpenAI chat search context OK model={} chars={}'.format(chat_model, len(txt)), 1)
                    return _ai_cache_set(cache_key, u'[OpenAI chat search live]\n' + txt[:1800])
            log('[AI_SEARCH] OpenAI chat search fallback status={} model={}'.format(getattr(r2, 'status_code', '-'), chat_model), 1)
        log('[AI_SEARCH] OpenAI web_search context EMPTY status={} fallback_status={}'.format(getattr(r, 'status_code', '-'), getattr(r2, 'status_code', '-')), 1)
    except Exception as exc:
        log('[AI_SEARCH] OpenAI web_search context ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
    return ''


def _gemini_web_research_context_for_history(history):
    # ZMIANA (2026-04) [PATCH]: Gemini dostaje osobny etap researchu Google Search jak OpenAI.
    # POWOD: samo tools[] w finalnym callu nie dawalo w logu pewnosci, czy grounding faktycznie zaszedl.
    try:
        api_key = (control.setting('ai_search.key.gemini') or '').strip()
    except Exception:
        api_key = ''
    if not api_key:
        return ''

    user_text = u' '.join((_chat_user_text(history or []) or '').split()).strip()
    if len(user_text) < 6:
        return ''
    model = _gemini_model_choice()
    cache_key = 'gemini_web_v3_multilang|{}|{}'.format(model, _ai_research_cache_fingerprint(history or [])[:700])
    cached = _ai_cache_get(cache_key)
    if cached is not None:
        log('[AI_SEARCH] Gemini google_search cache hit', 1)
        return cached

    import requests as _req
    payload = {
        'contents': [{'parts': [{'text': _provider_web_research_prompt(history)}]}],
        'tools': [{'google_search': {}}],
        'systemInstruction': {'parts': [{'text': 'Odpowiadasz krotko po polsku. Najpierw uzyj Google Search, potem podaj realne kandydaty filmow/seriali ze zrodel.'}]},
        'generationConfig': {'maxOutputTokens': 1200, 'temperature': 0.0},
    }
    try:
        r = _req.post(
            'https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent'.format(model),
            headers={'Content-Type': 'application/json', 'x-goog-api-key': api_key},
            json=payload,
            timeout=35,
        )
        if r.status_code >= 400:
            log('[AI_SEARCH] Gemini google_search context EMPTY status={}'.format(r.status_code), 1)
            return ''
        data = r.json()
        parts = (((data.get('candidates') or [{}])[0].get('content') or {}).get('parts') or [])
        body = ''.join([p.get('text', '') for p in parts if isinstance(p, dict)]).strip()
        srcs = _gemini_sources_from_response(data)
        query_count = _gemini_grounding_query_count(data)
        if body and (srcs or query_count):
            lines = [body[:2800]]
            if srcs:
                lines.append(u'ZRODLA GEMINI GOOGLE_SEARCH:')
                for title, url in srcs[:8]:
                    lines.append(u'- {} ({})'.format(title or url, url))
            log('[AI_SEARCH] Gemini google_search context OK: chars={} sources={} queries={}'.format(
                len(body or ''), len(srcs), query_count), 1)
            return _ai_cache_set(cache_key, u'[Gemini google_search live]\n' + u'\n'.join(lines))
        log('[AI_SEARCH] Gemini google_search context EMPTY: chars={} sources={} queries={}'.format(
            len(body or ''), len(srcs), query_count), 1)
    except Exception as exc:
        log('[AI_SEARCH] Gemini google_search context ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
    return ''


def _claude_web_research_context_for_history(history):
    # ZMIANA (2026-04) [PATCH]: Claude dostaje osobny etap web_search jak OpenAI.
    # POWOD: finalny call z toolsem nie wystarczal do jednoznacznego logowania realnego researchu.
    try:
        api_key = (control.setting('ai_search.key.claude') or '').strip()
    except Exception:
        api_key = ''
    if not api_key:
        return ''

    user_text = u' '.join((_chat_user_text(history or []) or '').split()).strip()
    if len(user_text) < 6:
        return ''
    cache_key = 'claude_web_v3_multilang|{}'.format(_ai_research_cache_fingerprint(history or [])[:700])
    cached = _ai_cache_get(cache_key)
    if cached is not None:
        log('[AI_SEARCH] Claude web_search cache hit', 1)
        return cached

    import requests as _req
    model = 'claude-sonnet-4-5-20251022'
    headers = {
        'x-api-key': api_key,
        'anthropic-version': '2023-06-01',
        'Content-Type': 'application/json',
    }
    payload = {
        'model': model,
        'max_tokens': 1200,
        'system': 'Odpowiadasz krotko po polsku. Najpierw uzyj web_search, potem podaj realne kandydaty filmow/seriali ze zrodel.',
        'messages': [{'role': 'user', 'content': _provider_web_research_prompt(history)}],
        'tools': [{'type': 'web_search_20250305', 'name': 'web_search', 'max_uses': 5}],
    }
    try:
        r = _req.post('https://api.anthropic.com/v1/messages', headers=headers, json=payload, timeout=40)
        if r.status_code >= 400:
            log('[AI_SEARCH] Claude web_search context EMPTY status={}'.format(r.status_code), 1)
            return ''
        data = r.json()
        body = ''.join([
            b.get('text') or '' for b in (data.get('content') or [])
            if isinstance(b, dict) and b.get('type') == 'text'
        ]).strip()
        srcs = _claude_sources_from_response(data)
        search_count = _claude_web_search_count(data)
        if body and (srcs or search_count):
            lines = [body[:2800]]
            if srcs:
                lines.append(u'ZRODLA CLAUDE WEB_SEARCH:')
                for title, url in srcs[:8]:
                    lines.append(u'- {} ({})'.format(title or url, url))
            log('[AI_SEARCH] Claude web_search context OK: chars={} sources={} searches={}'.format(
                len(body or ''), len(srcs), search_count), 1)
            return _ai_cache_set(cache_key, u'[Claude web_search live]\n' + u'\n'.join(lines))
        log('[AI_SEARCH] Claude web_search context EMPTY: chars={} sources={} searches={}'.format(
            len(body or ''), len(srcs), search_count), 1)
    except Exception as exc:
        log('[AI_SEARCH] Claude web_search context ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
    return ''


def _build_live_web_context_for_history(history):
    # ZMIANA (2026-04) [LEGAL]: jeden legalny kontekst API/search-tool podawany każdemu providerowi.
    # POWOD: funkcja "Nie pamiętam tytułu" ma mieć dobre wyniki przez oficjalne API/search tools.
    # NIE ZMIENIAC: limity wyników chronią przed długim czekaniem w Kodi i przed spamem zapytań.
    parts = []

    queries = _build_web_queries_from_history(history)
    user_text = _ai_text_without_actor_examples(_chat_user_text(history or []))
    log('[AI_SEARCH] legal research mode: provider web tools/TMDB/Wikidata/TVMaze/Google CSE; Wikipedia API disabled', 1)
    if queries:
        log('[AI_SEARCH] Codex-style queries: {}'.format(' | '.join(queries[:10])[:800]), 1)
    try:
        hypos = _ai_research_hypotheses_from_text(_chat_user_text(history or []))
        if hypos:
            log('[AI_SEARCH] Reasoning hypotheses: {}'.format(
                ' | '.join(['{}={}'.format(h.get('kind'), h.get('value')) for h in hypos[:6]])[:500]), 1)
    except Exception:
        pass

    seed_context = _ai_chatgpt_seed_context_from_history(history or [])
    if seed_context:
        # ZMIANA (2026-05) [FEATURE]: do legalnego researchu dokładamy lokalne tropy-seed jak w ChatGPT.
        # POWOD: dla krótkiego opisu „stare fantasy + aktor karzełek” sam web_search szedł w Leprechaun; seed wymusza porównanie Willow/alternatyw.
        # NIE ZMIENIAC: seed nie jest dowodem i nie scrapuje stron; finalny AI nadal ma zwrócić ranking lub potwierdzenie.
        parts.append(seed_context)
        log('[AI_SEARCH] local seed context added', 1)

    # ZMIANA (2026-04) [PATCH]: nie odpalamy dodatkowego OpenAI web_search w tle.
    # POWOD: wybór "Gemini" ma zużywać Gemini, a nie ukryte zapytania OpenAI.
    # NIE ZMIENIAC: legalny kontekst TMDB/Wikipedia/Google CSE zostaje bez ukrytego kosztu OpenAI.
    try:
        selected_provider = (control.setting('ai_search.provider') or '').strip()
    except Exception:
        selected_provider = ''
    selected_provider = _normalize_ai_provider(selected_provider, log_change=True)
    native_web_context_ok = False
    native_web_context_chars = 0
    if selected_provider == 'OpenAI':
        try:
            openai_web = _openai_web_research_context_for_history(history)
            if openai_web:
                native_part = openai_web[:4200]
                parts.append(native_part)
                native_web_context_ok = True
                native_web_context_chars += len(native_part or '')
        except Exception as exc:
            log('[AI_SEARCH] OpenAI web_search researcher ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
    elif selected_provider == 'Gemini':
        try:
            gemini_web = _gemini_web_research_context_for_history(history)
            if gemini_web:
                native_part = gemini_web[:4200]
                parts.append(native_part)
                native_web_context_ok = True
                native_web_context_chars += len(native_part or '')
        except Exception as exc:
            log('[AI_SEARCH] Gemini google_search researcher ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
    elif selected_provider == 'Claude':
        try:
            claude_web = _claude_web_research_context_for_history(history)
            if claude_web:
                native_part = claude_web[:4200]
                parts.append(native_part)
                native_web_context_ok = True
                native_web_context_chars += len(native_part or '')
        except Exception as exc:
            log('[AI_SEARCH] Claude web_search researcher ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
    else:
        log('[AI_SEARCH] provider web_search researcher skipped; selected provider={}'.format(selected_provider or '-'), 1)

    try:
        tmdb = _tmdb_context_search(history)
        if tmdb:
            parts.append(u'[TMDB live]\n' + tmdb[:1800])
    except Exception as exc:
        log('[AI_SEARCH] live TMDB ctx ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)

    try:
        tvmaze = _tvmaze_context_search(history)
        if tvmaze:
            parts.append(u'[TVMaze live]\n' + tvmaze[:1600])
    except Exception as exc:
        log('[AI_SEARCH] live TVMaze ctx ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)

    try:
        wikidata = _wikidata_context_search(history)
        if wikidata:
            parts.append(u'[Wikidata live]\n' + wikidata[:1800])
    except Exception as exc:
        log('[AI_SEARCH] live Wikidata ctx ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)

    # ZMIANA (2026-04) [PATCH]: Wikipedia API wylaczone z glownego researchu.
    # POWOD: u uzytkownika API zwracalo nie-JSON i tylko opoznialo wyszukiwanie; tryb ma byc blizszy Codex/OpenAI web search.
    # NIE ZMIENIAC: zostaja provider web tools, TMDB, Wikidata, TVMaze oraz awaryjny Google CSE.
    log('[AI_SEARCH] Wikipedia API skipped: disabled in Codex-style research mode', 1)

    search_results = []
    seen_urls = set()
    max_search_results = 20

    # ZMIANA (2026-04) [LEGAL]: Google CSE jako fallback, gdy natywny web providera nie zwroci kontekstu albo zwroci go za malo.
    # POWOD: samo "web_search cos zwrocil" nie wystarcza; przy slabym kontekscie AI ma za malo materialu do porownania scen.
    # NIE ZMIENIAC: nie dodawac pobierania stron wynikow ani parsowania znalezionych stron.
    if native_web_context_ok and native_web_context_chars >= 2800:
        log('[AI_SEARCH] Google CSE skipped: native provider web_search context rich enough chars={}'.format(native_web_context_chars), 1)
    else:
        if native_web_context_ok:
            log('[AI_SEARCH] Google CSE fallback: native provider context short chars={}'.format(native_web_context_chars), 1)
        for q in queries[:8]:
            for item in _google_cse_search(q, limit=4):
                url = item.get('url') or ''
                key = url.split('#')[0].lower()
                if not key or key in seen_urls:
                    continue
                seen_urls.add(key)
                search_results.append(item)
                if len(search_results) >= max_search_results:
                    break
            if len(search_results) >= max_search_results:
                break

    if (not search_results) and ((not native_web_context_ok) or native_web_context_chars < 1800):
        log('[AI_SEARCH] Google CSE no results/not configured; page parsing unavailable in legal mode', 1)

    if search_results:
        search_results = sorted(
            search_results,
            key=lambda item: _ai_search_result_score(item, user_text),
            reverse=True
        )
        lines = []
        for item in search_results[:8]:
            line = u'- {title} — {snippet} ({url})'.format(
                title=item.get('title') or '',
                snippet=item.get('snippet') or '',
                url=item.get('url') or '')
            lines.append(line[:420])
        parts.append(u'[Web search live]\n' + u'\n'.join(lines))

    context = u'\n\n'.join([p for p in parts if p]).strip()
    if context:
        log('[AI_SEARCH] live web context: {} znakow, queries={}'.format(len(context), len(queries)), 1)
    else:
        log('[AI_SEARCH] live web context: pusty — fallback na wiedze modelu', 1)
    return context[:9800]

def _tmdb_context_search(history):
    """
    ZMIANA (2026-04) [NOWA FUNKCJA]: przeszukuje TMDB realnym opisem użytkownika i zwraca
    listę pasujących filmów jako kontekst dla AI — analogicznie do wyszukiwania Google.
    POWOD: AI bez kontekstu zgaduje z wiedzy treningowej i może się mylić;
           z wynikami TMDB dostaje realne dane i wybiera najlepiej pasujący tytuł.
    NIE ZMIENIAC: błąd sieci zwraca '' — AI działa wtedy bez kontekstu (stary tryb).
    """
    try:
        # Zbierz wszystkie wiadomości użytkownika
        user_parts = [h.get('content', '') for h in history if h.get('role') == 'user']
        if not user_parts:
            return ''
        query_text = ' '.join(user_parts[-3:])  # max ostatnie 3 wiadomości
        query_text = query_text[:120].strip()
        if not query_text:
            return ''
        cache_key = 'tmdb_ctx|{}'.format(query_text.lower())
        cached = _ai_cache_get(cache_key)
        if cached is not None:
            log('[AI_SEARCH] TMDB context cache hit', 1)
            return cached

        tm_headers, tm_key = _tmdb_auth()
        if not tm_key and not tm_headers:
            return ''

        import requests as _requests
        try:
            from urllib.parse import quote as _quote
        except ImportError:
            from urllib import quote as _quote

        # Szukaj w TMDB multi-search (filmy + seriale) po opisie użytkownika
        params = 'language=pl-PL&query={}&page=1'.format(
            _quote(query_text.encode('utf-8')))
        if tm_key:
            params = 'api_key={}&'.format(tm_key) + params
        url = 'https://api.themoviedb.org/3/search/multi?' + params
        r = _requests.get(url, timeout=8, headers=tm_headers or None)
        r.raise_for_status()
        results = r.json().get('results') or []

        lines = []
        for item in results[:12]:
            media = item.get('media_type', 'movie')
            if media not in ('movie', 'tv'):
                continue
            pl_title   = item.get('title') or item.get('name') or ''
            orig_title = item.get('original_title') or item.get('original_name') or ''
            year       = (item.get('release_date') or item.get('first_air_date') or '')[:4]
            overview   = (item.get('overview') or '')[:120].strip()
            if pl_title:
                entry = u'{} / {} ({})'.format(pl_title, orig_title, year)
                if overview:
                    entry += u' — ' + overview
                lines.append(entry)

        if not lines:
            return ''

        log('[AI_SEARCH] TMDB context: {} wyników dla: {!r}'.format(len(lines), query_text[:50]), 1)
        return _ai_cache_set(cache_key, u'\n'.join(lines))

    except Exception as exc:
        log('[AI_SEARCH] TMDB context ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        return ''


def _build_mini_chat_prompt(history, tmdb_context='', force_answer=False):
    # ZMIANA (2026-04) [SIMPLIFY]: prompt jak zwykly ChatGPT/Google - krotki, naturalny, bez 50 regul.
    # POWOD: stary prompt z codex/judge/actor-example dezorientowal model i kasowal poprawne wyniki.

    rejected_titles = _ai_collect_rejected_titles(history or [])
    reject_block = u''
    if rejected_titles:
        reject_block = u'Nie proponuj juz tych tytulow (uzytkownik je odrzucil): ' + u', '.join(rejected_titles) + u'.\n\n'

    unknown_block = u''
    if _ai_user_said_unknown_actor(history or []):
        unknown_block += u'Uzytkownik nie zna aktora - nie pytaj o obsade, szukaj po fabule i scenach.\n'
    if _ai_user_said_unknown_year(history or []):
        unknown_block += u'Uzytkownik nie zna roku - nie pytaj o rok, uzyj przyblizonej epoki.\n'
    if unknown_block:
        unknown_block += u'\n'

    media_type_hint = _detect_user_media_type_hint(history=history)
    media_block = u''
    if media_type_hint == 'tv':
        media_block = u'Uzytkownik jawnie szuka SERIALU: zwracaj type="tv" i nie proponuj filmow kinowych.\n\n'
    elif media_type_hint == 'movie':
        media_block = u'Uzytkownik jawnie szuka FILMU: zwracaj type="movie" i nie proponuj seriali.\n\n'

    conv_lines = []
    for item in history[-14:]:
        role = u'UZYTKOWNIK' if item.get('role') == 'user' else u'AI'
        content = (item.get('content') or '').strip()
        if content:
            conv_lines.append(u'{}: {}'.format(role, content))
    conversation = u'\n'.join(conv_lines)

    live_context = (tmdb_context or '').strip()
    context_block = u''
    if live_context:
        context_block = (
            u'KONTEKST Z WYSZUKIWARKI (web search providera + TMDB/Wikidata/TVMaze):\n'
            + live_context + u'\n\n'
        )

    return (
        reject_block + unknown_block + media_block +
        u'Jestes asystentem ktory pomaga znalezc tytul filmu lub serialu po opisie uzytkownika.\n'
        u'Przeszukaj internet i podaj tytul. Odpowiedz WYLACZNIE w formacie JSON - zadnego tekstu przed ani po JSON.\n'
        u'Jesli masz dobry trop - podaj go z krotkim wyjasnieniem dlaczego pasuje. Jesli masz kilka opcji - podaj 2-3 kandydatow. Jesli opis jest zbyt ogolny - zadaj jedno krotkie pytanie.\n'
        u'Po odrzuceniu tytulu przez uzytkownika nie koncz sama prosba o szczegoly: pokaz ranking 2-3 nowych kandydatow, jezeli istnieje jakikolwiek rozsadny trop.\n'
        u'Jesli kontekst zawiera [LOCAL_CANDIDATE_HINTS], potraktuj je jak tropy do porownania: seed nie jest dowodem, ale ma byc sprawdzony i pokazany w rankingu, gdy pasuje lepiej niz wynik z jednego slowa.\n'
        u'Pisz po polsku, naturalnie, krotko. Bez technicznego zargonu, bez “zaraz sprawdze”, bez markdownu.\n'
        u'Dla filmu zagranicznego: confirmation_title/search_query po angielsku/oryginalnie, polski tytul w pl_title. Dla polskiego - polski tytul wszedzie.\n'
        u'NIE wpisuj frazy wyszukiwarkowej jako tytulu - tytul to konkretna nazwa filmu/serialu.\n'
        u'Jesli uzytkownik pyta "czesc 1/2/3" lub "Part X" serii — search_query to TYLKO bazowy tytul bez numeru (np. "Garfield czesc 1" → search_query="Garfield", year="2004"). TMDB nie rozumie "czesc" ani "Part X".\n'
        u'Rok (year): uzyj roku premiery kinowej, NIE roku produkcji. Wpisz tylko gdy masz pewnosc z web search — bledny rok blokuje wynik w TMDB. Jesli rok niepewny — zostaw year=null.\n'
        u'Confidence: 80+ jesli jestes pewny, 60-79 jesli prawdopodobne, ponizej 60 jesli zgadujesz.\n'
        u'Gdy jeden tytul wyraznie pasuje - ustaw ready_to_confirm=true.\n'
        u'Gdy uzytkownik napisze "tak" / "to ten" - potwierdz wybor. Numer kandydata traktuj tylko jako wybor tropu do podgladu.\n\n'
        + context_block +
        u'ROZMOWA:\n' + conversation +
        u'\n\nOdpowiedz WYLACZNIE w JSON zgodnym ze schematem systemowym.\n'
    )

def _ai_prompt_json(value, limit=5000):
    try:
        text = json.dumps(value or {}, ensure_ascii=False, sort_keys=True)
    except Exception:
        text = str(value or '')
    return text[:limit]


def _ai_candidate_judge_needed(ai_data, history, web_context):
    # ZMIANA (2026-04) [FEATURE]: osobny sedzia tropow po web search.
    # POWOD: model potrafil podac liste poprawnych kandydatow, ale nie wypromowal najlepszego do tytulu.
    if not web_context:
        return False
    ai_data = ai_data or {}
    title = _best_title_from_ai(ai_data)
    confidence = _ai_to_int(ai_data.get('confidence'))
    if _ai_ready_to_confirm(ai_data, history) and title:
        return False
    if title and confidence >= _AI_CHAT_CONFIRM_CONFIDENCE:
        return False
    msg = _chat_ai_message(ai_data) or ''
    candidates = ai_data.get('candidates') or []
    if candidates or title or confidence >= 50:
        return True
    if len(msg) > 40 and any(ch.isdigit() for ch in msg):
        return True
    return _ai_strong_search_from_first_turn(history or []) or _ai_should_force_deep_search(history or [])


def _build_candidate_judge_prompt(history, web_context, ai_data):
    conversation = []
    for item in (history or [])[-14:]:
        role = u'UZYTKOWNIK' if item.get('role') == 'user' else u'AI'
        content = (item.get('content') or '').strip()
        if content:
            conversation.append(u'{}: {}'.format(role, content))
    previous_json = _ai_prompt_json(ai_data or {}, 5200)
    previous_msg = (_chat_ai_message(ai_data or {}) or '').strip()[:2200]
    context = (web_context or '').strip()[:7600]
    actor_example_block = _ai_actor_example_note(history or [])
    codex_contract_block = _ai_codex_reasoning_contract(history or [])
    media_type_hint = _detect_user_media_type_hint(history=history)
    media_block = u''
    if media_type_hint == 'tv':
        media_block = u'0A. Uzytkownik jawnie szuka SERIALU: kandydaci typu movie nie moga byc promowani ani potwierdzani.\n'
    elif media_type_hint == 'movie':
        media_block = u'0A. Uzytkownik jawnie szuka FILMU: kandydaci typu tv nie moga byc promowani ani potwierdzani.\n'
    return (
        u'ETAP SEDZIEGO TROPOW PO WYSZUKIWANIU.\n'
        u'To nie jest nowy zwykly czat. Masz ocenic wyniki researchu i poprzednia odpowiedz AI.\n'
        + media_block +
        u'Nie masz wpisanych gotowych podpowiedzi aktorow ani tytulow. Zbuduj je sam z rozmowy i legalnego kontekstu.\n'
        u'1. Najpierw zrozum zdanie uzytkownika: oddziel opis szukanego filmu od przykladow aktora, pobocznych skojarzen i niepewnej pamieci.\n'
        u'2. Sam wyznacz GLOWNY TROP SCENY/FABULY z rozmowy. Nie ma gotowych scen w promptcie; bierzesz go tylko z tekstu uzytkownika.\n'
        u'3. Z rozmowy zbuduj liste MUST-HAVE: 3-7 najrzadszych tropow sceny/fabuly. Nie licz jako mocne samego kraju, gatunku, epoki ani znanego aktora.\n'
        u'3A. Jesli uzytkownik pisze, ze aktor "gral np. w" innym tytule, ten tytul, jego oryginalne tytuly i tlumaczenia sa tylko przykladem dorobku aktora, nie filmem docelowym. Nie licz ich jako matched_rare_clue.\n'
        u'4. Dla kazdego kandydata sprawdz, ktore MUST-HAVE sa doslownie albo sensownie potwierdzone w LEGALNYM KONTEKSCIE WEB/API.\n'
        u'5. Slabsze tropy ogolne, niepewne albo poboczne moga byc pomylone, ale glowny trop sceny/fabuly musi byc potwierdzony; jesli scena/fabula sie nie zgadza, nie bierz kandydata jako wyniku.\n'
        u'6. Nie promuj filmu, ktory pasuje tylko krajem/gatunkiem/aktorem/rokiem. Taki film moze byc kandydatem, ale ready_to_confirm=false.\n'
        u'7. Jesli kontekst nie potwierdza glownego tropu sceny/fabuly z opisu, ustaw ready_to_confirm=false, confidence max 70 i evidence_score max 60.\n'
        u'8. Jesli jeden kandydat ma wyrazna przewage i kontekst potwierdza glowny trop sceny/fabuly plus inne mocne tropy, ustaw ready_to_confirm=true, confidence 78-88 i evidence_score >= 75.\n'
        u'9. Wypelnij matched_rare_clues tylko tropami naprawde potwierdzonymi przez web/API; gdy ustawiasz ready_to_confirm=true, jeden wpis musi zaczynac sie od "SCENA/FABULA:".\n'
        u'10. Wypelnij missing_rare_clues tropami waznymi bez potwierdzenia.\n'
        u'11. Jesli masz kilka podobnych kandydatow, zostaw ready_to_confirm=false i pokaz ranking maksymalnie 3 pozycji.\n'
        u'12. Nie wymyslaj tytulu spoza kontekstu, chyba ze jasno zaznaczysz niska pewnosc i zostawisz ready_to_confirm=false.\n\n'
        + codex_contract_block + actor_example_block +
        u'ROZMOWA:\n' + u'\n'.join(conversation)[:2600] + u'\n\n'
        u'LEGALNY KONTEKST WEB/API:\n' + context + u'\n\n'
        u'POPRZEDNIA ODPOWIEDZ AI JSON:\n' + previous_json + u'\n\n'
        u'POPRZEDNIA WIADOMOSC AI:\n' + previous_msg + u'\n\n'
        u'Odpowiedz WYLACZNIE w JSON zgodnym ze schematem systemowym. '
        u'Jesli promujesz tytul, assistant_message ma krotko powiedziec czemu laczy najmocniejsze tropy i zapytac: czy to ten tytul?'
    )


def _ai_list_field(value):
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v or '').strip()]
    if isinstance(value, str) and value.strip():
        return [v.strip() for v in re.split(r'[;\n|]+', value) if v.strip()]
    return []


def _ai_scene_clue_terms(value):
    folded = _ai_fold_text(value or '')
    if not folded:
        return []
    stop = set([
        'film', 'filmu', 'movie', 'serial', 'series', 'tytul', 'title',
        'stary', 'old', 'classic', 'klasyczny', 'bardzo', 'very',
        'chyba', 'maybe', 'probably', 'lata', 'years', 'year',
        'francuski', 'french', 'polski', 'polish', 'amerykanski', 'american',
        'brytyjski', 'british', 'wloski', 'italian', 'niemiecki', 'german',
        'komedia', 'comedy', 'komediowy', 'funny', 'smieszny',
        'aktor', 'aktora', 'actor', 'famous', 'znany', 'known',
        'popularny', 'popular', 'glowny', 'main', 'rola', 'role',
        'oryginalny', 'original', 'polski', 'english',
    ])
    suffixes = ('ach', 'ami', 'owie', 'owego', 'owej', 'ego', 'iego', 'ym', 'im', 'em', 'ie', 'ow', 'a', 'u', 'y', 'i')
    terms = []
    for token in re.split(r'[^a-z0-9]+', folded):
        token = token.strip()
        if len(token) < 4 or token in stop:
            continue
        stem = token
        for suffix in suffixes:
            if stem.endswith(suffix) and len(stem) - len(suffix) >= 4:
                stem = stem[:-len(suffix)]
                break
        if stem and stem not in stop and stem not in terms:
            terms.append(stem)
    return terms[:8]


def _ai_clue_is_scene_or_plot(value):
    # ZMIANA (2026-04) [PATCH]: evidence musi zawierac konkretny trop sceny/fabuly, nie tylko aktora/kraj/gatunek.
    # POWOD: model promowal popularny falszywy wynik, gdy pasowaly tylko slabe tropy.
    folded = _ai_fold_text(value or '')
    if not folded:
        return False
    scene_markers = (
        'scen', 'scene', 'fab', 'plot', 'motyw', 'sytuac', 'zdarzen',
        'akcj', 'action', 'dzieje', 'happens', 'robi', 'does',
        'gdzie', 'where', 'kiedy', 'when', 'posta', 'character',
        'rekwiz', 'object', 'relac', 'relation', 'zawod', 'job',
        'funkcj', 'function', 'miejsce', 'place', 'nietyp', 'unusual',
    )
    terms = _ai_scene_clue_terms(folded)
    if any(marker in folded for marker in scene_markers) and terms:
        return True
    return len(terms) >= 2


def _ai_primary_scene_terms_from_history(history, limit=8):
    # ZMIANA (2026-04) [FEATURE]: niezalezny od modelu ekstraktor glownej sceny/fabuly z tekstu uzytkownika.
    # POWOD: web search moze zwrocic popularny podobny tytul; pewny wynik ma przejsc tylko po potwierdzonej scenie.
    text = _ai_text_without_actor_examples(_chat_user_text(history or []))
    folded = _ai_fold_text(text or '')
    if not folded:
        return []
    markers = ('scen', 'fab', 'fragment', 'motyw', 'jak ', 'gdzie', 'kiedy', 'ktory', 'ktora')
    positions = [folded.find(m) for m in markers if folded.find(m) >= 0]
    focused = folded[min(positions):] if positions else folded
    focused = re.sub(r'aktor znany z innego filmu.*', ' ', focused)
    stop = set([
        'film', 'filmu', 'filmie', 'serial', 'serialu', 'tytul', 'tytulu',
        'bardzo', 'stary', 'stara', 'stare', 'nowy', 'nowa', 'nowe',
        'chyba', 'moze', 'pamietam', 'szukam', 'jaki', 'jakis',
        'ktory', 'ktora', 'ktore', 'gdzie', 'kiedy', 'byla', 'bylo', 'byl',
        'byly', 'jest', 'jego', 'jej', 'nim', 'tam', 'ten', 'tego', 'taka',
        'taki', 'jako', 'oraz', 'albo', 'scena', 'scenie', 'sceny', 'scen',
        'aktor', 'aktora', 'aktorem', 'aktorka', 'znany', 'znana',
        'smieszny', 'komediowy', 'popularny', 'glowny', 'rola',
        'francuski', 'polski', 'amerykanski', 'angielski', 'brytyjski',
        'niemiecki', 'wloski', 'hiszpanski', 'komedia', 'horror', 'dramat',
        'thriller', 'lata', 'roku', 'wiek', 'wystepowal', 'wystepowala',
        'gral', 'grala', 'innego', 'innym', 'przyklad', 'przykladowy',
    ])
    suffixes = ('ach', 'ami', 'owie', 'owego', 'owej', 'ego', 'iego', 'ym', 'im', 'em', 'ie', 'ow', 'a', 'u', 'y', 'i')
    terms = []
    for token in re.split(r'[^a-z0-9]+', focused):
        token = token.strip()
        if len(token) < 4 or token.isdigit() or token in stop:
            continue
        stem = token
        for suffix in suffixes:
            if stem.endswith(suffix) and len(stem) - len(suffix) >= 4:
                stem = stem[:-len(suffix)]
                break
        if stem and stem not in stop and stem not in terms:
            terms.append(stem)
        if len(terms) >= limit:
            break
    return terms[:limit]


def _ai_scene_validation_needed(ai_data, history):
    if not _best_title_from_ai(ai_data or {}):
        return False
    return len(_ai_primary_scene_terms_from_history(history or [])) >= 2


def _ai_scene_terms_confirmed_by_context(history, web_context):
    terms = _ai_primary_scene_terms_from_history(history or [])
    if len(terms) < 2:
        return True, terms, terms
    hay = _ai_fold_text(web_context or '')
    if not hay:
        return False, terms, []
    hits = []
    for term in terms:
        probes = [term]
        if len(term) >= 6:
            probes.append(term[:-1])
            probes.append(term[:5])
        if any(p and p in hay for p in probes):
            hits.append(term)
    needed = 2 if len(terms) >= 3 else len(terms)
    return len(hits) >= needed, terms, hits


def _ai_mark_scene_gate(ai_data, ok, reason, terms=None, hits=None):
    data = dict(ai_data or {})
    data['scene_gate_checked'] = True
    data['scene_gate_ok'] = bool(ok)
    data['scene_gate_reason'] = reason or ''
    data['scene_gate_terms'] = list(terms or [])[:8]
    data['scene_gate_hits'] = list(hits or [])[:8]
    return data


def _ai_downgrade_scene_gate(ai_data, history, terms=None, hits=None, reason='scene_not_confirmed'):
    data = _ai_mark_scene_gate(ai_data, False, reason, terms, hits)
    old_title = _display_title_from_ai(data) or _best_title_from_ai(data)
    old_titles = []
    for candidate_title in (
            _display_title_from_ai(data),
            _best_title_from_ai(data),
            data.get('pl_title'),
            data.get('original_title'),
            data.get('english_title'),
            data.get('title'),
            data.get('confirmation_title'),
            data.get('search_query')):
        candidate_title = str(candidate_title or '').strip()
        if candidate_title and not any(_ai_titles_share_identity(candidate_title, item) for item in old_titles):
            old_titles.append(candidate_title)
    if old_titles:
        auto_rejected = _ai_list_field(data.get('auto_rejected_titles'))
        for candidate_title in old_titles:
            if not any(_ai_titles_share_identity(candidate_title, item) for item in auto_rejected):
                auto_rejected.append(candidate_title)
        data['auto_rejected_titles'] = auto_rejected[:8]
        kept_candidates = []
        removed = False
        for item in data.get('candidates') or []:
            if isinstance(item, dict):
                candidate_title = _display_title_from_ai(item) or _ai_candidate_title_text(item) or _best_title_from_ai(item)
                if candidate_title and any(_ai_titles_share_identity(candidate_title, blocked) for blocked in old_titles):
                    removed = True
                    continue
            kept_candidates.append(item)
        if removed:
            data['candidates'] = kept_candidates
    for key in ('title', 'search_query', 'confirmation_title', 'pl_title', 'english_title', 'original_title'):
        data[key] = ''
    data['ready_to_confirm'] = False
    data['confidence'] = min(_ai_to_int(data.get('confidence')), 60)
    data['evidence_score'] = min(_ai_to_int(data.get('evidence_score')), 60)
    data['assistant_message'] = (
        u'Nie mam jeszcze potwierdzenia glownej sceny/fabuly w wynikach, wiec nie podaje tego jako pewny tytul. '
        u'Szukam dalej po scenie albo dopisz jeszcze jeden konkretny szczegol.'
    )
    try:
        log('[AI_SEARCH] SCENE_GATE blocked title={!r} reason={} terms={} hits={}'.format(
            old_title, reason, ','.join((terms or [])[:6]), ','.join((hits or [])[:6])), 1)
    except Exception:
        pass
    return data


def _build_scene_evidence_validator_prompt(history, web_context, ai_data):
    user_text = _ai_text_without_actor_examples(_chat_user_text(history or []))
    title = _display_title_from_ai(ai_data or {}) or _best_title_from_ai(ai_data or {})
    terms = _ai_primary_scene_terms_from_history(history or [])
    return (
        u'ETAP SEDZIEGO SCENY/FABULY.\n'
        u'Masz sprawdzic tylko jedno: czy proponowany tytul ma potwierdzona glowna scene/fabule z opisu uzytkownika.\n'
        u'Nie wybieraj nowego tytulu. Nie zgaduj z pamieci modelu. Uzyj tylko legalnego kontekstu web/API ponizej; dodatkowe web search tylko do potwierdzenia tej samej sceny.\n'
        u'Jesli kontekst nie potwierdza sceny/fabuly, zwroc scene_confirmed=false, ready_to_confirm=false, confidence max 60 i evidence_score max 60.\n'
        u'Jesli potwierdza, matched_rare_clues musi zawierac wpis zaczynajacy sie od "SCENA/FABULA:" i opisujacy potwierdzony konkret.\n'
        u'Zwroc WYLACZNIE JSON: {"scene_confirmed": true/false, "assistant_message":"krotko po polsku", "ready_to_confirm": true/false, "confidence":0-100, "evidence_score":0-100, "matched_rare_clues":["SCENA/FABULA: ..."], "missing_rare_clues":["..."]}.\n\n'
        u'OPIS UZYTKOWNIKA:\n' + user_text[:1200] + u'\n\n'
        u'PROPONOWANY TYTUL:\n' + title[:220] + u'\n\n'
        u'TERMY SCENY Z TEKSTU UZYTKOWNIKA:\n' + u', '.join(terms[:8]) + u'\n\n'
        u'LEGALNY KONTEKST WEB/API:\n' + (web_context or '')[:7600]
    )


def _ai_scene_validator_confirms(scene_data):
    if not isinstance(scene_data, dict):
        return False
    matched = _ai_list_field(scene_data.get('matched_rare_clues'))
    evidence_score = _ai_to_int(scene_data.get('evidence_score'), default=-1)
    if scene_data.get('scene_confirmed') is True:
        return evidence_score >= 70 and any(_ai_clue_is_declared_scene_match(clue) for clue in matched)
    return bool(scene_data.get('ready_to_confirm')) and evidence_score >= 75 and any(
        _ai_clue_is_declared_scene_match(clue) for clue in matched)


def _ai_apply_scene_validator_result(ai_data, scene_data, history, terms=None, hits=None):
    if _ai_scene_validator_confirms(scene_data):
        data = _ai_mark_scene_gate(ai_data, True, 'scene_validator', terms, hits)
        if scene_data.get('matched_rare_clues'):
            data['matched_rare_clues'] = scene_data.get('matched_rare_clues')
        if scene_data.get('missing_rare_clues') is not None:
            data['missing_rare_clues'] = scene_data.get('missing_rare_clues')
        if scene_data.get('evidence_score') is not None:
            data['evidence_score'] = _ai_to_int(scene_data.get('evidence_score'))
        log('[AI_SEARCH] SCENE_GATE validator OK title={!r}'.format(_best_title_from_ai(data)), 1)
        return data
    reason = 'scene_validator_rejected'
    try:
        reason_text = str((scene_data or {}).get('assistant_message') or '')[:120]
        if reason_text:
            reason += ':' + reason_text
    except Exception:
        pass
    return _ai_downgrade_scene_gate(ai_data, history, terms, hits, reason)


def _ai_clue_is_declared_scene_match(value):
    # ZMIANA (2026-04) [PATCH]: scena/fabula jest pierwszym warunkiem, nie zwyklym bonusem punktowym.
    # POWOD: tytul nie moze przejsc jako pewny wynik, jesli model nie oznaczyl glownej sceny jako potwierdzonej.
    folded = _ai_fold_text(value or '').strip()
    if not folded:
        return False
    declared = (
        folded.startswith('scena/fabula') or
        folded.startswith('scena:') or
        folded.startswith('fabula:') or
        folded.startswith('plot:') or
        folded.startswith('scene:')
    )
    return declared and _ai_clue_is_scene_or_plot(value)


def _ai_missing_blocks_primary_scene(value):
    folded = _ai_fold_text(value or '')
    if not folded:
        return False
    blockers = (
        'scena/fabula', 'glowny trop', 'glowna scena', 'scena', 'fabula',
        'nie potwierdz', 'brak potwierdz', 'nie zgadza', 'bez potwierdz',
    )
    return any(marker in folded for marker in blockers) and _ai_clue_is_scene_or_plot(value)


def _ai_candidate_judge_has_evidence(judged, history=None):
    # ZMIANA (2026-04) [PATCH]: promocja wymaga dowodu na rzadkie tropy, nie tylko tytulu z web search.
    # POWOD: sedzia promowal popularne falszywe tropy, bo pasowal kraj/aktor/rok bez potwierdzonej sceny.
    matched = _ai_list_field((judged or {}).get('matched_rare_clues'))
    missing = _ai_list_field((judged or {}).get('missing_rare_clues'))
    evidence_score = _ai_to_int((judged or {}).get('evidence_score'), default=-1)
    if evidence_score < 75:
        return False
    if len(matched) < 2:
        return False
    if not any(_ai_clue_is_declared_scene_match(clue) for clue in matched):
        return False
    if any(_ai_missing_blocks_primary_scene(clue) for clue in missing):
        return False
    if len(missing) > 1:
        return False
    return True


def _ai_ready_to_confirm(ai_data, history=None):
    ai_data = ai_data or {}
    title = _best_title_from_ai(ai_data)
    if not title:
        return False
    if ai_data.get('user_confirmed'):
        return True
    confidence = _ai_to_int(ai_data.get('confidence'))
    if ai_data.get('ready_to_confirm') and confidence >= _AI_CHAT_CONFIRM_CONFIDENCE:
        return True
    if confidence >= _AI_CHAT_CONFIRM_CONFIDENCE + 10:
        return True
    return False


def _ai_candidate_judge_better(current, judged, history=None, web_context=''):
    if not isinstance(judged, dict):
        return False
    new_title = _best_title_from_ai(judged)
    if _ai_title_matches_actor_example(new_title, history) or _ai_candidate_matches_actor_example(judged, history or []):
        return False
    if _ai_title_matches_rejected(new_title, history):
        return False
    new_conf = _ai_to_int(judged.get('confidence'))
    new_candidates = judged.get('candidates') or []
    if not new_title and not new_candidates:
        return False
    cur_title = _best_title_from_ai(current or {})
    cur_conf = _ai_to_int((current or {}).get('confidence'))
    cur_candidates = (current or {}).get('candidates') or []
    has_evidence = _ai_candidate_judge_has_evidence(judged, history)
    if judged.get('ready_to_confirm') and new_title:
        return has_evidence and new_conf >= 78
    if new_title and not has_evidence:
        return False
    if new_title and not cur_title and new_conf >= 78:
        return True
    if new_title and new_conf >= max(cur_conf + 10, 78):
        return True
    if new_candidates and not cur_candidates and not cur_title:
        return True
    return False


def _ask_chat_followup(ai_data, history=None):
    # ZMIANA (2026-04) [FEATURE]: pytanie AI pokazuje się w pełnym oknie czatu, nie w nagłówku klawiatury.
    # POWOD: użytkownik ma widzieć pełną historię i pełne pytanie, bez uciętego tekstu.
    # NIE ZMIENIAC: odpowiedź użytkownika wraca do historii i jest analizowana w kolejnej rundzie AI.
    result = _open_ai_chat_window(history=history or [], ai_data=ai_data, allow_confirm=False)
    if result.get('action') != 'send':
        return ''
    return (result.get('text') or '').strip()


# ---------------------------------------------------------------------------
# ZMIANA (2026-04) [FEATURE]: detekcja TAK/NIE z tekstu uzytkownika zamiast przyciskow.
# POWOD: uzytkownik pisze jak w zwyklym czacie; "tak" = szukaj, "nie" = kontynuuj.
# NIE ZMIENIAC: _is_user_confirm sprawdza TAK przed NIE zeby "tak, nie jestem pewny" nie zablokował.
# ---------------------------------------------------------------------------
_CONFIRM_TOKENS = {'tak', 'yes', 'ok', 'zgadza', 'zgadzam', 'dokładnie', 'dokladnie',
                   'właśnie', 'wlasnie', 'trafiłeś', 'trafiles', 'znalazłeś', 'znalazles',
                   'to ten', 'to ta', 'to ten film', 'to ta seria', 'szukaj', 'wyszukaj'}
_REJECT_TOKENS  = {'nie', 'no', 'zły', 'zly', 'błędny', 'bledny', 'to nie', 'nie ten',
                   'nie ta', 'nie to', 'inny', 'inny film', 'inna', 'inne'}

def _ai_text_has_phrase_token(text, phrase):
    t = _ai_fold_text(text or '').strip()
    p = _ai_fold_text(phrase or '').strip()
    if not t or not p:
        return False
    return re.search(r'(^|[^a-z0-9]){}($|[^a-z0-9])'.format(re.escape(p)), t) is not None


def _is_user_confirm(text):
    t = text or ''
    for w in _CONFIRM_TOKENS:
        if _ai_text_has_phrase_token(t, w):
            return True
    return False

def _is_user_reject(text):
    t = text or ''
    if _is_user_confirm(t):
        return False
    for w in _REJECT_TOKENS:
        if _ai_text_has_phrase_token(t, w):
            return True
    # samo "nie" jako caly komunikat
    return _ai_fold_text(t).strip() in ('nie', 'no', 'n')


def _confirm_chat_guess(ai_data, history=None):
    # ZMIANA (2026-04) [FEATURE]: potwierdzenie tekstem zamiast przyciskami TAK/NIE.
    # POWOD: uzytkownik pisze "tak"/"nie"/nowy szczegol jak w zwyklym czacie.
    # NIE ZMIENIAC: _is_user_confirm sprawdza TAK przed NIE; brak odpowiedzi = cancel(2).
    result = _open_ai_chat_window(history=history or [], ai_data=ai_data, allow_confirm=False)
    action = result.get('action')
    text = (result.get('text') or '').strip()
    if action != 'send' or not text:
        return 2, ''
    if _is_user_confirm(text):
        return 0, text
    rejected = _best_title_from_ai(ai_data)
    if _is_user_reject(text):
        base = u'Nie, to nie "{}". To inny film.'.format(rejected) if rejected else u'Nie, to nie ten film.'
        extra = text.split(' ', 1)[1].strip() if ' ' in text else ''
        return 1, base + (u' ' + extra if extra and len(extra) > 3 else u'')
    return 1, text


def _run_ai_mini_chat(provider, api_key, fields):
    """
    Live-chat: otwiera _AIChatXMLDialog ktory sam zarzadza cala rozmowa w jednym oknie.
    ZMIANA (2026-04) [FEATURE]: zastapienie petli open/close jednym oknem z watkiem AI w tle.
    NIE ZMIENIAC: zwraca (fields, ai_data) po TAK od uzytkownika, None po Anuluj.
    """
    import os, xbmcaddon
    caller  = _CALLERS[provider]
    history = list(fields.get('chat_history') or [])

    try:
        addon_path = xbmcaddon.Addon().getAddonInfo('path')
        xml_path = os.path.join(addon_path, 'resources', 'skins', 'Default', '1080i',
                                _AI_CHAT_XML_FILE)
        if not os.path.exists(xml_path):
            raise RuntimeError('Brak XML: {}'.format(xml_path))
        dialog = _AIChatXMLDialog(
            _AI_CHAT_XML_FILE, addon_path, 'Default', '1080i',
            caller=caller, api_key=api_key, provider=provider,
            history=history, addon_path=addon_path,
        )
        dialog.doModal()
        result = dict(getattr(dialog, 'result', {'action': 'cancel'}))
        del dialog
    except Exception as exc:
        log('[AI_SEARCH] live-chat window ERROR: {}'.format(_safe_exception_text(exc, 120)), 1)
        return None

    if result.get('action') != 'confirm':
        return None

    ai_data      = result.get('ai_data') or {}
    if not _ai_ready_to_confirm(ai_data, result.get('history') or []):
        log('[AI_SEARCH] LIVE_CHAT confirm rejected title={!r} conf={} evidence_score={}'.format(
            _best_title_from_ai(ai_data), ai_data.get('confidence'), ai_data.get('evidence_score')), 1)
        return None
    final_history = result.get('history') or []
    fields['fabuła']       = _chat_user_text(final_history)
    fields['chat_history'] = final_history
    log('[AI_SEARCH] LIVE_CHAT confirmed provider={} title={!r} conf={}'.format(
        provider, _best_title_from_ai(ai_data), ai_data.get('confidence')), 1)
    return fields, ai_data


# ZMIANA (2026-05) [PATCH]: bezpiecznie kończy akcję aiSearch po Anuluj jako poprawny katalog.
# POWOD: po STOP filmu Kodi ponownie odpytywało plugin://.../?action=aiSearch; endOfDirectory(False)
#   dawało GetDirectory failed i wyrzucało użytkownika z wtyczki po zamknięciu czatu.
# NIE ZMIENIAC: Anuluj w trybie AI/Google nie może zwracać succeeded=False; to świadomy powrót użytkownika, nie błąd pluginu.
def _finish_ai_cancel_directory(handle, reason='cancel'):
    if handle is None or handle < 0:
        return
    try:
        item = xbmcgui.ListItem(label=u'[COLOR gray]Anulowano wyszukiwanie AI — wróć do menu[/COLOR]')
        xbmcplugin.addDirectoryItem(handle, '', item, False)
    except Exception:
        pass
    try:
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
    except TypeError:
        xbmcplugin.endOfDirectory(handle, succeeded=True)
    except Exception:
        try:
            xbmcplugin.endOfDirectory(handle, True)
        except Exception:
            pass
    try:
        log('[AI_SEARCH] aiSearch cancelled safely reason={} -> endOfDirectory succeeded=True'.format(reason), 1)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Obsługa pustych wyników — zamiast crashu pokazuje komunikat
# ---------------------------------------------------------------------------
def _show_no_results(search_query, handle):
    import sys
    xbmcgui.Dialog().notification(
        'FanVodPL AI',
        u'Brak wyników dla: "{}". Spróbuj inaczej opisać.'.format(search_query[:40]),
        xbmcgui.NOTIFICATION_WARNING,
        5000,
    )
    # Dodaj jeden pusty element żeby Kodi nie crashował
    item = xbmcgui.ListItem(label=u'[COLOR gray]Brak wyników — wróć i spróbuj ponownie[/COLOR]')
    xbmcplugin.addDirectoryItem(handle, '', item, False)
    xbmcplugin.endOfDirectory(handle, succeeded=True)

# ---------------------------------------------------------------------------
# Główna funkcja
# ---------------------------------------------------------------------------
def ai_search_action():
    import sys
    handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1

    provider = _normalize_ai_provider(control.setting('ai_search.provider') or _AI_DEFAULT_PROVIDER, log_change=True)
    key_id   = 'ai_search.key.' + provider.lower()
    api_key  = (control.setting(key_id) or '').strip()

    # --- Brak klucza ---
    if not api_key:
        url_hint = _KEY_URLS.get(provider, '')
        xbmcgui.Dialog().ok(
            'FanVodPL — Wyszukiwanie AI',
            'Brak klucza API dla providera: [B]{}[/B]\n\n'
            'Utworz lub wklej klucz API z: {}\n\n'
            'Dodaj go w: [I]Ustawienia → Wyszukiwanie AI[/I]'.format(provider, url_hint)
        )
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    # --- Mini-czat wejściowy ---
    fields = _get_user_input()
    if not fields:
        # ZMIANA (2026-05) [PATCH]: traktuj brak pól jak świadome przerwanie akcji, nie awarię katalogu.
        # POWOD: succeeded=False powoduje w Kodi GetDirectory failed i wyrzucenie z wtyczki przy powrocie z AI/Google.
        # NIE ZMIENIAC: flow bez danych wejściowych ma kończyć aiSearch czysto, bez ponownego otwierania czatu.
        _finish_ai_cancel_directory(handle, reason='empty_fields')
        return

    chat_result = _run_ai_mini_chat(provider, api_key, fields)
    if not chat_result:
        # ZMIANA (2026-05) [PATCH]: Anuluj w oknie AI/Google kończy katalog sukcesem zamiast błędem.
        # POWOD: po STOP filmu użytkownik wracał do czatu; kliknięcie Anuluj dawało endOfDirectory(False)
        #   i Kodi zgłaszało CGUIMediaWindow::GetDirectory(...aiSearch) failed.
        # NIE ZMIENIAC: brak potwierdzonego tytułu to anulowanie użytkownika, nie błąd runtime.
        _finish_ai_cancel_directory(handle, reason='chat_cancel')
        return

    fields, ai_data = chat_result
    country_hint = _detect_user_country_hint(fields)
    media_type_hint = _detect_user_media_type_hint(fields=fields)
    ai_data = _ai_apply_media_type_hint(ai_data, fields=fields)

    # --- Dane końcowe po potwierdzeniu użytkownika ---
    search_query = _best_title_from_ai(ai_data) or fields.get('fabuła', '')
    year_od = ''
    year_do = ''
    ai_year = str(ai_data.get('year') or '').strip()
    if ai_year and re.match(r'^\d{4}$', ai_year):
        year_od = year_do = ai_year

    search_plan = _build_ai_search_plan(ai_data, search_query, country_hint, media_type_hint)
    first_candidate = search_plan[0] if search_plan else {}
    search_query = (first_candidate.get('title') or first_candidate.get('pl_title') or search_query).strip()
    confidence = int(first_candidate.get('confidence') or ai_data.get('confidence') or 0)

    log('[AI_SEARCH] MINI_CHAT confirmed provider={} hint={} → plan={} year={}-{} conf={}'.format(
        provider, country_hint or '-', [(c.get('title') or c.get('pl_title'), c.get('confidence')) for c in search_plan],
        year_od, year_do, confidence), 1)

    # --- Wyszukiwanie w TMDB ---
    from resources.lib.indexers.movies import movies as MoviesClass
    try:
        m_obj = MoviesClass()

        # ZMIANA (2026-04) [FEATURE]: wybiera najlepszy kandydat z planu AI i zachowuje fallback multi.
        # POWOD: zamiast jednego dosłownego search_query AI przygotowuje kilka tropów, a kod nie traci starszej kompatybilności.
        # NIE ZMIENIAC: search_term może kończyć katalog Kodi, więc nie wywołujemy kilku wyszukiwań naraz bez potwierdzonego API zwrotu wyników.
        candidate = search_plan[0] if search_plan else {
            'title': search_query,
            'pl_title': '',
            'type': '',
            'confidence': confidence,
        }
        term = (candidate.get('title') or candidate.get('pl_title') or search_query).strip()
        media_type = candidate.get('type') or media_type_hint or 'movie'
        confidence = int(candidate.get('confidence') or confidence or 0)
        term, tmdb_year = _normalize_ai_title_year(term, candidate.get('year') or year_od)

        # ZMIANA (2026-04) [PATCH]: przekazuje twardy filtr kraju do warstwy TMDB.
        # POWOD: sam prompt AI nie wystarczał — po wyborze Polski potrafił przejść zagraniczny wynik z TMDB.
        # NIE ZMIENIAC: country_hint ma filtrować wyniki po original_language w movies.py, bez zwiększania liczby zapytań.
        tmdb_country_filter = country_hint if country_hint in ('polish', 'foreign') else ''
        ai_display_title = (candidate.get('pl_title') or ai_data.get('pl_title') or '').strip()
        ai_original_title = (
            candidate.get('original_title') or ai_data.get('original_title') or
            candidate.get('title') or term
        ).strip()

        if confidence >= 70:
            search_type = media_type if media_type in ('movie', 'tv') else 'movie'
            log('[AI_SEARCH] HIGH conf={} hint={} → {}: {} year={}'.format(
                confidence, tmdb_country_filter or '-', search_type, term, tmdb_year or '-'), 1)
            if search_type == 'tv':
                from resources.lib.indexers.tvshows import tvshows as TVShowsClass
                TVShowsClass().search_term(term, year=tmdb_year or '')
                return
            search_kwargs = {
                's_type': search_type,
                'country_filter': tmdb_country_filter,
            }
            if tmdb_year and search_type == 'movie':
                search_kwargs['year'] = tmdb_year
            m_obj.search_term(
                term,
                ai_display_title=ai_display_title,
                ai_original_title=ai_original_title,
                **search_kwargs
            )
        else:
            # Spróbuj po polskim tytule jeśli AI go zna, a potem szerzej przez multi.
            term = (candidate.get('pl_title') or term).strip()
            term, tmdb_year = _normalize_ai_title_year(term, tmdb_year)
            if tmdb_year:
                term = u'{} y:{}'.format(term, tmdb_year)
            if media_type == 'tv':
                log('[AI_SEARCH] LOW conf={} hint={} -> tv: {}'.format(
                    confidence, tmdb_country_filter or '-', term), 1)
                from resources.lib.indexers.tvshows import tvshows as TVShowsClass
                TVShowsClass().search_term(term, year=tmdb_year or '')
                return
            log('[AI_SEARCH] LOW conf={} hint={} → multi: {}'.format(
                confidence, tmdb_country_filter or '-', term), 1)
            m_obj.search_term(
                term,
                s_type='multi',
                country_filter=tmdb_country_filter,
                ai_display_title=ai_display_title,
                ai_original_title=ai_original_title,
            )

    except Exception as exc:
        safe_exc = _safe_exception_text(exc, 120)
        log('[AI_SEARCH] search ERROR: {}'.format(safe_exc), 1)
        _show_no_results(search_query, handle)
        log('[AI_SEARCH] ERROR provider={} exc={}'.format(provider, safe_exc), 1)
        xbmcgui.Dialog().notification(
            'FanVodPL AI',
            u'Błąd [{}]: {}'.format(provider, safe_exc[:60]),
            xbmcgui.NOTIFICATION_ERROR, 5000,
        )

    # --- Wyszukiwanie w TMDB ---


# ---------------------------------------------------------------------------
# Provider: Gemini  (AI Studio: free tier / platne limity)
# Rejestracja: https://aistudio.google.com → Get API Key
# ---------------------------------------------------------------------------
def _call_gemini(api_key, query):
    import requests
    model = _gemini_model_choice()
    url = 'https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent'.format(model)
    headers = {'Content-Type': 'application/json', 'x-goog-api-key': api_key}

    def _extract_gemini_text(data):
        parts = (((data.get('candidates') or [{}])[0].get('content') or {}).get('parts') or [])
        return ''.join([p.get('text', '') for p in parts if isinstance(p, dict)]).strip()

    def _is_gemini_json_answer(text):
        try:
            parsed = _parse_response(text)
            return isinstance(parsed, dict) and bool(parsed)
        except Exception:
            return False

    def _repair_gemini_json(raw_text):
        if not raw_text or _is_gemini_json_answer(raw_text):
            return raw_text
        repair_prompt = (
            u'Przepisz ponizsza odpowiedz do poprawnego JSON zgodnego ze schematem systemowym. '
            u'Nie dodawaj tekstu poza JSON. Nie wymyslaj nowych faktow, tylko przenies tytuly, kandydatow, pewnosc i pytanie.\n\n'
            u'ODPOWIEDZ DO NAPRAWY:\n' + raw_text[:5000]
        )
        try:
            rr = requests.post(url, headers=headers, json={
                'contents': [{'parts': [{'text': repair_prompt}]}],
                'systemInstruction': {'parts': [{'text': _SYSTEM_PROMPT}]},
                'generationConfig': {'maxOutputTokens': 1400, 'temperature': 0.0, 'responseMimeType': 'application/json'},
            }, timeout=20)
            if rr.status_code < 400:
                fixed = _extract_gemini_text(rr.json())
                if _is_gemini_json_answer(fixed):
                    log('[AI_SEARCH] Gemini JSON repair used', 1)
                    return fixed
        except Exception as exc:
            log('[AI_SEARCH] Gemini JSON repair skipped: {}'.format(_safe_exception_text(exc, 100)), 1)
        return raw_text
    # ZMIANA (2026-05) [PATCH]: pominięto próbę google_search+JSON mime — zawsze zwracała status=400.
    # POWOD: Gemini API nie pozwala łączyć google_search grounding z responseMimeType application/json
    #        (błąd potwierdzony w logach przy każdym wywołaniu). JSON parsowany przez _repair_gemini_json.
    # NIE ZMIENIAC: nie dodawać z powrotem responseMimeType do zapytania z tools google_search.
    r = requests.post(url, headers=headers, json={
        'contents': [{'parts': [{'text': query}]}],
        'tools': [{'google_search': {}}],
        'systemInstruction': {'parts': [{'text': _SYSTEM_PROMPT}]},
        'generationConfig': {'maxOutputTokens': 1400, 'temperature': 0.1},
    }, timeout=30)
    r.raise_for_status()
    data = r.json()
    usage = data.get('usageMetadata') or {}
    _log_ai_token_usage(
        'Gemini',
        model,
        input_tokens=usage.get('promptTokenCount'),
        output_tokens=usage.get('candidatesTokenCount'),
        total_tokens=usage.get('totalTokenCount'),
        extra={
            'cached': usage.get('cachedContentTokenCount'),
            'thoughts': usage.get('thoughtsTokenCount'),
            'tool': usage.get('toolUsePromptTokenCount'),
        },
    )
    text = _repair_gemini_json(_extract_gemini_text(data))
    try:
        srcs = _gemini_sources_from_response(data)
        query_count = _gemini_grounding_query_count(data)
        log('[AI_SEARCH] Gemini final google_search grounding: sources={} queries={}'.format(
            len(srcs), query_count), 1)
    except Exception:
        pass
    return text

# ---------------------------------------------------------------------------
# Provider: OpenAI  (platne limity API)
# Rejestracja: https://platform.openai.com
# ---------------------------------------------------------------------------
def _call_openai(api_key, query):
    # ZMIANA (2026-04) [PATCH]: OpenAI używa Responses API + web_search zamiast zwykłego chat/completions.
    # POWOD: sama odpowiedź GPT bez tools nie przegląda internetu; web_search daje live web podobnie do ChatGPT Search.
    # NIE ZMIENIAC: fallback web_search_preview/gpt-4o-search-preview chroni starsze konta/API przed twardym crashem.
    import requests

    def _extract_responses_text(data):
        if data.get('output_text'):
            return data.get('output_text')
        out = []
        for item in data.get('output', []) or []:
            if item.get('type') == 'message':
                for part in item.get('content', []) or []:
                    if part.get('type') in ('output_text', 'text'):
                        out.append(part.get('text', ''))
        return ''.join(out).strip()

    _primary_model, fallback_model = _openai_model_choice()
    r = None
    model = _primary_model
    # ZMIANA (2026-05) [PATCH]: OpenAI próbuje najpierw GPT-5.4, potem GPT-5.4 mini i GPT-4.1 w Responses API.
    # POWOD: GPT-5.4 jest docelowym modelem wyszukiwania, ale brak dostępu na koncie nie może zablokować całego czatu AI.
    # NIE ZMIENIAC: każdy wariant używa oficjalnego web_search/tool_choice=required; nie dodajemy scrapowania HTML stron.
    for model in _openai_response_model_candidates():
        payload = {
            'model': model,
            'tools': [{'type': 'web_search', 'search_context_size': 'high'}],
            'tool_choice': 'required',
            'include': ['web_search_call.action.sources'],
            'text': {'format': {'type': 'json_object'}},
            'input': [
                {'role': 'system', 'content': _SYSTEM_PROMPT},
                {'role': 'user', 'content': query},
            ],
            'max_output_tokens': 1400,
        }
        r = requests.post(
            'https://api.openai.com/v1/responses',
            headers={'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'},
            json=payload,
            timeout=45,
        )
        if r.status_code >= 400:
            log('[AI_SEARCH] OpenAI web_search unavailable status={} model={} fallback=web_search_preview'.format(r.status_code, model), 1)
            payload['tools'] = [{'type': 'web_search_preview'}]
            r = requests.post(
                'https://api.openai.com/v1/responses',
                headers={'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'},
                json=payload,
                timeout=45,
            )
        if r.status_code < 400:
            break
    if r.status_code < 400:
        data = r.json()
        usage = data.get('usage') or {}
        output_details = usage.get('output_tokens_details') or {}
        _log_ai_token_usage(
            'OpenAI',
            model,
            input_tokens=usage.get('input_tokens'),
            output_tokens=usage.get('output_tokens'),
            total_tokens=usage.get('total_tokens'),
            extra={'reasoning': output_details.get('reasoning_tokens')},
        )
        return _extract_responses_text(data)

    # ZMIANA (2026-05) [PATCH]: Chat Completions fallback próbuje nowy model search, a potem legacy search-preview.
    # POWOD: jeśli Responses web_search jest niedostępny na koncie, użytkownik nadal ma dostać wynik z oficjalnego search API.
    # NIE ZMIENIAC: fallbacki nie wykonują scrapowania; używają tylko web_search_options.
    last_response = None
    for chat_model in (fallback_model, _openai_legacy_search_model()):
        r2 = requests.post(
            'https://api.openai.com/v1/chat/completions',
            headers={'Authorization': 'Bearer ' + api_key, 'Content-Type': 'application/json'},
            json={
                'model': chat_model,
                'web_search_options': {},
                'messages': [
                    {'role': 'system', 'content': _SYSTEM_PROMPT},
                    {'role': 'user', 'content': query},
                ],
                'max_tokens': 1400,
            },
            timeout=45,
        )
        last_response = r2
        if r2.status_code < 400:
            data2 = r2.json()
            _log_openai_compatible_usage('OpenAI', chat_model, data2)
            return data2['choices'][0]['message']['content']
        log('[AI_SEARCH] OpenAI chat fallback unavailable status={} model={}'.format(r2.status_code, chat_model), 1)
    last_response.raise_for_status()

# ---------------------------------------------------------------------------
# Provider: Claude (Anthropic)  (platne limity API)
# Rejestracja: https://console.anthropic.com
# ---------------------------------------------------------------------------
def _call_claude(api_key, query):
    import requests
    model = 'claude-sonnet-4-5-20251022'
    headers = {
        'x-api-key': api_key,
        'anthropic-version': '2023-06-01',
        'anthropic-beta': 'web-search-2025-03-05',
        'Content-Type': 'application/json',
    }
    payload = {
        'model': model,
        'max_tokens': 1400,
        'system': _SYSTEM_PROMPT,
        'messages': [{'role': 'user', 'content': query}],
        'tools': [{'type': 'web_search_20250305', 'name': 'web_search', 'max_uses': 3}],
    }
    r = requests.post(
        'https://api.anthropic.com/v1/messages',
        headers=headers,
        json=payload,
        timeout=35,
    )
    if r.status_code >= 400:
        log('[AI_SEARCH] Claude web_search unavailable status={} fallback=no_tool'.format(r.status_code), 1)
        headers_no_beta = {k: v for k, v in headers.items() if k != 'anthropic-beta'}
        payload.pop('tools', None)
        r = requests.post(
            'https://api.anthropic.com/v1/messages',
            headers=headers_no_beta,
            json=payload,
            timeout=15,
        )
    r.raise_for_status()
    data = r.json()
    usage = data.get('usage') or {}
    _log_ai_token_usage(
        'Claude',
        model,
        input_tokens=usage.get('input_tokens'),
        output_tokens=usage.get('output_tokens'),
        extra={
            'cache_create': usage.get('cache_creation_input_tokens'),
            'cache_read': usage.get('cache_read_input_tokens'),
        },
    )
    out = []
    for block in data.get('content') or []:
        if isinstance(block, dict) and block.get('type') == 'text':
            out.append(block.get('text') or '')
    try:
        srcs = _claude_sources_from_response(data)
        search_count = _claude_web_search_count(data)
        log('[AI_SEARCH] Claude final web_search grounding: sources={} searches={}'.format(
            len(srcs), search_count), 1)
    except Exception:
        pass
    return ''.join(out).strip()

# ---------------------------------------------------------------------------
# Mapa providerów
# ---------------------------------------------------------------------------
_CALLERS = {
    'Gemini':  _call_gemini,
    'OpenAI':  _call_openai,
    'Claude':  _call_claude,
}

# Teksty pomocnicze — gdzie uzyskać klucz
_KEY_URLS = {
    'Gemini':  'aistudio.google.com  (free tier / platne limity)',
    'OpenAI':  'platform.openai.com  (platne limity API)',
    'Claude':  'console.anthropic.com  (platne limity API)',
}

# ---------------------------------------------------------------------------
# Parser odpowiedzi AI
# ---------------------------------------------------------------------------
def _parse_response(text):
    # ZMIANA (2026-04) [PATCH]: odporny parser odpowiedzi AI + awaryjne wyciąganie pól mini-czatu.
    # POWOD: LLM czasem zwraca niepełny JSON; mini-czat musi odzyskać pytanie, tytuł i confidence zamiast wracać do szukania po całym opisie.
    # NIE ZMIENIAC: jeśli JSON jest uszkodzony, próbujemy odzyskać pola rozmowy oraz search_query/pl_title/year/confidence.
    text = (text or '').strip()
    if not text:
        return {}

    m = re.search(r'```(?:json)?\s*([\s\S]+?)\s*```', text)
    if m:
        text = m.group(1).strip()

    candidates = [text]
    start = text.find('{')
    end = text.rfind('}')
    if start != -1 and end != -1 and end > start:
        candidates.append(text[start:end + 1].strip())

    cleaned = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', ' ', text)
    candidates.append(cleaned.strip())

    for candidate in candidates:
        if not candidate:
            continue
        try:
            parsed = json.loads(candidate)
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            pass

    def _extract_string(key):
        pattern = r'"' + re.escape(key) + r'"\s*:\s*"((?:\\.|[^"\\])*)"'
        match = re.search(pattern, text)
        if match:
            raw = match.group(1)
            try:
                return json.loads('"' + raw + '"')
            except Exception:
                return raw.replace('\\"', '"').strip()

        pattern = r'"' + re.escape(key) + r'"\s*:\s*"([^"\r\n,}]*)'
        match = re.search(pattern, text)
        return match.group(1).strip() if match else ''

    def _extract_number(key):
        match = re.search(r'"' + re.escape(key) + r'"\s*:\s*(\d+)', text)
        if not match:
            return 0
        try:
            return int(match.group(1))
        except Exception:
            return 0

    def _extract_bool(key):
        match = re.search(r'"' + re.escape(key) + r'"\s*:\s*(true|false)', text, re.I)
        if not match:
            return False
        return match.group(1).lower() == 'true'

    recovered = {
        'assistant_message': _extract_string('assistant_message'),
        'next_question': _extract_string('next_question'),
        'ready_to_confirm': _extract_bool('ready_to_confirm'),
        'confirmation_title': _extract_string('confirmation_title'),
        'search_query': _extract_string('search_query'),
        'english_title': _extract_string('english_title'),
        'pl_title': _extract_string('pl_title'),
        'original_title': _extract_string('original_title'),
        'is_polish': _extract_bool('is_polish'),
        'year': _extract_string('year'),
        'type': _extract_string('type') or 'movie',
        'confidence': _extract_number('confidence'),
        'candidates': [],
        'fallback_queries': [],
    }

    if (recovered['assistant_message'] or recovered['next_question'] or recovered['search_query'] or
            recovered['pl_title'] or recovered['english_title'] or recovered['original_title'] or
            recovered['confirmation_title']):
        if not recovered['confidence'] and (recovered['search_query'] or recovered['confirmation_title']):
            recovered['confidence'] = 75
        try:
            log('[AI_SEARCH] JSON parse salvage: recovered={!r}'.format(recovered), 1)
        except Exception:
            pass
        return recovered

    try:
        log('[AI_SEARCH] JSON parse fallback: invalid AI response prefix={!r}'.format(text[:180]), 1)
    except Exception:
        pass
    return {}

# ---------------------------------------------------------------------------
# Wyszukiwanie po zakresie lat (od / do)
# ---------------------------------------------------------------------------
def year_range_search_action():
    import sys
    handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1

    # --- Pole: OD ---
    kb = control.keyboard('', u'Od roku (np. 2016)')
    kb.doModal()
    if not kb.isConfirmed():
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    year_from = (kb.getText() or '').strip()

    m = re.search(r'\b(19|20)\d{2}\b', year_from)
    year_from = m.group(0) if m else ''
    if not year_from:
        xbmcgui.Dialog().notification('FanVodPL', u'Nieprawidłowy rok "od"', xbmcgui.NOTIFICATION_ERROR, 3000)
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    # --- Pole: DO ---
    kb = control.keyboard('', u'Do roku (np. 2025)')
    kb.doModal()
    if not kb.isConfirmed():
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    year_to = (kb.getText() or '').strip()

    m = re.search(r'\b(19|20)\d{2}\b', year_to)
    year_to = m.group(0) if m else year_from  # fallback: ten sam rok

    # Upewnij się że od <= do
    if int(year_from) > int(year_to):
        year_from, year_to = year_to, year_from

    date_from = year_from + '-01-01'
    date_to   = year_to   + '-12-31'

    xbmcgui.Dialog().notification(
        'FanVodPL',
        u'Szukam filmów {}\u2013{}…'.format(year_from, year_to),
        xbmcgui.NOTIFICATION_INFO,
        2000,
    )

    log('[YEAR_RANGE] {}-{}'.format(year_from, year_to), 1)

    from resources.lib.indexers.movies import movies as MoviesClass
    m = MoviesClass()
    url = m.tmdb_discover_years % (date_from, date_to)
    movies_mod = __import__('resources.lib.indexers.movies', fromlist=['movies'])
    movies_mod.movies.get(m, url, category=u'Filmy {}\u2013{}'.format(year_from, year_to))
