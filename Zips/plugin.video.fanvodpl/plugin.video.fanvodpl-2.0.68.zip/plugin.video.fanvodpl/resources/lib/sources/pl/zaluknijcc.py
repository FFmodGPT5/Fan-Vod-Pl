# -*- coding: UTF-8 -*-
import re
from ptw.libraries.client import parseDOM
from ptw.libraries import log_utils
from ptw.libraries import source_utils
from ptw.libraries import control
from ptw.libraries.log_utils import log, fflog
from ptw.debug import log_exception, fflog_exc
from requests.compat import urlparse
from urllib.parse import quote_plus
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        # self.domains = ["zaluknij.cc"]  # nie uzywane nigdzie
        self.search_title = []
        self.base_link =   "https://zaluknij.cc"
        self.search_link = "https://zaluknij.cc/wyszukiwarka?phrase="
        self.useragent =  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0"
        self.headers = {
            'Referer': 'https://zaluknij.cc/',
            # "Host": "zaluknij.cc",
            'user-agent': self.useragent,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
            # "DNT": "1",
            # "Upgrade-Insecure-Requests": "1",
            }

        if UA := control.setting("zaluknijcc.ua").strip().strip('"\''):
            self.headers.update({"User-Agent": UA})
            pass

        cookies = ""
        cf = control.setting("zaluknijcc.cf").strip().strip('"\'')
        cookies += ("; cf_clearance=" + cf) if cf else ""
        cookies = cookies.strip("; ")
        if cookies:
            self.headers.update({'Cookie': cookies})

        self.sess = requests.Session()


    def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        # fflog(f'{title=} {localtitle=} {year=} {kwargs=}')
        year_alt = kwargs.get("year_alt")
        if year_alt:
            year = (year, year_alt)
        return self.search(title, localtitle, year, 'movie', aliases)


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, **kwargs):
        # fflog(f'{tvshowtitle=} {localtvshowtitle=} {year=} {kwargs=}')
        year2 = None
        year_alt = 0
        year_alt = kwargs.get("year_alt")
        if year_alt:
            year2 = (year, year_alt)
        premiered = kwargs.get("spremiered")  # ma to być data premiery szukanego sezonu
        if premiered:
            year2 = [year, year_alt, premiered]
        if year2:
            year = year2
        return self.search(tvshowtitle, localtvshowtitle, year, 'tvshow', aliases)


    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        # fflog(f'{url=} {season=} {episode=} {premiered=} {kwargs=}')
        absolute_episode = kwargs.get("absolute_episode")
        return self.search_ep(url, season, episode, absolute_episode)


    def search(self, title, localtitle, year, type_, aliases=None):
        try:
            if not title:
                return

            # przeważnie jest tylko polski tytuł, więc zamianka
            title, localtitle = localtitle, title

            title = title.lower()
            localtitle = localtitle.lower()

            if title == localtitle and aliases:
                originalname = [a for a in aliases if "originalname" in a]
                originalname = originalname[0]["originalname"] if originalname else ""
                originalname = "" if source_utils.czy_litery_krzaczki(originalname) else originalname
                if originalname:
                    title = originalname.lower()


            # pierwsze szukanie
            url = self.do_search(title, year, type_)

            # kolejne szukanie, jeśli poprzednie nie przyniosło rezultatu
            if not url and localtitle and localtitle != title:
                control.sleep(500)
                url = self.do_search(localtitle, year, type_)


            # i kolejne szukania, jeśli dalej brak wyniku
            title1 = title
            localtitle1 = localtitle
            # '.' na ':'
            if not url and "." in title1:
                title1 = title1.replace(".", ":")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and "." in localtitle1:
                localtitle1 = localtitle1.replace(".", ":")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # "–" na "-"  i  '-' na ''
            if not url and any(m in title1 for m in ["–", "-"]):
                title1 = title1.replace("–", "-").replace(" - ", " ")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and any(m in localtitle1 for m in ["–", "-"]):
                localtitle1 = localtitle1.replace("–", "-").replace(" - ", " ")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # i kolejne szukania, jeśli dalej brak wyniku
            # '.' na ''
            if not url and "." in title1:
                title1 = title1.replace(".", "")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and "." in localtitle1:
                localtitle1 = localtitle1.replace(".", "")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # i kolejne szukania, jeśli dalej brak wyniku
            # ':' na ''
            if not url and ":" in title1:
                title1 = title1.replace(":", "")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and ":" in localtitle1:
                localtitle1 = localtitle1.replace(":", "")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # i kolejne szukania, jeśli dalej brak wyniku
            # "'" na ''
            if not url and "'" in title1:
                title1 = title1.replace("'", "")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and "'" in localtitle1:
                localtitle1 = localtitle1.replace("'", "")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # i kolejne szukania, jeśli dalej brak wyniku
            # "!" na ''
            if not url and "!" in title1:
                title1 = title1.replace("!", "")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and "!" in localtitle1:
                localtitle1 = localtitle1.replace("!", "")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # i kolejne szukania, jeśli dalej brak wyniku
            # "?" na ''
            if not url and "?" in title1:
                title1 = title1.replace("?", "")
                control.sleep(500)
                url = self.do_search(title1, year, type_, True)
            if not url and "?" in localtitle1:
                localtitle1 = localtitle1.replace("?", "")
                if localtitle1 != title1:
                    control.sleep(500)
                    url = self.do_search(localtitle1, year, type_, True)

            # PONIŻSZE MOGĄ DAWAĆ NIEPRAWDZIWE WYNIKI, bo nie jest sprawdzany tytuł
            if not control.settings.getBool("zaluknijcc.validate_full_title"):
                fflog(f'validate_full_title={control.settings.getBool("zaluknijcc.validate_full_title")}')
                # Fix if end of title char makes a search problem
                if not url:
                    title1 = title[:-1]  # czy title1 lepiej ?
                    if len(title1) > 1:
                        control.sleep(500)
                        url = self.do_search(title1, year, type_, False)
                        if url:
                            fflog('Uwaga! znaleziona pozycja może nie być tą, którą chcemy')
                            pass
                if not url and localtitle and localtitle != title:
                    localtitle1 = localtitle[:-1]  # czy localtitle1 lepiej ?
                    if len(localtitle1) > 1:
                        control.sleep(500)
                        url = self.do_search(localtitle1, year, type_, False)
                        if url:
                            fflog('Uwaga! znaleziona pozycja może nie być tą, którą chcemy')
                            pass

                # Search title phrase before ':'
                if not url and ":" in title:
                    split_title = title.split(":")[0]
                    control.sleep(500)
                    url = self.do_search(split_title, year, type_, False)
                    if url:
                        fflog('Uwaga! znaleziona pozycja może nie być tą, którą chcemy')
                        pass
                if not url and ":" in localtitle and localtitle != title:
                    split_title = localtitle.split(":")[0]
                    control.sleep(500)
                    url = self.do_search(split_title, year, type_, False)
                    if url:
                        fflog('Uwaga! znaleziona pozycja może nie być tą, którą chcemy')
                        pass

            return url
        except Exception:
            #log_exception(1)
            fflog_exc(1)
            pass


    def do_search(self, title, year, type_, validate_full_title=True):
        # print("[ZaluknijCC.py] search_title: ", title)

        # title = title.lower()
        if title in self.search_title:
            # fflog(f"search_title: {title=} has already been searched")
            return
        else:
            self.search_title.append(title)

        fflog(f"search_title: {title=} {type_=} {year=}  {validate_full_title=}")

        if not title:
            return

        fout = []
        sout = []
        results = []
        out_url = ''

        search_url = f'{self.search_link}{quote_plus(title)}'
        # fflog(f'{search_url=}')

        req = self.sess.get(search_url, headers=self.headers, timeout=60, verify=False)
        #fflog(f'{req=} {req.status_code=}')

        if req.status_code != 200:
            msg = f'Odpowiedź z serwera: {req.status_code}'
            fflog(msg)
            if not control.window.getProperty("blocked_sources_extend") == 'break':
                control.infoDialog(msg, 'Zaluknij', "WARNING")
            if req.status_code == 403:
                fflog(f'prawdopodobnie włączona weryfikacja cloudflare')
                # fflog(f'{req.text=}')
                return

        html = req.text

        links = parseDOM(html, 'div', attrs={'id': 'advanced-search'})
        if links:
            links = links[0]
        else:
            if "<body" not in html:
                fflog(f'{html=}', 1)
            else:
                fflog('wystąpił jakiś problem')
                fflog(f'{html=}', 0)               
            # html='Database connection could not be established.'  # też trafiłem na taki komunikat
            return

        links = parseDOM(links, 'div', attrs={'class': r'col-sm-\d+'})
        # fflog(f'{len(links)=}')

        for link in links:
            # fflog(f'{link=}')
            if 'href' in link:
                href  = parseDOM(link, 'a', ret='href')[0]
                tytul = parseDOM(link, 'div', attrs={'class': 'title'})[0]
                tytul = tytul.replace(" (Edycja kolorowa)", "")
                # fflog(f'{tytul=} {href=}')

                if not validate_full_title or re.search(f'( / |^){re.escape(title)}( / |$)', tytul.lower()):
                    # pasuje tytuł
                    if 'serial-online' in href or 'seasons' in href:
                        sout.append({'title': tytul, 'url': href})
                    else:
                        fout.append({'title': tytul, 'url': href})

        if type_ == 'movie':
            results = fout
        elif type_ == 'tvshow':
            results = sout
        # fflog(f'{results=}')

        results.sort(key=lambda k: len(k['title']), reverse=True)  # najdłuższe tytuły na początek listy?
        # fflog(f'{len(results)=}')

        if year:
            year_alt = 0
            premiered = 0
            # fflog(f'{year=}')
            # if isinstance(year, tuple):
            if isinstance(year, (tuple, list)):
                if len(year) == 3:
                    year, year_alt, premiered = year
                    premiered = re.findall(r"\d{4}", premiered)
                    premiered = int(premiered[0]) if premiered else 0
                else:
                    year, year_alt = year
                year_alt = int(year_alt) if year_alt else 0
            # fflog(f'{year=}')
            year = int(year)
            if year_alt:
                years = [year, year_alt]
            else:
                years = [year]
            if premiered:
                years += [premiered]
            if type_ == 'movie':  # czy dla seriali też trzeba ?
                years += [year-1]
                years += [year+1]  # jak premiera w Polsce jest w następnym roku niż światowa, to ten serwis podaje rok w Polsce
            if type_ == 'tvshow':
                years += [year+1]
                # years += [year-1]  # jeszcze nie trafiłem
        years = list(dict.fromkeys(years))  # pozbycie się duplikatów
        # fflog(f'{years=}')

        date = "0"

        for url in results:
            if type_ == 'movie':
                date = str(url['url'])[-4:]  # znaleziona data w adresie url
                # fflog(f"w url'u  {date=}")
            elif type_ == 'tvshow':
                control.sleep(500)
                html = self.sess.get(url['url'], headers=self.headers, timeout=60, verify=False)
                if not html:
                    fflog(f'{html=}')
                    continue
                html = html.text
                try:
                    date = parseDOM(html, 'div', attrs={'class': 'info'})
                    date = (parseDOM(date, 'li')[-1:])[0]
                except:
                    date = "0"
            # fflog(f'{year=} {date=}')
            if year and date.isnumeric() and int(date):
                #if int(date) == int(year):
                if int(date) in years:
                    # fflog(f'pasuje {url=}')
                    out_url = url['url']
                    break
                else:
                    fflog(f'odrzucone z powodu braku dopasowania daty i roku  {date=}  dla  {url=}')
            else:
                out_url = url['url']
                break

        # fflog(f'{out_url=}') if out_url else ""
        fflog(f'out {url=}') if out_url else ""
        if (out_url and (
                        not validate_full_title
                        or  year and date.isnumeric() and int(date) and year != int(date)
                        or True  # a może zawsze warto?
                        )
            ):
            tytul = url['title']
            # fflog(f'{tytul=}',1,1)
            if date.isnumeric() and int(date):
                tytul += f" ({date})"
            return (out_url, tytul)
        return out_url


    def search_ep(self, url, season, episode, absolute_episode=0):
        # fflog(f'{url=} {season=} {episode=} {absolute_episode=}',1,1)

        if isinstance(url, tuple):
            info2 = url[1]
            url = url[0]
        else:
            info2 = ''

        if not url:
            return

        html = self.sess.get(url, headers=self.headers, timeout=60, verify=False)

        if html.status_code != 200:
            fflog(f'otrzymano niestandardowy kod odpowiedzi z serwera: {html.status_code}')
            if html.status_code == 403:
                fflog(f'prawdopodobnie włączona weryfikacja cloudflare')
                # fflog(f'{req.text=}')
                return

        html = html.text

        sesres = parseDOM(html, 'ul', attrs={'id': 'episode-list'})
        if sesres:
            sesres = sesres[0]
        else:
            fflog(f'{sesres=}',1,1)
            return

        sezony = re.findall(r'(<span>.*?</ul>)', sesres, re.DOTALL)
        # fflog(f'{sezony=}',1,1)

        episode_url = ''
        should_break = False
        # fflog(f'{len(sezony)=}',1,1)
        for sezon in sezony:
            if should_break:
                break
            sesx = parseDOM(sezon, 'span')
            ses = ''
            if sesx:
                mch = re.search(r'(\d+)', sesx[0], re.DOTALL)
                ses = mch[1] if mch else '0'
            eps = parseDOM(sezon, 'li')
            # fflog(f'{len(eps)=}',1,1)
            for ep in eps:
                href = parseDOM(ep, 'a', ret='href')[0]
                tyt2 = parseDOM(ep, 'a')[0]
                epis = re.findall(r's\d+e(\d+)', tyt2)[0]
                # fflog(f'{ses=} {season=} {epis=} {episode=}',1,1)
                if (   int(ses) == int(season) and int(epis) == int(episode)
                    or int(ses) == 1 and int(epis) == absolute_episode
                    or int(epis) == absolute_episode  # and int(ses) == int(season)  # takie dziwne dla tego serwisu
                    ):
                    fflog(f'pasuje  {href=}  {ses=} {epis=}',0)
                    episode_url = href
                    info2 += f"  [s{ses:0>2} e{epis}]"
                    should_break = True
                    break
        fflog(f'{episode_url=} {info2=}',1,1)
        if info2:
            return (episode_url, info2.strip())
        else:
            return episode_url


    def sources(self, url, hostDict, hostprDict):
        fflog(f'{url=}',0,1)
        sources = []
        if not url:
            fflog('brak źródeł do przekazania')
            return sources
        info2 = ''
        if isinstance(url, tuple):
            # fflog(f'{url=}')
            info2 = url[1]
            url = url[0]
        if not url:
            fflog('brak źródeł do przekazania')
            return sources
        out = []
        # fflog(f'{url=}')
        control.sleep(500)
        try:
            html = self.sess.get(url, headers=self.headers, timeout=60, verify=False)
        except Exception:
            fflog_exc(0)
            html = None
            pass
        if not html:
            fflog(f'{html=} {url=}')
            return sources
        new_variant = False
        html = html.text
        result = parseDOM(html, 'tbody')
        if not result:
            # result = parseDOM(html, 'div', attrs={'id': 'item-info'})
            result = parseDOM(html, 'div', attrs={'class': r'row g-\d+'})
            new_variant = True
        # fflog(f'{result=}')
        if result:
            result = result[0]
            if not new_variant:
                videos = parseDOM(result, 'tr')
            else:
            # if not videos:
                videos = parseDOM(result, 'div', attrs={'class': 'video-card link-to-video'})
            # fflog(f'{len(videos)=}  {videos=}')
            for vid in videos:
                # fflog(f'{vid=}')
                if not new_variant:
                    hosthrefquallang = re.findall(r'href\s*=\s*"([^"]+).*?<td>([^<]+).*?<td>([^<]+)', vid, re.DOTALL)
                    # fflog(f'{len(hosthrefquallang)=} {hosthrefquallang=}')
                    if hosthrefquallang:  # len(hosthrefquallang)=1
                        for href, lang, qual in hosthrefquallang:
                            host = urlparse(href).netloc
                            out.append({
                                'href': href,
                                'host': host,
                                'lang': lang,
                                'qual': qual,
                                })
                else:
                    try:
                        href = parseDOM(vid, 'a', attrs={'class': 'stretched-link'}, ret='href')[0]
                        # host = parseDOM(vid, 'strong')[0]
                        lang = parseDOM(vid, 'span', attrs={'class': 'badge badge-version'})[0]
                        qual = ''
                        host = urlparse(href).netloc
                        out.append({
                            'href': href,
                            'host': host,
                            'lang': lang,
                            'qual': qual,
                            })
                    except Exception:
                        fflog_exc(1)
                        pass
            if out:
                for x in out:
                    if (link := x.get('href')):
                        if any(link == s["url"] for s in sources):
                            fflog(f'dubel {link=}',0)
                            continue
                        host = (x.get('host') or "").rsplit(".", 1)[0].rsplit(".", 1)[-1]
                        lang = x.get('lang')
                        qual = x.get('qual').lower()
                        sources.append({
                                        'source': host,
                                        'quality': '720p' if qual=='wysoka' else 'CAM' if qual=='niska' else 'SD',
                                        'language': 'pl',
                                        'url': link,
                                        'info': lang,
                                        'direct': False,
                                        'debridonly': False,
                                        'info2': info2,
                                        })
                    else:
                        fflog(f'{link=}')
                        pass
            else:
                fflog(f'{len(out)=}  {out=}')
                pass
        else:
            fflog(f'{result=}')
            pass
        fflog(f'przekazano źródeł: {len(sources)}')
        # import json
        # fflog(f'sources={json.dumps(sources, indent=2)}',1,1)
        return sources


    def resolve(self, url):
        link = str(url).replace('\\/', '/')
        link = link.replace("//", "/").replace(":/", "://")
        fflog(f'{link=}')
        return link
