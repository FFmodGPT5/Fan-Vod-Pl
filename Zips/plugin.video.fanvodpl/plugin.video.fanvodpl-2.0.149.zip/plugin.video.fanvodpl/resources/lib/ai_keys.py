"""
    FanVodPL — Import kluczy AI z pliku tekstowego
    Obsługuje wczytywanie i tworzenie szablonu pliku fanvodpl_ai_keys.txt
"""

# ZMIANA (2026-04) [FEATURE]: Nowy moduł obsługi importu kluczy AI z pliku .txt
# POWOD: Wpisywanie długich kluczy API na klawiaturze telefonu/TV jest uciążliwe;
#        plik txt na pendrive lub w userdata Kodi umożliwia jednorazowe ustawienie kluczy.
# NIE ZMIENIAC: Nazwy ID ustawień muszą być identyczne jak w settings.xml (ai_search.key.*);
#               używać control.setSetting/control.setting zgodnie z resztą projektu.

import xbmcvfs
import xbmcgui

from ptw.libraries import control
from ptw.libraries.log_utils import log

# ---------------------------------------------------------------------------
# Mapowanie nazw z pliku TXT → ID ustawień Kodi
# ---------------------------------------------------------------------------
_GEMINI_KEY_SLOTS = (
    ('gemini', 'Gemini klucz', 'ai_search.key.gemini'),
)

# Gemini Search i Gemini TTS maja po jednym aktywnym kluczu.
# Stare nazwy gemini1..gemini8 sa akceptowane tylko jako aliasy importu.
_TTS_GEMINI_KEY_SLOTS = (
    ('tts_gemini', 'Gemini TTS klucz', 'ai_voice.gemini_key'),
)

_GEMINI_IMPORT_NAMES = set([
    'gemini',
    'gemini1', 'gemini2', 'gemini3', 'gemini4', 'gemini5', 'gemini6', 'gemini7', 'gemini8',
    'ai_search.key.gemini',
    'ai_search.key.gemini2', 'ai_search.key.gemini3', 'ai_search.key.gemini4',
    'ai_search.key.gemini5', 'ai_search.key.gemini6', 'ai_search.key.gemini7',
    'ai_search.key.gemini8',
])

_TTS_GEMINI_IMPORT_NAMES = set([
    'tts_gemini',
    'tts_gemini1', 'tts_gemini2', 'tts_gemini3', 'tts_gemini4',
    'tts_gemini5', 'tts_gemini6', 'tts_gemini7', 'tts_gemini8',
    'ai_voice.gemini_key',
    'ai_voice.gemini_key2', 'ai_voice.gemini_key3', 'ai_voice.gemini_key4',
    'ai_voice.gemini_key5', 'ai_voice.gemini_key6', 'ai_voice.gemini_key7',
    'ai_voice.gemini_key8',
])

_KEY_MAP = {
    # ZMIANA (2026-05) [FEATURE]: klucze TTS Gemini — osobna pula dla syntezatora mowy
    'openai':                ('OpenAI',             'ai_search.key.openai'),
    'claude':                ('Claude',             'ai_search.key.claude'),
    # ZMIANA (2026-04) [PATCH]: dodano klucze Google Search
    # POWOD: AIza jest prefiksem zarówno Gemini jak i Google API Key — auto-detekcja nie zadziała;
    #        użytkownik musi użyć jawnego prefiksu: google_search.api_key=AIza...
    # NIE ZMIENIAC: ID muszą być identyczne jak w settings.xml
    'google_search.api_key': ('Google API Key',    'google_search.api_key'),
    'google_search.cx':      ('Google CX',         'google_search.cx'),
}

_DEFAULT_PATH = 'special://userdata/fanvodpl_ai_keys.txt'


def _get_path():
    """Zwraca ścieżkę z ustawień (lub domyślną) przetłumaczoną na realną."""
    raw = control.setting('ai_keys.file_path') or _DEFAULT_PATH
    return xbmcvfs.translatePath(raw)


# ---------------------------------------------------------------------------
# Przeglądarka plików + import w jednym kroku
# ---------------------------------------------------------------------------
def browse_and_import():
    """
    Otwiera natywną przeglądarkę Kodi startując od głównego widoku źródeł
    (Główny system plików, Nośnik przenośny, SMB itd.), a po wybraniu pliku
    od razu wczytuje klucze AI.
    ZMIANA (2026-04) [PATCH]: zastępuje type="file" w settings.xml
    POWOD: type="file" pamięta ostatnią ścieżkę z addon_settings.xml i ignoruje default;
           Dialog().browse() z default='' zawsze startuje od głównego widoku źródeł.
    NIE ZMIENIAC: shares='files', default='' — krytyczne dla startu od root.
    """
    selected = xbmcgui.Dialog().browse(
        1,                          # typ: 1 = wybór pojedynczego pliku
        'Wybierz plik z kluczami AI',
        'files',                    # pokazuje wszystkie źródła plików
        '.txt',                     # filtr: tylko pliki .txt
        False,                      # useThumbs
        False,                      # treatAsFolder
        ''                          # default='' → start od głównego widoku źródeł
    )

    if not selected or not selected.strip():
        return  # użytkownik anulował

    _import_from_path(xbmcvfs.translatePath(selected))


# ---------------------------------------------------------------------------
# Import kluczy z pliku
# ---------------------------------------------------------------------------
def _detect_provider(key):
    """
    Auto-detekcja providera na podstawie prefiksu klucza.
    ZMIANA (2026-04) [FEATURE]: umożliwia wklejenie samego klucza bez prefiksu 'provider='
    NIE ZMIENIAC: kolejność sprawdzania — sk-ant- musi być przed sk- (oba OpenAI/Claude)
    """
    key = key.strip()
    if key.startswith('AIza'):
        return 'gemini'
    if key.startswith('sk-ant-'):
        return 'claude'
    if key.startswith('sk-'):
        return 'openai'
    # Dla nieznanych — None (użytkownik musi użyć formatu provider=klucz)
    return None


def _same_key(a, b):
    return (a or '').strip() == (b or '').strip()


def _append_unique(items, value):
    if value and value not in items:
        items.append(value)


def _store_gemini_auto(value):
    """
    Zapisuje klucz Gemini do pierwszego pasującego slotu:
    - jeśli taki klucz już istnieje, nie dubluje go,
    - jesli to nowy klucz, zastapi glowny slot gemini.
    """
    value = (value or '').strip()
    if not value:
        return '', '', 'empty'

    slot_name, display_name, setting_id = _GEMINI_KEY_SLOTS[0]
    current = (control.setting(setting_id) or '').strip()
    if _same_key(current, value):
        return display_name, setting_id, 'exists'
    control.setSetting(setting_id, value)
    return display_name, setting_id, 'replaced' if current else 'saved'


def _store_tts_gemini_auto(value):
    """
    Zapisuje jeden aktywny klucz Gemini TTS w glownym slocie.
    POWOD: analogia do _store_gemini_auto ale dla osobnej puli kluczy TTS.
    NIE ZMIENIAC: iteracja po _TTS_GEMINI_KEY_SLOTS — nie mieszac z kluczami AI Search.
    """
    value = (value or '').strip()
    if not value:
        return '', '', 'empty'

    slot_name, display_name, setting_id = _TTS_GEMINI_KEY_SLOTS[0]
    current = (control.setting(setting_id) or '').strip()
    if _same_key(current, value):
        return display_name, setting_id, 'exists'
    control.setSetting(setting_id, value)
    return display_name, setting_id, 'replaced' if current else 'saved'


def _import_from_path(real_path):
    """Wspólna logika wczytywania kluczy z podanej ścieżki."""
    if not xbmcvfs.exists(real_path):
        xbmcgui.Dialog().ok(
            'FanVodPL – Import kluczy AI',
            'Nie znaleziono pliku:\n[B]{}[/B]\n\n'
            'Użyj opcji "Utwórz szablon pliku" aby wygenerować pusty plik do uzupełnienia.'.format(real_path)
        )
        log('[FanVodPL][ai_keys] plik nie istnieje: {}'.format(real_path))
        return

    try:
        f = xbmcvfs.File(real_path, 'r')
        raw = f.read()
        f.close()
        # ZMIANA (2026-04) [PATCH]: xbmcvfs.File.read() na Androidzie zwraca bytes zamiast str
        # POWOD: porównania str vs bytes powodowały że żadna linia nie pasowała do parsera
        # NIE ZMIENIAC: utf-8-sig usuwa też BOM (Windows Notepad zapisuje UTF-8 z BOM)
        if isinstance(raw, bytes):
            content = raw.decode('utf-8-sig')
        else:
            content = raw.lstrip('\ufeff')
        safe_line_count = len([line for line in content.splitlines() if line.strip() and not line.strip().startswith('#')])
        log('[FanVodPL][ai_keys] wczytano plik z kluczami AI; linie do sprawdzenia: {}'.format(safe_line_count))
    except Exception as e:
        xbmcgui.Dialog().ok('FanVodPL – Import kluczy AI', 'Błąd odczytu pliku:\n{}'.format(str(e)))
        log('[FanVodPL][ai_keys] błąd odczytu: {}'.format(str(e)))
        return

    imported = []
    skipped  = []

    # ZMIANA (2026-05) [PATCH]: dodano numer linii bez logowania treści sekretu.
    # POWÓD: diagnostyka importu ma wskazać miejsce błędu, ale bez ujawniania kluczy.
    # NIE ZMIENIAĆ: enumerate służy tylko logom, nie zmienia parsowania kluczy.
    for line_no, raw_line in enumerate(content.splitlines(), 1):
        line = raw_line.strip()
        if not line or line.startswith('#'):
            continue

        if '=' in line:
            # format: provider=klucz
            name_raw, _, value = line.partition('=')
            name_raw = name_raw.strip().lower()
            value    = value.strip()
            if name_raw in _GEMINI_IMPORT_NAMES and value:
                display_name, setting_id, status = _store_gemini_auto(value)
                if display_name:
                    _append_unique(imported, display_name)
                    log('[FanVodPL][ai_keys] wczytano klucz dla {} (format Gemini, status={})'.format(display_name, status))
                elif status == 'full':
                    skipped.append('gemini: nie zapisano')
            elif name_raw in _TTS_GEMINI_IMPORT_NAMES and value:
                # ZMIANA (2026-05) [FEATURE]: format tts_gemini=klucz — osobna pula kluczy TTS
                display_name, setting_id, status = _store_tts_gemini_auto(value)
                if display_name:
                    _append_unique(imported, display_name)
                    log('[FanVodPL][ai_keys] wczytano klucz TTS dla {} (status={})'.format(display_name, status))
                elif status == 'full':
                    skipped.append('tts_gemini: nie zapisano')
            elif name_raw in _KEY_MAP and value:
                display_name, setting_id = _KEY_MAP[name_raw]
                control.setSetting(setting_id, value)
                _append_unique(imported, display_name)
                log('[FanVodPL][ai_keys] wczytano klucz dla {} (format provider=klucz)'.format(display_name))
            elif name_raw in _GEMINI_IMPORT_NAMES:
                skipped.append(name_raw)
            elif name_raw in _TTS_GEMINI_IMPORT_NAMES:
                skipped.append(name_raw)
            elif name_raw in _KEY_MAP:
                skipped.append(name_raw)
        else:
            # ZMIANA (2026-04) [FEATURE]: auto-detekcja providera po prefiksie klucza
            # POWOD: użytkownik wkleił sam klucz bez prefiksu provider=
            # NIE ZMIENIAC: _detect_provider() musi sprawdzać sk-ant- przed sk-
            provider = _detect_provider(line)
            if provider == 'gemini':
                display_name, setting_id, status = _store_gemini_auto(line)
                if display_name:
                    _append_unique(imported, display_name)
                    log('[FanVodPL][ai_keys] wczytano klucz dla {} (auto-detekcja, status={})'.format(display_name, status))
                elif status == 'full':
                    skipped.append('gemini: nie zapisano')
                    log('[FanVodPL][ai_keys] pominieto Gemini auto-detekcja: nie zapisano')
            elif provider and provider in _KEY_MAP:
                display_name, setting_id = _KEY_MAP[provider]
                control.setSetting(setting_id, line)
                _append_unique(imported, display_name)
                log('[FanVodPL][ai_keys] wczytano klucz dla {} (auto-detekcja)'.format(display_name))
            else:
                # ZMIANA (2026-05) [PATCH]: nie logujemy początku nierozpoznanej linii z pliku kluczy.
                # POWÓD: błędnie wklejony klucz mógłby trafić do kodi.log jako pierwsze znaki linii.
                # NIE ZMIENIAĆ: zachować informację diagnostyczną bez ujawniania treści sekretu.
                log('[FanVodPL][ai_keys] nierozpoznana linia nr {}'.format(line_no if 'line_no' in locals() else '?'))

    if imported:
        msg = 'Wczytano klucze: [B]{}[/B]'.format(', '.join(imported))
        if skipped:
            msg += '\n[LIGHT]Pominięto (puste wartości): {}[/LIGHT]'.format(', '.join(skipped))
        xbmcgui.Dialog().notification(
            'FanVodPL',
            'Wczytano klucze AI: {}'.format(', '.join(imported)),
            xbmcgui.NOTIFICATION_INFO, 4000
        )
        xbmcgui.Dialog().ok('FanVodPL – Import kluczy AI', msg)
    else:
        xbmcgui.Dialog().ok(
            'FanVodPL – Import kluczy AI',
            'Nie znaleziono żadnych poprawnych kluczy w pliku.\n\n'
            'Upewnij się że plik ma format:\n[B]gemini=twój_klucz[/B]'
        )
        log('[FanVodPL][ai_keys] brak kluczy w pliku')


def import_ai_keys():
    """Wczytuje klucze z ścieżki zapisanej w ustawieniach."""
    _import_from_path(_get_path())


# ---------------------------------------------------------------------------
# Tworzenie szablonu pliku
# ---------------------------------------------------------------------------
def export_ai_keys_template():
    """
    Zapisuje szablon pliku txt z aktualnie ustawionymi kluczami (lub pustymi).
    Użytkownik uzupełnia plik i używa import_ai_keys().
    """
    real_path = _get_path()

    lines = [
        '# FanVodPL — klucze AI',
        '# Format: nazwa=klucz  (jedna linia na provider albo slot)',
        '# Linie zaczynające się od # są ignorowane',
        '#',
        '# Wypełnij klucze których używasz i zapisz plik.',
        '# Gemini AI Search ma jeden aktywny klucz: gemini=AIza...',
        '# Gemini TTS ma jeden opcjonalny klucz: tts_gemini=AIza... (oddzielny od AI Search)',
        '# Następnie w ustawieniach wtyczki kliknij: Wczytaj klucze AI z pliku',
        '#',
        '# Providery z prawdziwym web search (plan/limity zaleza od konta):',
        '#   Gemini: https://aistudio.google.com (free tier / platne limity)',
        '#   OpenAI: https://platform.openai.com (platne limity API)',
        '#   Claude: https://console.anthropic.com (platne limity API)',
        '#',
        '# Opcjonalnie: google_search.api_key / google_search.cx jako awaryjny Google CSE.',
        '',
    ]

    # Sekcja AI Search - jeden aktywny klucz Gemini
    lines.append('')
    lines.append('# === Klucze AI Search Gemini (wyszukiwanie) ===')
    for slot_name, display_name, setting_id in _GEMINI_KEY_SLOTS:
        current = (control.setting(setting_id) or '').strip()
        lines.append('{}={}'.format(slot_name, current))

    # Sekcja TTS - jeden opcjonalny klucz Gemini dla syntezatora mowy
    lines.append('')
    lines.append('# === Klucze Gemini TTS (syntezator mowy — osobna pula) ===')
    lines.append('# Jezeli puste — TTS uzywa kluczy AI Search powyzej')
    for slot_name, display_name, setting_id in _TTS_GEMINI_KEY_SLOTS:
        current = (control.setting(setting_id) or '').strip()
        lines.append('{}={}'.format(slot_name, current))

    # Pozostale klucze (OpenAI, Claude, Google)
    lines.append('')
    lines.append('# === Pozostale klucze ===')
    for key_name, (display_name, setting_id) in _KEY_MAP.items():
        if key_name.startswith('ai_search.key.gemini'):
            continue
        if key_name.startswith('ai_voice.gemini'):
            continue
        if key_name.startswith('gemini') or key_name.startswith('tts_gemini'):
            continue
        current = (control.setting(setting_id) or '').strip()
        lines.append('{}={}'.format(key_name, current))

    content = '\n'.join(lines) + '\n'

    try:
        f = xbmcvfs.File(real_path, 'w')
        f.write(content)
        f.close()
        xbmcgui.Dialog().ok(
            'FanVodPL – Szablon kluczy AI',
            'Zapisano szablon:\n[B]{}[/B]\n\n'
            'Otwórz plik w edytorze tekstowym, uzupełnij klucze,\n'
            'a następnie użyj "Wczytaj klucze AI z pliku".'.format(real_path)
        )
        log('[FanVodPL][ai_keys] export_ai_keys_template: zapisano do {}'.format(real_path))
    except Exception as e:
        xbmcgui.Dialog().ok('FanVodPL – Szablon kluczy AI', 'Błąd zapisu pliku:\n{}'.format(str(e)))
        log('[FanVodPL][ai_keys] export_ai_keys_template: błąd zapisu: {}'.format(str(e)))
