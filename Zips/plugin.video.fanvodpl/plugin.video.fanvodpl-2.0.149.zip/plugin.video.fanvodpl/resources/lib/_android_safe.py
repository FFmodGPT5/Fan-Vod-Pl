# -*- coding: utf-8 -*-
import re

_FF_ANDROID_MOBILE_SAFE_MODE = None

def is_exynos():
    global _FF_ANDROID_MOBILE_SAFE_MODE
    if _FF_ANDROID_MOBILE_SAFE_MODE is not None:
        return _FF_ANDROID_MOBILE_SAFE_MODE
    _FF_ANDROID_MOBILE_SAFE_MODE = False
    try:
        import xbmc as _xbmc
        if not _xbmc.getCondVisibility("System.Platform.Android"):
            return False
    except Exception:
        return False
    def _vis(expr):
        try:
            return bool(_xbmc.getCondVisibility(expr))
        except Exception:
            return False
    def _getprop(name):
        try:
            import subprocess as _sp
            for cmd in (['/system/bin/getprop', name], ['getprop', name]):
                try:
                    return _sp.check_output(cmd, stderr=_sp.DEVNULL, timeout=1).decode('utf-8', errors='ignore').strip().lower()
                except Exception:
                    continue
        except Exception:
            pass
        return ''
    def _getprop_many(*names):
        for name in names:
            value = _getprop(name)
            if value:
                return value
        return ''
    blob = ''
    for _fp in ('/proc/cpuinfo', '/system/build.prop', '/vendor/build.prop', '/product/build.prop'):
        try:
            with open(_fp, 'r', errors='ignore') as _f:
                blob += '\n' + _f.read().lower()
        except Exception:
            pass
    board = _getprop_many('ro.board.platform', 'ro.hardware')
    characteristics = _getprop_many('ro.build.characteristics', 'ro.product.characteristics')
    sdk_raw = _getprop_many('ro.build.version.sdk', 'ro.vendor.build.version.sdk')
    manufacturer = _getprop_many('ro.product.manufacturer', 'ro.product.vendor.manufacturer')
    brand = _getprop_many('ro.product.brand', 'ro.product.vendor.brand')
    model = _getprop_many('ro.product.model', 'ro.product.vendor.model', 'ro.product.system.model')
    device = _getprop_many('ro.product.device', 'ro.product.vendor.device', 'ro.product.system.device')
    marketname = _getprop_many('ro.product.marketname', 'ro.product.vendor.marketname')
    density_raw = _getprop_many('ro.sf.lcd_density', 'qemu.sf.lcd_density', 'persist.sys.dpi')
    try:
        sdk = int(re.sub(r'[^0-9]', '', sdk_raw) or '0')
    except Exception:
        sdk = 0
    try:
        density = int(re.sub(r'[^0-9]', '', density_raw) or '0')
    except Exception:
        density = 0
    joined = ' '.join(x for x in (manufacturer, brand, model, device, marketname, characteristics, board, blob) if x)
    is_exynos = board.startswith('s5e') or 'exynos' in joined or 's5e' in joined
    tv_tokens = (' tv', 'android tv', 'google tv', ' bravia', 'chromecast', 'shield', 'mibox',
        'stb', 'settop', 'set-top', 'smarttv', 'smart-tv', 'aft', 'operator_tier')
    characteristics_tv = any(token in characteristics for token in ('tv', 'atv', 'stb', 'box'))
    is_touch = any(_vis(expr) for expr in ('System.HasTouchInput', 'System.HasTouchScreen'))
    is_probably_tv = characteristics_tv or any(token in joined for token in tv_tokens) or _vis('System.Platform.AndroidTV')
    mobile_vendor_tokens = (
        'pixel', 'google', 'samsung', 'sm-', 'galaxy', 'xiaomi', 'redmi', 'poco', 'oneplus',
        'oppo', 'realme', 'vivo', 'motorola', 'moto', 'sony', 'xperia', 'huawei', 'honor',
        'nokia', 'asus', 'zenfone', 'nothing', 'lenovo', 'tablet', 'phone')
    is_mobile_by_characteristics = any(x in characteristics for x in ('phone', 'tablet', 'nosdcard')) and not characteristics_tv
    is_mobile_by_vendor = any(token in joined for token in mobile_vendor_tokens) and not is_probably_tv
    is_mobile_by_density = density >= 260 and not is_probably_tv
    is_android_mobile = not is_probably_tv and (is_touch or is_mobile_by_characteristics or is_mobile_by_vendor or is_mobile_by_density)
    _FF_ANDROID_MOBILE_SAFE_MODE = bool(is_exynos or is_android_mobile)
    if _FF_ANDROID_MOBILE_SAFE_MODE:
        try:
            _xbmc.log(
                '[ANDROID SAFE MODE] board={0} sdk={1} density={2} characteristics={3} manufacturer={4} brand={5} model={6} touch={7} tv={8}'.format(
                    board or '?', sdk, density, characteristics or '?', manufacturer or '?', brand or '?', model or '?', is_touch, is_probably_tv), _xbmc.LOGINFO)
        except Exception:
            pass
    try:
        import xbmcgui
        xbmcgui.Window(10000).setProperty('FanVodPL.mobile_device', '1' if _FF_ANDROID_MOBILE_SAFE_MODE else '0')
    except Exception:
        pass
    return _FF_ANDROID_MOBILE_SAFE_MODE


def safe_info_labels(meta, label, mediatype):
    data = {'title': meta.get('title') or label or '', 'mediatype': mediatype}
    if mediatype in ('season', 'episode'):
        tvshowtitle = meta.get('localtvshowtitle') or meta.get('tvshowtitle') or ''
        if tvshowtitle:
            data['tvshowtitle'] = tvshowtitle
    for key in ('year', 'season', 'episode', 'premiered', 'plot', 'duration', 'status'):
        val = meta.get(key)
        if val not in (None, '', '0'):
            data[key] = val
    return data


def apply_safe_video_metadata(item, meta, label, mediatype):
    data = safe_info_labels(meta, label, mediatype)
    try:
        vtag = item.getVideoInfoTag()
    except Exception:
        return
    if vtag is None:
        return
    def _call(method_name, *args):
        func = getattr(vtag, method_name, None)
        if not callable(func):
            return
        try:
            func(*args)
        except Exception:
            pass
    def _as_int(value):
        try:
            if value in (None, '', '0'):
                return None
            return int(float(value))
        except Exception:
            return None
    _call('setTitle', data.get('title', ''))
    _call('setMediaType', mediatype)
    tvshowtitle = data.get('tvshowtitle', '')
    if tvshowtitle:
        _call('setTvShowTitle', tvshowtitle)
    year = _as_int(data.get('year'))
    if year:
        _call('setYear', year)
    season = _as_int(data.get('season'))
    if season is not None:
        _call('setSeason', season)
    episode = _as_int(data.get('episode'))
    if episode is not None:
        _call('setEpisode', episode)
    duration = _as_int(data.get('duration'))
    if duration:
        _call('setDuration', duration)
    plot = data.get('plot', '')
    if plot:
        _call('setPlot', plot)
    premiered = data.get('premiered', '')
    if premiered:
        _call('setPremiered', premiered)
