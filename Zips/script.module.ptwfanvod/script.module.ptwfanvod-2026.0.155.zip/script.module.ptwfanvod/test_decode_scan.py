# -*- coding: utf-8 -*-
"""Test czujnika zaciec uzywanego przez skan probkujacy (StallSensor).

Sprawdza to, co decyduje o wartosci calego mechanizmu:
  1. trzy progi (programowy 2, sprzetowy 10, renderowania 1) dzialaja osobno,
  2. zdarzenia trafiaja do KAZDEGO licznika, a nie tylko do pierwszego,
  3. `arm()` kasuje stan po poprzednim punkcie (inaczej wpisy z seeka
     przenosilyby sie na kolejny punkt i dawaly falszywy alarm),
  4. zerowy przyrost logu jest odrozniony od "czysto" (had_signal),
  5. dwa czujniki sa od siebie NIEZALEZNE (skan nie psuje straznika).

Uruchomienie:  py test_decode_scan.py
Oczekiwane po latce: exit 0, "RAZEM: 5/5", "WYNIK: PASS".
Przed latka PADA na braku klasy StallSensor - i o to chodzi.
"""
import importlib.util
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DW_PATH = os.environ.get('DW_PATH') or os.path.join(
    HERE, 'lib', 'ptw', 'libraries', 'decode_watch.py')

LINIA_SW = 'CVideoPlayerVideo::OutputPicture - timeout waiting for buffer\n'
LINIA_HW = 'ActiveAE - large audio sync error: 6901.28\n'
LINIA_RN = 'ReleaseOutputBuffer error in render\n'


def zaladuj():
    spec = importlib.util.spec_from_file_location('decode_watch_ut', DW_PATH)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class FakeLog(object):
    """Plik logu, do ktorego test dopisuje linie w trakcie obserwacji."""

    def __init__(self, sciezka):
        self.sciezka = sciezka
        io.open(self.sciezka, 'w', encoding='utf-8').write('stary wpis\n' * 20)

    def dopisz(self, tekst):
        with io.open(self.sciezka, 'a', encoding='utf-8') as f:
            f.write(tekst)

    def opener(self, path):
        return io.open(path, 'rb')


def main():
    dw = zaladuj()
    if not hasattr(dw, 'StallSensor'):
        raise AssertionError(
            'decode_watch nie ma klasy StallSensor - skan probkujacy nie ma '
            'czym obserwowac punktow (latka niezaaplikowana)')

    tmp = os.path.join(HERE, '_test_kodi.log')
    wyniki = []

    try:
        # 1. prog programowy: 1 wpis nie wystarcza, 2 wystarczaja
        log = FakeLog(tmp)
        s = dw.StallSensor(tmp, opener=log.opener)
        s.arm()
        log.dopisz(LINIA_SW)
        fire1, _ = s.poll(0.0)
        log.dopisz(LINIA_SW)
        fire2, _ = s.poll(1.0)
        ok = (not fire1) and fire2
        wyniki.append(('prog programowy 2', ok,
                       'po 1 wpisie=%s, po 2 wpisach=%s' % (fire1, fire2)))

        # 2. prog sprzetowy: 9 wpisow to za malo, 10 wystarcza
        log = FakeLog(tmp)
        s = dw.StallSensor(tmp, opener=log.opener)
        s.arm()
        log.dopisz(LINIA_HW * 9)
        fire9, _ = s.poll(0.0)
        log.dopisz(LINIA_HW)
        fire10, _ = s.poll(0.5)
        ok = (not fire9) and fire10
        wyniki.append(('prog sprzetowy 10', ok,
                       'po 9=%s, po 10=%s' % (fire9, fire10)))

        # 3. arm() kasuje stan poprzedniego punktu
        log = FakeLog(tmp)
        s = dw.StallSensor(tmp, opener=log.opener)
        s.arm()
        log.dopisz(LINIA_SW)
        s.poll(0.0)                      # jeden wpis "z poprzedniego punktu"
        s.arm()                          # nowy punkt
        log.dopisz(LINIA_SW)
        fire, _ = s.poll(1.0)
        ok = not fire
        wyniki.append(('arm() kasuje stan', ok,
                       'po arm() jeden wpis dal epizod=%s (ma byc False)' % fire))

        # 4. zerowy przyrost logu != "czysto"
        log = FakeLog(tmp)
        s = dw.StallSensor(tmp, opener=log.opener)
        s.arm()
        for i in range(5):
            s.poll(float(i))
        cisza = s.had_signal()
        log.dopisz('cokolwiek\n')
        s.poll(9.0)
        po_wpisie = s.had_signal()
        ok = (not cisza) and po_wpisie
        wyniki.append(('brak sygnalu != czysto', ok,
                       'bez wpisow had_signal=%s, po wpisie=%s'
                       % (cisza, po_wpisie)))

        # 5. dwa czujniki niezalezne (skan nie psuje straznika)
        log = FakeLog(tmp)
        a = dw.StallSensor(tmp, opener=log.opener)
        b = dw.StallSensor(tmp, opener=log.opener)
        a.arm()
        b.arm()
        log.dopisz(LINIA_SW * 2)
        fire_a, _ = a.poll(0.0)
        a.arm()
        fire_a2, _ = a.poll(1.0)
        fire_b, _ = b.poll(1.0)
        ok = fire_a and (not fire_a2) and fire_b
        wyniki.append(('czujniki niezalezne', ok,
                       'A=%s, A po arm=%s, B=%s' % (fire_a, fire_a2, fire_b)))
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)

    print('%-26s %s' % ('sprawdzenie', 'wynik'))
    print('-' * 78)
    bledy = []
    for nazwa, ok, opis in wyniki:
        print('%-26s %-6s %s' % (nazwa, 'OK' if ok else 'BLAD', opis))
        if not ok:
            bledy.append('%s (%s)' % (nazwa, opis))
    print('-' * 78)
    print('RAZEM: %d/%d' % (len(wyniki) - len(bledy), len(wyniki)))
    if bledy:
        print('WYNIK: FAIL')
        raise AssertionError('czujnik skanu zachowuje sie blednie: %s'
                             % '; '.join(bledy))
    print('WYNIK: PASS')
    return 0


if __name__ == '__main__':
    sys.exit(main())
