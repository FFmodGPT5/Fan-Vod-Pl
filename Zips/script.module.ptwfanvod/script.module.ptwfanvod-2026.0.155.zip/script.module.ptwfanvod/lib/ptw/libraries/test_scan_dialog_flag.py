"""Test weryfikujący kolejność flagi _file_scan_in_progress względem dialogu yesno."""
import sys
import os

def test_flag_before_yesno():
    """Flaga _file_scan_in_progress musi być ustawiona PRZED dialogiem yesno."""
    player_path = os.path.join(os.path.dirname(__file__), 'player.py')
    with open(player_path, encoding='utf-8') as f:
        content = f.read()
    
    # Znajdź pozycję flagi i dialogu yesno w run()
    flag_pos = content.find('self._file_scan_in_progress = True')
    yesno_pos = content.find('_xgui_ask.Dialog().yesno(')
    
    assert flag_pos > 0, 'Nie znaleziono _file_scan_in_progress = True'
    assert yesno_pos > 0, 'Nie znaleziono _xgui_ask.Dialog().yesno('
    assert flag_pos < yesno_pos, (
        f'Flaga _file_scan_in_progress (pozycja {flag_pos}) musi być PRZED '
        f'dialogiem yesno (pozycja {yesno_pos})'
    )
    print(f'OK: flaga na pozycji {flag_pos}, yesno na pozycji {yesno_pos}')

def test_flag_cleared_when_no_scan():
    """Flaga musi być czyszczona gdy user wybrał NIE (_ask_scan=False)."""
    player_path = os.path.join(os.path.dirname(__file__), 'player.py')
    with open(player_path, encoding='utf-8') as f:
        content = f.read()
    
    # Znajdź blok if _ask_scan: ... else: ... _file_scan_in_progress = False
    ask_scan_pos = content.find('if _ask_scan:')
    assert ask_scan_pos > 0, 'Nie znaleziono if _ask_scan:'
    
    # Szukaj else: po if _ask_scan:
    after_ask_scan = content[ask_scan_pos:]
    else_pos = after_ask_scan.find('else:')
    assert else_pos > 0, 'Nie znaleziono else: po if _ask_scan:'
    
    # W else musi być czyszczenie flagi
    after_else = after_ask_scan[else_pos:]
    assert '_file_scan_in_progress = False' in after_else[:500], (
        'else: nie zawiera _file_scan_in_progress = False'
    )
    print('OK: flaga czyszczona w else (user->NIE)')

if __name__ == '__main__':
    test_flag_before_yesno()
    test_flag_cleared_when_no_scan()
    print('Wszystkie testy PASS')
