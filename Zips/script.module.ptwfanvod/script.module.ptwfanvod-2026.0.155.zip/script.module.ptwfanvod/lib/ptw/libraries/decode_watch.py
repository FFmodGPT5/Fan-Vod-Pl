# -*- coding: utf-8 -*-
# ZMIANA (2026-07): wykrywanie zaglodzenia dekodera wideo (obraz stoi, dzwiek
# leci) na podstawie WLASNEGO logu Kodi. Sygnal:
#   "CVideoPlayerVideo::OutputPicture - timeout waiting for buffer"
# emitowany przez rdzen Kodi (C++), poziom WARNING (zawsze w logu, bez trybu
# debug). Bez binarek i bez dekodera w Pythonie.
#
# KOREKTA (2026-07, po tescie na Androidzie): pierwotnie zalozono, ze powyzszy
# sygnal powstaje "na KAZDEJ platformie". TO NIEPRAWDA. Emituje go wylacznie
# programowa sciezka CVideoPlayerVideo. Gdy host dekoduje sprzetowo
# (CDVDVideoCodecAndroidMediaCodec na Androidzie), komunikat NIE POWSTAJE ANI
# RAZU - dowod: log uzytkownika z 2026-07-26, 52 083 linie, 0 wystapien, przy
# potwierdzonym zacinaniu obrazu. Zaciecie jest tam raportowane INNYM zestawem
# komunikatow - patrz DECODE_STALL_MARKERS_HW ponizej.
#
# Czysta logika (bez importu Kodi) - warstwa I/O (odczyt pliku) wstrzykiwalna
# przez `opener`, dla testowalnosci.

DECODE_STALL_MARKERS = (
    'OutputPicture - timeout waiting for buffer',
)

# ZMIANA (2026-07): drugi zestaw wzorcow - sygnaly zaciecia raportowane przez
# hosta przy dekodowaniu SPRZETOWYM (m.in. MediaCodec na Androidzie), gdzie
# komunikat OutputPicture nie powstaje. Wystepuja DZIESIATKAMI na jeden epizod
# (pomiar na realnym logu: 51 wpisow w oknie 4 s), dlatego maja WLASNY, wyzszy
# prog - patrz player.py, osobna instancja BurstDetector. Prog dla zestawu
# powyzej MUSI pozostac 2, bo tam jeden epizod to dokladnie 2 wpisy.
DECODE_STALL_MARKERS_HW = (
    'ActiveAE - large audio sync error',
    'AddPacketsRenderer - timeout adding data to renderer',
)

# ZMIANA (2026-07, po tescie na telefonie): trzeci zestaw - blad renderowania
# bufora obrazu przy dekodowaniu sprzetowym. W przeciwienstwie do zestawu
# powyzej wystepuje POJEDYNCZO, nie klastrami, dlatego ma prog 1 (patrz
# player.py). Pomiar na dwoch logach telefonu: poza oknem startowym wystapil
# WYLACZNIE przy uszkodzonym pliku (2x), a przy zdrowym materiale ani razu.
# Wystapienia tuz po starcie odtwarzania pokrywa istniejace wyciszenie 15 s.
DECODE_STALL_MARKERS_RENDER = (
    'ReleaseOutputBuffer error in render',
)


def count_markers(text, markers=DECODE_STALL_MARKERS):
    if not text:
        return 0
    n = 0
    for m in markers:
        n += text.count(m)
    return n


class LogTail:
    """Czyta tylko NOWE bajty pliku logu od ostatniego odczytu.
    Obsluguje rotacje logu (gdy plik sie skrocil -> czyta od poczatku)."""

    def __init__(self, path, opener=None):
        self.path = path
        self._offset = 0
        self._opener = opener or (lambda p: open(p, 'rb'))

    def prime(self):
        """Ustaw offset na aktualny koniec pliku (ignoruj stare wpisy)."""
        try:
            with self._opener(self.path) as f:
                f.seek(0, 2)
                self._offset = f.tell()
        except Exception:
            self._offset = 0

    def read_new(self):
        """Zwraca NOWY tekst (str) dopisany od ostatniego odczytu."""
        try:
            with self._opener(self.path) as f:
                f.seek(0, 2)
                size = f.tell()
                if size < self._offset:
                    self._offset = 0  # rotacja logu
                f.seek(self._offset)
                data = f.read()
                self._offset = f.tell()
            return data.decode('utf-8', 'replace')
        except Exception:
            return ''


class BurstDetector:
    """Zwraca True gdy w oknie `window_s` sekund uzbiera sie >= `burst` zdarzen."""

    def __init__(self, window_s=8.0, burst=3):
        self.window_s = float(window_s)
        self.burst = int(burst)
        self._events = []

    def add(self, count, now):
        for _ in range(int(count)):
            self._events.append(now)
        cutoff = now - self.window_s
        self._events = [t for t in self._events if t >= cutoff]
        return len(self._events) >= self.burst

    def reset(self):
        self._events = []


# ZMIANA (2026-08): progi wyciagniete ze straznika do stalych, zeby skan
# probkujacy uzywal DOKLADNIE tych samych wartosci co reaktywny straznik.
# NIE ZMIENIAC prog programowy (2) - na dekoderze programowym jeden epizod
# to dokladnie 2 wpisy; sprzetowy ma prog 10, bo tam jeden epizod to
# kilkadziesiat wpisow (pomiar: 51 w oknie 4 s); renderowania ma prog 1,
# bo wystepuje pojedynczo.
DECODE_STALL_WINDOW_S = 10.0
DECODE_STALL_BURST_SW = 2
DECODE_STALL_BURST_HW = 10
DECODE_STALL_BURST_RN = 1


class StallSensor:
    """Komplet czujnika zaciec: ogon logu + trzy liczniki z wlasnymi progami.

    Powstal po to, zeby skan probkujacy mogl uzyc TEGO SAMEGO czujnika co
    reaktywny straznik, nie wspoldzielac z nim stanu i nie duplikowac progow.

    Klucz do uczciwosci wyniku: `saw_bytes`. Zerowy przyrost logu przez caly
    czas obserwacji NIE JEST dowodem, ze plik jest zdrowy - moze oznaczac, ze
    host nic nie pisze (np. renderowanie powierzchniowe na Androidzie) albo ze
    dekodowanie w ogole nie trwa. Bez tego rozroznienia awaria wygladalaby
    jak sukces.
    """

    def __init__(self, path, opener=None, window_s=DECODE_STALL_WINDOW_S):
        self.tail = LogTail(path, opener=opener)
        self.sw = BurstDetector(window_s=window_s, burst=DECODE_STALL_BURST_SW)
        self.hw = BurstDetector(window_s=window_s, burst=DECODE_STALL_BURST_HW)
        self.rn = BurstDetector(window_s=window_s, burst=DECODE_STALL_BURST_RN)
        self.saw_bytes = 0
        self.markers = 0

    def arm(self):
        """Ustaw punkt odniesienia w logu i wyzeruj liczniki.
        WOLAC DOPIERO po ustabilizowaniu obrazu po seeku - wpisy powstale
        w trakcie skoku NIE MOGA wpasc do licznika (to byla przyczyna
        falszywych alarmow poprzedniej wersji skanu)."""
        self.tail.prime()
        self.sw.reset()
        self.hw.reset()
        self.rn.reset()
        self.saw_bytes = 0
        self.markers = 0

    def poll(self, now):
        """Jeden obrot obserwacji. Zwraca (epizod, (n_sw, n_hw, n_rn)).
        Kazdy licznik dostaje swoje zdarzenia NIEZALEZNIE - skrot logiczny
        `or` pominalby dopisanie zdarzen do pozostalych licznikow."""
        text = self.tail.read_new()
        self.saw_bytes += len(text)
        n_sw = count_markers(text, DECODE_STALL_MARKERS)
        n_hw = count_markers(text, DECODE_STALL_MARKERS_HW)
        n_rn = count_markers(text, DECODE_STALL_MARKERS_RENDER)
        self.markers += n_sw + n_hw + n_rn
        fire_sw = self.sw.add(n_sw, now)
        fire_hw = self.hw.add(n_hw, now)
        fire_rn = self.rn.add(n_rn, now)
        return (fire_sw or fire_hw or fire_rn), (n_sw, n_hw, n_rn)

    def had_signal(self):
        """Czy host w ogole cokolwiek pisal w czasie obserwacji."""
        return self.saw_bytes > 0
