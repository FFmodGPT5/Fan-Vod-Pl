# -*- coding: utf-8 -*-
# ZMIANA (2026-08): czysta logika przebiegu skanu x4 - maszyna stanow
# "przebieg -> potwierdzenie -> werdykt". Wydzielona z player.py z tego
# samego powodu, dla ktorego wydzielony jest decode_watch.py: bez importu
# Kodi da sie ja przetestowac bez uruchomionego hosta.
#
# NIE ZMIENIAC ZASADY: strzal czujnika przy predkosci skanu NIE JEST
# werdyktem. Przyspieszenie x4 czterokrotnie zwieksza zapotrzebowanie na
# dane, a marker programowy hosta to doslownie "timeout waiting for buffer",
# czyli komunikat o GLODZIE bufora - moze powstac bez uszkodzenia pliku.
# Oskarzenie pada dopiero, gdy ten sam czujnik strzeli PONOWNIE przy
# predkosci normalnej, czyli w warunkach, w ktorych jest udowodniony.

# ZMIANA (2026-08-09, po tescie na urzadzeniu): predkosc skanu obnizona
# z 4 na 2. POWOD - pomiar, nie preferencja. Przy x4 czujnik NIE STRZELIL
# ani razu mimo 5 markerow zaciecia w logu, bo przy tej predkosci markery
# przychodza POJEDYNCZO (odstepy 24.7 / 25.1 / 44.3 / 127.0 s), a prog to
# 2 wpisy w oknie 10 s. Ten sam material przy predkosci 1 dal pary
# odlegle o 1.6 s i 2.6 s - czyli prog osiagniety dwa razy. Mechanizm:
# przy przyspieszeniu host przelatuje uszkodzony fragment kilkakrotnie
# krocej, wiec nie zdaza powtorzyc timeoutu i klaster sie nie tworzy.
# NIE PODNOSIC z powrotem bez pomiaru z urzadzenia.

FAZA_PRZEBIEG = 'przebieg'
FAZA_POTWIERDZENIE = 'potwierdzenie'
FAZA_KONIEC = 'koniec'

WERDYKT_ZACIECIE = 'ZACIECIE'
WERDYKT_BEZ_ZACIEC = 'BEZ_ZACIEC'
WERDYKT_NIEROZSTRZYGNIETY = 'NIEROZSTRZYGNIETY'

PREDKOSC_SKANU = 2
PREDKOSC_NORMALNA = 1
MARGINES_S = 15.0  # musi być >= _FS_WYCISZENIE_S (player.py:1949, obecnie 12.0) + zapas
POTWIERDZENIE_S = 25.0
LIMIT_POTWIERDZEN = 3


class ScanRun(object):
    """Stan przebiegu skanu. Nie dotyka hosta - tylko liczy i decyduje."""

    def __init__(self, dlugosc_s, predkosc=PREDKOSC_SKANU,
                 margines_s=MARGINES_S, potwierdzenie_s=POTWIERDZENIE_S,
                 limit_potwierdzen=LIMIT_POTWIERDZEN):
        self.dlugosc_s = float(dlugosc_s or 0.0)
        self.predkosc = float(predkosc or 1.0)
        self.margines_s = float(margines_s)
        self.potwierdzenie_s = float(potwierdzenie_s)
        self.limit_potwierdzen = int(limit_potwierdzen)
        self.faza = FAZA_PRZEBIEG
        self.podejrzenia = 0
        self.pozycja_podejrzenia = None
        self.wznow_od = None

    def postep(self, pozycja_s):
        """Procent przebiegu liczony POZYCJA W MATERIALE (0..100)."""
        if self.dlugosc_s <= 0:
            return 0
        p = int(100.0 * float(pozycja_s or 0.0) / self.dlugosc_s)
        if p < 0:
            return 0
        if p > 100:
            return 100
        return p

    def pozostalo_zegara_s(self, pozycja_s):
        """Ile sekund ZEGARA zostalo - material dzielony przez predkosc."""
        if self.predkosc <= 0:
            return 0.0
        zostalo = self.dlugosc_s - float(pozycja_s or 0.0)
        if zostalo < 0.0:
            zostalo = 0.0
        return zostalo / self.predkosc

    def na_epizod(self, pozycja_s):
        """Czujnik strzelil podczas przebiegu. To NIE jest werdykt - to
        polecenie zwolnienia do predkosci normalnej i cofniecia sie przed
        podejrzane miejsce, zeby obejrzec je jeszcze raz."""
        self.podejrzenia += 1
        self.pozycja_podejrzenia = float(pozycja_s or 0.0)
        self.wznow_od = self.pozycja_podejrzenia
        cel = self.pozycja_podejrzenia - self.margines_s
        if cel < 0.0:
            cel = 0.0
        self.faza = FAZA_POTWIERDZENIE
        return {'predkosc': PREDKOSC_NORMALNA, 'seek_do': cel,
                'obserwuj_s': self.potwierdzenie_s, 'werdykt': None,
                'pozycja': self.pozycja_podejrzenia}

    def na_potwierdzeniu(self, strzal):
        """Wynik obserwacji przy predkosci normalnej."""
        if strzal:
            self.faza = FAZA_KONIEC
            return {'werdykt': WERDYKT_ZACIECIE,
                    'pozycja': self.pozycja_podejrzenia,
                    'predkosc': PREDKOSC_NORMALNA}
        if self.podejrzenia >= self.limit_potwierdzen:
            self.faza = FAZA_KONIEC
            return {'werdykt': WERDYKT_BEZ_ZACIEC, 'pozycja': None,
                    'predkosc': PREDKOSC_NORMALNA}
        self.faza = FAZA_PRZEBIEG
        # ZMIANA (2026-08-09): powrot do predkosci TEGO przebiegu (self.predkosc),
        # a nie do stalej modulu. Poprzednia wersja zwracala PREDKOSC_SKANU, wiec
        # przebieg uruchomiony z inna predkoscia wracal po potwierdzeniu do
        # wartosci domyslnej - cicha niespojnosc, ktora ujawnila sie dopiero
        # przy obnizeniu stalej z 4 na 2.
        return {'werdykt': None, 'predkosc': int(self.predkosc),
                'wznow_od': self.wznow_od, 'pozycja': None}

    def na_koniec_materialu(self, byl_sygnal):
        """Material przejrzany do konca. Cisza hosta NIE jest dowodem
        zdrowia pliku - to samo rozroznienie, ktore niesie had_signal()."""
        self.faza = FAZA_KONIEC
        if not byl_sygnal:
            return WERDYKT_NIEROZSTRZYGNIETY
        return WERDYKT_BEZ_ZACIEC
