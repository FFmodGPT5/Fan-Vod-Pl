# -*- coding: utf-8 -*-
"""Test logiki przebiegu skanu x4 (modul scan_drive).

Sprawdza to, co decyduje o wartosci nowego skanu, BEZ uruchomionego hosta:
  1. postep liczony pozycja w materiale (0..100, monotoniczny w przebiegu),
  2. czas pozostaly liczony ZEGAREM, czyli dlugosc/predkosc,
  3. strzal czujnika przy x4 NIE jest werdyktem - przelacza w potwierdzenie
     przy predkosci 1, z cofnieciem o margines (nigdy ponizej 0),
  4. potwierdzony strzal przy predkosci 1 = werdykt ZACIECIE z pozycja
     PIERWSZEGO podejrzenia (nie pozycja po cofnieciu),
  5. NIEpotwierdzony strzal = powrot do przebiegu x4, plik NIE oskarzony,
  6. koniec materialu bez ANI JEDNEGO bajtu w logu = NIEROZSTRZYGNIETY
     (cisza hosta nie jest dowodem zdrowia - decode_watch.py:126-129),
  7. koniec materialu z sygnalem i bez strzalu = BEZ ZACIEC.

Uruchomienie:  py test_scan_drive.py
Oczekiwane PO latce: exit 0, "RAZEM: 8/8", "WYNIK: PASS".
PRZED latka PADA na braku modulu scan_drive.py - i o to chodzi (cykl RED->GREEN).
"""
import importlib.util
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SD_PATH = os.environ.get('SD_PATH') or os.path.join(
    HERE, 'lib', 'ptw', 'libraries', 'scan_drive.py')


def zaladuj():
    if not os.path.exists(SD_PATH):
        raise AssertionError(
            'brak modulu %s - logika przebiegu skanu x4 nie istnieje '
            '(latka niezaaplikowana)' % SD_PATH)
    spec = importlib.util.spec_from_file_location('scan_drive_ut', SD_PATH)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    sd = zaladuj()
    for nazwa in ('ScanRun', 'FAZA_PRZEBIEG', 'FAZA_POTWIERDZENIE',
                  'FAZA_KONIEC', 'WERDYKT_ZACIECIE', 'WERDYKT_BEZ_ZACIEC',
                  'WERDYKT_NIEROZSTRZYGNIETY'):
        if not hasattr(sd, nazwa):
            raise AssertionError('scan_drive nie ma %s' % nazwa)

    TOTAL = 8634.592          # realna dlugosc z kodi.log:459
    wyniki = []

    # 1. postep liczony pozycja w materiale
    r = sd.ScanRun(TOTAL, predkosc=4.0)
    p0 = r.postep(0.0)
    p_polowa = r.postep(TOTAL / 2.0)
    p_koniec = r.postep(TOTAL)
    p_poza = r.postep(TOTAL * 2)
    ok = (p0 == 0 and 49 <= p_polowa <= 51 and p_koniec == 100
          and p_poza == 100)
    wyniki.append(('postep 0/50/100', ok,
                   'start=%s polowa=%s koniec=%s poza=%s'
                   % (p0, p_polowa, p_koniec, p_poza)))

    # 2. czas pozostaly liczony zegarem (dlugosc/predkosc)
    r = sd.ScanRun(TOTAL, predkosc=4.0)
    zostalo = r.pozostalo_zegara_s(0.0)
    oczekiwane = TOTAL / 4.0
    ok = abs(zostalo - oczekiwane) < 1.0
    wyniki.append(('czas zegarowy przy x4', ok,
                   'zwrocono %.1f s, oczekiwano %.1f s' % (zostalo, oczekiwane)))

    # 3. strzal przy x4 -> potwierdzenie przy predkosci 1, z cofnieciem
    r = sd.ScanRun(TOTAL, predkosc=4.0, margines_s=10.0)
    d = r.na_epizod(201.0)
    ok = (r.faza == sd.FAZA_POTWIERDZENIE
          and d.get('predkosc') == 1
          and abs(d.get('seek_do', -1) - 191.0) < 0.001)
    wyniki.append(('strzal x4 -> potwierdzenie', ok,
                   'faza=%s predkosc=%s seek_do=%s'
                   % (r.faza, d.get('predkosc'), d.get('seek_do'))))

    # 3b. cofniecie nie moze zejsc ponizej zera
    r = sd.ScanRun(TOTAL, predkosc=4.0, margines_s=10.0)
    d = r.na_epizod(3.0)
    ok = d.get('seek_do') == 0.0
    wyniki.append(('cofniecie nie ponizej 0', ok,
                   'seek_do=%s (pozycja podejrzenia 3.0 s)' % d.get('seek_do')))

    # 4. potwierdzony strzal = ZACIECIE z pozycja PIERWSZEGO podejrzenia
    r = sd.ScanRun(TOTAL, predkosc=4.0, margines_s=10.0)
    r.na_epizod(201.0)
    d = r.na_potwierdzeniu(strzal=True)
    ok = (d.get('werdykt') == sd.WERDYKT_ZACIECIE
          and abs(d.get('pozycja', -1) - 201.0) < 0.001
          and r.faza == sd.FAZA_KONIEC)
    wyniki.append(('potwierdzone = ZACIECIE', ok,
                   'werdykt=%s pozycja=%s faza=%s'
                   % (d.get('werdykt'), d.get('pozycja'), r.faza)))

    # 5. NIEpotwierdzony strzal = powrot do predkosci TEGO przebiegu.
    # Asercja celowo NIE porownuje ze stala modulu (taka asercja przechodzi
    # dla dowolnej wartosci i niczego nie broni) - sprawdza, ze przebieg
    # wraca do predkosci, z ktora zostal URUCHOMIONY.
    r = sd.ScanRun(TOTAL, predkosc=2.0, margines_s=10.0)
    r.na_epizod(201.0)
    d = r.na_potwierdzeniu(strzal=False)
    r3 = sd.ScanRun(TOTAL, predkosc=3.0, margines_s=10.0)
    r3.na_epizod(201.0)
    d3 = r3.na_potwierdzeniu(strzal=False)
    ok = (d.get('werdykt') is None
          and d.get('predkosc') == 2
          and d3.get('predkosc') == 3
          and r.faza == sd.FAZA_PRZEBIEG)
    wyniki.append(('powrot do predkosci przebiegu', ok,
                   'run(2)->%s, run(3)->%s, werdykt=%s faza=%s'
                   % (d.get('predkosc'), d3.get('predkosc'),
                      d.get('werdykt'), r.faza)))

    # 5b. domyslna predkosc skanu = 2 (zmierzona na urzadzeniu 2026-08-09:
    # przy 4 czujnik nie uzbieral klastra i zaciecie przechodzilo niezauwazone)
    dom = sd.ScanRun(TOTAL)
    ok = (sd.PREDKOSC_SKANU == 2 and dom.predkosc == 2.0)
    wyniki.append(('domyslna predkosc skanu = 2', ok,
                   'stala=%s, przebieg bez argumentu=%s'
                   % (sd.PREDKOSC_SKANU, dom.predkosc)))

    # 6/7. koniec materialu: cisza hosta != zdrowy plik
    r = sd.ScanRun(TOTAL, predkosc=4.0)
    w_cisza = r.na_koniec_materialu(byl_sygnal=False)
    r2 = sd.ScanRun(TOTAL, predkosc=4.0)
    w_sygnal = r2.na_koniec_materialu(byl_sygnal=True)
    ok = (w_cisza == sd.WERDYKT_NIEROZSTRZYGNIETY
          and w_sygnal == sd.WERDYKT_BEZ_ZACIEC)
    wyniki.append(('cisza != bez zaciec', ok,
                   'bez sygnalu=%s, z sygnalem=%s' % (w_cisza, w_sygnal)))

    print('%-32s %s' % ('sprawdzenie', 'wynik'))
    print('-' * 90)
    bledy = []
    for nazwa, ok, opis in wyniki:
        print('%-32s %-6s %s' % (nazwa, 'OK' if ok else 'BLAD', opis))
        if not ok:
            bledy.append('%s (%s)' % (nazwa, opis))
    print('-' * 90)
    print('RAZEM: %d/%d' % (len(wyniki) - len(bledy), len(wyniki)))
    if bledy:
        print('WYNIK: FAIL')
        raise AssertionError('logika przebiegu skanu jest bledna: %s'
                             % '; '.join(bledy))
    print('WYNIK: PASS')
    return 0


if __name__ == '__main__':
    sys.exit(main())
