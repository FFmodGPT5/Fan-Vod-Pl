# -*- coding: utf-8 -*-
"""
FanVodPL — Trace Logger
=======================
Zapisuje szczegółowy dziennik diagnostyczny do pliku fanvodpl_trace.log
w tym samym folderze co kodi.log i kodi.old.log.

Przy każdym starcie Kodi stary plik jest rotowany do fanvodpl_trace.old.log.

Użycie:
    from ptw.libraries import trace_log
    trace_log.trace("default.py", "action=episodes", imdb="tt0944947")
    trace_log.error("player.py", "getTime failed", exc=e)
"""

import os
import time
import threading
import traceback

# ── Ścieżka logu — ten sam folder co kodi.log ─────────────────────────────
def _get_log_dir():
    try:
        import xbmcvfs
        path = xbmcvfs.translatePath("special://logpath/")
        if path and os.path.isdir(path):
            return path
    except Exception:
        pass
    try:
        import xbmc
        path = xbmc.translatePath("special://logpath/")
        if path and os.path.isdir(path):
            return path
    except Exception:
        pass
    return None

_LOG_DIR  = _get_log_dir()
_LOG_FILE = os.path.join(_LOG_DIR, "fanvodpl_trace.log")  if _LOG_DIR else None
_OLD_FILE = os.path.join(_LOG_DIR, "fanvodpl_trace.old.log") if _LOG_DIR else None

_lock       = threading.Lock()
_rotated    = False
_ENABLED    = _LOG_FILE is not None

# ── Rotacja przy starcie ───────────────────────────────────────────────────
def _rotate():
    global _rotated
    if _rotated or not _ENABLED:
        return
    _rotated = True
    try:
        if os.path.exists(_LOG_FILE):
            if os.path.exists(_OLD_FILE):
                os.remove(_OLD_FILE)
            os.rename(_LOG_FILE, _OLD_FILE)
    except Exception:
        pass

# ── Zapis linii do pliku ───────────────────────────────────────────────────
def _write(line):
    if not _ENABLED:
        return
    try:
        _rotate()
        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        with _lock:
            with open(_LOG_FILE, "a", encoding="utf-8", errors="replace") as f:
                f.write(f"[{ts}] {line}\n")
    except Exception:
        pass

# ── Publiczne API ──────────────────────────────────────────────────────────
def trace(source, event, **kwargs):
    """Zapis zdarzenia diagnostycznego.

    Args:
        source: nazwa pliku lub modułu (np. "default.py", "service.py")
        event:  krótki opis zdarzenia (np. "action=episodes", "onPlayBackStopped")
        **kwargs: dowolne dodatkowe dane (imdb, season, folder, pct itp.)
    """
    parts = [f"[TRACE] [{source}] {event}"]
    if kwargs:
        kv = "  ".join(f"{k}={v!r}" for k, v in kwargs.items())
        parts.append(f"  | {kv}")
    _write("".join(parts))

def error(source, event, exc=None, **kwargs):
    """Zapis błędu lub wyjątku — zawiera pełny traceback."""
    parts = [f"[ERROR] [{source}] {event}"]
    if kwargs:
        kv = "  ".join(f"{k}={v!r}" for k, v in kwargs.items())
        parts.append(f"  | {kv}")
    _write("".join(parts))
    if exc is not None:
        tb = traceback.format_exc()
        if tb and tb.strip() != "NoneType: None":
            for tbline in tb.splitlines():
                _write(f"        {tbline}")

def nav(source, action, **kwargs):
    """Skrót dla zdarzeń nawigacyjnych (action=, FolderPath, itp.)."""
    trace(source, f"NAV action={action}", **kwargs)

def player_event(source, event, **kwargs):
    """Skrót dla zdarzeń playera (onStart, onStop, itp.)."""
    trace(source, f"PLAYER {event}", **kwargs)

def section(title):
    """Separator sekcji w logu — czytelność przy analizie."""
    _write(f"{'─'*60}")
    _write(f"[====] {title}")
    _write(f"{'─'*60}")

def info(source, msg, **kwargs):
    """Ogólny wpis informacyjny."""
    parts = [f"[INFO]  [{source}] {msg}"]
    if kwargs:
        kv = "  ".join(f"{k}={v!r}" for k, v in kwargs.items())
        parts.append(f"  | {kv}")
    _write("".join(parts))

# ── Inicjalizacja — wpis startowy ─────────────────────────────────────────
def _init():
    if not _ENABLED:
        return
    try:
        import xbmcaddon
        ver = xbmcaddon.Addon().getAddonInfo('version')
    except Exception:
        ver = "?"
    try:
        import xbmc
        kodi_ver = xbmc.getInfoLabel("System.BuildVersion") or "?"
    except Exception:
        kodi_ver = "?"
    section(f"FanVodPL v{ver} | Kodi {kodi_ver} | trace start")

try:
    _init()
except Exception:
    pass
