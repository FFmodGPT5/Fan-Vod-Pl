import os as _os
import shutil as _shutil
import sys as _sys


def _addon_root():
    try:
        return _os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))))
    except Exception:
        return _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))


def _clear_python_cache():
    try:
        _base = _addon_root()
        for root, dirs, files in _os.walk(_base):
            for d in list(dirs):
                if d == "__pycache__":
                    _shutil.rmtree(_os.path.join(root, d), ignore_errors=True)
                    try:
                        dirs.remove(d)
                    except Exception:
                        pass
            for f in files:
                if f.endswith((".pyc", ".pyo")):
                    try:
                        _os.remove(_os.path.join(root, f))
                    except Exception:
                        pass
    except Exception:
        pass

    try:
        import importlib as _importlib
        _importlib.invalidate_caches()
    except Exception:
        pass


def _drop_stale_library_modules():
    try:
        for name in list(_sys.modules):
            if name != __name__ and name.startswith("ptw.libraries"):
                _sys.modules.pop(name, None)
    except Exception:
        pass


_clear_python_cache()
_drop_stale_library_modules()

try:
    from ptw.libraries import cfscrape

    cfScraper = cfscrape.create_scraper()
except:
    pass

try:
    from kodi_six import xbmcaddon

    __addon__ = xbmcaddon.Addon(id="script.module.ptwfanvod")
except:
    __addon__ = None
    pass


def enabledCheck(module_name):
    if __addon__ is not None:
        if __addon__.getSetting("provider." + module_name) == "true":
            return True
        else:
            return False
    return True


def custom_base_link(scraper):
    try:
        url = __addon__.getSetting("url." + scraper)
        if url and url.startswith("http"):
            if url.endswith("/"):
                url = url[:-1]
            return url
        else:
            return None
    except:
        return None
