# AUTO-CLEAR Python cache po aktualizacji
# Rozszerzone: czyści __pycache__ + .pyc/.pyo i wyrzuca stare moduły z sys.modules
import os as _os
import shutil as _shutil
import sys as _sys


def _addon_root():
    try:
        return _os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
    except Exception:
        return _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))


def _clear_python_cache():
    try:
        _base = _addon_root()
        for root, dirs, files in _os.walk(_base):
            for d in list(dirs):
                if d == "__pycache__":
                    _shutil.rmtree(_os.path.join(root, d), ignore_errors=True)
                    try:
                        dirs.remove(d)
                    except Exception:
                        pass
            for f in files:
                if f.endswith((".pyc", ".pyo")):
                    try:
                        _os.remove(_os.path.join(root, f))
                    except Exception:
                        pass
    except Exception:
        pass

    try:
        import importlib as _importlib
        _importlib.invalidate_caches()
    except Exception:
        pass


def _drop_stale_ptw_modules():
    try:
        for name in list(_sys.modules):
            if name != __name__ and name.startswith("ptw."):
                _sys.modules.pop(name, None)
    except Exception:
        pass


_clear_python_cache()
_drop_stale_ptw_modules()

# Force patching Kodi API
# Basic logging.
from .libraries.log_utils import log  # noqa: F401

import sys
PY2 = sys.version_info < (3, 0)


# Monkey-patching datetime.strptime
# see: https://forum.kodi.tv/showthread.php?tid=112916&pid=2953239
# see: https://bugs.python.org/issue27400
import datetime as datetime_module            # noqa: E402
from datetime import datetime as _datetime    # noqa: E402

if not getattr(datetime_module, '_datetime_is_patched', False):
    class datetime(_datetime):
        @classmethod
        def strptime(cls, date_string: str, format: str) -> _datetime:
            # log(f"Monkey-patching datetime.strptime  {date_string=}", 1)
            try:
                return _dt_strptime(date_string, format)
            except TypeError:
                import time
                return datetime(*(time.strptime(date_string, format)[0:6]))

    _dt_strptime = _datetime.strptime
    datetime_module.datetime = datetime
    datetime_module._datetime = _datetime
    datetime_module._datetime_is_patched = True
