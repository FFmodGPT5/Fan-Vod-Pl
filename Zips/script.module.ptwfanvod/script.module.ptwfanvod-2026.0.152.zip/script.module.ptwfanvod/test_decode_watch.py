# -*- coding: utf-8 -*-
# Test jednostkowy decode_watch (bez Kodi, bez plikow) - warstwa I/O wstrzykiwana.
# Uruchomienie: py test_decode_watch.py   (exit 0 = PASS)

import io
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib', 'ptw', 'libraries'))
import decode_watch as dw

REAL = (
    "2026-07-25 11:16:19.595 T:20760 warning <general>: "
    "CVideoPlayerVideo::OutputPicture - timeout waiting for buffer\n"
    "2026-07-25 11:16:20.112 T:20760 warning <general>: "
    "CVideoPlayerVideo::OutputPicture - timeout waiting for buffer\n"
)


class Store:
    def __init__(self, text=''):
        self.buf = text.encode('utf-8')

    def append(self, text):
        self.buf += text.encode('utf-8')

    def rotate(self, text=''):
        self.buf = text.encode('utf-8')

    def opener(self, path):
        return io.BytesIO(self.buf)


def run():
    assert dw.count_markers(REAL) == 2, ('count-real', dw.count_markers(REAL))
    assert dw.count_markers('nic tu nie ma') == 0
    assert dw.count_markers('') == 0

    st = Store("stare linie bez markera\n" * 100)
    tail = dw.LogTail('x', opener=st.opener)
    tail.prime()
    assert tail.read_new() == '', 'po prime brak nowych'
    st.append(REAL)
    assert dw.count_markers(tail.read_new()) == 2, 'tail-2'
    assert tail.read_new() == '', 'drugi odczyt nic nowego'
    st.append("2026 ... OutputPicture - timeout waiting for buffer\n")
    assert dw.count_markers(tail.read_new()) == 1, 'inkrementalnie 1'

    st.rotate("OutputPicture - timeout waiting for buffer\n")
    assert dw.count_markers(tail.read_new()) == 1, 'po rotacji 1'

    bd = dw.BurstDetector(window_s=8.0, burst=3)
    assert bd.add(1, 19.595) is False
    assert bd.add(1, 20.112) is False
    assert bd.add(1, 25.757) is True, 'burst 3/8s'
    bd.reset()
    assert bd.add(1, 45.409) is False, 'pojedyncze != burst'

    bd2 = dw.BurstDetector(window_s=8.0, burst=3)
    bd2.add(1, 1.0)
    bd2.add(1, 2.0)
    assert bd2.add(1, 20.0) is False, 'stare wypadly z okna'

    print('PASS: decode_watch 5/5 grup (count_markers / LogTail inkrementalny / '
          'rotacja / BurstDetector / okno czasowe)')


if __name__ == '__main__':
    run()
