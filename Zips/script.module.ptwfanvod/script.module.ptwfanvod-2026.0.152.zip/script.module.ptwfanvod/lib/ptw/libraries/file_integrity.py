# -*- coding: utf-8 -*-
# ZMIANA (2026-07): nowy modul skanu integralnosci pliku wideo (pre-play).
# Czysta logika, bez importu Kodi. Warstwa HTTP wstrzykiwana (parametr `http`)
# dla testowalnosci; domyslnie oparta na requests.
#
# scan(url, headers, http, opts) -> {'verdict','reason','position'}
#   verdict in {'OK','CORRUPTED','INCONCLUSIVE'}
# Zasada fail-open: cokolwiek uniemozliwia rozstrzygniecie -> INCONCLUSIVE
# (nigdy nie blokuj zdrowego pliku bez dowodu uszkodzenia).

OK = 'OK'
CORRUPTED = 'CORRUPTED'
INCONCLUSIVE = 'INCONCLUSIVE'

HEAD_BYTES = 65536
TAIL_BYTES = 65536
SAMPLE_POINTS = 6
SAMPLE_CHUNK = 65536


def _verdict(verdict, reason, position=None):
    return {'verdict': verdict, 'reason': reason, 'position': position}


def _lower_headers(h):
    out = {}
    try:
        for k, v in h.items():
            out[str(k).lower()] = v
    except Exception:
        pass
    return out


def _to_int(v):
    try:
        return int(str(v).split(',')[0].strip())
    except Exception:
        return None


def _range_get(http, url, headers, start, end):
    """Zwraca (status, body_len). status/body z warstwy http (wstrzykiwalnej)."""
    resp = http('GET', url, headers, (start, end))
    status = resp.get('status', 0)
    body = resp.get('body') or b''
    try:
        blen = len(body)
    except Exception:
        blen = 0
    return status, blen


def _classify_container(head):
    if not head:
        return None
    if len(head) >= 8 and head[4:8] == b'ftyp':
        return 'mp4'
    if head[:4] == b'\x1a\x45\xdf\xa3':
        return 'mkv'
    if head[0:1] == b'\x47':
        return 'ts'
    return None


def _iter_mp4_atoms(buf):
    """Yield (atom_type:bytes, size:int|None, offset:int) dla atomow top-level
    widocznych w buforze. size=None gdy 'do konca pliku' (size==0)."""
    import struct
    off = 0
    n = len(buf)
    while off + 8 <= n:
        size32 = struct.unpack('>I', buf[off:off + 4])[0]
        atype = buf[off + 4:off + 8]
        header = 8
        if size32 == 1:
            if off + 16 > n:
                break
            size = struct.unpack('>Q', buf[off + 8:off + 16])[0]
            header = 16
        elif size32 == 0:
            size = None  # do EOF
        else:
            size = size32
        yield atype, size, off
        if size is None or size < header:
            break
        off += size


def _check_mp4(head, tail, tail_start, clen):
    """Wykrywa jawne uszkodzenie struktury MP4. Zwraca verdict dict albo None
    (None = brak dowodu uszkodzenia -> kontynuuj probkowanie)."""
    for atype, size, off in _iter_mp4_atoms(head):
        if size is None:
            continue
        # Atom deklaruje rozmiar wychodzacy POZA plik -> uciety (typowo mdat).
        if off + size > clen:
            return _verdict(
                CORRUPTED,
                'atom %r deklaruje %d B poza rozmiar pliku (%d B) - plik uciety'
                % (atype.decode('latin-1', 'replace'), off + size, clen),
                position=off,
            )
    return None


def _sample_ranges(http, url, headers, clen):
    """Probkuje N zakresow w rownych odstepach. 206+niepuste=OK; 206 puste/krotkie
    lub blad zakresu=CORRUPTED; brak wsparcia zakresow (200)=INCONCLUSIVE."""
    fracs = [(i + 1.0) / (SAMPLE_POINTS + 1.0) for i in range(SAMPLE_POINTS)]
    for frac in fracs:
        start = int(clen * frac)
        end = min(start + SAMPLE_CHUNK - 1, clen - 1)
        if end < start:
            continue
        status, blen = _range_get(http, url, headers, start, end)
        if status == 200:
            return _verdict(INCONCLUSIVE, 'serwer ignoruje Range (200) - brak skanu')
        if status != 206:
            return _verdict(CORRUPTED,
                            'zakres %d-%d zwrocil status %s' % (start, end, status),
                            position=start)
        if blen == 0:
            return _verdict(CORRUPTED, 'martwy (pusty) zakres na %d B' % start,
                            position=start)
    return None


def _default_http(method, url, headers, range_tuple):
    import requests
    hdrs = dict(headers or {})
    if range_tuple is not None:
        hdrs['Range'] = 'bytes=%d-%d' % (range_tuple[0], range_tuple[1])
    if method == 'HEAD':
        r = requests.head(url, headers=hdrs, timeout=8, allow_redirects=True)
        return {'status': r.status_code, 'headers': dict(r.headers), 'body': b''}
    r = requests.get(url, headers=hdrs, timeout=8, allow_redirects=True, stream=True)
    body = r.raw.read(SAMPLE_CHUNK + 16) if r.raw else (r.content or b'')
    return {'status': r.status_code, 'headers': dict(r.headers), 'body': body}


def scan(url, headers=None, http=None, opts=None):
    opts = opts or {}
    headers = headers or {}
    if http is None:
        http = _default_http
    try:
        h = http('HEAD', url, headers, None)
        status = h.get('status', 0)
        hh = _lower_headers(h.get('headers') or {})
        clen = _to_int(hh.get('content-length'))
        ctype = (hh.get('content-type') or '').lower()
        accept_ranges = (hh.get('accept-ranges') or '').lower()

        if status and status >= 400:
            return _verdict(INCONCLUSIVE, 'HEAD status %s' % status)
        if 'mpegurl' in ctype or 'm3u8' in ctype or ctype.startswith('text/'):
            return _verdict(INCONCLUSIVE, 'nie-bezposredni plik (content-type %s)' % ctype)
        if not clen or clen <= 0:
            return _verdict(INCONCLUSIVE, 'brak content-length')
        if 'none' in accept_ranges:
            return _verdict(INCONCLUSIVE, 'serwer nie wspiera Range')

        head = None
        st, _ = None, None
        resp = http('GET', url, headers, (0, min(HEAD_BYTES, clen) - 1))
        if resp.get('status') != 206:
            return _verdict(INCONCLUSIVE, 'Range niewspierany (probka head)')
        head = resp.get('body') or b''

        tail_start = max(0, clen - TAIL_BYTES)
        rt = http('GET', url, headers, (tail_start, clen - 1))
        if rt.get('status') != 206:
            return _verdict(INCONCLUSIVE, 'Range niewspierany (probka tail)')
        tail = rt.get('body') or b''

        container = _classify_container(head)
        if container == 'mp4':
            v = _check_mp4(head, tail, tail_start, clen)
            if v is not None:
                return v

        v = _sample_ranges(http, url, headers, clen)
        if v is not None:
            return v

        return _verdict(OK, '%s kompletny; probki OK' % (container or 'unknown'))
    except Exception as e:
        return _verdict(INCONCLUSIVE, 'blad skanu: %s' % e.__class__.__name__)
