# -*- coding: utf-8 -*-

"""
    FanVodPL Add-on
    Copyright (C) 2015 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

from ptw.libraries import control
from ptw.libraries import log_utils
from ptw.libraries.log_utils import log, fflog
from ptw.debug import log_exception, fflog_exc
from ptw.libraries import trakt
import json as _json

# niektóre nie mają imdb
# imdb = imdb or tmdb



def _ensure_progress_runtime_table(dbcur):
    dbcur.execute(
        "CREATE TABLE IF NOT EXISTS progress_runtime ("
        "type TEXT, "
        "imdb TEXT, "
        "season TEXT, "
        "episode TEXT, "
        "totalTime REAL, "
        "UNIQUE(type, imdb, season, episode)"
        ");"
    )



def set_saved_total_time(media_type, imdb, total_time, season="", episode=""):
    try:
        total_time = float(total_time or 0)
    except Exception:
        return
    if total_time <= 0:
        return
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_progress_runtime_table(dbcur)
        dbcur.execute(
            "INSERT OR REPLACE INTO progress_runtime(type, imdb, season, episode, totalTime) VALUES (?, ?, ?, ?, ?)",
            (media_type, imdb, str(season or ''), str(episode or ''), total_time),
        )
        dbcon.commit()
    except Exception:
        fflog_exc(0)



def get_saved_total_time(media_type, imdb, season="", episode=""):
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_progress_runtime_table(dbcur)
        dbcur.execute(
            "SELECT totalTime FROM progress_runtime WHERE type = ? AND imdb = ? AND season = ? AND episode = ?",
            (media_type, imdb, str(season or ''), str(episode or '')),
        )
        match = dbcur.fetchone()
        dbcon.commit()
        if match and match[0]:
            return float(match[0])
    except Exception:
        fflog_exc(0)
    return 0.0



def delete_saved_total_time(media_type, imdb, season="", episode=""):
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_progress_runtime_table(dbcur)
        dbcur.execute(
            "DELETE FROM progress_runtime WHERE type = ? AND imdb = ? AND season = ? AND episode = ?",
            (media_type, imdb, str(season or ''), str(episode or '')),
        )
        dbcon.commit()
    except Exception:
        fflog_exc(0)

def get(media_type, imdb, season=None, episode=None, local=False, tmdb=None):  # tmdb nie dorobione jeszcze
    # fflog(f'{media_type=} {imdb=} {local=} {season=} {episode=} {tmdb=}',1,1)
    offset = 0
    runtime = 0
    # imdb = imdb or tmdb
    source = None
    if (
        local == False
        #and control.setting('resume.source') == '1'  # nie ma takiego settingsu
        and trakt.getTraktIndicatorsInfo()
        and trakt.getTraktCredentialsInfo() == True
        ):
        try:
            fflog(f'from trakt', 0)
            source = 'trakt'
            #control.sleep(500)
            if media_type == 'episode':
                # Looking for a Episode progress
                traktInfo = trakt.getTraktAsJson('https://api.trakt.tv/sync/playback/episodes?extended=full')
                fflog(f'{traktInfo=}') if not traktInfo else ""
                for i in traktInfo:
                    if imdb == i['show']['ids']['imdb']:  # or tmdb == i['show']['ids']['tmdb']
                        # Checking Episode Number
                        if int(season) == i['episode']['season'] and int(episode) == i['episode']['number']:
                            runtime = int(i['episode']['runtime']) * 60
                            fflog(f"{i['progress']=}",0)
                            seekable = 1 < i['progress'] < 92
                            fflog(f'{seekable=}',0)
                            if seekable:
                                # Calculating Offset to seconds
                                offset = float(i['progress'] / 100) * int(i['episode']['runtime']) * 60
                            else:
                                offset = 0
            else:
                # Looking for a Movie Progress
                traktInfo = trakt.getTraktAsJson('https://api.trakt.tv/sync/playback/movies?extended=full')  # full aby mieć runtime, tylko czemu szuka wszystkich filmów, a nie tylko jednego ?
                fflog(f'{traktInfo=}') if not traktInfo else ""
                for i in traktInfo:
                    if imdb == i['movie']['ids']['imdb']:  # or tmdb == i['movie']['ids']['tmdb']
                        runtime = int(i['movie']['runtime']) * 60
                        fflog(f"{i['progress']=}",0)
                        seekable = 1 < i['progress'] < 92
                        fflog(f'{seekable=}',0)
                        if seekable:
                            # Calculating Offset to seconds
                            offset = float(i['progress'] / 100) * int(i['movie']['runtime']) * 60
                        else:
                            offset = 0
            fflog(f'{offset=}  {runtime=}', 0)
            if offset > 0:  # chociaż ten warunek też jest dalej sprawdzany
                return offset, runtime, source  # więc może tego tu nie być
                pass
        except Exception:
            fflog_exc(1)
            offset = 0

    # else:
    if True:
        if offset == 0:  # ten warunek jest ważny
            fflog(f'from local machine', 0)
            source = 'local'
            # runtime = 0  # pomyśleć nad tym
            # imdb = imdb or tmdb
            try:
                sql_select = "SELECT * FROM bookmarks WHERE imdb = '%s'" % imdb
                if media_type == "episode":
                    sql_select += " AND season = '%s' AND episode = '%s'" % (season, episode)
                control.makeFile(control.dataPath)
                dbcon = database.connect(control.bookmarksFile)
                dbcur = dbcon.cursor()
                dbcur.execute(sql_select)
                match = dbcur.fetchone()
                if match:
                    offset = match[0]
                    offset = float(offset)
                    runtime = get_saved_total_time(media_type, imdb, season, episode)
                else:
                    offset = 0
                fflog(f'{offset=}', 0)
                dbcon.commit()
            except Exception as e:
                log_utils.log("bookmarks_get %s" % e, "module")
                fflog_exc(0)
                offset = 0

    #return offset
    # return offset, runtime
    return offset, runtime, source


def reset(current_time, total_time, media_type, imdb, season="", episode=""):
    #fflog(f'[reset] {current_time=} {total_time=} {imdb=} {season=} {episode=}')
    try:
        _playcount = 0
        overlay = 6
        timeInSeconds = str(current_time)
        ok = int(current_time) > 120 and (current_time / total_time) < 0.92
        watched = (current_time / total_time) >= 0.92

        sql_select = "SELECT * FROM bookmarks WHERE imdb = '%s'" % imdb
        if media_type == "episode":
            sql_select += " AND season = '%s' AND episode = '%s'" % (season, episode)

        sql_update = "UPDATE bookmarks SET timeInSeconds = '%s' WHERE imdb = '%s'" % (timeInSeconds, imdb,)
        if media_type == "episode":
            sql_update += " AND season = '%s' AND episode = '%s'" % (season, episode)

        if media_type == "movie":
            sql_update_watched = (
                # "UPDATE bookmarks SET timeInSeconds = '0', playcount = %s, overlay = %s WHERE imdb = '%s'" % ("%s", "%s", imdb)
                "UPDATE bookmarks SET timeInSeconds = '%s', playcount = %s, overlay = %s WHERE imdb = '%s'" % (timeInSeconds, "%s", "%s", imdb)
            )
        elif media_type == "episode":
            sql_update_watched = (
                # "UPDATE bookmarks SET timeInSeconds = '0', playcount = %s, overlay = %s WHERE imdb = '%s' AND season = '%s' AND episode = '%s'" % ("%s", "%s", imdb, season, episode)
                "UPDATE bookmarks SET timeInSeconds = '%s', playcount = %s, overlay = %s WHERE imdb = '%s' AND season = '%s' AND episode = '%s'" % (timeInSeconds, "%s", "%s", imdb, season, episode)
            )

        if media_type == "movie":
            sql_insert = (
                "INSERT INTO bookmarks Values ('%s', '%s', '%s', '', '', '%s', '%s')"
                % (timeInSeconds, media_type, imdb, _playcount, overlay)
            )
        elif media_type == "episode":
            sql_insert = (
                "INSERT INTO bookmarks Values ('%s', '%s', '%s', '%s', '%s', '%s', '%s')"
                % (
                    timeInSeconds,
                    media_type,
                    imdb,
                    season,
                    episode,
                    _playcount,
                    overlay,
                )
            )

        if media_type == "movie":
            sql_insert_watched = (
                "INSERT INTO bookmarks Values ('%s', '%s', '%s', '', '', '%s', '%s')"
                % (timeInSeconds, media_type, imdb, "%s", "%s")
            )
        elif media_type == "episode":
            sql_insert_watched = (
                "INSERT INTO bookmarks Values ('%s', '%s', '%s', '%s', '%s', '%s', '%s')"
                % (timeInSeconds, media_type, imdb, season, episode, "%s", "%s")
            )

        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        """ przeniosełem do def _indicators
        dbcur.execute(
            "CREATE TABLE IF NOT EXISTS bookmarks ("
            "timeInSeconds TEXT, "
            "type TEXT, "
            "imdb TEXT, "  # czasami może być numer tmdb, ale dla kompatybilności w kolumnie o nazwie imdb
            "season TEXT, "
            "episode TEXT, "
            "playcount INTEGER, "
            "overlay INTEGER, "
            "UNIQUE(imdb, season, episode)"
            ");"
        )
        _ensure_progress_runtime_table(dbcur)
        """
        dbcur.execute(sql_select)
        match = dbcur.fetchone()
        # fflog(f'{match=} {imdb=}',1,1)
        fflog(f'{match=}  {ok=}  {current_time=}  {total_time=}  {imdb=}',1,1)
        if total_time and total_time > 0:
            dbcur.execute(
                "INSERT OR REPLACE INTO progress_runtime(type, imdb, season, episode, totalTime) VALUES (?, ?, ?, ?, ?)",
                (media_type, imdb, str(season or ''), str(episode or ''), float(total_time)),
            )

        if match:
            if ok:
                dbcur.execute(sql_update)
            elif watched:
                _playcount = match[5] + 1
                overlay = 7
                dbcur.execute(sql_update_watched % (_playcount, overlay))
        else:
            if ok:
                # fflog(f'{sql_insert=}',1,1)
                dbcur.execute(sql_insert)
            elif watched:
                _playcount = 1
                overlay = 7
                dbcur.execute(sql_insert_watched % (_playcount, overlay))
        dbcon.commit()
    except Exception:
        log_utils.log("bookmarks_reset", "module")
        fflog_exc(0)
        pass


def set_scrobble(current_time, total_time, _content, _imdb="", _tvdb="", _season="", _episode="", last_time=0, action=""):
    #fflog(f'[set_scrobble] {current_time=} {total_time=} {_imdb=} {_season=} {_episode=}')
    try:
        if current_time <= 120 and last_time:
            current_time = last_time
        if not (current_time == 0 or total_time == 0):
            percent = float((current_time / total_time)) * 100
        else:
            percent = 0
        #fflog(f'{percent=}')

        if action == "start" and percent < 99:
            trakt.scrobbleMovie(
                _imdb, percent, action="start"
            ) if _content == "movie" else trakt.scrobbleEpisode(
                _imdb, _season, _episode, percent, action="start"
            )
            #if control.setting("trakt.scrobble.notify") == "true":  # nie ma takiego ustawienia
            if True:
                #control.sleep(1000)
                control.infoDialog("Trakt: Scrobble Start", time=1)
                fflog("Trakt: Scrobble Start")
            return

        #if int(current_time) > 120 and 2 < percent < 92:
        if percent < 92:  # zatrzymanie wideo powinno także zatrzymać progress w dashboardzie, niezależnie od procentu (poniżej granicy finish)
            trakt.scrobbleMovie(
                _imdb, percent, action="pause"
            ) if _content == "movie" else trakt.scrobbleEpisode(
                _imdb, _season, _episode, percent, action="pause"
            )
            #if control.setting("trakt.scrobble.notify") == "true":  # nie ma takiego ustawienia
            if True:
                #control.sleep(1000)
                control.infoDialog("Trakt: Scrobble Paused", time=1)
                fflog("Trakt: Scrobble Paused")
        elif percent >= 92:
            trakt.scrobbleMovie(
                _imdb, percent, action="stop"
            ) if _content == "movie" else trakt.scrobbleEpisode(
                _imdb, _season, _episode, percent, action="stop"
            )
            #if control.setting("trakt.scrobble.notify") == "true":  # nie ma takiego ustawienia
            if True:
                #control.sleep(1000)
                control.infoDialog("Trakt: Scrobbled (finish)", time=1)
                fflog("Trakt: Scrobbled (finish)")
    except Exception:
        fflog_exc(1)
        log_utils.log("Scrobble - Exception", "module")
        control.infoDialog("Scrobble Failed")


def get_scrobble( _content, imdb, season="", episode=""):
    if _content == "movie":
        percent = trakt.getMovieProgress(imdb)
        return percent
    else:
        percent = trakt.getEpisodeProgress(imdb, season, episode)
        return percent


def _indicators(out=None, media_type=None):
    control.makeFile(control.dataPath)
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()
    dbcur.execute(
        "CREATE TABLE IF NOT EXISTS bookmarks ("
        "timeInSeconds TEXT, "
        "type TEXT, "
        "imdb TEXT, "  # czasami może być numer tmdb, ale dla kompatybilności w kolumnie o nazwie imdb
        "season TEXT, "
        "episode TEXT, "
        "playcount INTEGER, "
        "overlay INTEGER, "
        "UNIQUE(imdb, season, episode)"
        ");"
    )
    _ensure_progress_runtime_table(dbcur)
    sql_select = "SELECT * FROM bookmarks WHERE overlay = 7"
    if media_type:
        sql_select += " AND type = '%s'" % media_type
    dbcur.execute(sql_select)
    match = dbcur.fetchall()
    dbcon.commit()
    if match:
        # fflog(f'{match=}',1,1)
        if not out:
            return [i[2] for i in match]
        else:
            if out == 'all':
                return [i for i in match]
            elif 'episode' in out or media_type == 'episode':
                # return [(i[2], (i[3],i[4])) for i in match]
                return [(i[2], i[3], i[4]) for i in match]
    else: return []  # czy lepiej None?


def _get_watched(media_type, imdb, season=None, episode=None):
    sql_select = "SELECT * FROM bookmarks WHERE imdb = '%s' AND overlay = 7" % imdb
    # sql_select = "SELECT * FROM bookmarks WHERE imdb = '%s'" % imdb
    if media_type == "episode":
        # sql_select += " AND season = '%s' AND episode = '%s'" % (season, episode)
        if season:
            sql_select += " AND season = '%s'" % season
        if episode:
            sql_select += " AND episode = '%s'" % episode
    control.makeFile(control.dataPath)
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()
    dbcur.execute(sql_select)
    match = dbcur.fetchone()
    dbcon.commit()
    # fflog(f'{match=}',1,1)
    if match:
        # if match[6] == 7:
            # return 7
        # else
            # return 6
        return 7  # tu typ liczbowy (a nie string)
    else:
        return 6
        # return 0


def _update_watched(media_type, new_value, imdb, season=None, episode=None):
    sql_update = "UPDATE bookmarks SET overlay = %s WHERE imdb = '%s'" % (new_value, imdb,)
    if media_type == "episode":
        # sql_update += " AND season = '%s' AND episode = '%s'" % (season, episode)
        if season:
            sql_select += " AND season = '%s'" % season
        if episode:
            sql_select += " AND episode = '%s'" % episode
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()
    dbcur.execute(sql_update)
    dbcon.commit()


def _delete_record(media_type, imdb, season=None, episode=None):
    fflog(f'{imdb=}  {media_type=}  {season=}  {episode=}',1,1)
    sql_delete = "DELETE FROM bookmarks WHERE imdb = '%s'" % imdb
    if media_type == "episode":
        sql_delete += " AND season = '%s' AND episode = '%s'" % (season, episode)
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()
    _ensure_progress_runtime_table(dbcur)
    dbcur.execute(sql_delete)
    dbcur.execute(
        "DELETE FROM progress_runtime WHERE type = ? AND imdb = ? AND season = ? AND episode = ?",
        (media_type, imdb, str(season or ''), str(episode or '')),
    )
    dbcon.commit()


def _get_inprogress_episode_rows(imdb=None, season=None):
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        sql_select = (
            "SELECT imdb, season, episode, timeInSeconds FROM bookmarks "
            "WHERE type = 'episode' AND CAST(timeInSeconds AS REAL) > 0 AND overlay != 7"
        )
        if imdb:
            sql_select += " AND imdb = '%s'" % imdb
        if season not in (None, '', 'None'):
            sql_select += " AND season = '%s'" % season
        sql_select += " GROUP BY imdb, season, episode ORDER BY rowid DESC"
        dbcur.execute(sql_select)
        match = dbcur.fetchall()
        dbcon.commit()
        return match or []
    except Exception:
        fflog_exc(0)
        return []


def get_inprogress_episode_count(imdb, season=None):
    try:
        return len(_get_inprogress_episode_rows(imdb=imdb, season=season))
    except Exception:
        return 0


def has_inprogress_episode(imdb, season=None):
    try:
        return get_inprogress_episode_count(imdb, season=season) > 0
    except Exception:
        return False


def last_position():
    # from local database
    sql_select = "SELECT type, imdb, season, episode FROM bookmarks WHERE rowid = (SELECT MAX(rowid) FROM bookmarks);"
    control.makeFile(control.dataPath)
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()
    dbcur.execute(sql_select)
    match = dbcur.fetchone()
    dbcon.commit()
    return match


def last_positions(limit=10):
    # from local database
    # sql_select = "SELECT type, imdb, season, episode FROM bookmarks"
    sql_select = "SELECT type, imdb, season, episode FROM bookmarks ORDER BY rowid DESC LIMIT %s" % limit
    control.makeFile(control.dataPath)
    dbcon = database.connect(control.bookmarksFile)
    dbcur = dbcon.cursor()
    dbcur.execute(sql_select)
    match = dbcur.fetchall()
    dbcon.commit()
    # fflog(f'{len(match)=}  {match=}',1,1)
    # match = match[::-1][:limit]
    # fflog(f'{len(match)=}  {match=}',1,1)
    return match


def get_inprogress_all(limit=20):
    """Zwraca listę naprawdę niedokończonych filmów i odcinków (< 92% obejrzane).
    Filmy: jeden wpis na film.
    Seriale: jeden wpis na serial (najnowszy niedokończony odcinek).
    Posortowane od najnowszych. Używane przez 'Kontynuuj oglądanie'."""
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        # JOIN z progress_runtime żeby mieć totalTime i obliczyć procent
        sql = (
            "SELECT b.type, b.imdb, b.season, b.episode, "
            "CAST(b.timeInSeconds AS REAL) as t, "
            "COALESCE(pr.totalTime, 0) as total "
            "FROM bookmarks b "
            "LEFT JOIN progress_runtime pr "
            "ON pr.type=b.type AND pr.imdb=b.imdb AND pr.season=b.season AND pr.episode=b.episode "
            "WHERE CAST(b.timeInSeconds AS REAL) > 120 AND b.overlay != 7 "
            "ORDER BY b.rowid DESC"
        )
        dbcur.execute(sql)
        rows = dbcur.fetchall()
        dbcon.commit()

        seen_key = set()
        result = []
        for row in rows:
            media_type, imdb, season, episode, t, total = row
            if not imdb or imdb in ('0', 'None', ''):
                continue
            # Pomiń jeśli totalTime znane i odcinek/film obejrzany >= 92%
            if total and total > 0 and (t / total) >= 0.92:
                continue
            # Deduplikacja: dla odcinków po (imdb+season+episode), dla filmów po imdb
            if media_type == 'episode':
                key = '%s_%s_%s' % (imdb, season, episode)
            else:
                key = imdb
            if key in seen_key:
                continue
            seen_key.add(key)
            percent = int((t / total * 100)) if total and total > 0 else 0
            result.append({
                'media_type': media_type,
                'imdb': imdb,
                'season': season,
                'episode': episode,
                'timeInSeconds': t,
                'percent': percent,
            })
            if len(result) >= limit:
                break
        return result
    except Exception:
        fflog_exc(0)
        return []


# ============================================================
# GROUP AUDIO CACHE – self-learning Multi language filter
# Uczy się na podstawie faktycznych ścieżek audio po starcie.
# ============================================================

def _ensure_group_audio_cache_table(dbcur):
    dbcur.execute(
        """CREATE TABLE IF NOT EXISTS group_audio_cache (
            group_name TEXT PRIMARY KEY,
            verdict TEXT,
            foreign_langs TEXT,
            confirm_count INTEGER DEFAULT 1,
            updated_at TEXT
        );"""
    )


# Ile razy musi się potwierdzić obcy język zanim zablokuje PRZED odtworzeniem
_GROUP_CACHE_CONFIRM_THRESHOLD = 1


def group_cache_lookup(group_name):
    """
    Sprawdza cache dla podanej nazwy grupy.
    Zwraca 'safe', 'foreign' (>=2 potwierdzeń), lub None (nieznany/za mało danych).
    """
    if not group_name:
        return None
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_group_audio_cache_table(dbcur)
        dbcur.execute(
            'SELECT verdict, confirm_count FROM group_audio_cache WHERE group_name = ?',
            (group_name.lower(),)
        )
        row = dbcur.fetchone()
        dbcon.commit()
        if not row:
            return None
        verdict, count = row
        if verdict in ('dead', 'lowres', 'corrupted'):
            return verdict  # dead/lowres/corrupted blokuje od razu bez progu
        if verdict == 'foreign' and count < _GROUP_CACHE_CONFIRM_THRESHOLD:
            fflog(f'[GROUP_CACHE] {group_name}: foreign ale tylko {count}/{_GROUP_CACHE_CONFIRM_THRESHOLD} potwierdzen - jeszcze nie blokuj', 0)
            return None
        return verdict
    except Exception:
        fflog_exc(0)
        return None


def group_cache_record(group_name, langs_found, foreign_langs):
    """
    Zapisuje wynik po faktycznym odtworzeniu (onAVStarted).
    langs_found  - set wszystkich jezykow z getAvailableAudioStreams()
    foreign_langs - set obcych jezykow (poza PL/EN/und)
    """
    if not group_name:
        return
    # Obsługa verdictów: dead > foreign > safe
    if 'dead' in (foreign_langs or set()):
        verdict = 'dead'
        foreign_json = _json.dumps(['dead'])
    elif foreign_langs:
        verdict = 'foreign'
        foreign_json = _json.dumps(sorted(foreign_langs))
    else:
        verdict = 'safe'
        foreign_json = _json.dumps([])
    try:
        import datetime as _dt
        now = _dt.datetime.now().isoformat()
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_group_audio_cache_table(dbcur)
        dbcur.execute(
            'SELECT verdict, confirm_count FROM group_audio_cache WHERE group_name = ?',
            (group_name.lower(),)
        )
        row = dbcur.fetchone()
        if row:
            old_verdict, old_count = row
            # Ten sam wyrok - zwieksz licznik. Zmiana - resetuj.
            new_count = old_count + 1 if old_verdict == verdict else 1
            dbcur.execute(
                'UPDATE group_audio_cache SET verdict=?, foreign_langs=?, confirm_count=?, updated_at=? WHERE group_name=?',
                (verdict, foreign_json, new_count, now, group_name.lower())
            )
        else:
            dbcur.execute(
                'INSERT INTO group_audio_cache(group_name, verdict, foreign_langs, confirm_count, updated_at) VALUES(?,?,?,1,?)',
                (group_name.lower(), verdict, foreign_json, now)
            )
        dbcon.commit()
        fflog(f'[GROUP_CACHE] zapisano: {group_name!r} -> {verdict} | langs={langs_found} | foreign={foreign_langs}', 0)
    except Exception:
        fflog_exc(1)


def group_cache_record_lowres(group_name, declared_quality, actual_height, min_required):
    """
    Zapisuje verdict 'lowres' dla grupy gdy faktyczna rozdzielczosc
    jest istotnie nizsza od zadeklarowanej w zrodle.

    declared_quality - string ze zrodla (np. '4K', '1080p', 'FHD')
    actual_height    - faktyczna wysokosc w px zmierzona przez player
    min_required     - minimalna akceptowalna wysokosc dla zadeklarowanej jakosci

    Priorytet verdictow: dead > foreign > lowres > safe.
    Nie nadpisujemy wpisow dead/foreign (mocniejsze blokady).
    """
    if not group_name:
        return
    try:
        import datetime as _dt
        now = _dt.datetime.now().isoformat()
        meta = {
            'declared': str(declared_quality or ''),
            'actual': int(actual_height or 0),
            'min_required': int(min_required or 0),
        }
        meta_json = _json.dumps(meta, ensure_ascii=False)

        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_group_audio_cache_table(dbcur)
        dbcur.execute(
            'SELECT verdict, confirm_count FROM group_audio_cache WHERE group_name = ?',
            (group_name.lower(),)
        )
        row = dbcur.fetchone()
        if row:
            old_verdict, old_count = row
            # Nie osłabiaj mocniejszych werdyktów.
            if old_verdict in ('dead', 'foreign'):
                fflog(f'[GROUP_CACHE][LOWRES] pomijam zapis - istnieje mocniejszy verdict={old_verdict!r} dla {group_name!r}', 0)
                dbcon.commit()
                return
            new_count = old_count + 1 if old_verdict == 'lowres' else 1
            dbcur.execute(
                'UPDATE group_audio_cache SET verdict=?, foreign_langs=?, confirm_count=?, updated_at=? WHERE group_name=?',
                ('lowres', meta_json, new_count, now, group_name.lower())
            )
        else:
            dbcur.execute(
                'INSERT INTO group_audio_cache(group_name, verdict, foreign_langs, confirm_count, updated_at) VALUES(?,?,?,1,?)',
                (group_name.lower(), 'lowres', meta_json, now)
            )
        dbcon.commit()
        fflog(f'[GROUP_CACHE][LOWRES] zapisano: {group_name!r} declared={declared_quality!r} actual={actual_height}px min={min_required}px', 1)
    except Exception:
        fflog_exc(1)


def group_cache_record_stall(group_name, stall_count, stall_total_s):
    """
    Zapisuje verdict 'corrupted' dla grupy gdy uzytkownik potwierdzil
    (po komunikacie STALL_CHECK), ze plik/link powtarzalnie sie zacina
    w tych samych miejscach - podejrzenie uszkodzonego pliku.

    stall_count    - liczba wykrytych epizodow zaciecia w tej sesji
    stall_total_s  - laczny czas zaciecia (przyblizenie, sekundy)

    Priorytet verdictow: dead > foreign > lowres > corrupted > safe.
    Nie nadpisujemy wpisow dead/foreign/lowres (mocniejsze/wczesniejsze blokady).
    """
    if not group_name:
        return
    try:
        import datetime as _dt
        now = _dt.datetime.now().isoformat()
        meta = {
            'stall_count': int(stall_count or 0),
            'stall_total_s': round(float(stall_total_s or 0.0), 1),
        }
        meta_json = _json.dumps(meta, ensure_ascii=False)

        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_group_audio_cache_table(dbcur)
        dbcur.execute(
            'SELECT verdict, confirm_count FROM group_audio_cache WHERE group_name = ?',
            (group_name.lower(),)
        )
        row = dbcur.fetchone()
        if row:
            old_verdict, old_count = row
            # Nie osłabiaj mocniejszych werdyktów.
            if old_verdict in ('dead', 'foreign', 'lowres'):
                fflog(f'[GROUP_CACHE][STALL] pomijam zapis - istnieje mocniejszy verdict={old_verdict!r} dla {group_name!r}', 0)
                dbcon.commit()
                return
            new_count = old_count + 1 if old_verdict == 'corrupted' else 1
            dbcur.execute(
                'UPDATE group_audio_cache SET verdict=?, foreign_langs=?, confirm_count=?, updated_at=? WHERE group_name=?',
                ('corrupted', meta_json, new_count, now, group_name.lower())
            )
        else:
            dbcur.execute(
                'INSERT INTO group_audio_cache(group_name, verdict, foreign_langs, confirm_count, updated_at) VALUES(?,?,?,1,?)',
                (group_name.lower(), 'corrupted', meta_json, now)
            )
        dbcon.commit()
        fflog(f'[GROUP_CACHE][STALL] zapisano: {group_name!r} stall_count={stall_count} stall_total_s={stall_total_s}', 1)
    except Exception:
        fflog_exc(1)


def _ensure_stall_positions_table(dbcur):
    dbcur.execute(
        """CREATE TABLE IF NOT EXISTS stall_positions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_name TEXT,
            position REAL,
            session_id TEXT,
            recorded_at TEXT
        );"""
    )
    dbcur.execute(
        'CREATE INDEX IF NOT EXISTS idx_stall_positions_group ON stall_positions(group_name);'
    )


# Tolerancja (w sekundach) przy porownywaniu pozycji zaciecia miedzy sesjami.
_STALL_POSITION_TOLERANCE_S = 15.0


def group_cache_record_corrupt(group_name, reason='file_scan'):
    """
    Zapisuje verdict 'corrupted' dla grupy po wykryciu uszkodzenia pliku przez
    pre-play skan integralnosci (file_integrity.scan). Analogiczne do
    group_cache_record_stall, ale bez pol stall - z powodem tekstowym.
    Priorytet: dead > foreign > lowres > corrupted > safe (nie oslabiamy
    mocniejszych werdyktow).
    """
    if not group_name:
        return
    try:
        import datetime as _dt
        now = _dt.datetime.now().isoformat()
        meta_json = _json.dumps({'reason': str(reason)[:200]}, ensure_ascii=False)
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_group_audio_cache_table(dbcur)
        dbcur.execute(
            'SELECT verdict, confirm_count FROM group_audio_cache WHERE group_name = ?',
            (group_name.lower(),)
        )
        row = dbcur.fetchone()
        if row:
            old_verdict, old_count = row
            if old_verdict in ('dead', 'foreign', 'lowres'):
                fflog(f'[GROUP_CACHE][CORRUPT] pomijam - mocniejszy verdict={old_verdict!r}', 0)
                dbcon.commit()
                return
            new_count = old_count + 1 if old_verdict == 'corrupted' else 1
            dbcur.execute(
                'UPDATE group_audio_cache SET verdict=?, foreign_langs=?, confirm_count=?, updated_at=? WHERE group_name=?',
                ('corrupted', meta_json, new_count, now, group_name.lower())
            )
        else:
            dbcur.execute(
                'INSERT INTO group_audio_cache(group_name, verdict, foreign_langs, confirm_count, updated_at) VALUES(?,?,?,1,?)',
                (group_name.lower(), 'corrupted', meta_json, now)
            )
        dbcon.commit()
        fflog(f'[GROUP_CACHE][CORRUPT] zapisano: {group_name!r} reason={reason!r}', 1)
    except Exception:
        fflog_exc(1)


def stall_position_check_and_record(group_name, position, session_id, tolerance=None):
    """
    Sprawdza, czy TA SAMA pozycja pliku (w granicach tolerancji, domyslnie
    15s) zaciela sie juz wczesniej w INNEJ (niezaleznej) sesji odtwarzania.

    Zwraca True, jesli znaleziono dopasowanie z INNYM session_id - to realna
    poszlaka uszkodzenia pliku (przypadkowa niestabilnosc sieci prawie nigdy
    nie trafia dwa razy w to samo miejsce, w oddzielnych sesjach).

    Zawsze zapisuje NOWY wpis (do porownan w przyszlych sesjach), niezaleznie
    od wyniku sprawdzenia.
    """
    if not group_name:
        return False
    if tolerance is None:
        tolerance = _STALL_POSITION_TOLERANCE_S
    repeat_found = False
    try:
        import datetime as _dt
        now = _dt.datetime.now().isoformat()
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_stall_positions_table(dbcur)
        dbcur.execute(
            'SELECT position, session_id FROM stall_positions WHERE group_name = ?',
            (group_name.lower(),)
        )
        rows = dbcur.fetchall()
        for stored_position, stored_session in rows:
            if str(stored_session) != str(session_id) and abs(float(stored_position) - float(position)) <= tolerance:
                repeat_found = True
                break
        dbcur.execute(
            'INSERT INTO stall_positions(group_name, position, session_id, recorded_at) VALUES(?,?,?,?)',
            (group_name.lower(), float(position), str(session_id), now)
        )
        dbcon.commit()
        if repeat_found:
            fflog(f'[STALL_POS] powtorzone zaciecie w tym samym miejscu (~{position:.0f}s) dla {group_name!r} - inna sesja', 1)
        else:
            fflog(f'[STALL_POS] zapisano nowa pozycje zaciecia ({position:.0f}s) dla {group_name!r}', 0)
    except Exception:
        fflog_exc(1)
    return repeat_found


def group_cache_clear(group_name=None):
    """Czyści cache – wszystkie grupy lub konkretną (np. z panelu ustawień)."""
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_group_audio_cache_table(dbcur)
        if group_name:
            dbcur.execute('DELETE FROM group_audio_cache WHERE group_name = ?', (group_name.lower(),))
            fflog(f'[GROUP_CACHE] wyczyszczono grupe: {group_name}', 0)
        else:
            dbcur.execute('DELETE FROM group_audio_cache')
            fflog('[GROUP_CACHE] wyczyszczono caly cache', 0)
        dbcon.commit()
    except Exception:
        fflog_exc(1)


def group_cache_clear_corrupt(group_name):
    """Usuwa wpis z group_audio_cache TYLKO gdy verdict=='corrupted' (zaciecie).
    Uzywane gdy uzytkownik wybral "ogladaj dalej" (NIE) - plik NIE ma zostac na
    czarnej liscie. NIE rusza werdyktow dead/foreign/lowres (silniejsze blokady)."""
    if not group_name:
        return
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_group_audio_cache_table(dbcur)
        dbcur.execute(
            "DELETE FROM group_audio_cache WHERE group_name = ? AND verdict = 'corrupted'",
            (group_name.lower(),)
        )
        dbcon.commit()
        fflog(f'[GROUP_CACHE] usunieto wpis corrupted (user: ogladaj dalej) dla {group_name!r}', 1)
    except Exception:
        fflog_exc(1)


def group_cache_record_stall_soft(group_name):
    """Zapisuje verdict 'stall_soft' - plik oznaczony przez usera jako uszkodzony,
    ale GRYWALNY (wybor "ogladaj dalej" w oknie zacinania). NIE blokuje
    odtwarzania i NIE usuwa z listy zrodel - sluzy tylko do pokazania etykiety
    "USZKODZONY" przy zrodle. NIE nadpisuje mocniejszych werdyktow
    (dead/foreign/lowres/corrupted)."""
    if not group_name:
        return
    try:
        import datetime as _dt
        now = _dt.datetime.now().isoformat()
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_group_audio_cache_table(dbcur)
        dbcur.execute(
            'SELECT verdict FROM group_audio_cache WHERE group_name = ?',
            (group_name.lower(),)
        )
        row = dbcur.fetchone()
        if row and row[0] in ('dead', 'foreign', 'lowres', 'corrupted'):
            dbcon.commit()
            return
        dbcur.execute(
            'INSERT OR REPLACE INTO group_audio_cache(group_name, verdict, foreign_langs, confirm_count, updated_at) VALUES(?,?,?,1,?)',
            (group_name.lower(), 'stall_soft', '[]', now)
        )
        dbcon.commit()
        fflog(f'[GROUP_CACHE] oznaczono stall_soft (uszkodzony ale grywalny) dla {group_name!r}', 1)
    except Exception:
        fflog_exc(1)


# ============================================================
# SOURCE URL CACHE – blokuje konkretne URLe z obcym audio
# Klucz: pierwsze 400 znaków oryginalnego URL hostingu
# ============================================================

def _ensure_source_url_cache_table(dbcur):
    dbcur.execute(
        """CREATE TABLE IF NOT EXISTS source_url_cache (
            url_key TEXT PRIMARY KEY,
            verdict TEXT,
            foreign_langs TEXT,
            created_at TEXT
        );"""
    )


def source_url_cache_lookup(url):
    """
    Sprawdza czy URL jest zablokowany (wykryto obce audio).
    Zwraca 'foreign' lub None.
    """
    if not url:
        return None
    url_key = str(url)[:400]
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_source_url_cache_table(dbcur)
        dbcur.execute(
            'SELECT verdict FROM source_url_cache WHERE url_key = ?',
            (url_key,)
        )
        row = dbcur.fetchone()
        dbcon.commit()
        if row:
            fflog(f'[URL_CACHE] hit: {url_key[:60]!r} -> {row[0]}', 0)
            return row[0]
        return None
    except Exception:
        fflog_exc(1)
        return None


def source_url_cache_record(url, langs_found, foreign_langs):
    """
    Zapisuje URL jako 'foreign' po wykryciu obcego audio w onAVStarted.
    """
    if not url or not foreign_langs:
        return
    url_key = str(url)[:400]
    foreign_json = _json.dumps(sorted(foreign_langs))
    try:
        import datetime as _dt
        now = _dt.datetime.now().isoformat()
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_source_url_cache_table(dbcur)
        dbcur.execute(
            'INSERT OR REPLACE INTO source_url_cache(url_key, verdict, foreign_langs, created_at) VALUES(?,?,?,?)',
            (url_key, 'foreign', foreign_json, now)
        )
        dbcon.commit()
        fflog(f'[URL_CACHE] zapisano FOREIGN: {url_key[:80]!r} langs={foreign_langs}', 1)
    except Exception:
        fflog_exc(0)


def source_url_cache_clear():
    """Czyści cały cache URL (np. z panelu ustawień)."""
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_source_url_cache_table(dbcur)
        dbcur.execute('DELETE FROM source_url_cache')
        dbcon.commit()
        fflog('[URL_CACHE] wyczyszczono', 0)
    except Exception:
        fflog_exc(0)


# ============================================================
# HOST SPEED CACHE – uczy sie czasu startu per host+rozdzielczość
# ============================================================

# Limity czasu startu (ms) per rozdzielczość – powyżej = "wolny host"
_FF_HOST_SPEED_LIMITS = {
    '4k':    15000,
    '2160p': 15000,
    '1080p': 8000,
    '1080i': 8000,
    '720p':  5000,
    'hd':    5000,
    'sd':    4000,
    '':      8000,  # fallback
}


def _ensure_host_speed_table(dbcur):
    dbcur.execute(
        """CREATE TABLE IF NOT EXISTS host_speed_cache (
            host_key  TEXT PRIMARY KEY,
            host      TEXT,
            quality   TEXT,
            avg_ms    REAL,
            count     INTEGER DEFAULT 1,
            slow_count INTEGER DEFAULT 0,
            updated_at TEXT
        );"""
    )


def host_speed_record(host, quality, start_ms):
    """
    Zapisuje czas startu odtwarzania dla danego hosta i rozdzielczości.
    host     - nazwa hosta (np. 'nopremium', 'rapideo')
    quality  - rozdzielczość (np. '1080p', '4K')
    start_ms - czas startu w ms (i * 100 z pętli czekania)
    """
    if not host or start_ms is None:
        return
    try:
        import datetime as _dt
        q = (quality or '').lower().strip()
        key = host.lower().strip() + '|' + q
        limit = _FF_HOST_SPEED_LIMITS.get(q, _FF_HOST_SPEED_LIMITS[''])
        is_slow = 1 if start_ms > limit else 0

        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_host_speed_table(dbcur)
        dbcur.execute(
            'SELECT avg_ms, count, slow_count FROM host_speed_cache WHERE host_key = ?',
            (key,)
        )
        row = dbcur.fetchone()
        now = _dt.datetime.now().isoformat()
        if row:
            old_avg, old_count, old_slow = row
            new_count = old_count + 1
            # Średnia krocząca (max 20 pomiarów żeby nie było zbyt inercyjne)
            weight = min(old_count, 20)
            new_avg = (old_avg * weight + start_ms) / (weight + 1)
            new_slow = old_slow + is_slow
            dbcur.execute(
                'UPDATE host_speed_cache SET avg_ms=?, count=?, slow_count=?, updated_at=? WHERE host_key=?',
                (new_avg, new_count, new_slow, now, key)
            )
        else:
            dbcur.execute(
                'INSERT INTO host_speed_cache(host_key, host, quality, avg_ms, count, slow_count, updated_at) VALUES(?,?,?,?,1,?,?)',
                (key, host.lower().strip(), q, float(start_ms), is_slow, now)
            )
        dbcon.commit()
        fflog(f'[HOST_SPEED] {host!r} {q!r}: {start_ms}ms (avg={row[0] if row else start_ms:.0f}ms slow={is_slow})', 0)
    except Exception:
        fflog_exc(0)


def mark_source_failed_session(imdb, host):
    """
    Oznacza hosta jako niedawno zawodnego dla danego tytulu - TYLKO w biezacej
    sesji Kodi (window property, nic nie zapisuje na dysk). Uzywane po
    przerwaniu odtwarzania przed osiagnieciem progu "obejrzane", zeby przy
    ponownym doborze zrodla dla tego samego tytulu obnizyc priorytet tego
    hosta (patrz sources.py: play(), za self.getSources(...)).
    """
    if not imdb or not host:
        return
    try:
        key = 'FanVodPL.failedHosts.' + str(imdb).strip().lower()
        host = str(host).strip().lower()
        existing = control.window.getProperty(key)
        failed = set(existing.split('|')) if existing else set()
        failed.add(host)
        control.window.setProperty(key, '|'.join(sorted(h for h in failed if h)))
    except Exception:
        pass


def get_failed_hosts_session(imdb):
    """Zwraca set() hostow oznaczonych jako zawodne dla tego tytulu w biezacej sesji."""
    if not imdb:
        return set()
    try:
        key = 'FanVodPL.failedHosts.' + str(imdb).strip().lower()
        existing = control.window.getProperty(key)
        return set(existing.split('|')) if existing else set()
    except Exception:
        return set()


def host_speed_lookup(host, quality):
    """
    Zwraca priorytet hosta: 0 = szybki, 1 = nieznany, 2 = wolny.
    Używane przez sources.py przy sortowaniu.
    """
    if not host:
        return 1
    try:
        q = (quality or '').lower().strip()
        key = host.lower().strip() + '|' + q
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_host_speed_table(dbcur)
        dbcur.execute(
            'SELECT avg_ms, count, slow_count FROM host_speed_cache WHERE host_key = ?',
            (key,)
        )
        row = dbcur.fetchone()
        dbcon.commit()
        if not row or row[1] < 2:
            return 1  # za mało danych
        avg_ms, count, slow_count = row
        limit = _FF_HOST_SPEED_LIMITS.get(q, _FF_HOST_SPEED_LIMITS[''])
        # Wolny jeśli: średnia przekracza limit LUB >50% pomiarów było wolnych
        if avg_ms > limit or (count >= 3 and slow_count / count > 0.5):
            return 2  # wolny
        return 0  # szybki
    except Exception:
        fflog_exc(0)
        return 1  # fallback = nieznany

# ============================================================
# BLACKLIST EXPORT / IMPORT
# Folder: special://profile/addon_data/plugin.video.fanvodpl/blacklist/
# Eksportuje: group_audio_cache (foreign+dead) + host_speed_cache
# NIE eksportuje: zakładki, historia oglądania
# ============================================================

def _ff_blacklist_folder():
    """Zwraca sciezke do folderu blacklist wtyczki (tworzy jesli nie istnieje)."""
    try:
        # xbmcvfs jest bezpieczniejszy na Androidzie niz os.makedirs
        try:
            import xbmcvfs as _vfs
            special = 'special://profile/addon_data/plugin.video.fanvodpl/blacklist/'
            _vfs.mkdirs(special)
            path = _vfs.translatePath(special)
        except Exception:
            import xbmc as _xbmc_bl
            path = _xbmc_bl.translatePath(
                'special://profile/addon_data/plugin.video.fanvodpl/blacklist/'
            )
            import os as _os_bl
            _os_bl.makedirs(path, exist_ok=True)
        if path:
            return path
        return None
    except Exception:
        fflog_exc(1)
        return None


def blacklist_export(filepath=None):
    """
    Eksportuje czarną listę do pliku JSON.
    filepath – jesli None, zapisuje do folderu wtyczki.
    Zwraca: (True, liczba_wpisow) lub (False, komunikat_bledu)
    """
    try:
        import datetime as _dt
        import os as _os_exp

        if not filepath:
            folder = _ff_blacklist_folder()
            if not folder:
                return False, 'Nie można utworzyć folderu eksportu'
            filepath = _os_exp.path.join(folder, 'fanvodpl_blacklist.json')

        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_group_audio_cache_table(dbcur)
        _ensure_host_speed_table(dbcur)

        dbcur.execute(
            'SELECT group_name, verdict, foreign_langs, confirm_count, updated_at '
            'FROM group_audio_cache'
        )
        audio_rows = dbcur.fetchall()

        dbcur.execute(
            'SELECT host_key, host, quality, avg_ms, count, slow_count, updated_at '
            'FROM host_speed_cache'
        )
        speed_rows = dbcur.fetchall()
        dbcon.commit()

        data = {
            'fanvodpl_blacklist': True,
            'version': 1,
            'exported_at': _dt.datetime.now().isoformat(),
            'group_audio_cache': [
                {
                    'group_name': r[0],
                    'verdict': r[1],
                    'foreign_langs': r[2],
                    'confirm_count': r[3],
                    'updated_at': r[4],
                }
                for r in audio_rows
            ],
            'host_speed_cache': [
                {
                    'host_key': r[0],
                    'host': r[1],
                    'quality': r[2],
                    'avg_ms': r[3],
                    'count': r[4],
                    'slow_count': r[5],
                    'updated_at': r[6],
                }
                for r in speed_rows
            ],
        }

        with open(filepath, 'w', encoding='utf-8') as f:
            _json.dump(data, f, ensure_ascii=False, indent=2)

        total = len(audio_rows) + len(speed_rows)
        fflog(f'[BLACKLIST] eksport: {len(audio_rows)} audio + {len(speed_rows)} speed → {filepath}', 1)
        return True, len(audio_rows) + len(speed_rows)

    except Exception as e:
        fflog_exc(1)
        return False, str(e)


def blacklist_import(filepath=None):
    """
    Importuje czarną listę z pliku JSON.
    Jeśli filepath=None – szuka fanvodpl_blacklist.json w folderze wtyczki.
    Nie nadpisuje własnych danych – tylko dodaje brakujące wpisy.
    Zwraca: (True, liczba_dodanych) lub (False, komunikat_bledu)
    """
    try:
        import os as _os_imp

        if not filepath:
            folder = _ff_blacklist_folder()
            if not folder:
                return False, 'Nie można otworzyć folderu importu'
            filepath = _os_imp.path.join(folder, 'fanvodpl_blacklist.json')

        if not _os_imp.path.exists(filepath):
            return False, f'Plik nie istnieje:\n{filepath}'

        with open(filepath, 'r', encoding='utf-8') as f:
            data = _json.load(f)

        if not data.get('fanvodpl_blacklist'):
            return False, 'Nieprawidłowy plik – brak znacznika fanvodpl_blacklist'

        control.makeFile(control.dataPath)
        dbcon = database.connect(control.bookmarksFile)
        dbcur = dbcon.cursor()
        _ensure_group_audio_cache_table(dbcur)
        _ensure_host_speed_table(dbcur)

        added = 0

        for row in data.get('group_audio_cache', []):
            try:
                gn = (row.get('group_name') or '').strip()
                verdict = row.get('verdict', '')
                if not gn or verdict not in ('foreign', 'dead', 'lowres'):
                    continue
                dbcur.execute(
                    'SELECT verdict FROM group_audio_cache WHERE group_name = ?', (gn,)
                )
                if dbcur.fetchone():
                    continue  # własny wpis – nie nadpisuj
                dbcur.execute(
                    'INSERT OR IGNORE INTO group_audio_cache'
                    '(group_name, verdict, foreign_langs, confirm_count, updated_at) '
                    'VALUES(?,?,?,?,?)',
                    (gn, verdict, row.get('foreign_langs', '[]'),
                     row.get('confirm_count', 1), row.get('updated_at', ''))
                )
                added += 1
            except Exception:
                pass

        for row in data.get('host_speed_cache', []):
            try:
                hk = (row.get('host_key') or '').strip()
                if not hk or not row.get('slow_count', 0):
                    continue  # pomijaj szybkie hosty
                dbcur.execute(
                    'SELECT host_key FROM host_speed_cache WHERE host_key = ?', (hk,)
                )
                if dbcur.fetchone():
                    continue  # własny wpis – nie nadpisuj
                dbcur.execute(
                    'INSERT OR IGNORE INTO host_speed_cache'
                    '(host_key, host, quality, avg_ms, count, slow_count, updated_at) '
                    'VALUES(?,?,?,?,?,?,?)',
                    (hk, row.get('host', ''), row.get('quality', ''),
                     row.get('avg_ms', 0), row.get('count', 1),
                     row.get('slow_count', 0), row.get('updated_at', ''))
                )
                added += 1
            except Exception:
                pass

        dbcon.commit()
        fflog(f'[BLACKLIST] import: dodano {added} wpisów z {filepath}', 1)
        return True, added

    except Exception as e:
        fflog_exc(1)
        return False, str(e)

