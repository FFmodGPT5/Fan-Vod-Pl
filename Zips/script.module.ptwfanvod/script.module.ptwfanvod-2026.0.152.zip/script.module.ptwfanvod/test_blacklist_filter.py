#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Test odsiewu zrodel oznaczonych jako uszkodzone (verdict 'corrupted').

CZESC A - TEST WDROZENIA (regresja na pliku DOCELOWYM):
  sprawdza, czy plik uruchamiany przez Kodi zawiera 'corrupted' w OBU
  warunkach blokujacych funkcji _ff_url_audio_is_blocked. Ten test
  wykrywa sytuacje, w ktorej aktualizacja dodatku nadpisala plik i
  cofnela poprawke (dokladnie to zdarzylo sie 2026-07-25 18:19:47).

CZESC B - TEST LOGIKI (bez hosta Kodi):
  odtwarza decyzje filtra dla wszystkich werdyktow i sprawdza, ze
  'corrupted' blokuje, a pozostale zachowania sie NIE zmieniaja.

Uruchomienie:
    py test_blacklist_filter.py
    py test_blacklist_filter.py "<sciezka do sources.py>"

Exit 0 = PASS. Exit 1 = FAIL.
"""
import io
import os
import re
import sys

DEFAULT_TARGET = os.path.join(
    os.environ.get('APPDATA', ''),
    'Kodi', 'addons', 'script.module.ptwfanvod',
    'lib', 'ptw', 'libraries', 'sources.py',
)

BLOCKING_VERDICTS = ('foreign', 'dead', 'lowres', 'corrupted')

_passed = 0
_failed = 0


def check(name, condition, detail=''):
    global _passed, _failed
    if condition:
        _passed += 1
        print('  PASS  %s' % name)
    else:
        _failed += 1
        print('  FAIL  %s%s' % (name, ('  -> ' + detail) if detail else ''))


# ---------------------------------------------------------------- CZESC A
def part_a(target):
    print('CZESC A - TEST WDROZENIA')
    print('  plik docelowy: %s' % target)

    if not os.path.isfile(target):
        check('plik docelowy istnieje', False, 'nie znaleziono pliku')
        return

    with io.open(target, 'r', encoding='utf-8', errors='replace') as fh:
        lines = fh.readlines()

    check('plik docelowy istnieje', True)

    # Warunki blokujace: 'elif _v_url in (...)' oraz 'elif _v_fp in (...)'
    rx_url = re.compile(r"elif\s+_v_url\s+in\s*\(([^)]*)\)")
    rx_fp = re.compile(r"elif\s+_v_fp\s+in\s*\(([^)]*)\)")

    found_url = []
    found_fp = []
    for idx, line in enumerate(lines, start=1):
        m = rx_url.search(line)
        if m:
            found_url.append((idx, m.group(1)))
        m = rx_fp.search(line)
        if m:
            found_fp.append((idx, m.group(1)))

    check('znaleziono warunek blokujacy dla klucza URL',
          len(found_url) == 1,
          'oczekiwano 1 wystapienia, jest %d' % len(found_url))
    check('znaleziono warunek blokujacy dla klucza FINGERPRINT',
          len(found_fp) == 1,
          'oczekiwano 1 wystapienia, jest %d' % len(found_fp))

    for label, found in (('URL', found_url), ('FINGERPRINT', found_fp)):
        if not found:
            continue
        line_no, body = found[0]
        has = "'corrupted'" in body or '"corrupted"' in body
        check("warunek %s (linia %d) zawiera 'corrupted'" % (label, line_no),
              has,
              'tresc krotki: (%s)' % body.strip())
        # Werdykty, ktore MUSZA pozostac - ochrona przed regresja
        for verdict in ('foreign', 'dead', 'lowres'):
            check("warunek %s nadal zawiera '%s'" % (label, verdict),
                  ("'%s'" % verdict) in body)

    # Galaz bypassu 'foreign' NIE moze zostac dotknieta (granica N1)
    src = ''.join(lines)
    check("galaz bypassu 'foreign' dla hostow non-premium nietknieta",
          "if _v_url == 'foreign' and not is_premium_audio_guard:" in src
          and "if _v_fp == 'foreign' and not is_premium_audio_guard:" in src)
    check("fail-open (except Exception: pass) zachowany",
          re.search(r"except Exception:\s*\n\s*pass\s*\n\s*return False", src)
          is not None)


# ---------------------------------------------------------------- CZESC B
def decide(verdict_url, verdict_fp, is_premium):
    """Odtworzenie decyzji _ff_url_audio_is_blocked (sources.py:825-847)
    w wersji PO poprawce. Zwraca True = pozycja usunieta z listy."""
    if verdict_url == 'foreign' and not is_premium:
        pass                                   # bypass - nie blokuj
    elif verdict_url in BLOCKING_VERDICTS:
        return True
    if verdict_fp:
        if verdict_fp == 'foreign' and not is_premium:
            pass
        elif verdict_fp in BLOCKING_VERDICTS:
            return True
    return False


def part_b():
    print('')
    print('CZESC B - TEST LOGIKI DECYZYJNEJ')

    # cel zadania: uszkodzony plik znika z listy
    check("verdict 'corrupted' po kluczu URL -> pozycja USUNIETA",
          decide('corrupted', None, True) is True)
    check("verdict 'corrupted' po kluczu FINGERPRINT -> pozycja USUNIETA",
          decide(None, 'corrupted', True) is True)
    check("verdict 'corrupted' takze dla hosta non-premium -> USUNIETA",
          decide('corrupted', None, False) is True)

    # brak regresji na dotychczasowych werdyktach
    check("verdict 'dead' -> nadal blokuje", decide('dead', None, True) is True)
    check("verdict 'lowres' -> nadal blokuje", decide('lowres', None, True) is True)
    check("verdict 'foreign' + host premium -> nadal blokuje",
          decide('foreign', None, True) is True)
    check("verdict 'foreign' + host non-premium -> nadal PRZEPUSZCZA (bypass)",
          decide('foreign', None, False) is False)

    # pozycje zdrowe i sciezka "ogladaj dalej"
    check('brak werdyktu -> pozycja ZOSTAJE na liscie',
          decide(None, None, True) is False)
    check("verdict 'safe' -> pozycja ZOSTAJE na liscie",
          decide('safe', None, True) is False)
    check("verdict 'stall_soft' (user wybral NIE) -> pozycja ZOSTAJE",
          decide('stall_soft', None, True) is False)
    check("verdict 'stall_soft' po fingerprincie -> pozycja ZOSTAJE",
          decide(None, 'stall_soft', True) is False)


def main():
    target = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_TARGET
    print('=' * 62)
    print(' TEST: odsiew zrodel z czarnej listy (verdict corrupted)')
    print('=' * 62)
    part_a(target)
    part_b()
    print('')
    print('-' * 62)
    print('WYNIK: %d PASS, %d FAIL' % (_passed, _failed))
    if _failed:
        print('OK: NIE - poprawka nie jest wdrozona albo wystapila regresja')
        return 1
    print('OK: odsiew corrupted dziala, brak regresji')
    return 0


if __name__ == '__main__':
    sys.exit(main())
