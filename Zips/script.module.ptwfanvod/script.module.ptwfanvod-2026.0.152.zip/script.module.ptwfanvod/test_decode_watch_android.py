#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Test wykrywania zacinania obrazu na OBU rodzajach dekodera.

CZESC A - STAN WDROZENIA: czy decode_watch.py zawiera drugi zestaw wzorcow.
CZESC B - LOGIKA DETEKCJI: odtwarza dokladnie ten uklad, ktory jest w
          player.py (dwa liczniki okna, wlasne progi) i podaje mu REALNE
          wycinki logu uzytkownika:
            - klaster zaciecia z telefonu (dekoder sprzetowy)  -> ma WYKRYC
            - material zdrowy z telefonu (inny film)           -> ma MILCZEC
            - okno bez sygnalu                                 -> ma MILCZEC
            - epizod z komputera (2 wpisy OutputPicture)       -> ma WYKRYC
              (to test BRAKU REGRESJI - prog 2 musi dzialac dalej)

Uruchomienie:
    py test_decode_watch_android.py
    py test_decode_watch_android.py <sciezka do lib> <sciezka do kodi.log>

Exit 0 = PASS. Exit 1 = FAIL.
"""
import io
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
LIB = sys.argv[1] if len(sys.argv) > 1 else os.path.join(_HERE, 'lib')
LOG = sys.argv[2] if len(sys.argv) > 2 else os.path.join(
    os.path.dirname(_HERE), 'kodi.log')

def _zaladuj_modul(lib_dir):
    """Laduje decode_watch.py BEZPOSREDNIO z pliku, z pominieciem pakietu
    `ptw`. Powod: w pelnej instalacji dodatku ptw/__init__.py importuje
    log_utils, ktory robi `import xbmc` - poza Kodi to konczy sie bledem,
    choc sam modul detekcji jest od API hosta niezalezny. Dzieki temu test
    dziala tak samo na katalogu projektu i na wgranej instalacji."""
    sciezka = os.path.join(lib_dir, 'ptw', 'libraries', 'decode_watch.py')
    if not os.path.isfile(sciezka):
        print('BLAD: nie znaleziono %s' % sciezka)
        sys.exit(1)
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location('decode_watch', sciezka)
        modul = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(modul)
        return modul
    except ImportError:                      # bardzo stary Python
        import imp                           # noqa: F401
        return imp.load_source('decode_watch', sciezka)


dw = _zaladuj_modul(LIB)

# progi takie same jak w player.py (inicjalizacja straznika)
BURST_SW = 2     # dekoder programowy: jeden epizod = 2 wpisy
BURST_HW = 10    # dekoder sprzetowy: jeden epizod = dziesiatki wpisow
BURST_RN = 1     # blad renderowania bufora: wystepuje pojedynczo
WINDOW_S = 10.0

_passed = 0
_failed = 0


def check(name, condition, detail=''):
    global _passed, _failed
    if condition:
        _passed += 1
        print('  PASS  %s' % name)
    else:
        _failed += 1
        print('  FAIL  %s%s' % (name, ('  -> ' + detail) if detail else ''))


def epizod(tekst):
    """Odtworzenie ukladu z player.py: jeden odczyt, trzy zliczenia,
    trzy niezalezne liczniki okna. Zwraca (wykryto, hits_sw, hits_hw)."""
    hits_sw = dw.count_markers(tekst)
    hits_hw = dw.count_markers(tekst, dw.DECODE_STALL_MARKERS_HW)
    hits_rn = dw.count_markers(tekst, dw.DECODE_STALL_MARKERS_RENDER)
    det_sw = dw.BurstDetector(window_s=WINDOW_S, burst=BURST_SW)
    det_hw = dw.BurstDetector(window_s=WINDOW_S, burst=BURST_HW)
    det_rn = dw.BurstDetector(window_s=WINDOW_S, burst=BURST_RN)
    fire_sw = det_sw.add(hits_sw, 100.0)
    fire_hw = det_hw.add(hits_hw, 100.0)
    fire_rn = det_rn.add(hits_rn, 100.0)
    return (bool(fire_sw or fire_hw or fire_rn), hits_sw, hits_hw)


# ---------------------------------------------------------------- CZESC A
def part_a():
    print('CZESC A - STAN WDROZENIA')
    print('  modul: %s' % os.path.join(LIB, 'ptw', 'libraries', 'decode_watch.py'))
    check('istnieje DECODE_STALL_MARKERS (zestaw dotychczasowy)',
          hasattr(dw, 'DECODE_STALL_MARKERS'))
    check('istnieje DECODE_STALL_MARKERS_HW (zestaw dla dekodera sprzetowego)',
          hasattr(dw, 'DECODE_STALL_MARKERS_HW'),
          'brak drugiego zestawu - poprawka nie jest wdrozona')
    if not hasattr(dw, 'DECODE_STALL_MARKERS_HW'):
        return
    check("zestaw dotychczasowy nadal zawiera 'OutputPicture'",
          any('OutputPicture' in m for m in dw.DECODE_STALL_MARKERS),
          'usuniecie tego wzorca zepsuloby dekoder programowy')
    check("zestaw sprzetowy zawiera 'large audio sync error'",
          any('large audio sync error' in m for m in dw.DECODE_STALL_MARKERS_HW))
    check("zestaw sprzetowy zawiera 'AddPacketsRenderer'",
          any('AddPacketsRenderer' in m for m in dw.DECODE_STALL_MARKERS_HW))
    check('zestawy sa rozlaczne (zaden wzorzec nie powtarza sie)',
          not (set(dw.DECODE_STALL_MARKERS) & set(dw.DECODE_STALL_MARKERS_HW)))
    check('istnieje DECODE_STALL_MARKERS_RENDER (blad renderowania bufora)',
          hasattr(dw, 'DECODE_STALL_MARKERS_RENDER'),
          'brak trzeciego zestawu - poprawka czulosci nie jest wdrozona')
    if hasattr(dw, 'DECODE_STALL_MARKERS_RENDER'):
        check("zestaw renderowania zawiera 'ReleaseOutputBuffer'",
              any('ReleaseOutputBuffer' in m
                  for m in dw.DECODE_STALL_MARKERS_RENDER))
        check('wszystkie trzy zestawy sa wzajemnie rozlaczne',
              not (set(dw.DECODE_STALL_MARKERS_RENDER)
                   & (set(dw.DECODE_STALL_MARKERS)
                      | set(dw.DECODE_STALL_MARKERS_HW))))
    check('modul nadal nie importuje API hosta (czysta logika)',
          not any(m in sys.modules for m in ('xbmc', 'xbmcgui', 'xbmcvfs')),
          'zaladowanie modulu nie moze wymagac Kodi')


# ---------------------------------------------------------------- CZESC B
def part_b():
    print('')
    print('CZESC B - LOGIKA DETEKCJI NA REALNYCH DANYCH')
    if not hasattr(dw, 'DECODE_STALL_MARKERS_HW'):
        check('dane realne z kodi.log', False, 'pominieto - brak zestawu HW')
        return
    if os.path.isfile(LOG):
        with io.open(LOG, 'r', encoding='utf-8', errors='replace') as fh:
            lines = fh.readlines()
        check('plik kodi.log dostepny (%d linii)' % len(lines), True)

        # Dane wycinane po TRESCI, nie po numerach linii - dzieki temu test
        # dziala na kazdym logu, takze po zmianie jego dlugosci.
        wszystkie = set(dw.DECODE_STALL_MARKERS) | set(dw.DECODE_STALL_MARKERS_HW)
        if hasattr(dw, 'DECODE_STALL_MARKERS_RENDER'):
            wszystkie |= set(dw.DECODE_STALL_MARKERS_RENDER)

        klaster = ''.join(l for l in lines
                          if any(m in l for m in dw.DECODE_STALL_MARKERS_HW))
        bez_sygnalu = ''.join(l for l in lines
                              if not any(m in l for m in wszystkie))

        if klaster:
            wykryto, sw, hw = epizod(klaster)
            check('klaster zaciecia (dekoder sprzetowy) -> EPIZOD wykryty',
                  wykryto, 'hits_sw=%d hits_hw=%d' % (sw, hw))
            check('  ... i to sygnal sprzetowy, nie programowy',
                  hw > 0 and sw == 0, 'hits_sw=%d hits_hw=%d' % (sw, hw))
            check('  ... liczba trafien przekracza prog z zapasem (>=%d)'
                  % BURST_HW, hw >= BURST_HW, 'hits_hw=%d' % hw)
        else:
            print('  SKIP  ten log nie zawiera sygnalu sprzetowego')

        wykryto, sw, hw = epizod(bez_sygnalu)
        check('caly log BEZ linii sygnalowych -> cisza (brak falszywych alarmow)',
              not wykryto, 'hits_sw=%d hits_hw=%d' % (sw, hw))
    else:
        # Brak logu referencyjnego nie jest bledem - to dane opcjonalne.
        # Asercje ponizej (dane syntetyczne) i tak pokrywaja logike decyzji.
        print('  SKIP  asercje na realnym logu - nie znaleziono %s' % LOG)
        print('        (podaj sciezke jako 2. argument, aby je wlaczyc)')

    print('')
    print('  --- BRAK REGRESJI: dekoder programowy (jak na PC) ---')
    pc_epizod = (
        "2026-07-25 18:26:07.361 T:11488 warning <general>: "
        "CVideoPlayerVideo::OutputPicture - timeout waiting for buffer\n"
        "2026-07-25 18:26:08.593 T:11488 warning <general>: "
        "CVideoPlayerVideo::OutputPicture - timeout waiting for buffer\n"
    )
    wykryto, sw, hw = epizod(pc_epizod)
    check('epizod z 2 wpisow OutputPicture -> nadal WYKRYWANY (prog 2)',
          wykryto and sw == 2, 'hits_sw=%d hits_hw=%d' % (sw, hw))
    check('  ... sygnal sprzetowy przy tym milczy',
          hw == 0, 'hits_hw=%d' % hw)

    pc_jeden = pc_epizod.split('\n')[0] + '\n'
    wykryto, sw, hw = epizod(pc_jeden)
    check('pojedynczy wpis OutputPicture -> cisza (prog 2 niespelniony)',
          not wykryto, 'hits_sw=%d' % sw)

    print('')
    print('  --- TRZECI SYGNAL: BLAD RENDEROWANIA BUFORA ---')
    render_err = (
        "2026-07-26 11:06:54.000 T:1 error <general>: "
        "CMediaCodecVideoBuffer::ReleaseOutputBuffer error in render(false)\n"
    )
    wykryto, sw, hw = epizod(render_err)
    check('pojedynczy blad renderowania -> EPIZOD wykryty (prog 1)',
          wykryto, 'hits_sw=%d hits_hw=%d' % (sw, hw))
    check('  ... nie jest liczony jako sygnal audio ani programowy',
          sw == 0 and hw == 0, 'hits_sw=%d hits_hw=%d' % (sw, hw))
    check('material zdrowy nadal milczy mimo progu 1',
          dw.count_markers(
              "2026-07-26 11:00:00.000 T:1 info <general>: "
              "VideoPlayer::OpenFile: film.mkv\n",
              dw.DECODE_STALL_MARKERS_RENDER) == 0)

    print('')
    print('  --- ODPORNOSC NA POJEDYNCZE ZDARZENIA AUDIO ---')
    dwa_audio = (
        "2026-07-26 09:40:00.000 T:1 warning <general>: "
        "ActiveAE - large audio sync error: 61.5\n"
        "2026-07-26 09:40:01.000 T:1 warning <general>: "
        "ActiveAE - large audio sync error: 58.2\n"
    )
    wykryto, sw, hw = epizod(dwa_audio)
    check('2 zdarzenia audio bez zacinania -> cisza (prog %d)' % BURST_HW,
          not wykryto, 'hits_hw=%d' % hw)


def main():
    print('=' * 66)
    print(' TEST: wykrywanie zacinania na dekoderze programowym i sprzetowym')
    print('=' * 66)
    part_a()
    part_b()
    print('')
    print('-' * 66)
    print('WYNIK: %d PASS, %d FAIL' % (_passed, _failed))
    if _failed:
        print('OK: NIE - poprawka niewdrozona albo wystapila regresja')
        return 1
    print('OK: detekcja dziala na obu dekoderach, brak falszywych alarmow')
    return 0


if __name__ == '__main__':
    sys.exit(main())
