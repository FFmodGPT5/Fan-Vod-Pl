# Stub kover module to satisfy Kodi dependency
def autoinstall(*args, **kwargs):
    return None
