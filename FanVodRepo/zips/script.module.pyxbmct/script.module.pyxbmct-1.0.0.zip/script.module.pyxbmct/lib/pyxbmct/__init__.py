# Stub pyxbmct module to satisfy Kodi dependency
