# Stub metahandler module to satisfy Kodi dependency
