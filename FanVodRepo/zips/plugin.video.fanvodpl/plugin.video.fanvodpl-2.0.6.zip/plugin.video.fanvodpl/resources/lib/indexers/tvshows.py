# -*- coding: utf-8 -*-

"""
    FanVodPL Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import datetime
import json
import os
import re
import sys
import urllib
from urllib.parse import quote_plus, urlparse, parse_qsl, urlencode, urlsplit, quote
try:
    import urllib.parse as urllib
except:
    pass
import requests

from resources.lib.indexers import navigator
from ptw.libraries import cache
from ptw.libraries import cleangenre
from ptw.libraries import cleantitle
from ptw.libraries import client
from ptw.libraries import control
from ptw.libraries import playcount
from ptw.libraries import trakt
from ptw.libraries import utils
from ptw.libraries import views
from ptw.libraries import apis
from ptw.libraries import log_utils
from ptw.libraries.log_utils import log, fflog, _is_debugging
from ptw.debug import log_exception, fflog_exc

from ptw.libraries.utils import convert
from xbmcplugin import addSortMethod, SORT_METHOD_UNSORTED, SORT_METHOD_LABEL, SORT_METHOD_TITLE, SORT_METHOD_VIDEO_YEAR, SORT_METHOD_VIDEO_RATING


import six

params = (
    dict(parse_qsl(sys.argv[2].replace("?", "")))
    if len(sys.argv) > 1
    else dict()
)

action = params.get("action")


class tvshows:
    def __init__(self):
        # fflog("inicjalizacja klasy tvshows")

        # fix for not always current value
        global params, action
        params = dict(urllib.parse_qsl(sys.argv[2].replace("?", ""))) if len(sys.argv) > 1 else dict()
        action = params.get("action")

        ### BASE ###
        self.list = []
        self.idx = True
        self.session = requests.Session()
        self.tvdb_jwt_token = None
        self.imdb_link   = "http://www.imdb.com"
        self.trakt_link  = "https://api.trakt.tv"
        self.tvmaze_link = "http://www.tvmaze.com"
        self.logo_link   = "https://i.imgur.com/"
        self.tmdb_link   = 'https://api.themoviedb.org'


        ### SETTINGS ###

        self.tvshowssort = control.setting("tvshows.sort")
        if self.tvshowssort == "0":
            self.tvshowssort = "popularity.desc"
        elif self.tvshowssort == "1":
            self.tvshowssort = "first_air_date.desc"

        self.tmdbvote = control.setting("tmdbtv.vote")

        self.fanart_tv_user = control.setting("fanart.tv.user") or apis.fanarttv_client_key
        self.fanart_tv_API_key = control.setting("fanart.tv.dev") or apis.fanarttv_API_key
        self.fanart_tv_headers = {"api-key": self.fanart_tv_API_key, "client-key": self.fanart_tv_user}
        self.user = control.setting("fanart.tv.user") + str("")

        self.trakt_user = control.setting("trakt.user").strip()

        self.imdb_user = control.setting("imdb.user").replace("ur", "")

        self.tm_user = control.setting("tm.user") or apis.tmdb_API  # api_key
        self.tm_bearer = control.setting("tm.user_bearer") or apis.tmdb_bearer  # v4 - czy to nie to samo co access_token?
        self.tmdbuser = control.setting("tmdb.username") or "me"  # or control.setting("tmdb.account_id")  # v4
        self.tmdb_account_id = control.setting("tmdb.account_id") or ""  # może lepiej nie mieszać (nie wiem)  https://www.themoviedb.org/talk/6531957e481382011c209e34
        self.tmdb_sessionid = control.setting("tmdb.sessionid") or ""  # potrzebne do indywidualnych operacji
        self.tmdb_guest_session_id = control.setting("tmdb.guest_session_id") or ""  # do ocen anonimowych użytkowników
        self.tmdb_access_token = control.setting("tmdb.access_token") or ""  # v4 ? czym to się różni od bearer?

        self.lang = control.apiLanguage()["tmdb"]  # iso 639-1 | daje 'pl' (ciekawe, czy wielkość liter ma znaczenie, bo wg Wiki to "PL"
        self.language = f"{self.lang}-{self.lang.upper()}"  # ISO_3166_1 | wg doc api z tmdb to "language-COUNTRY", czyli np. "pl-PL" (z wyjątkiem obrazków?)
        self.region = self.lang.upper()  # filter to search for and display matching release date information. This parameter is expected to be an ISO 3166-1 code


        ### DATY ###
        self.datetime = datetime.datetime.utcnow() - datetime.timedelta(hours=5)
        self.today_date = self.datetime.strftime("%Y-%m-%d")
        #self.today_date = ""  # bo domyślnie tmdb i tak bierze dzisiejszą, a ścieżki będą uniwersalniejsze


        ### LINKI API DO TMDB ###
        self.metasearch = (self.tm_user, self.lang, self.today_date,)  # TODO dodatkowe ustawienia

        self.tmdb_api_link = 'https://api.themoviedb.org/3/tv/%s?api_key=%s&language=%s&append_to_response=credits,external_ids' % ('%s', self.tm_user, self.lang)

        self.tmdb_tv_search = (
            "https://api.themoviedb.org/3/search/tv?api_key=%s&language=%s&sort_by=popularity.desc&query=%%s&page=1" % (
                self.tm_user, self.lang))

        self.tmbd_airing_link = ("https://api.themoviedb.org/3/tv/airing_today?api_key=%s&language=%s&sort_by=popularity.desc&vote_count.gte=%s&include_adult=false&include_video=false&page=1" % (
                self.tm_user, self.language, self.tmdbvote))
        self.tmbd_airing_link =  "https://api.themoviedb.org/3/tv/airing_today?api_key=%s&language=%s&page=1" % (self.tm_user, self.language)

        self.tmdb_premiere_link = (
            "https://api.themoviedb.org/3/discover/tv?api_key=%s&language=%s&sort_by=primary_release_date.desc&first_air_date.lte=%s&vote_count.gte=%s&include_adult=false&include_video=false&page=1" % (
                self.tm_user, self.lang, self.today_date, self.tmdbvote))
        self.tmdb_premiere_link = "https://api.themoviedb.org/3/tv/on_the_air?api_key=%s&language=%s&page=1" % (self.tm_user, self.language)

        self.tmdb_discover = (
            "https://api.themoviedb.org/3/discover/tv?api_key=%s&language=%s&sort_by=%s&first_air_date.lte=%s&vote_count.gte=%s&include_adult=false&include_video=false&%%s&page=1" % (
                self.tm_user, self.lang, self.tvshowssort, self.today_date, self.tmdbvote))

        self.tmdb_language = (
            "https://api.themoviedb.org/3/discover/tv?api_key=%s&language=%s&sort_by=%s&first_air_date.lte=%s&include_adult=false&include_video=false&%%s&page=1" % (
                self.tm_user, self.lang, self.tvshowssort, self.today_date))

        self.tmdb_discover_year = (
            "https://api.themoviedb.org/3/discover/tv?api_key=%s&language=%s&sort_by=primary_release_date.asc&include_adult=false&include_video=false&first_air_date.gte=%%s-01-01&first_air_date.lte=%%s-12-31&vote_count.gte=%s&page=1" % (
                self.tm_user, self.lang, self.tmdbvote))

        self.tmdb_discover_years = (
            "https://api.themoviedb.org/3/discover/tv?api_key=%s&language=%s&sort_by=popularity.desc&include_adult=false&include_video=false&first_air_date.gte=%%s-01-01&first_air_date.lte=%%s-12-31&vote_count.gte=%s&page=1" % (
                self.tm_user, self.lang, self.tmdbvote))

        self.tmdb_by_imdb = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % ('%s', self.tm_user)

        self.tmdb_networks_link = self.tmdb_link + '/3/discover/tv?api_key=%s&with_networks=%s&language=%s&sort_by=%s&page=1' % (self.tm_user, '%s', self.lang, self.tvshowssort)

        #self.tmdb_popular_link = ("https://api.themoviedb.org/3/tv/popular?api_key=%s&language=%s&primary_release_date.lte=%s&include_adult=false&vote_count.gte=200&include_video=false&page=1" % self.metasearch)
        self.tmdb_popular_link =  "https://api.themoviedb.org/3/tv/popular?api_key=%s&language=%s&page=1" % (self.tm_user, self.language)

        self.tmdb_top_rated_link = "https://api.themoviedb.org/3/tv/top_rated?api_key=%s&language=%s&page=1" % (self.tm_user, self.language)

        self.tmdb_similar = ("https://api.themoviedb.org/3/tv/%%s/similar?api_key=%s&language=%s&sort_by=%s&first_air_date.lte=%s&vote_count.gte=%s&include_adult=false&include_video=false&page=1" % (
            self.tm_user, self.lang, self.tvshowssort, self.today_date, self.tmdbvote))

        self.tmdb_recommendations = ("https://api.themoviedb.org/3/tv/%%s/recommendations?api_key=%s&language=%s&sort_by=%s&first_air_date.lte=%s&vote_count.gte=%s&include_adult=false&include_video=false&page=1" % (
            self.tm_user, self.lang, self.tvshowssort, self.today_date, self.tmdbvote))


        # aktorzy
        self.tmdb_person_link = (
            "https://api.themoviedb.org/3/search/person?api_key=%s&language=%s&query=%%s&include_adult=false&page=1" % (
                self.tm_user, self.lang))

        self.tmdb_personid_link = (
            "https://api.themoviedb.org/3/person/%%s/tv_credits?api_key=%s&language=%s&include_adult=false&page=1" % (
                self.tm_user, self.lang))


        ### Manager TMDB ###
        self.tmdb_add_to_favourite_link = "https://api.themoviedb.org/3/account/%s/favorite?api_key=%s&session_id=%s"  % (self.tmdbuser, self.tm_user, self.tmdb_sessionid)
        self.tmdb_add_to_watchlist_link = "https://api.themoviedb.org/3/account/%s/watchlist?api_key=%s&session_id=%s" % (self.tmdbuser, self.tm_user, self.tmdb_sessionid)

        # self.tmdbuserAddItem_link    = "https://api.themoviedb.org/3/list/%%s/add_item?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)
        # self.tmdbuserRemoveItem_link = "https://api.themoviedb.org/3/list/%%s/remove_item?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)

        self.tmdbuserAddItems_link    = "https://api.themoviedb.org/4/list/%%s/items?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)
        self.tmdbuserRemoveItems_link = "https://api.themoviedb.org/4/list/%%s/items?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)  # delete method

        self.tmdbuserCreateList_link = "https://api.themoviedb.org/3/list?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)
        self.tmdbuserDeleteList_link = "https://api.themoviedb.org/3/list/%%s?api_key=%s&session_id=%s" % (self.tm_user, self.tmdb_sessionid)  # delete method


        ### TMDB USER ###
        self.tmdb_user_lists = (
            "https://api.themoviedb.org/3/account/%s/lists?api_key=%s&language=%s&session_id=%s&page=1" % (
                self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid))

        self.tmdb_lists_link = (
            "https://api.themoviedb.org/3/list/%%s?api_key=%s&language=%s&session_id=%s&page=1" % (
                self.tm_user, self.lang, self.tmdb_sessionid))

        self.tmdbuserwatchlist_link = (
            "https://api.themoviedb.org/3/account/%s/watchlist/tv?api_key=%s&language=%s&session_id=%s&sort_by=created_at.desc&page=1" % (
                self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid))

        self.tmdbuserfavourite_link = (
            "https://api.themoviedb.org/3/account/%s/favorite/tv?api_key=%s&language=%s&session_id=%s&sort_by=created_at.desc&page=1" % (
                self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid))

        self.tmdbuserrated_link = (
            "https://api.themoviedb.org/3/account/%s/rated/tv?api_key=%s&language=%s&session_id=%s&sort_by=created_at.desc&page=1" % (
                self.tmdbuser, self.tm_user, self.lang, self.tmdb_sessionid))

        self.tmdbguestrated_link = (
            "https://api.themoviedb.org/3/guest_session/%s/rated/tv?api_key=%s&language=%s&sort_by=created_at.desc&page=1" % (
                self.tmdb_guest_session_id, self.tm_user, self.lang))

        # v4
        self.tmdbrecommended_link = "https://api.themoviedb.org/4/account/%s/tv/recommendations?language=%s&page=1" % (self.tmdb_account_id, self.language)


        ### SUPERINFO ###
        self.tmdb_arts   = 'https://api.themoviedb.org/3/tv/%s/images?api_key=%s&include_image_language=pl,en' % ('%s', self.tm_user)
        self.tm_img_link = 'https://image.tmdb.org/t/p/w%s%s'


        ### LINKI API TRAKT ###
        self.search_link          = "https://api.trakt.tv/search/show?limit=20&page=1&query="
        self.trending_link        = "http://api.trakt.tv/shows/trending?limit=40&page=1"
        self.traktlists_link      = "https://api.trakt.tv/users/me/lists"
        self.traktlikedlists_link = "https://api.trakt.tv/users/likes/lists?limit=1000000"
        self.traktlist_link       = "https://api.trakt.tv/users/%s/lists/%s/items"
        self.traktcollection_link = "https://api.trakt.tv/users/me/collection/shows"
        self.traktwatchlist_link  = "https://api.trakt.tv/users/me/watchlist/shows"
        self.traktfavorites_link  = "https://api.trakt.tv/users/me/favorites/shows"
        self.traktfeatured_link   = "https://api.trakt.tv/recommendations/shows?limit=40"


        ### LINKI API INNE ###
        self.fanart_tv_art_link   = "http://webservice.fanart.tv/v3/tv/%s"
        self.fanart_tv_level_link = "http://webservice.fanart.tv/v3/level"


        ### LINKI IMDB ###
        # self.persons_link        = "https://www.imdb.com/search/name?count=100&name="  # nieużywane
        # self.personlist_link     = "https://www.imdb.com/search/name?count=100&gender=male,female"  # nieużywane

        # self.imdbUserLists_link = "https://www.imdb.com/list/%s/?view=detail&sort=alpha,asc&title_type=tvSeries,miniSeries&count=100&start=1"  # nigdzie nie używane w kodzie
        self.imdblist1_link      = "https://www.imdb.com/list/%s/?view=detail&sort=alpha,asc&title_type=tvSeries,miniSeries&start=1"
        self.imdblist2_link      = "https://www.imdb.com/list/%s/?view=detail&sort=date_added,desc&title_type=tvSeries,miniSeries&start=1"

        self.imdblists_link      = "https://www.imdb.com/user/ur%s/lists?tab=all&sort=mdfd&order=desc&filter=titles" % self.imdb_user

        self.imdbwatchlist_link  = "https://www.imdb.com/user/ur%s/watchlist" % self.imdb_user
        self.imdbwatchlist1_link = "https://www.imdb.com/user/ur%s/watchlist?sort=alpha,asc" % self.imdb_user
        self.imdbwatchlist2_link = "https://www.imdb.com/user/ur%s/watchlist?sort=date_added,desc" % self.imdb_user


        import resources.lib.indexers.tmdb_manager as subm
        methods = [ m for m in dir(subm)
                   if not m.startswith('__')
                  ]
        for m in methods:
            # setattr(movies, m, getattr(subm, m))
            setattr(type(self), m, getattr(subm, m))
            pass
        subm = None


    ### KATALOGI SERIALI ###

    ## Języki ##
    def languages(self, ret_list=False, extended=None):
        languages = [
            ("polski", "pl"),
            ("afrykanerski", "af"), ("albański", "sq"), ("angielski", "en"), ("arabski", "ar"),
            ("bośniacki", "bs"), ("bułgarski", "bg"), ("chiński", "zh"), ("chorwacki", "hr"),
            ("czeski", "cs"), ("duński", "da"), ("estoński", "et"), ("fiński", "fi"), ("francuski", "fr"),
            ("grecki", "el"), ("gruziński", "ka"), ("hebrajski", "he"), ("hindi ", "hi"), ("hiszpański", "es"),
            ("holenderski", "nl"), ("irlandzki", "ga"), ("islandzki", "is"), ("japoński", "ja"), ("koreański", "ko"),
            ("litewski", "lt"), ("łotewski", "lv"), ("macedoński", "mk"), ("niemiecki", "de"), ("norweski", "no"),
            ("pendżabski", "pa"), ("perski", "fa"), ("portugalski", "pt"), ("rosyjski", "ru"), ("rumuński", "ro"),
            ("serbski", "sr"), ("serbsko-chorwacki", "sh"), ("słowacki", "sk"), ("słoweński", "sl"),
            ("szwedzki", "sv"), ("turecki", "tr"), ("ukraiński", "uk"), ("węgierski", "hu"), ("włoski", "it"),
        ]

        if ret_list:
            if not extended:
                return languages
            else:
                # return languages, ("with_original_language", 1)
                return (0, ["Wszystkie"] + languages), ("with_original_language", 1)

        for i in languages:
            self.list.append({
                "name": i[0],
                "url": self.tmdb_language % ("with_original_language=" + i[1]),
                "image": "languages.png",
                # "action": "tvshows" + f"&item={str(i[1])}",
                "action": "tvshows" + f"&item={str(i[0])}",
            })
        self.addDirectory(self.list, category="Języki")
        return self.list


    ## Certyfikaty ##
    def certifications(self, country, ret_list=False, extended=None):
        if not country:
            navigator.navigator().addDirectoryItem("amerykańskie", "tvCertificates&certification_country=US", "certificates.png", "DefaultMovies.png")
            navigator.navigator().addDirectoryItem("polskie", "tvCertificates&certification_country=PL", "certificates.png", "DefaultMovies.png")
            navigator.navigator().endDirectory()
        else:
            if country == "US":
                #certificates = ["G", "PG", "PG-13", "R", "NC-17"]  # to dla filmów
                #certificates = ["TV-G", "TV-PG", "TV-14", "TV-MA"]
                certificates = ["TV-Y", "TV-Y7", "TV-G", "TV-PG", "TV-14", "TV-MA", "NR"]
            elif country == "PL":
                certificates = ["0 ", "7 ", "12 ", "16 ", "18 "]  # w Polsce - sprawdzić, czy ma sens, czy pozostać przy US
            else:
                navigator.navigator().addDirectoryItem("nieznana zmienna kraju: "+country, "", "certificates.png", "DefaultMovies.png")
                country = ""

            if ret_list:
                if not extended:
                    return certificates
                else:
                    # return certificates, f"certification_country={country}&certification"
                    return ["brak"] + certificates, f"certification_country={country}&certification"

            if country:
                for i in certificates:
                    self.list.append({
                                     "name": str(i),
                                     "url": self.tmdb_discover % (f"certification_country={country}&certification=" + str(i).strip()),
                                     #"url": self.tmdb_discover % (f"certification_country=PL&certification=" + str(i)),
                                     "image": "certificates.png",
                                     "action": "tvshows" + f"&item={str(i)}",
                                     # "action": "tvshows" + f"&item={urllib.quote_plus(str(i))}",
                                    })
            self.addDirectory(self.list, category="Kategorie wiekowe")

        return self.list


    ## Lata ##
    def years(self, ret_list=False, extended=None):

        if not ret_list:
            # wstawienie odnośnika do zakresów lat
            navigator.navigator().addDirectoryItem(32630, "tvYearsTop", "years.png", "DefaultMovies.png")

        # lata
        year = self.datetime.strftime("%Y")
        zakres = range(int(year) - 0, 1935, -1)

        if ret_list:
            years_list = [i for i in zakres]
            if not extended:
                return years_list
            else:
                return ["Wszystkie"] + years_list, "first_air_date.gte=%%s-01-01&first_air_date.lte=%%s-12-31"

        # for i in range(int(year) - 0, 1935, -1):
        for i in zakres:
            self.list.append({
                              "name": str(i),
                              "url": self.tmdb_discover_year % (str(i), str(i)),
                              "image": "years.png",
                              "action": "tvshows" + f"&item={str(i)}",
                            })

        self.addDirectory(self.list, category="Lata")
        return self.list


    ## Lata TOP (zakres lat) ##
    def years_top(self):
        year = self.datetime.strftime("%Y")
        dec = int(year[:3]) * 10
        for i in range(dec, 1920, -10):  # od 1930
            self.list.append({
                              "name": str(i) + "-" + str(i + 9),
                              #"url": self.tmdb_discover_years % (str(i), str(i + 9)),
                              "url": self.tmdb_discover_years % (str(i)+"-01-01", str(i + 9)+"-12-31"),
                              "image": "years.png",
                              "action": "tvshows" + f'&item={str(i) + "-" + str(i + 9)}',
                            })
        self.addDirectory(self.list, category="Lata")
        return self.list


    def networks(self, ret_list=False, extended=None):
        networks = [
            ("54", "Disney Channel", "https://i.imgur.com/ZCgEkp6.png"),
            ("44", "Disney XD", "https://i.imgur.com/PAJJoqQ.png"),
            ("2", "ABC", "https://i.imgur.com/qePLxos.png"),
            ("493", "BBC America", "https://i.imgur.com/TUHDjfl.png"),
            ("6", "NBC", "https://i.imgur.com/yPRirQZ.png"),
            ("13", "Nickelodeon", "https://i.imgur.com/OUVoqYc.png"),
            ("14", "PBS", "https://i.imgur.com/r9qeDJY.png"),
            ("16", "CBS", "https://i.imgur.com/8OT8igR.png"),
            ("19", "FOX", "https://i.imgur.com/6vc0Iov.png"),
            ("21", "The WB", "https://i.imgur.com/rzfVME6.png"),
            ("24", "BET", "https://i.imgur.com/ZpGJ5UQ.png"),
            ("30", "USA Network", "https://i.imgur.com/Doccw9E.png"),
            ("32", "CBC", "https://i.imgur.com/unQ7WCZ.png"),
            ("33", "MTV", "https://i.imgur.com/QM6DpNW.png"),
            ("34", "Lifetime", "https://i.imgur.com/tvYbhen.png"),
            ("35", "Nick Junior", "https://i.imgur.com/leuCWYt.png"),
            ("41", "TNT", "https://i.imgur.com/WnzpAGj.png"),
            ("43", "National Geographic", "https://i.imgur.com/XCGNKVQ.png"),
            ("47", "Comedy Central", "https://i.imgur.com/ko6XN77.png"),
            ("49", "HBO", "https://i.imgur.com/Hyu8ZGq.png"),
            ("55", "Spike", "https://i.imgur.com/BhXYytR.png"),
            ("67", "Showtime", "https://i.imgur.com/SawAYkO.png"),
            ("56", "Cartoon Network", "https://i.imgur.com/zmOLbbI.png"),
            ("65", "History Channel", "https://i.imgur.com/LEMgy6n.png"),
            ("84", "TLC", "https://i.imgur.com/c24MxaB.png"),
            ("68", "TBS", "https://i.imgur.com/RVCtt4Z.png"),
            ("71", "The CW", "https://i.imgur.com/Q8tooeM.png"),
            ("74", "Bravo", "https://i.imgur.com/TmEO3Tn.png"),
            ("76", "E!", "https://i.imgur.com/3Delf9f.png"),
            ("77", "Syfy", "https://i.imgur.com/9yCq37i.png"),
            ("80", "Adult Swim", "https://i.imgur.com/jCqbRcS.png"),
            ("91", "Animal Planet", "https://i.imgur.com/olKc4RP.png"),
            ("110", "CTV", "https://i.imgur.com/qUlyVHz.png"),
            ("129", "A&E", "https://i.imgur.com/xLDfHjH.png"),
            ("158", "VH1", "https://i.imgur.com/IUtHYzA.png"),
            ("174", "AMC", "https://i.imgur.com/ndorJxi.png"),
            ("928", "Crackle", "https://i.imgur.com/53kqZSY.png"),
            ("202", "WGN America", "https://i.imgur.com/TL6MzgO.png"),
            ("209", "Travel Channel", "https://i.imgur.com/mWXv7SF.png"),
            ("213", "Netflix", "https://i.imgur.com/jI5c3bw.png"),
            ("251", "Audience", "https://i.imgur.com/5Q3mo5A.png"),
            ("270", "SundanceTV", "https://i.imgur.com/qldG5p2.png"),
            ("318", "Starz", "https://i.imgur.com/Z0ep2Ru.png"),
            ("359", "Cinemax", "https://i.imgur.com/zWypFNI.png"),
            ("364", "truTV", "https://i.imgur.com/HnB3zfc.png"),
            ("384", "Hallmark Channel", "https://i.imgur.com/zXS64I8.png"),
            ("397", "TV Land", "https://i.imgur.com/1nIeDA5.png"),
            ("1024", "Amazon", "https://i.imgur.com/ru9DDlL.png"),
            ("1267", "Freeform", "https://i.imgur.com/f9AqoHE.png"),
            ("4", "BBC One", "https://i.imgur.com/u8x26te.png"),
            ("332", "BBC Two", "https://i.imgur.com/SKeGH1a.png"),
            ("3", "BBC Three", "https://i.imgur.com/SDLeLcn.png"),
            ("100", "BBC Four", "https://i.imgur.com/PNDalgw.png"),
            ("214", "Sky One", "https://i.imgur.com/xbgzhPU.png"),
            ("9", "ITV", "https://i.imgur.com/5Hxp5eA.png"),
            ("26", "Channel 4", "https://i.imgur.com/6ZA9UHR.png"),
            ("99", "Channel 5", "https://i.imgur.com/5ubnvOh.png"),
            ("136", "E4", "https://i.imgur.com/frpunK8.png"),
            ("210", "HGTV", "https://i.imgur.com/INnmgLT.png"),
            ("453", "Hulu", "https://i.imgur.com/uSD2Cdw.png"),
            ("1436", "YouTube Red", "https://i.imgur.com/ZfewP1Y.png"),
            ("64", "Discovery Channel", "https://i.imgur.com/8UrXnAB.png"),
            ("2739", "Disney+", "https://i.imgur.com/DVrPgbM.png"),
            ("2552", "Apple TV +", "https://i.imgur.com/fAQMVNp.png"),
            ("2697", "Acorn TV", "https://i.imgur.com/fSWB5gB.png"),
            ("1709", "CBS All Access", "https://i.imgur.com/ZvaWMuU.png"),
            ("3186", "HBO Max", "https://i.imgur.com/mmRMG75.png"),
            ("2243", "DC Universe", "https://i.imgur.com/bhWIubn.png"),
            ("2076", "Paramount Network", "https://i.imgur.com/ez3U6NV.png"),
            ("4330", "Paramount+", "https://i.imgur.com/dmUjWmU.png"),
            ("3353", "Peacock", "https://imgur.com/1JXFkSM.png"),
            ("504", "TVN", "https://i.imgur.com/yA8TJ4o.png"),
            ("483", "TVP1", "https://i.imgur.com/as4ipbu.png"),
            ("466", "TVP2", "https://i.imgur.com/qj1Ta1Q.png"),
            ("315", "Polsat", "https://i.imgur.com/knnmJG5.png")
        ]

        if ret_list:
            if not extended:
                return networks
            else:
                # return networks, ("with_networks", 0)
                return (1, ["Wszystkie"] + networks), ("with_networks", 0)

        for i in networks:
            self.list.append(
                {
                    "name": i[1],
                    "url": self.tmdb_networks_link % i[0],
                    "image": i[2],
                    # "action": "tvshows" + f"&item={str(i[1])}",
                    "action": "tvshows" + f"&item={urllib.quote_plus(str(i[1]))}",
                    
                }
            )
        self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
        self.addDirectory(self.list, category="Sieci TV")
        return self.list


    def genres(self, ret_list=False, extended=None):
        genres = [
                    ("10759", "Akcja i Przygoda", "Action and Adventure.png"),
                    ("16", "Animacja", "Animation.png"),
                    ("10762", "Dla dzieci", "Kids.png"),
                    ("99", "Dokumentalny", "Documentary.png"),
                    ("18", "Dramat", "Drama.png"),
                    ("10751", "Familijny", "Family.png"),
                    ("35", "Komedia", "Comedy.png"),
                    ("80", "Kryminał", "Crime.png"),
                    ("10763", "News", "News.png"),
                    ("10764", "Reality", "Reality_show.png"),
                    ("10766", "Romans", "Romance.png"),
                    ("10765", "Sci-Fi i Fantazja", "Sci_fi_and_fantasy.png"),
                    ("9648", "Tajemnica", "Mystery.png"),
                    ("10767", "Talk Show", "Television.png"),
                    ("37", "Western", "Western.png"),
                    ("10768", "Wojna i Polityka", "Historical.png"),
                ]

        if ret_list:
            if not extended:
                return genres
            else:
                # return genres, ("with_genres", 0)
                return (1, ["Wszystkie"] + genres), ("with_genres", 0)

        for i in genres:
            self.list.append({
                                "name": i[1],
                                "url": self.tmdb_discover % ("with_genres=" + i[0]),
                                "image": i[2],
                                "action": "tvshows" + f"&item={str(i[1])}",
                            })
        self.addDirectory(self.list, category="Gatunki")
        return self.list


    def custom(self, url2=""):
        # fflog(f'{url2=}',1,1)
        if not url2:

            folderpath = control.infoLabel('Container.FolderPath')
            params1 = dict(urllib.parse_qsl(folderpath.split('?')[-1]))
            action1 = params1.get('action')  # może być też puste
            fflog(f'{action1=}',1,1)
            if action1 in ["tvshowPage", "tvshows"]:  # pomaga, aby klawiatura nie pojawiała ponownie się przy cofnięciu
            # if action1 not in ["movieNavigator", "cu2stomMovieCriteria"]:
                return
                pass

            criteria = {
                # "gatunki": [0, (1, ["Wszystkie"] + self.genres(ret_list=True)), ("with_genres",0)],
                "gatunki": [0, *self.genres(ret_list=True, extended=True)],
                "sieci": [0, *self.networks(ret_list=True, extended=True)],
                # "języki": [0, (0,[("wszystkie",""), ("polski", "pl"), ("angielski","en"), ("chiński","ch")]), ("with_original_language",1)],
                "języki": [0, *self.languages(ret_list=True, extended=True)],
                # "lata": [0, ["wszystkie", 2025, 2024, 2023], "primary_release_year"],
                "lata": [0, *self.years(ret_list=True, extended=True)],
                "ograniczenia wiekowe": [0, *self.certifications(country="PL", ret_list=True, extended=True)],
                "minimalna ilość głosów": [0, sorted(set([0,1,10,5,50,100,int(self.tmdbvote)])), "vote_count.gte"],
            }
            if "minimalna ilość głosów" in criteria:
                criteria["minimalna ilość głosów"][0] = criteria["minimalna ilość głosów"][1].index(int(self.tmdbvote))
            # fflog(f'{criteria=}',1,1)
            # fflog(f'criteria={json.dumps(criteria, indent=2)}',1,1)

            przechowalnia = control.window.getProperty('FanVodPL.var.TvCriteria')  # z pamięci
            if przechowalnia:
                przechowalnia = eval(przechowalnia)
                for k,v in przechowalnia.items():
                    if k in criteria:
                        criteria[k][0] = v
                        pass
            # fflog(f'{criteria=}',1,1)
            # fflog(f'criteria={json.dumps(criteria, indent=2)}',1,1)

            preselect = -1
            selected0 = 0
            if action1 not in ["tvshowPage", "tvshows"]:  # pomaga, aby klawiatura nie pojawiała ponownie się przy cofnięciu
                while selected0 > -1:
                    # główne menu - wybór głównych kryteriów
                    labels = [f"[LIGHT]{k}[/LIGHT]: [I]" + (
                                                            # "Wszystkie" if v[0]==0 else 
                                                            ( str(v[1][1][0]) if isinstance(v[1], tuple) else str(v[1][0]) )  if v[0]==0  else 
                                                                "[B]" + ( f"{v[1][1] [v[0]] [ v[1][0] ]}" if isinstance(v[1], tuple) else str(v[1][v[0]]) ) + "[/B]"
                                                           ) + "[/I]"
                                                            for k,v in criteria.items()]
                    labels += ["===  [B] S z u k a j [/B]  ==="]  # jako ostatni - takie założenie, bo potem jest to sprawdzane
                    # control.log(f'GŁÓWNE {labels=}',1)
                    selected0 = control.selectDialog(labels, 'Wybierz [I]kryteria[/I] i [B]Szukaj[/B]', preselect=preselect)
                    # selected0 = 0  # dokonany wybór pozycji z listy
                    if selected0 > -1:
                        preselect = selected0
                        # wybór podkryteriów
                        podkryterium = labels[selected0].split(":")[0]
                        podkryterium = podkryterium.replace("[LIGHT]", "").replace("[/LIGHT]", "")
                        # if podkryterium.startswith("Szukaj"):
                        if selected0 == len(labels) - 1:  # ostatni
                            # selected0 = -1
                            # control.log(f'SZUKAM\n{criteria=}',1)
                            break
                        labels1 = criteria[podkryterium][1]
                        if isinstance(labels1, tuple):
                            index = labels1[0]
                            #print(index)
                            labels1 = [ l[index] if isinstance(l,tuple) else l  for l in labels1[1] ]
                        labels1 = [str(l) for l in labels1]  # konwersja liczb na string (jeśli są)
                        # control.log(f'{podkryterium=}  {labels1=}',1)
                        preselect1 = criteria[podkryterium][0]
                        selected1 = control.selectDialog(labels1, f'wybierz {podkryterium}', preselect=preselect1)
                        # selected1 = 1
                        if selected1 > -1:
                            # preselect1 = selected1
                            criteria[podkryterium][0] = selected1  # modyfikacja
                            selected1 = -1  # czy to potrzebne?

            if selected0 > -1:
                # trzeba zbudować teraz adres 
                query = ""
                for k,v in criteria.items():
                    # fflog(f'{k=} {v=}',1,1)
                    if v[0] or v[-1] == 'vote_count.gte':
                        if isinstance(v[1], tuple):
                            key = v[2] [0]
                            val = v[1] [1] [v[0]] [ v[2][1] ]
                        else:
                            key = v[2]
                            val = v[1] [v[0]]
                        val = str(val).strip()
                        # fflog(f'{key=}, {val=}',1,1)
                        if "%%s" in key:
                            query += "&" + key.replace("%%s", str(val))
                            pass
                        else:
                            query += f"&{key}={val}"
                            pass
                fflog(f'{query=}',1,1)
                if not query:
                    fflog("nie wybrałeś żadnych kryteriów",1,1)
                    # control.dialog.notification("FanVodPL", "nie wybrałeś żadnych kryteriów")
                    control.infoDialog('Nie wybrałeś żadnych kryteriów', sound=True, icon="WARNING")
                    pass
                else:
                    url2 = self.tmdb_discover % query
                    url2 = url2.replace("&&", "&")
                    # url2 = url2.replace("first_air_date.lte", "nic")  # test
                    # control.log(f'{url2=}',1)

                    url2 = re.sub("(?<=api_key=)[^&]*", "", url2)
                    url2 = re.sub("(?<=session_id=)[^&]*", "", url2)

                    przechowalnia = {}
                    for k,v in criteria.items():
                        przechowalnia.update({k: v[0]})
                    control.window.setProperty('FanVodPL.var.TvCriteria', repr(przechowalnia))  # do pamięci
                    # fflog(f'{przechowalnia=}',1,1)
                    # do wyświetlenia to lepiej odrzucić 0 i wyświetlać etykiety zamiast cyfr (budowa prawie jak głównych labels)
                    # do_wyswietlenia = str(przechowalnia).replace("{","").replace("}","").replace("'","")
                    # control.dialog.notification("", do_wyswietlenia, time=3000)

        if url2:
            # movies.get(self, url2, category="Własne kryteria")
            # return  # koniec funkcji
            pass

            # pomaga, aby klawiatura nie pojawiała ponownie się przy cofnięciu
            generate_short_path = control.setting("generate_short_path") == "true"
            if not generate_short_path:
                url = "{}?action={}".format(sys.argv[0], "tvshows&url=%s" % urllib.quote_plus(url2))
            else:
                control.window.setProperty('FanVodPL.var.url', url2)
                url = "{}?action={}".format(sys.argv[0], "tvshows&item=%s" % urllib.quote_plus('Własne kryteria'))
            # navigator.navigator().addDirectoryItem('... proszę czekać, trwa wyszukiwanie wg wybranych kryteriów ...', "", "search.png", "DefaultAddonsSearch.png")
            control.addItem(int(sys.argv[1]), url, control.item("... proszę czekać, trwa wyszukiwanie wg wybranych kryteriów ..."), True)
            control.directory(int(sys.argv[1]), cacheToDisc=False)
            # navigator.navigator().endDirectory(cacheToDisc=False, category="Własne kryteria")
            control.sleep0(50)
            control.execute('Container.Update("%s")' % url)  # nowe rozdanie :-)
            # control.execute('Container.Update("%s")' % (url+"&r=1"))  # nowe rozdanie :-)
            return  # koniec funkcji



    def similar(self, tmdb):
        tvshows.get(self, self.tmdb_similar % tmdb)


    def recommendations(self, tmdb):
        tvshows.get(self, self.tmdb_recommendations % tmdb)


    def search(self):
        navigator.navigator().addDirectoryItem("[LIGHT][B]["+control.lang(32603)+"][/B][/LIGHT]", "tvSearchnew", "", "DefaultTVShowTitle.png")

        generate_short_path = control.setting("generate_short_path") == "true"

        from sqlite3 import dbapi2 as database
        db_dir = os.path.dirname(control.searchFile)
        if db_dir and not os.path.exists(db_dir):
            try:
                os.makedirs(db_dir, exist_ok=True)
            except Exception:
                pass
        dbcon = database.connect(control.searchFile)
        dbcur = dbcon.cursor()
        try:
            dbcur.executescript("CREATE TABLE IF NOT EXISTS tvshow (ID Integer PRIMARY KEY AUTOINCREMENT, term);")
        except:
            pass
        dbcur.execute("SELECT * FROM tvshow ORDER BY ID DESC")

        lst = []
        delete_option = False
        for (id, term) in dbcur.fetchall():
            if term not in str(lst):
                lst += [term]
                delete_option = True
                navigator.navigator().addDirectoryItem(
                    term,
                    # "tvSearchterm&name=%s" % term,
                    # "tvSearchterm",  # nie powraca focus na wywoływaną pozycję
                    # "tvSearchterm&item=%s" % len(lst),  # aby po powrocie focus ustawiał się na poprzedniej pozycji
                    "tvSearchterm&item=%s" % len(lst) if generate_short_path else "tvSearchterm&name=%s" % term,
                    "search.png",
                    "DefaultAddonsSearch.png",
                    context=("Usuń z historii wyszukiwania", "removeFromSearchHistory&term=%s&content=tvshow" % urllib.quote_plus(term),),
                )
        dbcur.close()

        if delete_option:
            navigator.navigator().addDirectoryItem("[LIGHT][I]["+control.lang(32605)+"][/I][/LIGHT]", "clearCacheSearch&content=tvshow", "", "DefaultIconWarning.png", isFolder=False)

        syshandle = int(sys.argv[1])
        addSortMethod(syshandle, sortMethod=SORT_METHOD_UNSORTED)
        addSortMethod(syshandle, sortMethod=SORT_METHOD_LABEL)
        control.pluginCategory(syshandle, "Szukaj / Seriale")
        navigator.navigator().endDirectory(cacheToDisc=False)


    ### WYSZUKIWANIE NOWE ###
    def search_new(self):

        folderpath = control.infoLabel('Container.FolderPath')
        params1 = dict(urllib.parse_qsl(folderpath.split('?')[-1]))
        action1 = params1.get('action')  # może być też puste
        if action1 in ["tvSearchterm", "play"]:
            return
            pass
        """
        #if action1 == "tvSearchterm":
        if action1 in ["tvSearchterm", "play"]:
            # taki hack na Kodi, bo inaczej wywala do głównego menu Kodi
            control.directory(int(sys.argv[1]), cacheToDisc=True)
            url = "{}?action={}".format(sys.argv[0], "tvSearch")
            control.execute('Container.Update("%s", replace)' % url)  # ale po cofnięciu i tak wywala aż do początku
            control.execute('Container.Update("%s")' % url)  # nie przetestowałem jeszcze
            return
        """
        k = control.keyboard("", control.lang(32010))
        k.doModal()
        q = k.getText() if k.isConfirmed() else ""
        q = q.strip() if q is not None else q
        if q is None or q == "" or q == "..":
            fflog(f'dodanie pustego katalogu',1,1)
            navigator.navigator().endDirectory()
            fflog(f'akcja wstecz',1,1)
            control.execute('Action(Back)')
            return
        # q = cleantitle.normalize(q)  # for polish characters

        from sqlite3 import dbapi2 as database
        db_dir = os.path.dirname(control.searchFile)
        if db_dir and not os.path.exists(db_dir):
            try:
                os.makedirs(db_dir, exist_ok=True)
            except Exception:
                pass
        dbcon = database.connect(control.searchFile)
        dbcur = dbcon.cursor()

        dbcur.execute("SELECT * FROM tvshow WHERE term=?", (q,))
        if dbcur.fetchone():
            dbcur.execute("DELETE FROM tvshow WHERE term=?", (q,))
        dbcur.execute("INSERT INTO tvshow VALUES (?,?)", (None, q))

        dbcon.commit()
        dbcur.close()

        # if not control.condVisibility('Window.IsActive(busydialog)'):
        if True:  # pomaga, aby klawiatura nie pojawiała ponownie się przy cofnięciu
            navigator.navigator().addDirectoryItem('... proszę czekać, trwa wyszukiwanie ...', "tvSearch", "search.png", "DefaultTVShows.png")
            control.directory(int(sys.argv[1]), cacheToDisc=False)
            generate_short_path = control.setting("generate_short_path") == "true"
            if not generate_short_path:
                url = "{}?action={}".format(sys.argv[0], "tvSearchterm&name=%s" % urllib.quote_plus(q))
            else:
                control.window.setProperty('FanVodPL.var.name', q)
                url = "{}?action={}".format(sys.argv[0], "tvSearchterm&item=%s" % '1')
            control.execute('Container.Update("%s")' % url)
            return  # koniec funkcji

        # control.busy()
        # tvshows.get(self, self.tmdb_tv_search % quote_plus(q))
        # control.idle()


    def search_term(self, name, year=""):
        # log_utils.fflog(f"{name=}")
        if name and name != "..":
            if m := re.search(r'^(.+) +(?:\(|y:)(\d{4})\)?$', name):
                name, year = m[1], m[2]
            if year:
                tvshows.get(self, self.tmdb_tv_search % quote_plus(name) + f"&year={year}", category=name)
            else:
                tvshows.get(self, self.tmdb_tv_search % quote_plus(name), category=name)
        else:
            import xbmcgui
            xbmcgui.Dialog().notification('FanVodPL', 'szukanie niemożliwe z powodu błędnego parametru', xbmcgui.NOTIFICATION_ERROR)
            navigator.navigator().endDirectory()
            log_utils.fflog(f'szukanie niemożliwe z powodu błędnego parametru {name=}')
            control.execute('Action(Back)')


    ### SEARCH PERSONS ### TODO - historia
    def person(self, url=None):
        # fflog(f'{url=}',1,1)
        try:
            if not url:
                t = control.lang(32010)
                k = control.keyboard("", t)
                k.doModal()
                q = k.getText() if k.isConfirmed() else ""
                q = q.strip() if q is not None else q

                if q is None or q == "":
                    return

                # q = cleantitle.normalize(q)  # for polish characters

                # url = self.persons_link + urllib.quote_plus(q)
                # url = '%s?action=tvPersons&url=%s' % (sys.argv[0], urllib.quote_plus(url))
                tvshows.persons(self, self.tmdb_person_link % urllib.quote_plus(q), category=q)
            else:
                tvshows.persons(self, url)  # może to jest przy następnych stronach ?
        except:
            return


    ## Osoby - wyszukiwanie ##
    def persons(self, url, category=""):
        # fflog(f'{url=}',1,1)

        url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
        url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)

        tmdb_results = requests.get(url, timeout=30).json()

        if "results" not in tmdb_results:
            fflog(f'{url=}  {tmdb_results=}',1,1)

        page = tmdb_results.get("page", 0)
        total = tmdb_results.get("total_pages", 0)
        # fflog(f'{page=} {total=}',1,1)
        if page < total and "page=" in url:
            next_page = re.sub(r"page=\d+", f"page={page + 1}", url)
        else:
            next_page = ""
        # fflog(f'{next_page=}',1,1)

        next_page = re.sub("(?<=api_key=)[^&]*", "", next_page)
        next_page = re.sub("(?<=session_id=)[^&]*", "", next_page)

        i = 0
        generate_short_path = control.setting("generate_short_path") == "true"
        for item in tmdb_results["results"]:
            # if True:
            if item.get("known_for_department") == "Acting":
                i += 1
                if item.get("profile_path"):
                    photo = str("http://www.themoviedb.org/t/p/w300_and_h450_bestv2" + item.get("profile_path", ""))
                else:
                    photo = "people.png"
                    # photo = ""
                self.list.append(
                    {
                        "name": item.get("name"),
                        "url": self.tmdb_personid_link % str(item.get("id")),
                        "image": photo,
                        # "action": "tvshows",
                        "action": "tvshows" + (f'&item={i}' if generate_short_path else ""),
                    })
        # fflog(f'{len(self.list)=}',1,1)
        if self.list:
            # self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
            pass
        if self.list and next_page:
            self.list[0]["next"] = {"url": next_page, "action": "tvPerson",}
        self.addDirectory(self.list, category=category)
        return self.list



    ### SCRAPERY API/STRON ###

    ### TMDB ###
    def tmdb_list(self, url):
        # fflog(f'{params=}', 1, 1)
        # fflog(f'{url=}', 1, 1)

        if "/4/" in url:  # v4 API
            fflog(f'wersja v4 API',1,1)
            headers = {
                "accept": "application/json",
                # "Authorization": f"Bearer {self.tm_bearer}"  # nie wiem, który powinien być
                "Authorization": f"Bearer {self.tmdb_access_token}"  # nie wiem, który powinien być
            }
            tmdb_results = requests.get(url, headers=headers)  # zapytanie do serwera
        else:
            url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
            url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)
            # fflog(f'{url=}', 1, 1)
            tmdb_results = requests.get(url, timeout=30)

        if not tmdb_results:
            fflog(f'wystąpił jakiś problem  {tmdb_results=}  {url=}',1,1)
            pass

        tmdb_results = tmdb_results.json()  # format json, czyli słownik będzie w Pythonie
        # fflog(f'{tmdb_results=}',1,1)
        # fflog(f'tmdb_results={json.dumps(tmdb_results, indent=2)}',1,1)


        page = tmdb_results.get("page", 0)
        total = tmdb_results.get("total_pages", 0)
        if page < total and "page=" in url:
            next_page = re.sub(r"page=\d+", f"page={page + 1}", url)
        else:
            next_page = ""
        # next_page = re.sub("(?<=api_key=)[^&]*", "", next_page)
        # next_page = re.sub("(?<=session_id=)[^&]*", "", next_page)
        # fflog(f'{next_page=}')
        # next = next_page

        monitor = control.monitor

        if not self.idx:
            # fflog(f'{self.idx=}',1,1)
            if ("/watchlist/" in url or "/favorite/" in url):  # a favorite ?
                # fflog(f'kolejne strony mogą być potrzebne')
                # tmdb_results = {'results': []}
                for np in range(2, total + 1):
                    fflog(f'{np=}')
                    next_url = re.sub(r"page=\d+", f"page={np}", url)
                    # fflog(f'{next_url=}',1,1)
                    tmdb_results_tmp = requests.get(next_url).json()  # kolejny request do serwera
                    [tmdb_results['results'].append(x) for x in tmdb_results_tmp['results']]  # dodanie wyników
                    if monitor.abortRequested():
                        fflog('sygnal zamknięcia Kodi',1,1)
                        return sys.exit()
            else:
                fflog(f'adres url nie jest objęty warunkiem pozyskiwania kolejnych podstron')
                pass

        if "results" in tmdb_results:
            items = tmdb_results["results"]
        elif "items" in tmdb_results:
            items = tmdb_results["items"]
        elif "parts" in tmdb_results:
            items = tmdb_results["parts"]
        elif "cast" in tmdb_results and (items := tmdb_results["cast"]):
            # items = tmdb_results["cast"]
            pass
        elif "crew" in tmdb_results and (items := tmdb_results["crew"]):
            # items = tmdb_results["crew"]
            pass
        else:
            fflog(f'[tmdb_list] błąd: brak poprawnych danych do stworzenia listy  |  {tmdb_results=}')
            items = []

        media_id_list = []  # pomocniczo
        fflog(f'{len(items)=}',1,1)
        for item in items:
            try:
                # fflog(f'item={json.dumps(item, indent=2)}')

                if 'media_type' in item and not item['media_type'] == 'tv':
                    #raise Exception()
                    continue

                tmdb = str(item.get('id'))

                if tmdb not in media_id_list:
                    if tmdb:
                        media_id_list.append(tmdb)
                else:
                    continue

                try:
                    title = item['name']
                except:
                    title = ''
                title = six.ensure_str(title)

                try:
                    originaltitle = item['original_name']
                except:
                    originaltitle = ''
                originaltitle = six.ensure_str(originaltitle)
                if not originaltitle:
                    originaltitle = title

                try:
                    premiered = item['first_air_date']
                except:
                    premiered = ''
                if not premiered:
                    premiered = '0'

                try:
                    plot = item['overview']
                except:
                    plot = ''
                if not plot:
                    plot = ''

                try:
                    year = re.findall(r'(\d{4})', premiered)[0]
                except:
                    year = ''
                if not year:
                    year = '0'


                self.list.append({'title': title,
                                  'originaltitle': originaltitle,
                                  'premiered': premiered,
                                  'year': year,
                                  'imdb': '0',
                                  'tmdb': tmdb,
                                  'tvdb': '0',
                                  'plot': plot,
                                  'poster': '0',
                                  'next': next_page,
                                  "curr_page": page,  # number
                                  "total_pages": total,
                                  })
            except Exception:
                fflog_exc(1)
                pass
        # fflog(f'self.list={json.dumps(self.list, indent=2)}',1,1)
        return self.list


    ### TRAKT ###
    def trakt_list(self, url, user):
        # fflog(f'{url=} {user=}',1,1)
        try:
            dupes = []

            q = dict(parse_qsl(urlsplit(url).query))
            q.update({"extended": "full"})
            q = (urlencode(q)).replace("%2C", ",")
            u = url.replace("?" + urlparse(url).query, "") + "?" + q
            # fflog(f'{u=}',1,1)
            # result = trakt.getTraktAsJson(u)  # pobranie danych z serwera
            result, headers = trakt.getTraktAsJson(u, ret_headers=True)  # pobranie danych z serwera

            # fflog(f'{headers=}',1,1)
            # fflog(f'{len(result)=}',1,1)
            # fflog(f'result={json.dumps(result, indent=2)}',1,1)

            result = convert(result)  # co to robi?

            items = []
            for i in result:
                try:
                    items.append(i["show"])
                except Exception:
                    pass
                    # fflog_exc(1)
            if len(items) == 0:
                items = result  # bo są różne wersje wyników
                pass
        except Exception:
            fflog_exc(1)
            return

        try:
            q = dict(parse_qsl(urlsplit(url).query))
            if not int(q["limit"]) == len(items):
                raise Exception()
            q.update({"page": str(int(q["page"]) + 1)})
            q = (urlencode(q)).replace("%2C", ",")
            next = url.replace("?" + urlparse(url).query, "") + "?" + q
            # next = next
        except:
            next = ""

        total_pages = int(headers.get('X-Pagination-Page-Count') or 0)
        curr_page   = int(headers.get('X-Pagination-Page') or 0)

        for item in items:
            # fflog(f'item={json.dumps(item, indent=2)}',1,1)
            try:
                # if i["type"] not in ["show", "episode"]:  # movie i person odpadają
                    # fflog(f'niepasujący typ {i["type"]=}',1,1)
                    # continue

                if not "title" in item:
                    continue
                title = item["title"]
                title = re.sub(r"\s(|[(])(UK|US|AU|\d{4})(|[)])$", "", title)
                title = client.replaceHTMLCodes(title)

                year = item["year"]
                year = re.sub("[^0-9]", "", str(year))
                if int(year) > int((self.datetime).strftime("%Y")):
                    #raise Exception()
                    continue

                imdb = item["ids"]["imdb"]
                if imdb is None or imdb == "":
                    imdb = "0"
                else:
                    imdb = "tt" + re.sub("[^0-9]", "", str(imdb))

                tvdb = item["ids"]["tvdb"]
                if tvdb is None or tvdb == "":
                    tvdb = "0"
                else:
                    tvdb = re.sub("[^0-9]", "", str(tvdb))
                    dupes.append(tvdb)

                tmdb = item["ids"]["tmdb"]
                if tmdb is None or tmdb == "":
                    tmdb = "0"
                else:
                    tmdb = re.sub("[^0-9]", "", str(tmdb))
                    dupes.append(tmdb)

                try:
                    premiered = item["first_aired"]
                except:
                    premiered = "0"
                try:
                    premiered = re.compile(r"(\d{4}-\d{2}-\d{2})").findall(premiered)[0]
                except:
                    premiered = "0"

                try:
                    studio = item["network"]
                except:
                    studio = "0"
                if studio is None:
                    studio = "0"

                try:
                    genre = item["genres"]
                except:
                    genre = "0"
                genre = [i.title() for i in genre]
                if genre == []:
                    genre = "0"
                genre = " / ".join(genre)

                try:
                    duration = str(item["runtime"])
                except:
                    duration = "0"
                if duration is None:
                    duration = "0"

                try:
                    rating = str(item["rating"])
                except:
                    rating = "0"
                if rating is None or rating == "0.0":
                    rating = "0"

                try:
                    votes = str(item["votes"])
                except:
                    votes = "0"
                try:
                    votes = str(format(int(votes), ",d"))
                except:
                    pass
                if votes is None:
                    votes = "0"

                try:
                    mpaa = item["certification"]
                except:
                    mpaa = "0"
                if mpaa is None:
                    mpaa = "0"

                try:
                    plot = item["overview"]
                except:
                    plot = "0"
                if plot is None:
                    plot = "0"
                plot = client.replaceHTMLCodes(plot)

                self.list.append(
                    {
                        "title": title,
                        "originaltitle": title,
                        "year": year,
                        "premiered": premiered,
                        "studio": studio,
                        "genre": genre,
                        "duration": duration,
                        "rating": rating,
                        "votes": votes,
                        "mpaa": mpaa,
                        "plot": plot,
                        "imdb": imdb,
                        "tvdb": tvdb,
                        "tmdb": tmdb,
                        "poster": "0",
                        "next": next,
                        "total_pages": total_pages,
                        "curr_page": curr_page,
                    }
                )
            except Exception:
                fflog_exc(1)
                # fflog(f'{items=}',1,1)
                # fflog(f'items={json.dumps(items, indent=2)}',1,1)
                pass

        return self.list


    ### IMDB ###
    def imdb_list(self, url):
        media_list = []

        # headers = {'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7'}
        headers = {"Accept-Language": self.lang}
        dupes = []

        for i in re.findall(r"date\[(\d+)\]", url):
            url = url.replace(
                "date[%s]" % i,
                (self.datetime - datetime.timedelta(days=int(i))).strftime("%Y-%m-%d"),
            )

        def imdb_watchlist_id(url):  # już chyba niepotrzebne
            return client.parseDOM(
                client.request(url, headers=headers),
                "meta",
                ret="content",
                attrs={"property": "pageId"},
            )[0]

        # coś się zmieniło na stronie IMDb - może to już niepotrzebne
        if url == self.imdbwatchlist_link:
            pass
        elif url == self.imdbwatchlist1_link:
            # url = cache.get(imdb_watchlist_id, 8640, url)
            # url = self.imdblist1_link % url
            pass
        elif url == self.imdbwatchlist2_link:
            # url = cache.get(imdb_watchlist_id, 8640, url)
            # url = self.imdblist2_link % url
            pass

        result = client.request(url, headers=headers)

        # result = result.replace("\n", " ")

        # check if list is private
        private_list = client.parseDOM(result, "h3", attrs={"class": "ipc-title__text"})
        if private_list and "rivate list" in private_list[0]:
            # fflog(f'[imdb_list] {re.sub("<[^>]+>", "", private_list[0])}')
            fflog(f'[imdb_list] {client.replaceHTMLCodes(private_list[0])}')
            private_list_description = client.parseDOM(result, "div", attrs={"class": "ipc-title__description"})
            if private_list_description:
                fflog(f'[imdb_list] description: {private_list_description[0]}')
            control.infoDialog('Private list\n'+private_list_description[0], 'IMDb', "WARNING", 5000)
            control.sleep(5000)
            return

        jsdata = client.parseDOM(result, "script", attrs={"type": "application/json"})
        try:
            jsdata = json.loads(jsdata[0])
            # fflog(f'jsdata={json.dumps(jsdata, indent=4)}',1,1)
        except Exception:
            fflog_exc(1)
            jsdata = {}

        js_items = {}
        if jsdata:
            try:
                js_items = jsdata['props']['pageProps']
                # fflog(f'js_items={json.dumps(js_items, indent=4)}',1,1)
            except Exception:
                fflog_exc(1)

            jsdata = None

            if js_items:
                if "/list/" in url:
                    try:
                        js_items = js_items['mainColumnData']['list']['titleListItemSearch']['edges']  # pasuje do watchlist
                    except Exception:
                        fflog_exc(1)
                elif "/user/" in url:
                    try:
                        js_items = js_items['mainColumnData']['predefinedList']['titleListItemSearch']['edges']  # pasuje do watchlist
                    except Exception:
                        fflog_exc(1)
                else:
                    try:
                        js_items = js_items['searchResults']['titleResults']['titleListItems']  # pasuje do Oskarów
                    except Exception:
                        fflog_exc(1)

                fflog(f'{len(js_items)=}', 1,1)

        items = []
        #items = client.parseDOM(result, "div", attrs={"class": "lister-item .+?"})
        # items = client.parseDOM(result, "ul", attrs={"class": "ipc-metadata-list .+?"})
        # fflog(f'[imdb_list] {items=}')
        #items += client.parseDOM(result, "div", attrs={"class": "list_item.+?"})
        items += client.parseDOM(result, "li", attrs={"class": "ipc-metadata-list-summary-item"})  # każdy tytuł z osobna
        fflog(f'[imdb_list] {len(items)=}')

        if len(js_items) >= len(items):
            items = js_items

        next_page = ""
        """
        try:  # tylko, że teraz paginacja jest poprzez dynamiczne doczytywanie, więc to już nie działa Trzeba by podejrzeć, co przeglądarka wysyła i z tym kombinować.
            next_page = client.parseDOM(result, "a", ret="href", attrs={"class": ".+?ister-page-nex.+?"})
            if len(next_page) == 0:
                next_page = client.parseDOM(result, "div", attrs={"class": "pagination"})[0]
                next_page = zip(client.parseDOM(next_page, "a", ret="href"), client.parseDOM(next_page, "a"))
                next_page = [i[0] for i in next_page if "Next" in i[1]]
            next_page = url.replace(urllib.urlparse(url).query, urllib.urlparse(next_page[0]).query)
            next_page = client.replaceHTMLCodes(next_page)
        # next_page = next_page.encode("utf-8")
        except Exception:
            # fflog_exc(1)
            fflog(f'[imdb_list] brak paginacji')
            next_page = ""
        """
        
        result = None

        fflog(f'[imdb_list] zatem {len(items)=}')
        for item in items:
            # fflog(f'[imdb_list] {item=}')
            try:
                if items is js_items:
                    if "/user/" in url or "/list/" in url:
                        title = item['listItem']['titleText']['text']
                        originaltitle = item['listItem']['originalTitleText']['text']
                    else:
                        title = item['titleText']
                        originaltitle = item['originalTitleText']
                else:
                    title = client.parseDOM(item, "a")[1]
                    title = client.parseDOM(title, "h3", attrs={"class": "ipc-title__text"})[0]
                    title = client.replaceHTMLCodes(title)
                    title = re.sub(r"^\d+\. ", "", title)
                    originaltitle = title
                # fflog(f'{title=}',1,1)  # debug

                # potrzebne, bo na watchliscie są zmieszane pozycje
                if items is js_items:
                    if "/user/" in url or "/list/" in url:
                        # content_type = item['listItem']['titleType']['id']  # "tvSeries" lub "tvMiniSeries" i inne
                        content_type = item['listItem']['titleType']['text']  # "TV Series" lub "TV Mini Series" i inne
                    else:
                        # content_type = item['titleType']['id']
                        content_type = item['titleType']['text']
                else:
                    content_type = client.parseDOM(item, "span", attrs={"class": ".+? dli-title-type-data"})
                    content_type = content_type[0] if content_type else ""
                    # fflog(f'[imdb_list] {content_type=}')
                if not content_type or content_type.lower() == "movie":  # oczekiwane "TV Series" lub "TV Mini Series" dla seriali
                    # fflog(f'to nie jest serial {title=}  {content_type=}',1,1)
                    continue

                if items is js_items:
                    if "/user/" in url or "/list/" in url:
                        year = item['listItem']['releaseYear']['year']
                    else:
                        year = item['releaseYear']
                    year = str(year)
                else:
                    # year = client.parseDOM(item, "span", attrs={"class": "lister-item-year.+?"})
                    year = client.parseDOM(item, "span", attrs={"class": ".+? dli-title-metadata-item"})
                    # year += client.parseDOM(item, "span", attrs={"class": "year_type"})
                    # year = re.findall(r"(\d{4})", year[0])[0]
                    try:
                        if type(year) == list:
                            year = year[0]
                        year = re.compile(r"(\d{4})").findall(year)[0]
                    except:
                        year = "0"
                if int(year) > int((self.datetime).strftime("%Y")):  # to coś pomija, ale dlaczego?
                    fflog(f' {int(year)=}  >  {int(self.datetime.strftime("%Y"))=}  | {title=}')
                    #raise Exception()
                    # continue
                    pass

                if items is js_items:
                    if "/user/" in url or "/list/" in url:
                        premiered = item['listItem']['releaseDate']
                    else:
                        premiered = item['releaseDate']
                    premiered = f"{premiered['year']}-{premiered['month']:02d}-{premiered['day']:02d}"
                else:
                    premiered = "0"

                if items is js_items:
                    if "/user/" in url or "/list/" in url:
                        imdb = item['listItem']['id']
                    else:
                        imdb = item['titleId']
                else:
                    imdb = client.parseDOM(item, "a", ret="href")[0]
                    imdb = re.findall(r"(tt\d*)", imdb)[0]

                if imdb in dupes:  # może przydatne, jak pozycje zbierane są z kilku list
                    continue
                dupes.append(imdb)

                poster = rating = votes = plot = mpaa = genre = "0"

                # czy reszty nie można pociągnąć z super_info? ale może lepiej mieć niektóre dane z imdb
                if True:
                # if items is not js_items:  # potem dorobię i dla js_items
                    if items is js_items:
                        if "/user/" in url or "/list/" in url:
                            poster = item['listItem']['primaryImage']['url']
                        else:
                            poster = item['primaryImage']['url']
                    else:
                        try:
                            poster = client.parseDOM(item, "img", ret="loadlate")[0]
                        except:
                            poster = "0"
                        if "/nopicture/" in poster or '/sash/':
                            poster = "0"
                        poster = re.sub(r"(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.", "_SX500.", poster)
                        poster = client.replaceHTMLCodes(poster)

                    rating = "0"
                    if items is js_items:
                        if "/user/" in url or "/list/" in url:
                            rating = item['listItem']['ratingsSummary']['aggregateRating']
                        else:
                            rating = item['ratingsSummary']['aggregateRating']
                        rating = str(rating)
                        # fflog(f'{title=}  {rating=}')
                    else:
                        # te class są nieaktualne
                        try:
                            rating = client.parseDOM(item, "span", attrs={"class": "ipc-rating-star--rating"})[0]
                        except:
                            pass
                        if rating == "0":
                            try:
                                rating = client.parseDOM(item, "span", attrs={"class": "rating-rating"})[0]
                            except:
                                pass
                            try:
                                rating = client.parseDOM(rating, "span", attrs={"class": "value"})[0]
                            except:
                                rating = "0"
                        if rating == "0":
                            try:
                                rating = client.parseDOM(item, "div", ret="data-value", attrs={"class": ".*?imdb-rating"})[0]
                            except:
                                pass
                            if rating == "" or rating == "-":
                                rating = "0"
                        rating = client.replaceHTMLCodes(rating)

                    if items is js_items:
                        if "/user/" in url or "/list/" in url:
                            votes = item['listItem']['ratingsSummary']['voteCount']
                        else:
                            votes = item['ratingsSummary']['voteCount']
                        votes = str(votes)
                        # fflog(f'{title=}  {voteCount=}')

                    plot = "0"
                    if items is js_items:
                        if "/user/" in url or "/list/" in url:
                            plot = item['listItem']['plot']['plotText']['plainText']
                        else:
                            plot = item['plot']
                        # fflog(f'{title=}  {plot=}')
                    else:
                        try:
                            plot = client.parseDOM(item, "p", attrs={"class": "text-muted"})[0]
                        except:
                            pass
                        if plot == "0":
                            try:
                                plot = client.parseDOM(item, "div", attrs={"class": "item_description"})[0]
                            except:
                                pass
                        plot = plot.rsplit("<span>", 1)[0].strip()
                        plot = re.sub("<.+?>|</.+?>", "", plot)
                        if not plot:
                            plot = "0"
                        plot = client.replaceHTMLCodes(plot)

                if items is js_items:
                    try:
                        if "/user/" in url or "/list/" in url:
                            mpaa = item['listItem']['certificate']['rating']
                        else:
                            mpaa = item['certificate']
                    except:
                        # mpaa = ""
                        pass

                if items is js_items:
                    try:
                        if "/user/" in url or "/list/" in url:
                            genres = item['listItem']['titleGenres']['genres']
                            genre = " / ".join([g['genre']['text'] for g in genres]) if genres else ""
                        else:
                            genres = item['genres']
                            genre = " / ".join([g for g in genres]) if genres else ""
                    except Exception:
                        fflog_exc(1)
                        # genre = ""
                        pass

                # self.list.append(
                item_el = (  # bo potrzebuję do debugu
                    {
                     "title": title,
                     "originaltitle": originaltitle,
                     "year": year,
                     "premiered": premiered,
                     "rating": rating,
                     "votes": votes,
                     "plot": plot,  # opisy są po angielsku
                     "poster": poster,
                     "mpaa": mpaa,
                     "genre": genre,
                     "imdb": imdb,
                     "tmdb": "0",
                     "tvdb": "0",
                     "next": next_page,
                    }
                )
                # fflog(f'item_el={json.dumps(item_el, indent=2)}',1,1)
                self.list.append(item_el)
            except Exception:
                fflog_exc(1)
                pass

        if items is not js_items:
            # self.list = self.worker(self.list)  # uzupełnienie danych z super_info
            pass

        return self.list


    ### MOJE FILMY - LISTY FILMÓW ###
    ## Listy Użytkownika (TRAKT + IMDB + TMDB)
    def userlists(self, refresh=None):
        fflog(f'{params=}', 1, 1)

        userlists = []

        try:
            self.list = []
            if self.tmdb_sessionid == "":
                raise Exception()
            cache_timeout = 0 if refresh else 0.1  # 6 minut
            userlists += cache.get(self.tmdblist, cache_timeout, self.tmdb_user_lists)
        except Exception:
            #fflog_exc(1)
            pass

        try:
            self.list = []
            if not self.imdb_user:
                raise Exception()
            cache_timeout = 0 if refresh else 0.5  # 30 minut
            userlists += cache.get(self.imdb_user_list, cache_timeout, self.imdblists_link)
        except Exception:
            #fflog_exc(1)
            pass

        try:
            if trakt.getTraktCredentialsInfo() is False:
                raise Exception()
            activity = trakt.getActivity()
            #fflog(f'{activity=}')
        except Exception:
            #fflog_exc(1)
            pass

        try:
            if trakt.getTraktCredentialsInfo() is False:
                raise Exception()
            try:
                if activity > cache.timeout(self.trakt_user_list, self.traktlists_link, self.trakt_user):
                    raise Exception()
                #fflog(f'z cache')
                userlists += cache.get(self.trakt_user_list, 720, self.traktlists_link, self.trakt_user)
            except:
                #fflog(f'odświeżam')
                userlists += cache.get(self.trakt_user_list, 0, self.traktlists_link, self.trakt_user)
        except Exception:
            #fflog_exc(1)
            pass

        try:
            self.list = []
            if trakt.getTraktCredentialsInfo() is False:
                raise Exception()
            try:
                if activity > cache.timeout(self.trakt_user_list, self.traktlikedlists_link, self.trakt_user):
                    raise Exception()
                #fflog(f'z cache')
                userlists += cache.get(self.trakt_user_list, 720, self.traktlikedlists_link, self.trakt_user)
            except:
                #fflog(f'odświeżam')
                userlists += cache.get(self.trakt_user_list, 0, self.traktlikedlists_link, self.trakt_user)
        except Exception:
            #fflog_exc(1)
            pass

        self.list = userlists
        for i in range(0, len(self.list)):
            self.list[i].update({
                "action": "tvshows",
                "image": "userlists.png" if not (img:=self.list[i].get("image")) else img,
                })
            #fflog(f'{self.list[i]=}')
        # fflog(f'{self.list=}')
        # fflog(f'self.list={json.dumps(self.list, indent=2)}')
        self.addDirectory(self.list, add_refresh=True)
        return self.list


    ### TRAKT ###
    def trakt_user_list(self, url, user):
        #fflog(f'{url=} {user=}')
        try:
            items = trakt.getTraktAsJson(url)
        except Exception:
            fflog_exc(1)
            pass

        for item in items:
            try:
                try:
                    name = item["list"]["name"]
                    # name += " *"
                    name += f'  [LIGHT][I][{item["list"]["user"]["username"]}][/I][/LIGHT]'
                except:
                    name = item["name"]
                name = client.replaceHTMLCodes(name)

                try:
                    # url = (trakt.slug(item["list"]["user"]["username"]), item["list"]["ids"]["slug"])
                    url = (item["list"]["user"]["ids"]["slug"], item["list"]["ids"]["slug"],)
                except:
                    url = ("me", item["ids"]["slug"])

                url = self.traktlist_link % url
                url = url.replace("/users/None/", "/")
                # url = url

                self.list.append({"name": name, "url": url, "context": url, "image": "trakt.png",})
            except Exception:
                fflog_exc(1)
                pass

        self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
        return self.list


    ## TMDB##
    def tmdblist(self, url):
        # fflog(f'{url=}', 1, 1)
        # url = self.tmdb_user_lists
        url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
        url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)
        tmdb_results = requests.get(url, timeout=30).json()

        # `next` nie jest nigdzie użyte (rysson)  # może to niepotrzebne wcale?
        # page = tmdb_results.get("page", 0)
        # total = tmdb_results.get("total_pages", 0)
        # if page < total and "page=" in url:
        #     next = re.sub(r"page=\d+", f"page={page + 1}", url)
        # else:
        #     next = ""

        if "results" in tmdb_results:
            items = tmdb_results["results"]
        elif "items" in tmdb_results:
            items = tmdb_results["items"]
        elif "parts" in tmdb_results:
            items = tmdb_results["parts"]
        elif "cast" in tmdb_results and (items := tmdb_results["cast"]):
            # items = tmdb_results["cast"]
            pass
        elif "crew" in tmdb_results and (items := tmdb_results["crew"]):
            # items = tmdb_results["crew"]
            pass
        else:
            items = []
            fflog(f'jakiś błąd  {tmdb_results=}',1,1)

        for item in items:
            # if item.get('original_language') != 'ru':
            if item.get('list_type') == 'movie':  # tylko, że zawsze jest "movie" (głupie TMDB)
                # continue
                pass
            self.list.append({
                "name": item.get("name"),
                "id": str(item.get("id")),
                "url": self.tmdb_lists_link % str(item.get("id")),
                "context": self.tmdb_lists_link % str(item.get("id")),
                "image": "tmdb.png",
                })

        fflog(f'{len(self.list)=}',1,1)
        # self.addDirectory(self.list)
        if self.list:
            self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
        return self.list


    ### IMDB ###
    def imdb_user_list(self, url):
        try:
            result = client.request(url)
            items = client.parseDOM(result, "li", attrs={"class": "ipc-metadata-list-summary-item"})
        except Exception:
            fflog_exc(1)
            pass

        for item in items:
            try:
                name = client.parseDOM(item, "a", attrs={"class": "ipc-metadata-list-summary-item__t"})[0]
                name = client.replaceHTMLCodes(name)
                # name = name  # to już niepotrzebne

                url = client.parseDOM(item, "a", ret="href")[0]
                url = url = url.split("/list/", 1)[-1].strip("/")
                url = self.imdblist1_link % url
                url = client.replaceHTMLCodes(url)
                # url = url

                self.list.append({"name": name, "url": url, "context": url, "image": "imdb.png",})
            except Exception:
                fflog_exc(1)
                pass

        self.list = sorted(self.list, key=lambda k: utils.title_key(k["name"]))
        return self.list


    def get(self, url, idx=True, create_directory=True, refresh=None, category=""):
        """ tworzy różne katalogi (wirtualne) Kodi """

        # debug
        if not "http" in url: 
            fflog(f'{params=}', fn=True)
            pass
        else:
            if not _is_debugging():
                fflog(f'params={({**params, "url": "*"})}', 1, 1)
                pass
            else:
                fflog(f'params={({**params, "url": url})}', 0)

        # import sys
        # sys.path.append("D:\PyCharm 2022.1.4\debug-eggs\pydevd-pycharm.egg")
        # import pydevd_pycharm
        # pydevd_pycharm.settrace('localhost', port=5678, stdoutToServer=True, stderrToServer=True)
        try:
            # url = re.sub("(?<=api_key=)[^&]*", self.tm_user, url)
            # url = re.sub("(?<=session_id=)[^&]*", self.tmdb_sessionid, url)

            # fflog(f' z {url=}')
            try:
                url = getattr(self, url + "_link")  # szuka atrybutu (np. zmiennej) klasy (self, czyli tvshow)
            except Exception:
                # fflog_exc(1)
                # fflog(f'nie dopasowano _link do url-a , bo {url=}')
                pass
            # fflog(f'na {url=}')

            u = urlparse(url).netloc.lower()  # np. "api.themoviedb.org"
            # fflog(f'{u=}')

            cache_timeout = from_cache = True

            self.idx = idx

            if u in self.tmdb_link and ('/list/' in url or '/collection/' in url or '/discover/' in url or '/airing_today' in url):
                # fflog(f'   wariant1 {url=}')
                cache_timeout = 0 if refresh or not idx else 12  # 12 godzin
                if cache_timeout:
                    # if any(i in url for i in ["/watchlist/", "/favorite/", "/rated/"]):
                    if any(i in url for i in ["/account/", "/list/", "/guest_session/"]):
                        # cache_timeout = 0  # wyłączenie z cachowania
                        cache_timeout = 0 if refresh else 0.1  # 6 minut
                        pass
                self.list = cache.get(self.tmdb_list, cache_timeout, url, output_type="tuple")
                if isinstance(self.list, tuple):
                    self.list, from_cache = self.list
                if idx is True:
                    self.worker(from_cache=from_cache)

            #elif u in self.tmdb_link and self.tmdb_tv_search in url:
            #elif u in self.tmdb_link and "/search/" in url:
            elif u in self.tmdb_link:
                # fflog(f'   wariant2 {url=}')  # wszystkie pozostałe - tu są m.in. watchlisty i ulubione oraz szukanie
                cache_timeout = 0 if refresh or not idx else 12
                if cache_timeout:
                    # if any(i in url for i in ["/watchlist/", "/favorite/", "/rated/"]):
                    if any(i in url for i in ["/account/", "/list/", "/guest_session/"]):
                        # cache_timeout = 0  # wyłączenie z cachowania
                        cache_timeout = 0 if refresh else 0.1  # 6 minut
                        pass
                self.list = cache.get(self.tmdb_list, cache_timeout, url, output_type="tuple")  # lista tytułów
                if isinstance(self.list, tuple):
                    self.list, from_cache = self.list
                    # fflog(f'list {from_cache=}')
                if idx is True:
                    self.worker(from_cache=from_cache)  # uszczegółowienie każdego tytułu z listy
                if self.list and "/search/" in url:
                    # fflog(f'tmdb przestał sortować wyszukiwania, którą są wg frazy',1,1)
                    # fflog(f'self.list={json.dumps(self.list, indent=2)}',1,1)  # dla sprawdzenia
                    tvshowssort = int(control.setting("tvshows.sort"))
                    # fflog(f'{tvshowssort=}')
                    tvshowssort = 0  # wymuszenie na popularność, bo to w tym przypadku to praktyczniejsze
                    if tvshowssort:
                        # fflog(f'posortowanie wg roku',1,1)
                        self.list = sorted(self.list, key=lambda k: k.get("year", ""), reverse=True)
                        pass
                    else:
                        # fflog(f'posortowanie wg popularności',1,1)
                        self.list = sorted(self.list, key=lambda k: k.get("popularity", 0), reverse=True)

            # elif u in self.tmdb_link:
                # fflog(f'   wariant3 {url=}')  # wszystkie pozostałe - tu są m.in. watchlisty i ulubione
                # cache_timeout = 0 if refresh or not idx else 12
                # if cache_timeout:
                    # # if any(i in url for i in ["/watchlist/", "/favorite/", "/rated/"]):
                    # if any(i in url for i in ["/account/", "/list/", "/guest_session/"]):
                        # cache_timeout = 0  # wyłączenie z cachowania
                        # cache_timeout = 0 if refresh else 0.1  # 6 minut
                        # pass
                # self.list = cache.get(self.tmdb_list, cache_timeout, url, output_type="tuple")  # lista tytułów
                # if isinstance(self.list, tuple):
                    # self.list, from_cache = self.list
                    # # fflog(f'list {from_cache=}')
                # if idx is True:
                    # self.worker(from_cache=from_cache)  # uszczegółowienie każdego tytułu z listy

            elif u in self.trakt_link and "/users/" in url:
                try:
                    if not "/users/me/" in url:
                        raise Exception()
                    if trakt.getActivity() > cache.timeout(self.trakt_list, url, self.trakt_user):
                        raise Exception()
                    self.list = cache.get(self.trakt_list, 720, url, self.trakt_user, output_type="tuple")
                except:
                    self.list = cache.get(self.trakt_list, 0, url, self.trakt_user)
                if isinstance(self.list, tuple):
                    self.list, from_cache = self.list
                if "/users/me/" in url and "/collection/" in url:
                    if self.list:
                        self.list = sorted(self.list, key=lambda k: utils.title_key(k["title"]))
                if idx is True:
                    self.worker(from_cache=from_cache)

            elif u in self.trakt_link and self.search_link in url:
                self.list = cache.get(self.trakt_list, 1, url, self.trakt_user, output_type="tuple")
                if isinstance(self.list, tuple):
                    self.list, from_cache = self.list
                if idx is True:
                    self.worker(level=0, from_cache=from_cache)

            elif u in self.trakt_link:
                self.list = cache.get(self.trakt_list, 24, url, self.trakt_user, output_type="tuple")
                if isinstance(self.list, tuple):
                    self.list, from_cache = self.list
                if idx is True:
                    self.worker(from_cache=from_cache)

            elif u in self.imdb_link and ("/user/" in url or "/list/" in url):
                cache_timeout = 0 if refresh else 1
                self.list = cache.get(self.imdb_list, cache_timeout, url)
                if isinstance(self.list, tuple):
                    self.list, from_cache = self.list
                if idx is True:
                    self.worker(from_cache=from_cache)

            elif u in self.imdb_link:
                self.list = cache.get(self.imdb_list, 24, url, output_type="tuple")
                if isinstance(self.list, tuple):
                    self.list, from_cache = self.list
                if idx is True:
                    self.worker(from_cache=from_cache)

            elif u in self.tvmaze_link:
                self.list = cache.get(self.tvmaze_list, 168, url, output_type="tuple")
                if isinstance(self.list, tuple):
                    self.list, from_cache = self.list
                if idx is True:
                    self.worker(from_cache=from_cache)


            if self.list:
                #fflog(f'{len(self.list)=}')
                # self.list = [i for n, i in enumerate(self.list) if i not in self.list[n + 1:]]  # eliminacja dubli (ale zostawia ostatnie)
                self.list = [i for n, i in enumerate(self.list) if i not in self.list[:n]]  # eliminacja dubli (to lepsze, bo usuwa dalsze/kolejne)
                #fflog(f'{len(self.list)=}')


            if idx is True and create_directory is True:
                if self.list:
                    self.tvshowDirectory(self.list, category=category)
                else:
                    import xbmcgui
                    xbmcgui.Dialog().notification('Błąd', 'Nic nie znaleziono', xbmcgui.NOTIFICATION_ERROR)
                    navigator.navigator().endDirectory()
                    control.execute('Action(Back)')


            return self.list

        except Exception as e:
            fflog_exc(1)
            print(e)
            pass



    def worker(self, media_list=None, level=1, from_cache=None):  # do czego miał służyć "level" ?
        """ pobieranie informacji o tytułach z tmdb"""
        from threading import Thread
        from resources.lib.indexers.super_info import SuperInfo

        # self.meta = []

        if not media_list:
            media_list = self.list  # mutowanie listy będzie następowało

        total = len(media_list) if media_list else 0

        # for i in range(0, total):
        #     self.list[i].update({"metacache": False})
        #
        # self.list = metacache.fetch(self.list, self.lang, self.user)
        #
        # for i in range(total):
        #     self.list[i]["metacache"] = False
        #
        # self.list = metacache.fetch(self.list, self.lang, self.user)
        # log_utils.fflog(f"{len(media_list)=} {media_list=}")

        super_info_media_list = []  # do zwrócenia wyniku

        for r in range(0, total, 20):

            threads = {super_info_obj: Thread(target=super_info_obj.get_info, args=(i,from_cache,)) for i in
                       range(r, min(total, r + 20)) for super_info_obj in
                       (SuperInfo(media_list, self.session, self.lang, 'tvshow'),)}

            [i.start() for i in threads.values()]
            [i.join() for i in threads.values()]

            for super_info_obj in threads:
                if super_info_obj.meta:
                    super_info_media_list.append( super_info_obj.meta[0].get('item') )  # jak ma być zwrócony wynik

            # if self.meta:  #     metacache.insert(self.meta)

        return super_info_media_list  # opcjonalnie, gdy wyniki są zwracane poprzez zmutowanie self.list, no chyba, że została zadana jakaś konkretna lista (jako argument tej funkcji)

#        self.list = [i for i in self.list if not i["tvdb"] == "0"]
#
#        if self.fanart_tv_user == "":
#            for i in self.list:
#                i.update({"clearlogo": "0", "clearart": "0"})


    def tvshowDirectory(self, items, cacheToDisc=False, directory=True, multi=False, category=""):
        fflog(f'[tvshowDirectory]')
        if items is None or len(items) == 0:
            sys.exit()

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])
        currentPath = dict(urllib.parse_qsl(sys.argv[2][1:]))

        if control.setting("zastepcze_grafiki") == "true":
            addonPoster = control.addonPoster()
            addonFanart = control.addonFanart()
            addonBanner = control.addonBanner()
        else:
            addonPoster = addonFanart = addonBanner = ""

        settingFanart = control.setting("fanart")

        tmdbCredentials = False if control.setting("tmdb.sessionid") == "" else True

        traktCredentials = trakt.getTraktCredentialsInfo()
        traktIndicators  = trakt.getTraktIndicatorsInfo()

        try:
            isOld = False
            control.item().getArt("type")
        except:
            isOld = True

        indicators = (
            playcount.getTVShowIndicators(refresh=True)
            if action == "tvshows"
            else playcount.getTVShowIndicators()
        )
        # fflog(f'{indicators=}',1,1)

        flatten = True if control.setting("flatten.tvshows") == "true" else False

        watchedMenu = (
            control.lang(32068)
            if traktIndicators is True
            else control.lang(32066)
        )

        unwatchedMenu = (
            control.lang(32069)
            if traktIndicators is True
            else control.lang(32067)
        )

        queueMenu = control.lang(32065)
        traktManagerMenu = control.lang(32070)
        tmdbManagerMenu = "Menadżer TMDB"
        nextMenu = control.lang(32053)
        nextMenu = nextMenu + "  >>"
        playRandom = control.lang(32535)
        addToLibrary = control.lang(32551)

        generate_short_path = control.setting("generate_short_path") == "true"

        # add_rating_for_tmdb = control.setting("add_rating_for_tmdb.tvshows") == "true" and control.setting("add_rating_for_tmdb") == "true"
        add_rating_for_tmdb = True

        # from ptw.libraries import source_utils
        # kodiver = source_utils.get_kodi_version()
        # fflog(f'{kodiver.version=}')
        # fflog(f'{kodiver.major=} {kodiver.minor=}')

        addSortMethod(syshandle, sortMethod=SORT_METHOD_UNSORTED, labelMask="%L")
        # addSortMethod(syshandle, sortMethod=SORT_METHOD_PLAYLIST_ORDER, labelMask="%L")  # wykorzystuje countera
        addSortMethod(syshandle, sortMethod=SORT_METHOD_VIDEO_YEAR, labelMask="%L")
        addSortMethod(syshandle, sortMethod=SORT_METHOD_TITLE, labelMask="%L")
        addSortMethod(syshandle, sortMethod=SORT_METHOD_VIDEO_RATING, labelMask="%L")

        cm_enable_autoplay = control.setting("cm.enable.autoplay") == "true"
        cm_enable_similar_trakt = control.setting("cm.enable.similar_trakt") == "true"
        cm_enabl_similar_tmdb = control.setting("cm.enable.similar_tmdb") == "true"
        cm_enable_recommendations_tmdb = control.setting("cm.enable.recommendations_tmdb") == "true"
        cm_enable_removeFromBookmarks = control.setting("cm.enable.removeFromBookmarks") == "true"
        cm_enable_addToLibrary = control.setting("cm.enable.addToLibrary") == "true"
        cm_enable_addMultiToLibrary = control.setting("cm.enable.addMultiToLibrary") == "true"
        cm_enable_editForSearch = control.setting("cm.enable.editForSearch") == "true"
        cm_enable_queueMenu = control.setting("cm.enable.queueMenu") == "true"  # to chyba Kodi dodaje od wersji 21.2
        cm_enable_watchedUnwatched = control.setting("cm.enable.watchedUnwatched") == "true"

        unpremiered_color = control.setting("unpremiered_color")
        if unpremiered_color == "inny":
            unpremiered_color = control.setting("unpremiered_custom_color")
        else:
            colors_map = {
                "szary": "gray",
                "czerwony": "red",
                "fioletowy": "magenta",
                "pomarańczowy": "orange",
                }
            unpremiered_color = colors_map[unpremiered_color]
        # fflog(f'{unpremiered_color=}')

        add_year = control.setting("titles.add_year") == "true"

        counter = 1
        for i in items:
            try:
                # fflog(f'i={json.dumps(i, indent=2)}',1,1)

                def has(key):
                    val = i.get(key)
                    return val and val != "0"


                if "label" in i.keys():
                    label = i["label"]
                else:
                    label = i["title"]

                if not label:
                    continue


                if "year" in i.keys():
                    year = str(i["year"])
                else:
                    year = None

                if add_year and year and year != "0":
                    if year not in label:
                        # label += f' ({i["year"]}) '
                        label += f' [LIGHT]({i["year"]})[/LIGHT]'


                if multi:
                    if currentPath.get("action") != "lastWatched":
                        label = f'[{label}]'  # ciekawe, czy to nie popsuje wyszukiwania prawidłowych trailerów
                        pass


                systitle = sysname = quote_plus(i["originaltitle"])
                syslocaltitle = quote_plus(i["title"])


                item = control.item(label=label, offscreen=True)  # create ListItem


                if "imdb" in i.keys():
                    imdb = str(i["imdb"])
                else:
                    imdb = None

                if "tvdb" in i.keys():
                    tvdb = str(i["tvdb"])
                else:
                    tvdb = None

                if "tmdb" in i.keys():
                    tmdb = str(i["tmdb"])
                else:
                    tmdb = None


                meta = dict((k, v) for k, v in i.items() if not v == "0")
                # log_utils.fflog(f'{meta=}')


                meta.pop("next", None)

                meta.update({"code": imdb, "imdbnumber": imdb, "imdb_id": imdb})
                # meta.update({"imdb_id": imdb})
                meta.update({"tvdb_id": tvdb})
                meta.update({"tmdb_id": tmdb})

                meta.update({"mediatype": "tvshow"})

                meta.update({"trailer": "%s?action=trailer&name=%s&url=%s" % (sysaddon, quote_plus(label), quote_plus(meta.get("trailer") or ""))})

                if not "duration" in i:
                    # meta.update({"duration": "60"})
                    pass
                elif i["duration"] == "0":
                    # meta.update({"duration": "60"})
                    pass
                try:
                    if meta.get("duration") and meta.get("duration") != "0":
                        meta.update({"duration": str(int(meta["duration"]) * 60)})
                except:
                    pass

                # try:
                    # meta.update({"genre": cleangenre.lang(meta["genre"], self.lang)})
                # except:
                    # pass

                premiered = meta.get("premiered", 0)
                if not premiered or int(re.sub("[^0-9]", "", str(premiered))) > int(re.sub("[^0-9]", "", str(self.today_date))):
                    label = f"[COLOR {unpremiered_color}][I]%s[/I][/COLOR]" % label


                episodes = i.get("episodes") or 0  # TotalEpisodes
                # fflog(f'{episodes=}  |  {tmdb=}  {label=}',1,1)
                # okazało się, że TMDB może podawać odcinki, które jeszcze nie zostały wyemitowane
                watched = 0
                try:
                    overlay = playcount.getTVShowOverlay(indicators, imdb, tmdb, episodes, ret_tuple=True)
                    # fflog(f'{overlay=}  {imdb=}  {tmdb=}  {label=} ')
                    if isinstance(overlay, tuple):
                        overlay, watched, episodes = overlay
                    overlay = int(overlay)
                    if overlay == 7:
                        meta.update({"playcount": 1, "overlay": 7})  # to zmienia ptaszki
                    else:
                        meta.update({"playcount": 0, "overlay": 6})  # to zmienia ptaszki
                except Exception:
                    fflog_exc(1)
                    overlay = 6
                # fflog(f'{episodes=}  |  {tmdb=}  {label=}',1,1)

                if episodes:
                    item.setProperty("TotalEpisodes", str(episodes))  # nie wiem, gdzie to ma znaczenie
                    item.setProperty("WatchedEpisodes", str(watched))
                    item.setProperty("UnWatchedEpisodes", str(episodes - watched))
                    progress = int((watched / episodes) * 100)
                    # item.setProperty("WatchedProgress", str(progress))  # też działa
                    item.setProperty("WatchedEpisodePercent", str(progress))  # for tvshow and season


                cm = []  # prepare context menu

                # tu by się przydało jakieś autoplay ale w sensie odtwarzanie serialu od pierwszego odcinka pierwszego sezonu
                if cm_enable_autoplay:
                    pass

                if cm_enable_addToLibrary:
                    cm.append(
                        (
                            addToLibrary,
                            "RunPlugin(%s?action=tvshowToLibrary&tvshowtitle=%s&localtvshowtitle=%s&year=%s&imdb=%s&tvdb=%s)"
                            % (sysaddon, systitle, syslocaltitle, year, imdb, tvdb),
                        )
                    )

                if cm_enable_watchedUnwatched:
                    if not traktIndicators:
                        if overlay != 7:
                            cm.append(
                                (
                                    watchedMenu,
                                    "RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tmdb=%s&query=7)"
                                    % (sysaddon, systitle, imdb, tmdb),
                                )
                            )
                        if True:  # to powinno być zawsze dostępne
                            cm.append(
                                (
                                    unwatchedMenu,
                                    "RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tmdb=%s&query=6)"
                                    % (sysaddon, systitle, imdb, tmdb),
                                )
                            )

                if traktCredentials is True:
                    cm.append(
                        (
                            traktManagerMenu,
                            "RunPlugin(%s?action=traktManager&name=%s&imdb=%s&tmdb=%s&content=tvshow&overlay=%s)"
                            % (sysaddon, sysname, imdb, tmdb, overlay),
                        )
                    )

                if tmdbCredentials:
                    if add_rating_for_tmdb:
                        cm.append((tmdbManagerMenu, "RunPlugin(%s?action=tmdbManager&tmdb=%s&content=tv&overlay=%s&WatchedEpisodes=%s)" % (sysaddon, tmdb, overlay, watched),))
                    else:
                        cm.append((tmdbManagerMenu, "RunPlugin(%s?action=tmdbManager&tmdb=%s&content=tv)" % (sysaddon, tmdb),))

                if cm_enable_removeFromBookmarks:
                    if currentPath.get("action") == "lastWatched":
                        cm.append(("Usuń z lokalnej historii", "RunPlugin(%s?action=removeFromBookmarks&imdb=%s&content=tvshow)" % (sysaddon, imdb),))

                if cm_enable_similar_trakt:
                    cm.append(
                        (
                            "Znajdź podobne (Trakt)",
                            "ActivateWindow(10025,%s?action=tvshows&url=https://api.trakt.tv/shows/%s/related,return)"
                            % (sysaddon, imdb),
                        )
                    )

                if cm_enabl_similar_tmdb:
                    if not generate_short_path:
                        #cm.append(("Znajdź podobne", "ActivateWindow(10025,%s?action=tvsimilar&tmdb=%s)" % (sysaddon, tmdb),))
                        cm.append(("Podobne (TMDB)", "Container.Update(%s?action=tvsimilar&tmdb=%s)" % (sysaddon, tmdb),))
                    else:
                        cm.append(("Podobne (TMDB)", "Container.Update(%s?action=tvsimilar)" % (sysaddon,),))

                if cm_enable_recommendations_tmdb:
                    if not generate_short_path:
                        #cm.append(("Rekomendacje", "ActivateWindow(10025,%s?action=tvrecommendations&tmdb=%s)" % (sysaddon, tmdb),))
                        cm.append(("Rekomendacje (TMDB)", "Container.Update(%s?action=tvrecommendations&tmdb=%s)" % (sysaddon, tmdb),))
                    else:
                        cm.append(("Rekomendacje (TMDB)", "Container.Update(%s?action=tvrecommendations)" % (sysaddon,),))

                if cm_enable_queueMenu:
                    if not generate_short_path:  # bo inaczej źle dodaje (dodaje te same odcinki kilka razy w zależności od ilości sezonów)
                        cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))

                if False:  # wyłączenie
                    # Odtwarzaj losowo (? - trochę dziwne to, raczej do teledysków się nadaje, niż do seriali).
                    cm.append(
                        (
                            playRandom,
                            # "RunPlugin(%s?action=random&rtype=season&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s)"  # czy tu nie ma błędu ?
                            "RunPlugin(%s?action=random&rtype=show&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s)"  # a może to jest źle ?
                            % (
                                sysaddon,
                                systitle,
                                year,
                                imdb,
                                tvdb,
                            ),
                        )
                    )

                if generate_short_path:
                    cm.append(("[I]przygotuj do ulubionych[/I]", "Container.Update(%s?action=prepareItemForAddToLibrary)" % (sysaddon),))

                if isOld is True:
                    cm.append((control.lang2(19033), "Action(Info)"))

                if add_rating_for_tmdb:
                    # if progress >= 50:  # jeśli połowa
                    if watched > 1:  # co najmniej 1 odcinek obejrzany
                    # if True:
                        if not tmdbCredentials:
                            cm.append(("Oceń serial", "RunPlugin(%s?action=add_rating&content=tv&tmdb=%s)" % (sysaddon, tmdb),))


                item.addContextMenuItems(cm)


                art = {}

                poster = i['poster'] if has("poster") else addonPoster
                # poster = i['poster'] if has("poster") else ""

                art.update({
                    "icon": poster,
                    "thumb": poster,
                    "poster": poster,
                    # poniższych chyba nie trzeba (to się raczej wykorzystuje na kolejnych poziomach: sezonach i odcinkach)
                    # "tvshow.poster": poster,
                    # "season.poster": poster,
                    })

                fanart = art["fanart"] = i["fanart"] if settingFanart == 'true' and has("fanart") else addonFanart

                landscape = art["landscape"] = i["landscape"] if has("landscape") else fanart

                banner = art["banner"] = i["banner"] if has("banner") else addonBanner

                for key in ("clearlogo", "clearart", "keyart"):
                    if has(key):
                        art[key] = i[key]
                        #art[f"{key}"] = i[key]
                        #art[f"tvshow.{key}"] = i[key]

                if has("characterart"):
                    characterart = i["characterart"]
                    if isinstance(characterart, list):
                        for an in range(0, len(characterart)):
                            if an == 0:
                                art["characterart"] = characterart[an]
                            else:
                                art[f"characterart{an+1}"] = characterart[an]
                    else:
                        art["characterart"] = characterart


                # fflog(f'{label=}  {art=}',1,1)
                item.setArt(art)

                # control.sleep(1000)
                # item.setArt({"dupa":"test"})

                item.setProperty("Fanart_Image", fanart)


                castwiththumb = i.get('castwiththumb')
                if castwiththumb:
                    item.setCast(castwiththumb)


                seasons_meta = {
                    'poster': poster,
                    'fanart': fanart,
                    'banner': banner,
                    'clearlogo': i.get('clearlogo') or '0',
                    'clearart': i.get('clearart') or '0',
                    'keyart': i.get('keyart') or '0',
                    'characterart': i.get('characterart') or '0',
                    'landscape': landscape,
                    'seasons_posters': i.get('seasons_posters') or {},
                    'seasons_banners': i.get('seasons_banners') or {},
                    'seasons_landscapes': i.get('seasons_landscapes') or {},
                    'seasons_fanarts': i.get('seasons_fanarts') or {},
                    'country': i.get('country') or '0',
                    'original_language': i.get('original_language') or '0',
                    'original_translation_lang': i.get('original_translation_lang') or '0',
                }
                # fflog(f'seasons_meta={json.dumps(seasons_meta, indent=2)}',1,1)

                episodes_meta = {
                    **seasons_meta,
                    'duration': i.get('duration', '0'),
                    'status': i.get('status', '0')
                }

                sysmeta = quote_plus(json.dumps(seasons_meta))
                epmeta = quote_plus(json.dumps(episodes_meta))


                fullpath = ""
                if flatten is True:
                    url = "%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&meta=%s" % (sysaddon, systitle, year, imdb, tmdb, tvdb, epmeta)
                    if generate_short_path:
                        fullpath = url
                        url = "{}?action=episodes&item={}".format(sysaddon, counter)
                        item.setProperty("meta", json.dumps(episodes_meta))
                else:
                    url = "%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&meta=%s" % (sysaddon, systitle, year, imdb, tmdb, tvdb, sysmeta)
                    if generate_short_path:
                        fullpath = url
                        url = "{}?action=seasons&item={}".format(sysaddon, counter)
                        item.setProperty("meta", json.dumps(seasons_meta))


                item.setInfo(type="video", infoLabels=control.metadataClean(meta))
                # fflog(f'metadataClean={json.dumps(control.metadataClean(meta), indent=2)}',1,1)


                # korekta pod standard ListItem (bo super_info.py inaczej generuje)
                # vtag.setOriginalTitle(meta.get("originalname") or meta.get("originaltitle", ""))  # nie wiem czy dopiero od Kodi 20
                item.setInfo(type="Video", infoLabels={'OriginalTitle': meta.get("originalname") or meta.get("originaltitle", "")})
                item.setProperty("EnglishTitle", meta.get("englishtitle") or meta.get("originaltitle", ""))

                if generate_short_path:
                    try:
                        vtag = item.getVideoInfoTag()
                        vtag.setUniqueIDs({'imdb': imdb, 'tmdb' : tmdb, 'tvdb' : tvdb})
                    except Exception:
                        item.setProperty("imdb_id", imdb)
                        item.setProperty("tmdb_id", tmdb)
                        item.setProperty("tvdb_id", tvdb)


                if fullpath:
                    item.setProperty("fullpath", fullpath)


                # item.addStreamInfo("video", {"codec": "h264"})  # czy to konieczne?


                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)  # dodanie całej pozycji do listy katalogu Kodi

                counter += 1

            except Exception as exc:
                fflog_exc(1)
                import traceback
                # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}', file=sys.stderr)  # stderr is logged as ERROR
                print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}')  # default (stdout) is logged as DEBUG
                pass

        if not directory:
            return


        try:
            # curr_page = int(items[0].get("curr_page"))
            pass
        except Exception:
            pass
            # fflog_exc(1)

        if params.get("url"):
            url = dict(urllib.parse_qsl(params.get("url")))
            curr_page = int(url.get("page") or 0)  # to coś źle działa na ostatniej stronie
            # fflog(f'{curr_page=}',1,1)
        else:
            # curr_page = items[0].get("curr_page") if items else 0  # to chyba sprawdzało się
            # fflog(f'{curr_page=}',1,1)
            curr_page = int(params.get("page") or 0)
            # fflog(f'{curr_page=}',1,1)
        # fflog(f'{curr_page=} \n{params=} \n{url=}')

        # następna strona
        try:
            url = items[0]["next"]
            if url:
                url = re.sub("(?<=api_key=)[^&]*", "", url)
                url = re.sub("(?<=session_id=)[^&]*", "", url)

                icon = control.addonNext()
                addonLandscape = control.addonLandscape()

                label = nextMenu

                total_pages = items[0].get("total_pages")
                total_pages = 500 if total_pages > 500 else total_pages  # jakieś ograniczenie ze strony tmdb
                curr_page = items[0].get("curr_page")
                # fflog(f'{curr_page=} {total_pages=}',1,1)

                if curr_page + 1 <= total_pages:

                    if (curr_page + 1 == total_pages
                        and total_pages > 2
                    ):
                        label = label.replace("Następna", "Ostatnia")
                        pass

                    if total_pages and curr_page:
                        label += f"[I][LIGHT] ({curr_page + 1} z {total_pages}) [/LIGHT][/I]"

                    item = control.item(label=label)  # create ListItem

                    item.setArt({"icon": icon, "thumb": icon, "poster": icon, "banner": icon, "landscape": addonLandscape})
                    if addonFanart is not None:
                        item.setProperty("Fanart_Image", addonFanart)

                    if generate_short_path:
                        page = dict(urllib.parse_qsl(url)).get("page", "")
                        item.setProperty("url", re.sub(f"((?<=[?/])|&)page[=/]{page}", "", url).replace("?&", "?").rstrip("?&"))  # uniwersalniejsze
                        url = "{}?action=tvshowPage&page={}".format(sysaddon, page)
                    else:
                        url = "%s?action=tvshowPage&url=%s" % (sysaddon, quote_plus(url))

                    refresh = params.get("refresh")
                    if refresh:
                        url += "&refresh="+refresh

                    # może pomóc dla zachowania kategorii na kolejnych stronach
                    if params.get("item") and "item=" not in url:
                        url += "&item=" + urllib.quote_plus(params.get("item"))

                    # pomaga odświeżać kolejne podstrony
                    if params.get("refresh") and "refresh=" not in url:
                        url += "&refresh=" + urllib.quote_plus(params.get("refresh"))

                    cm = []
                    # cm.append(("A Wybierz stronę", "Container.Update(%s&total_pages=%s&curr_page=%s)" % (url, total_pages, curr_page,),))
                    cm.append(("Wybierz stronę", "RunPlugin(%s&total_pages=%s&curr_page=%s)" % (url, total_pages, curr_page,),))
                    item.addContextMenuItems(cm)

                    control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
        except Exception as exc:
            fflog_exc(1)
            import traceback
            # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}', file=sys.stderr)  # stderr is logged as ERROR
            print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}')  # default (stdout) is logged as DEBUG
            pass

        control.content(syshandle, "tvshows")

        cat_label = ""
        if category:
            if isinstance(category, list):
                category = " / ".join(category).strip(" /")
            cat_label += category
        if curr_page and curr_page > 1:
            if cat_label:
                cat_label += " [LIGHT]/[/LIGHT] "
            cat_label += f'[LIGHT]str. {curr_page}[/LIGHT]'
        if cat_label:
            control.pluginCategory(syshandle, cat_label)

        updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie
        control.directory(syshandle, cacheToDisc=cacheToDisc, updateListing=updateListing)

        views.setView("tvshows")  # dodatkowa funkcja FanVodPL



    def addDirectory(self, items, queue=False, cacheToDisc=True, add_refresh=False, category=""):
        fflog(f'[addDirectory]')

        if items is None or len(items) == 0:
            sys.exit()

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])

        addonFanart, addonThumb, artPath = (
            control.addonFanart(),
            control.addonThumb(),
            control.artPath(),
        )

        queueMenu = control.lang(32065)
        playRandom = control.lang(32535)
        addToLibrary = control.lang(32551)
        generate_short_path = control.setting("generate_short_path") == "true"

        for i in items:
            # fflog(f'(i) item={json.dumps(i, indent=2)}',1,1)
            try:
                name = i["name"]

                if i["image"].startswith("http"):
                    thumb = i["image"]
                elif artPath is not None:
                    thumb = os.path.join(artPath, i["image"])
                else:
                    thumb = addonThumb

                i["url"] = re.sub("(?<=api_key=)[^&]*", "", i["url"])
                i["url"] = re.sub("(?<=session_id=)[^&]*", "", i["url"])

                cm = []  # preparing to buld context menu
                cm.append(
                    (
                        playRandom,
                        "RunPlugin(%s?action=random&rtype=show&url=%s)"
                        % (sysaddon, quote_plus(i["url"])),
                    )
                )
                if queue is True:
                    cm.append((queueMenu, "RunPlugin(%s?action=queueItem)" % sysaddon))
                try:
                    cm.append(
                        (
                            addToLibrary,
                            "RunPlugin(%s?action=tvshowsToLibrary&url=%s)"
                            % (sysaddon, quote_plus(i["context"])),
                        )
                    )
                except:
                    pass


                item = control.item(label=name)  # create ListItem

                item.setArt({"icon": thumb, "thumb": thumb, "poster": thumb,})
                if addonFanart is not None:
                    item.setProperty("Fanart_Image", addonFanart)

                if f"https://api.themoviedb.org/3/list/{(list_id:=i.get('id'))}?" in i["url"]:
                    cm.append(( "Usuń listę", "RunPlugin(%s?action=DeleteList&id=%s&name=%s)" % (sysaddon, list_id, urllib.quote_plus(i["name"]),) ))


                url = "%s?action=%s" % (sysaddon, i["action"])  # akcja, czyli co ma się wykonać po naciśnięciu ENTER na danej pozycji
                action = dict(urllib.parse_qsl("action="+i["action"]))
                try:
                    #if not generate_short_path or i["action"] not in ["tvshows", "tvshowPage"]:  # zabezpieczenie, jakbym nie wszystko sprawdził
                    # if not generate_short_path or action["action"] not in ["tvshows", "tvshowPage"] or not "item" in action:  # zabezpieczenie, jakbym nie wszystko sprawdził
                    if not generate_short_path or action["action"] not in ["tvshows", "tvshowPage"]:
                        url += "&url=%s" % quote_plus(i["url"])
                        # url = re.sub(r"\bitem=[^&]*", "", url)  # przeszkadza dla category
                    else:
                        item.setProperty("url", i["url"])
                        item.setProperty("urlD", i["url"])
                except Exception:
                    #fflog_exc(1)
                    pass


                if add_refresh:
                    cm.append(("Odśwież teraz", "Container.Update(%s&refresh=1)" % url))  # url potrzebny


                item.addContextMenuItems(cm)


                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
            except Exception as exc:
                fflog_exc(1)
                import traceback
                # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}', file=sys.stderr)  # stderr is logged as ERROR
                print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}')  # default (stdout) is logged as DEBUG
                pass


        try:
            # curr_page = int(items[0].get("next").get("curr_page"))
            pass
        except Exception:
            pass
            # fflog_exc(1)

        if params.get("url"):
            url = dict(urllib.parse_qsl(params.get("url")))
            curr_page = int(url.get("page") or 0)
            # fflog(f'{curr_page=}',1,1)
        else:
            # curr_page = items[0].get("curr_page") if items else 0
            # fflog(f'{curr_page=}',1,1)
            curr_page = int(params.get("page") or 0)
            # fflog(f'{curr_page=}',1,1)
        # fflog(f'{curr_page=} \n{params=} \n{url=}')

        # następna strona
        try:
            i = items[0]
            url = i.get("next")
            if url:
                # fflog(f'next {url=}',1,1)
                if isinstance(url, dict):
                    action = url.get("action")
                    url = url.get("url")
                else:
                    action = ""  # ? coś musi być
                    fflog(f'{action=}',1,1)

                url = re.sub("(?<=api_key=)[^&]*", "", url)
                url = re.sub("(?<=session_id=)[^&]*", "", url)

                nextMenu = control.lang(32053)
                nextMenu = nextMenu + "  >>"
                icon = control.addonNext()
                addonFanart = control.addonFanart()
                addonLandscape = control.addonLandscape()

                label = nextMenu

                total_pages = i.get("next").get("total_pages")
                total_pages = 500 if total_pages > 500 else total_pages  # jakieś ograniczenie ze strony tmdb
                curr_page = i.get("next").get("curr_page")
                # fflog(f'{curr_page=} {total_pages=}',1,1)

                if curr_page + 1 <= total_pages:

                    if (curr_page + 1 == total_pages
                        and total_pages > 2
                    ):
                        label = label.replace("Następna", "Ostatnia")
                        pass

                    if total_pages and curr_page:
                        label += f"[I][LIGHT] ({curr_page + 1} z {total_pages}) [/LIGHT][/I]"

                    item = control.item(label=label)  # create ListItem

                    item.setArt({
                                "icon": icon, 
                                "thumb": icon, 
                                "poster": icon,
                                "banner": icon,
                                "fanart": addonFanart, 
                                "landscape": addonLandscape,
                                })

                    if not generate_short_path:  # or not "item" in action:
                        url = "{}?action={}&url={}".format(sysaddon, action, urllib.quote_plus(url))
                        # url = re.sub(r"\bitem=[^&]*", "", url)
                    else:
                        page = dict(urllib.parse_qsl(url)).get("page", "")
                        # fflog(f'next {page=}',1,1)
                        item.setProperty("urlDNext", url)
                        url = "{}?action={}&page={}".format(sysaddon, action, page)
                    # fflog(f'next {url=}',1,1)

                    # pomaga odświeżać kolejne podstrony (choć nie wiem, czy tu akurat jest to wykorzystywane)
                    if params.get("refresh") and "refresh=" not in url:
                        url += "&refresh=" + urllib.quote_plus(params.get("refresh"))

                    # item.setInfo(type="Video", infoLabels={'count': counter})  # do sortowania potrzebne - tylko, że to nie jest element wideo, a inaczej nie można wstawić countera - głupie to

                    cm = []
                    cm.append(("Wybierz stronę", "RunPlugin(%s&total_pages=%s&curr_page=%s)" % (url, total_pages, curr_page,),))
                    # fflog(f'{action=}',1,1)
                    item.addContextMenuItems(cm)

                    control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
        except Exception as exc:
            fflog_exc(1)
            # import traceback
            # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}', file=sys.stderr)  # stderr is logged as ERROR
            # print(f'EXCEPTION: {exc!r}\n{traceback.format_exc()}')  # default (stdout) is logged as DEBUG
            pass

        cat_label = ""
        if category:
            if isinstance(category, list):
                category = " / ".join(category).strip(" /")
            cat_label += category
        if curr_page and curr_page > 1:
            if cat_label:
                cat_label += " [LIGHT]/[/LIGHT] "
            cat_label += f'[LIGHT]str. {curr_page}[/LIGHT]'
            # cat_label = cat_label.strip(" /")
        if cat_label:
            control.pluginCategory(syshandle, cat_label)

        # control.content(syshandle, "addons")
        updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie
        control.directory(syshandle, cacheToDisc=cacheToDisc, updateListing=updateListing)
        views.setView("addons")  # dodatkowa funkcja FanVodPL