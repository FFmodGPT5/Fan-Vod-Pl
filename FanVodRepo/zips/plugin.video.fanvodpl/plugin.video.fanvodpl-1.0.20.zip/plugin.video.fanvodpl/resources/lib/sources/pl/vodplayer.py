# -*- coding: utf-8 -*-
"""
FanFilm ‑ źródło: vod.pl
Copyright (C) 2025 :)

Dystrybuowane na licencji GPL‑3.0.
"""
# from lib.ff.item import FFItem

import json
import random
import re
import requests
from urllib.parse import urlencode, parse_qs
from ptw.libraries import cleantitle
from ptw.debug import fflog_exc, fflog


class source:
    # ffitem: FFItem  # ↓ przypisany dynamicznie przez FanFilm

    def __init__(self):
        self.priority = 1
        self.language = ['pl']
        self.base_url = 'https://player.pl/'
        self.api_url = 'https://player.pl/playerapi/'
        self.platform = 'ANDROID_TV'
        self.UA = 'playerTV/2.2.2 (455) (Linux; Android 8.0.0; Build/sdk_google_atv_x86) net/sdk_google_atv_x86userdebug 8.0.0 OSR1.180418.025 6695156 testkeys'
        self.device_uid = self._code_gen(16)
        self.uid = self._code_gen(32)

    def _code_gen(self, length):
        base = '0123456789abcdef'
        return ''.join(random.choice(base) for _ in range(length))

    def _headers(self):
        correlation_id = f"androidTV_{self._code_gen(8)}-{self._code_gen(4)}-{self._code_gen(4)}-{self._code_gen(4)}-{self._code_gen(12)}"
        return {
            'User-Agent': self.UA,
            'accept-encoding': 'gzip',
            'api-correlationid': correlation_id,
            'api-deviceuid': self.device_uid,
            'api-deviceinfo': 'sdk_google_atv_x86;unknown;Android;8.0.0;Unknown;2.2.2 (455);',
        }

    def _cookies(self):
        return {'uid': self.uid}

    def _is_available(self, item):
        if item.get('payable', False):
            return False
        try:
            schedules = [s for s in item.get('displaySchedules', []) if s.get('active')]
            if schedules and schedules[0].get('type') == 'SOON':
                return False
        except:
            pass
        return True

    def _get_quality(self, item):
        if item.get('uhd'):
            return '4K'
        quality = 'SD'
        for typ in ['android_tv','pc','smart_tv','playstation','mobile','apple_tv']:
            imgs = item.get('images', {}).get(typ, [])
            if imgs and 'mainUrl' in imgs[0]:
                match = re.search(r'dstw=(\d+)&dsth=(\d+)', imgs[0]['mainUrl'])
                if match:
                    h = int(match.group(2))
                    if h >= 1080: quality='1080p'
                    elif h >= 720: quality='720p'
                    elif h >= 480: quality='480p'
                    elif h >= 360: quality='360p'
                    if quality != 'SD': break
        return quality

    def _get_image(self, images):
        try:
            img = images['pc'][0]['mainUrl']
            if img.startswith('//'): img = 'https:' + img
            return img
        except:
            return ''

    def movie(self, imdb, title, localtitle, aliases, year):
        # fflog(f'szukanie żródeł filmu {title=} {localtitle=} {year=} {aliases=}', 1)
        return self.search(title, localtitle, year, aliases=aliases)

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # fflog(f'szukanie serialu {tvshowtitle=} {localtvshowtitle=} {year=} {aliases=}', 1)
        return (tvshowtitle, localtvshowtitle, aliases), year

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, episode_title=None):
        # fflog(f'{url=} \n{imdb=} {tvdb=} {title=} {premiered=} {season=} {episode=} {episode_title=}',1,1)
        
        titles = self._extract_titles(url, title)
        if not titles:
            # fflog("vodpl: no titles to search")
            return []

        series_id = self._find_series(titles)
        if not series_id:
            # fflog("vodpl: no matching series found")
            return []

        # Przekazujemy tytuł odcinka jeśli jest znany (czy ma być polski czy oryginalny?)
        # episode_title = self.ffitem.title  # nowy FF
        # episode_title = kwargs.get("episode_title") if not episode_title else episode_title
        episode_title = title  # tak jest w starym FF

        return self._get_episodes(series_id, int(season), int(episode), episode_title=episode_title)

    def _extract_titles(self, url, default_title):
        titles = []
        try:
            if isinstance(url, tuple) and len(url)==2 and isinstance(url[0], tuple):
                t0,t1,aliases = (url[0]+(None,)*3)[:3]
                for t in [t0,t1]:
                    if t and t not in titles: titles.append(t)
                if aliases:
                    for a in aliases:
                        if isinstance(a, dict) and 'title' in a and a['title'] not in titles:
                            titles.append(a['title'])
            elif isinstance(url, str):
                params = parse_qs(url)
                for k in ('titles','tvshowtitle','localtvshowtitle'):
                    val = params.get(k, [None])[0]
                    if val and val not in titles: titles.append(val)
            elif isinstance(url, dict) and 'titles' in url:
                for t in url['titles']:
                    if t and t not in titles: titles.append(t)
            if not titles and default_title: titles.append(default_title)
        except Exception as e:
            fflog_exc()
            # fflog(f"vodpl: error extracting titles: {e}")

        # Deduplikacja z logiem
        unique_titles = list({t.lower(): t for t in titles}.values())
        # fflog(f"vodpl: extracted and deduplicated titles: {unique_titles}")
        return unique_titles

    def _find_series(self, titles, year=None):
        # fflog(f"vodpl: _find_series called with titles: {titles}")
        cleaned_titles = [cleantitle.get(t) for t in titles]
        for t in titles:
            # fflog(f"vodpl: searching series for title '{t}'")
            try:
                resp = requests.get(
                    self.api_url+'item/search',
                    headers=self._headers(),
                    cookies=self._cookies(),
                    params={'4K':'true','platform':self.platform,'keyword':t,'episodes':'false'}
                )
                # fflog(f"vodpl: search response status {resp.status_code} for '{t}'")
                if resp.status_code != 200: continue

                for item in resp.json():
                    el = item.get('element')
                    if not el: continue
                    if el.get('type') != 'SERIAL' or not self._is_available(el):
                        continue

                    match_title = el.get('title')
                    match_year = el.get('year')
                    # fflog(f"vodpl: candidate series: '{match_title}' ({match_year}), id {el.get('id')}")

                    clean_match_title = cleantitle.get(match_title)

                    if clean_match_title in cleaned_titles:
                        # Year check
                        if year and match_year:
                            try:
                                if abs(int(year)-int(match_year)) > 1:
                                    # fflog(f"vodpl: skipping due to year mismatch ({year} vs {match_year})")
                                    continue
                            except:
                                pass

                        # fflog(f"vodpl: matched series ID {el.get('id')} for title '{match_title}'")
                        return el.get('id')

            except Exception as e:
                fflog_exc()
                # fflog(f"vodpl: exception during series search for '{t}': {e}")
        # fflog("vodpl: no series matched from titles")
        return None

    def _get_episodes(self, series_id, season, episode, episode_title=None):
        # fflog(f"vodpl: _get_episodes called for series {series_id}, season {season}, episode {episode}, episode_title={episode_title!r}")
        try:
            results = []
            resp = requests.get(
                f"{self.api_url}product/vod/serial/{series_id}/season/list",
                headers=self._headers(),
                cookies=self._cookies(),
                params={'4K':'true','platform':self.platform}
            )
            if resp.status_code != 200:
                # fflog(f"vodpl: failed to fetch season list, status {resp.status_code}")
                return []

            seasons = resp.json()
            # fflog(f"vodpl: found seasons: {[s.get('number') for s in seasons]}")

            target = next((s for s in seasons if s.get('number')==season), None)
            if not target:
                # fflog(f"vodpl: season {season} not found")
                return []

            season_id = target.get('id')
            resp = requests.get(
                f"{self.api_url}product/vod/serial/{series_id}/season/{season_id}/episode/list",
                headers=self._headers(),
                cookies=self._cookies(),
                params={'4K':'true','platform':self.platform}
            )
            if resp.status_code != 200:
                # fflog(f"vodpl: failed to fetch episodes list, status {resp.status_code}")
                return []

            episodes = resp.json()
            # fflog(f"episodes={json.dumps(episodes, indent=2)}")
            # to coś źle pokazuje
            # temp = [f'{ep.get("episode")}->{ep.get("title")}' for ep in episodes]
            # fflog(f'vodpl: episodes in season {season}: {temp}')

            if episode_title:
                # próbujemy dopasować po tytule
                results = [ep for ep in episodes if ep.get('title', '').lower() == episode_title.lower() and self._is_available(ep)]
                # fflog(f"vodpl: matched episodes by title: {[ep.get('title') for ep in results]}")
            # jeśli nie znaleziono (lub tytuły puste), fallback po numerze
            if not results:
                results = [ep for ep in episodes if ep.get('episode')==episode and self._is_available(ep)]
                # fflog(f"vodpl: matched episodes by number: {[ep.get('title') for ep in results]}")

            return results
        except Exception as e:
            fflog_exc(1)
            # fflog(f"vodpl: exception fetching episodes: {e}")
            return []

    def search(self, title, localtitle, year="", episode="", premiered="", aliases=None):
        # fflog(f"vodpl: search called with title='{title}', localtitle='{localtitle}'")

        search_titles = []
        if localtitle:
            search_titles.append(localtitle)
        if title and title not in search_titles:
            search_titles.append(title)

        if aliases:
            for a in aliases:
                if 'title' in a and a['title'] not in search_titles:
                    search_titles.append(a['title'])

        # fflog(f"vodpl: searching for titles: {search_titles}")

        cleaned_titles = [cleantitle.get(t) for t in search_titles]
        results=[]

        for q in search_titles:
            # fflog(f"vodpl: performing search for '{q}'")
            try:
                resp = requests.get(self.api_url+'item/search', headers=self._headers(), cookies=self._cookies(),
                                    params={'4K':'true','platform':self.platform,'keyword':q,'episodes':'true'})
                if resp.status_code != 200:
                    # fflog(f"vodpl: search for '{q}' failed with status {resp.status_code}")
                    continue

                for item in resp.json():
                    el = item.get('element')
                    if not el or episode or el.get('type') != 'VOD' or not self._is_available(el):
                        continue

                    match_title = el.get('title')
                    if not match_title: continue

                    clean_match_title = cleantitle.get(match_title)

                    if clean_match_title in cleaned_titles:
                        if year:
                            y = el.get('year')
                            if y:
                                try:
                                    if abs(int(year)-int(y)) > 1: continue
                                except:
                                    pass # ignore year parsing errors

                        if el not in results:
                            # fflog(f"vodpl: found matching movie: '{match_title}'")
                            results.append(el)

            except Exception:
                fflog_exc()

        fflog(f"vodpl: search finished, found {len(results)} results.")
        return results

    def sources(self, rows, hostDict=None, hostprDict=None):
        # fflog(f"vodpl: sources called with {len(rows) if rows else 0} items")
        if not rows: return []
        sources=[]
        for el in rows:
            try:
                item_type = el.get('type','VOD')
                info=''
                if item_type=='EPISODE':
                    season = el.get('season',{}).get('number',0)
                    episode = el.get('episode',0)
                    serial_title = el.get('season',{}).get('serial',{}).get('title','')
                    title = el.get('title','')
                    if title: info += f" - {title}"
                else:
                    serial_title=''
                sources.append({
                    'source': '',
                    'quality': self._get_quality(el),
                    'language': 'pl',
                    'url': f"DRMCDA|{el.get('id')}|{item_type}",
                    'info': info,
                    'info2': serial_title if item_type=='EPISODE' else '',
                    'direct': False,
                    'direct': True,
                    'debridonly': False,
                    'image': self._get_image(el.get('images',{}))
                })
            except Exception:
                fflog_exc()
        return sources

    def resolve(self, url):
        # fflog(f"vodpl: resolving url: {url}")
        if not url.startswith('DRMCDA|'): return url
        try:
            _, item_id, item_type = url.split('|')

            item_data = requests.get(f"{self.api_url}product/vod/{item_id}",
                                     headers=self._headers(), cookies=self._cookies(),
                                     params={'4K':'true','platform':self.platform}).json()
            # fflog(f"item_data={json.dumps(item_data, indent=2)}")

            tid = item_data['shareUrl'].replace(self.base_url,'').replace(',','_').replace('-','_').replace('/','_')
            playlist_data = requests.get(f"{self.api_url}item/{item_id}/playlist",
                                         headers=self._headers(), cookies=self._cookies(),
                                         params={'type':'MOVIE','page':tid,'4K':'true','platform':self.platform,'version':'3.1'}).json()
            # fflog(f"playlist_data={json.dumps(playlist_data, indent=2)}")

            if 'code' in playlist_data: return None

            video = playlist_data.get('movie',{}).get('video',{})
            # fflog(f"video={json.dumps(video, indent=2)}")

            if 'sources' in video and 'dash' in video['sources']:
                stream = video['sources']['dash']['url']
                if 'protections' in video and 'widevine' in video['protections']:
                    lic = video['protections']['widevine']['src']
                    hea = {'User-Agent':self.UA,'Referer':self.base_url,'Content-Type':''}
                    adaptive = {'protocol':'mpd',
                                'mimetype':'application/dash+xml',
                                'manifest':stream,
                                'licence_type':'com.widevine.alpha',
                                'licence_url':lic,
                                'licence_header':urlencode(hea),
                                'post_data':'R{SSM}',
                                'response_data':''}
                    fflog(f'wariant A')
                    return f"DRMCDA|{repr(adaptive)}"
                else:
                    fflog(f'wariant B')
                    return stream
            elif 'sources' in video and 'hls' in video['sources']:
                fflog(f'wariant C')
                return video['sources']['hls']['url']

        except Exception:
            fflog_exc(1)
        return None
