# -*- coding: utf-8 -*-
"""
FanFilm - źródło: adapter.pl
Copyright (C) 2025 :)

Dystrybuowane na licencji GPL-3.0.
"""

import json
import re
import requests
from urllib.parse import urlencode, quote_plus
from ptw.libraries import cleantitle
from ptw.debug import fflog_exc, fflog


class source:

    def __init__(self):
        self.priority = 1
        self.language = ['pl']
        self.base_url = 'https://adapter.pl/'
        self.search_url = '?s='
        self.UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0'
        self.session = requests.Session()

    def get_headers(self):
        return {
            'User-Agent': self.UA,
            'Referer': self.base_url,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
        }

    def clean_text(self, text):
        """Clean HTML entities and tags from text"""
        # Handle HTML entities like &#123;
        entities = re.findall(r'(&#[0-9]+?;)', text)
        for entity in entities:
            try:
                text = text.replace(entity, chr(int(entity[2:-1])))
            except Exception:
                pass

        # Remove HTML tags
        text = re.sub(r'<.*?>', '', text)
        return text.strip()

    def normalize_title_for_comparison(self, title):
        """Normalize title for comparison - handle different punctuation"""
        normalized = cleantitle.normalize(title).lower()
        # Replace different types of colons, dashes, and punctuation
        normalized = normalized.replace(':', ' ').replace('–', ' ').replace('—', ' ').replace('-', ' ')
        # Remove multiple spaces
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        return normalized

    def search_movies(self, query):
        """Search for movies on adapter.pl"""
        try:
            search_url = f'{self.base_url}{self.search_url}{quote_plus(query)}'
            # fflog(f"adapter_pl: Searching with URL: {search_url}")

            response = self.session.get(search_url, headers=self.get_headers())

            if response.status_code != 200:
                # fflog(f"adapter_pl: Search failed with status {response.status_code}")
                return []

            html = response.text

            if 'Brak wyników wyszukiwania' in html:
                # fflog("adapter_pl: No search results found")
                return []

            return self.parse_movie_list(html)

        except Exception:
            # fflog_exc()
            return []

    def parse_movie_list(self, html):
        """Parse movie list from HTML"""
        movies = []
        try:
            # Find movie grid section
            if '"movie-grid"' not in html:
                return movies

            grid_section = html.split('"movie-grid"')[1]
            if '"main-subcategory__recommended"' in grid_section:
                grid_section = grid_section.split('"main-subcategory__recommended"')[0]

            # Split by movie items
            movie_items = grid_section.split('"media-thumb-full"')

            for item in movie_items:
                if 'media-thumb-full__info' not in item:
                    continue

                try:
                    # Extract image and title
                    img_title_match = re.search(r'<img src="([^"]+?)" alt="([^"]+?)"', item)
                    if not img_title_match:
                        continue

                    img_url, title = img_title_match.groups()
                    title = self.clean_text(title)

                    # Extract link
                    link_match = re.search(r'href="([^"]+?)"', item)
                    if not link_match:
                        continue

                    link = link_match.group(1)

                    # Extract description
                    desc_match = re.search(r'"media-thumb-full__excerpt">([^<]+?)<', item)
                    description = desc_match.group(1) if desc_match else ''

                    movie_info = {
                        'title': title,
                        'link': link,
                        'image': img_url,
                        'description': description
                    }

                    movies.append(movie_info)
                    # fflog(f"adapter_pl: Found movie: {title}")

                except Exception:
                    # fflog_exc()
                    continue

            return movies

        except Exception:
            # fflog_exc()
            return []

    def get_video_url(self, movie_link):
        """Extract video URL from movie page"""
        try:
            # fflog(f"adapter_pl: Getting video URL from: {movie_link}")

            response = self.session.get(movie_link, headers=self.get_headers())

            if response.status_code != 200:
                # fflog(f"adapter_pl: Failed to get movie page, status: {response.status_code}")
                return None

            # Check if login is required
            if 'logowanie' in response.url:
                # fflog("adapter_pl: Login required for this content")
                return None

            html = response.text

            # Try to find video ID
            video_id_match = re.search(r'id-video="([^"]+?)"', html)
            if video_id_match:
                video_id = video_id_match.group(1)
                stream_url = f'https://media.adapter.pl/{video_id}/hls/playlist.m3u8'
                # fflog(f"adapter_pl: Found video ID: {video_id}")
                return stream_url

            # Try to find direct video URL
            video_url_match = re.search(r'data-video-url="([^"]+?)"', html)
            if video_url_match:
                stream_url = video_url_match.group(1)
                # fflog(f"adapter_pl: Found direct video URL")
                return stream_url

            # fflog("adapter_pl: No video URL found")
            return None

        except Exception:
            # fflog_exc()
            return None

    def movie(self, imdb, title, localtitle, aliases, year):
        # fflog(f"adapter_pl: Searching for movie '{localtitle}' ({year})")
        # Sprawdzenie czy Polska jest na liście krajów
        from ptw.libraries import control
        country = control.infoLabel('ListItem.country')
        # fflog(f'{country=}')
        if not country:
            meta = control.window.getProperty("plugin.video.fanvodpl.container.meta")
            try:
                meta = json.loads(meta)
            except Exception:
                pass
                # fflog_exc()
                meta = {}
            # fflog(f"meta={json.dumps(meta, indent=2)}")
            country = meta.get("country")
            # fflog(f'{country=}')
        if country and country.lower() not in ["poland", "polska", "pl"]:
            fflog(f"adapterpl: to nie jest polski film, bo {country=}, pomijam")
            return []
        try:
            # Search for the movie
            search_results = self.search_movies(localtitle)

            if not search_results:
                fflog("adapter_pl: No search results found")
                return []

            sources = []
            normalized_search_title = self.normalize_title_for_comparison(localtitle)
            # fflog(f"adapter_pl: Normalized search title: '{normalized_search_title}'")

            for movie in search_results:
                movie_title = movie.get('title', '')
                movie_link = movie.get('link', '')

                if not movie_title or not movie_link:
                    continue

                normalized_movie_title = self.normalize_title_for_comparison(movie_title)
                # fflog(f"adapter_pl: Comparing '{normalized_search_title}' with '{normalized_movie_title}'")

                # --- Matching logic ---
                is_valid_match = False
                title_lower = movie_title.lower()

                # Case 1: Exact match after normalization
                if normalized_search_title == normalized_movie_title:
                    is_valid_match = True
                    # fflog(f"adapter_pl: Exact title match: {movie_title}")

                # Case 2: Check if movie title starts with search title (for suffixes)
                elif normalized_movie_title.startswith(normalized_search_title):
                    remaining_part = normalized_movie_title[len(normalized_search_title):].strip()

                    # Allow empty remaining part or specific allowed suffixes
                    if (not remaining_part or
                        remaining_part.lower() in ("pjm", "z nowa audiodeskrypcja", "z nową audiodeskrypcją")):
                        is_valid_match = True
                        # fflog(f"adapter_pl: Allowed suffix match: {movie_title}")
                    # else:
                        # fflog(f"adapter_pl: Rejecting match due to extra words: '{remaining_part}' in {movie_title}")

                # Case 3: Also check if search title starts with movie title (reverse)
                elif normalized_search_title.startswith(normalized_movie_title):
                    remaining_part = normalized_search_title[len(normalized_movie_title):].strip()

                    # Allow if remaining part is small or empty
                    if not remaining_part or len(remaining_part) <= 3:
                        is_valid_match = True
                        # fflog(f"adapter_pl: Reverse match: {movie_title}")

                if is_valid_match:
                    # fflog(f"adapter_pl: Found potential match: {movie_title}")

                    # Try to get video URL to verify it's playable
                    video_url = self.get_video_url(movie_link)

                    if video_url:
                        # Determine protocol and quality
                        protocol = 'hls'
                        quality = 'HD'  # adapter.pl usually provides good quality

                        if '.m3u8' in video_url or '.m3u' in video_url:
                            protocol = 'hls'
                        elif '.mpd' in video_url:
                            protocol = 'mpd'

                        # --- Build info field ---
                        info = []

                        if "pjm" in title_lower:  # co to "pjm" ?
                            info = "PJM"
                        elif "nową audiodeskrypcją" in title_lower:
                            info = "NOWA AUDIODESKRYPCJA"
                        else:
                            info = "AUDIODESKRYPCJA"

                        source_info = {
                            'source': '',
                            'quality': quality,
                            'language': 'pl',
                            'url': f"DRMCDA|{movie_link}|{protocol}",
                            'info': info,
                            'info2': '',  # Not used
                            'direct': False,
                            'direct': True,
                            'debridonly': False,
                        }

                        sources.append(source_info)
                        # fflog(f"adapter_pl: Added source for: {movie_title}")

            return sources

        except Exception:
            # fflog_exc()
            return []

    def sources(self, url, hostDict, hostprDict):
        # fflog(f'{url=}')
        fflog(f'Przekazano źródeł: {len(url)}')
        return url

    def resolve(self, url):
        """Resolve video URL"""
        # fflog(f"adapter_pl: Resolving URL: {url}")

        if not url.startswith('DRMCDA|'):
            return url

        try:
            parts = url.split('|')
            if len(parts) != 3:
                # fflog(f"adapter_pl: Invalid URL format: {url}")
                return None

            _, movie_link, expected_protocol = parts

            # Get the actual video URL
            video_url = self.get_video_url(movie_link)

            if not video_url:
                # fflog("adapter_pl: Could not extract video URL")
                return None

            # Prepare headers for streaming
            stream_headers = self.get_headers()
            stream_headers.update({
                'Origin': self.base_url.rstrip('/'),
                'Accept': '*/*',
                'Connection': 'keep-alive'
            })

            # Determine actual protocol
            if '.m3u8' in video_url or '.m3u' in video_url:
                protocol = 'hls'
                mimetype = 'application/x-mpegURL'
            elif '.mpd' in video_url:
                protocol = 'mpd'
                mimetype = 'application/dash+xml'
            else:
                # fflog(f"adapter_pl: Unknown protocol for URL: {video_url}")
                return None

            # Create adaptive data structure
            adaptive_data = {
                'protocol': protocol,
                'mimetype': mimetype,
                'manifest': video_url,
                # Empty DRM fields (required by FanFilm)  # bo tak funkcja Lantash'a jest napisana
                'licence_type': '',
                'licence_url': '',
                'licence_header': '',
                'post_data': '',
                'response_data': '',
                # VOD properties for seeking support
                'content_lookup': False,
                'is_playable': True,
                'stream_headers': urlencode(stream_headers),
                'manifest_headers': urlencode(stream_headers)
            }

            return video_url  # stream bez wymaganych zabezpieczeń (może być odtwarzany także przez standardowy odtwarzacz Kodi, choć wtedy mogą być problemy z przewijaniem)
            # fflog(f"adapter_pl: Returning adaptive stream: {video_url}")
            return f"DRMCDA|{repr(adaptive_data)}"  # to wymusza użycie ISA

        except Exception:
            # fflog_exc()
            return None