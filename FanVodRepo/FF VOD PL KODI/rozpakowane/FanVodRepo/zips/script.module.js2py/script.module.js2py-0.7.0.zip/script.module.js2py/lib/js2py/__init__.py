# Stub js2py module to satisfy Kodi dependency
class EvalJs:
    def __init__(self, env=None):
        self.env = env or {}
    def execute(self, code):
        return None

def disable_pyimport():
    return None

def eval_js(code):
    return None
